//Esta es la funcion del Ajax, le puse Buscador por gusto, Hector: agregue funcion EventoFiltromultiple,Eliminardoblerepanel
function Buscador()
{
        var xmlhttp=false;
        try 
        {
               xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
        } 
        catch (e) 
        {
               try
               {
                  xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
               } 
               catch (E)
        	   {
                  xmlhttp = false;
               }
        }
 
        if (!xmlhttp && typeof XMLHttpRequest!='undefined') 
		{
               xmlhttp = new XMLHttpRequest();
			   xmlhttp.overrideMimeType('text/xml');
        }

        return xmlhttp;
}

function Filtrar()
{
	var filtro=document.getElementById('texto_filtro').value;
	var tabla=document.getElementById('resultados');
	var pag=document.getElementById('paginaFiltro').value;
	var ajax=Buscador();
	ajax.open('GET',pag+'?filtro='+filtro);
//	ajax.open('POST',pag);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			tabla.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}

function EventoFiltro()
{
	var filtro=document.getElementById('texto_filtro').value;
        var grupoevento=document.getElementById('grupoevento').value;
	var tabla=document.getElementById('resultados');
	var pag=document.getElementById('paginaFiltro').value;
	var ajax=Buscador();
	ajax.open('GET',pag+'?filtro='+filtro+'&grupoevento='+grupoevento);
//	ajax.open('POST',pag);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			tabla.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}

function EventoFiltromultiple(division,pagina)
{
	var filtro=document.getElementById('texto_filtro').value;
        var grupoevento=document.getElementById('grupoevento').value;
	var tabla=document.getElementById(division);
	var pag=document.getElementById(pagina).value;
	var ajax=Buscador();
	ajax.open('GET',pag+'?filtro='+filtro+'&grupoevento='+grupoevento);
//	ajax.open('POST',pag);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			tabla.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}

function Filtrar2(div,pagina,parametros)
{
	//Función para filtrar datos y desplegar en un DIV diferente al de 'resultados'
//	pag=document.getElementById('paginaFiltro').value;
	var panel = document.getElementById(div);
	var ajax=Buscador();
	ajax.open('GET',pagina+'?'+parametros);
//	ajax.open('POST',pag);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			panel.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}
function Filtrar3(parametros)
{
	var filtro=document.getElementById('texto_filtro').value;
	var tabla=document.getElementById('resultados');
	var pag=document.getElementById('paginaFiltro').value;
	var ajax=Buscador();
	ajax.open('GET',pag+'?filtro='+filtro+'&'+parametros);
//	ajax.open('POST',pag);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			tabla.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}
function Editar(idRegistro)
{
	//resultados tiene que ser un DIV (un "panel") para desplegar los resultados de la página a abrir
	var panel=document.getElementById('resultados');
	var pagina=document.getElementById('paginaEditar');
	var ajax=Buscador();
	ajax.open('GET',pagina+"?idRegistro="+idRegistro);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			panel.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}
/*
	Esta función simplemente abrira una pagina que tiene que estar escrito
	en un campo oculto <hidden value="guardar.php" (cualquier página)
	El método es post asi que en "guardar.php"
	tendran que recibir esos parametros que necesiten procesar.

*/
function AbrirPagina(idRegistro,pagina)
{
    var conte=document.createElement("DIV");
    conte.setAttribute("style","display:none;");
	var parametro=document.createElement("INPUT");
	parametro.setAttribute("type","hidden");
	parametro.name="idRegistro";
parametro.value=idRegistro;
    var boton=document.createElement("INPUT");
    boton.setAttribute("type","submit");
	var formulario=document.createElement("FORM");
	formulario.name="formAbrirPagina";
	formulario.method="post";
	formulario.action=pagina;
	formulario.appendChild(parametro);
    formulario.appendChild(boton);
    conte.appendChild(formulario);
    document.getElementById('cuadro').appendChild(conte);
    boton.click();
/*	<form id="form1" name="form1" method="post" action="">*/
	/*location.href=carpeta de la página que esta llamando a la función*/
/*	setTimeout("location.href = \""+pagina+"\"",3000);*/
}
function AbrirPagina2(idRegistro,idRegistro2,pagina)
{
	var conte=document.createElement("DIV");
    conte.setAttribute("style","display:none;");
	var boton=document.createElement("INPUT");
    boton.setAttribute("type","submit");
    var parametro=document.createElement("INPUT");
	parametro.setAttribute("type","hidden");
	parametro.name="idRegistro";
	parametro.value=idRegistro;
    var parametro2=document.createElement("INPUT");
    parametro2.setAttribute("type","hidden")
	parametro2.name="idRegistro2";
	parametro2.value=idRegistro2;
	var formulario=document.createElement("FORM");
	formulario.name="form1";
	formulario.method="post";
	formulario.action=pagina;
	formulario.appendChild(parametro);
	formulario.appendChild(parametro2);
	formulario.appendChild(boton);
	conte.appendChild(formulario);
	boton.click();
/*	<form id="form1" name="form1" method="post" action="">*/
	/*location.href=carpeta de la página que esta llamando a la función*/
/*	setTimeout("location.href = \""+pagina+"\"",3000);*/
}
function AbrirPaginaPostConParametros(pagina,param)
{
	//ejemplo parametros='\'nombreParametro=valor&Parametro2=valor2\'';
	var conte=document.createElement("DIV");
    conte.setAttribute("style","display:none;");
	var boton=document.createElement("INPUT");
    boton.setAttribute("type","submit");
	var formulario=document.createElement("FORM");
	formulario.name="pagForm";
	formulario.method="post";
	formulario.action=pagina;
	var parametros=param.toString();
    while(parametros!==""){
    	var texto=document.getElementById('texto');
	    pos=parametros.indexOf('&');
		subTexto=parametros.substring(0,pos);
		if(subTexto===""){
        	subTexto=parametros;
            parametros="";
        }     
        else
        	parametros=parametros.substring(pos+1);
		pos=subTexto.indexOf('=');
		if(pos>0)
    	{
        	NombreParametro=subTexto.substring(0,pos);
           	ValorParametro=subTexto.substring(pos+1);
	        if(NombreParametro!==""&&ValorParametro!==""){
				parametro=document.createElement("INPUT");
				parametro.setAttribute("type","hidden")
				parametro.name=NombreParametro;
				parametro.value=ValorParametro;
				formulario.appendChild(parametro);
			}
        }
	}
	formulario.appendChild(boton);
	conte.appendChild(formulario);
	boton.click();
}

function ProcesarPaginaPostConParametros(pagina,parametros,panel)
{
	/*ejemplo
	parametros="nombreParametro=valor&Parametro2=valor2";
	pagina="pagina.php";
	panel="nombreDIV";
	*/
	/*var resultado=document.getElementById(panel);*/
	var ajax=Buscador();
	ajax.open('POST',pagina);
	ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4 && ajax.status==200)
		{
			document.getElementById(panel).innerHTML = ajax.responseText;
		}
	}
	ajax.send(parametros);
}
function ProcesarPaginaGetConParametros(pagina,parametros,panel)
{
	//ejemplo parametros='\'nombreParametro=valor&Parametro2=valor2\'';
	if(panel=="")
	panel="resultados";
	var ajax=Buscador();
	ajax.open('GET',pagina+"?"+parametros);
	ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			document.getElementById(panel).innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}
function Procesar(idRegistro,pagina)
{
	//resultados tiene que ser un DIV (un "panel") para desplegar los resultados de la página a abrir
	var parametro="idRegistro="+idRegistro;
	var ajax=Buscador();
	ajax.open('POST',pagina);
	ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			panel=document.getElementById('resultados').innerHTML = ajax.responseText;
		}
	}
	ajax.send(parametro);
}


function Eliminar(idRegistro)
{
	if(confirm("Esta seguro de eliminar el registro"))
	{
		var panel=document.getElementById('resultados');
		var pagina=document.getElementById('paginaEliminar').value;
		var params = "idRegistro="+idRegistro+"&formulario="+document.getElementById('formulario').value;
		ajax=Buscador();
		ajax.open('POST',pagina);
		ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		/*ajax.setRequestHeader("Content-length", params.length);
		ajax.setRequestHeader("Connection", "close");*/
		ajax.onreadystatechange=function()
		{
            if(ajax.readyState == 4)
            {
                if (ajax.status == 200) {
					panel.innerHTML = ajax.responseText;
                    setTimeout("Filtrar()",interval = 2000);
                }
            }
		}
		ajax.send(params);
	}
	else
		return false;
}

function Eliminar2(idRegistro,pagina,parametro,panel)
{
    if(confirm("Esta seguro de eliminar el registro"))
	{
		//var params = "idRegistro="+idRegistro+"&formulario="+document.getElementById('formulario').value;
		var ajax=Buscador();
		ajax.open('POST',pagina);
		ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		/*ajax.setRequestHeader("Content-length", params.length);
		ajax.setRequestHeader("Connection", "close");*/
		ajax.onreadystatechange=function()
		{
			  if(ajax.readyState == 4)
			  {
				  if (ajax.status == 200) {
					document.getElementById(panel).innerHTML = ajax.responseText;
				  }
			  }
		}
		ajax.send(parametro+"&idRegistro="+idRegistro);
	}
	else
		return false;
}

function Eliminardoblere(idRegistro,idRegistro2,verificacion)
{
	if(confirm("Esta seguro de eliminar el registro"))
	{
		var panel=document.getElementById('resultados');
		var pagina=document.getElementById('paginaEliminar').value;
		var params = "idRegistro="+idRegistro+"&formulario="+document.getElementById('formulario').value+"&idRegistro2="+idRegistro2+"&verificacion="+verificacion;
		ajax=Buscador();
		ajax.open('POST',pagina);
		ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		/*ajax.setRequestHeader("Content-length", params.length);
		ajax.setRequestHeader("Connection", "close");*/
		ajax.onreadystatechange=function()
		{
			  if(ajax.readyState == 4)
			  {
				  if (ajax.status == 200) {
					panel.innerHTML = ajax.responseText;
					setTimeout("EventoFiltro();",interval = 1200);
				  }
			  }
		}
		ajax.send(params);
	}
	else
		return false;
}
function Eliminardoblerepanel(idRegistro,idRegistro2,verificacion)
{
	if(confirm("Esta seguro de eliminar el registro"))
	{
if(verificacion==1)
{
		var panel=document.getElementById('Educador');
		var pagina=document.getElementById('paginaEliminar').value;
		var params = "idRegistro="+idRegistro+"&formulario="+document.getElementById('formulario').value+"&idRegistro2="+idRegistro2+"&verificacion="+verificacion;
		ajax=Buscador();
		ajax.open('POST',pagina);
		ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		/*ajax.setRequestHeader("Content-length", params.length);
		ajax.setRequestHeader("Connection", "close");*/
		ajax.onreadystatechange=function()
		{
			  if(ajax.readyState == 4)
			  {
				  if (ajax.status == 200) {
					panel.innerHTML = ajax.responseText;
					setTimeout("EventoFiltromultiple('Educador','paginaeducador');",interval = 1200);
				  }
			  }
		}
}
else if(verificacion==2)
{
		var panel=document.getElementById('Lugar');
		var pagina=document.getElementById('paginaEliminar').value;
		var params = "idRegistro="+idRegistro+"&formulario="+document.getElementById('formulario').value+"&idRegistro2="+idRegistro2+"&verificacion="+verificacion;
		ajax=Buscador();
		ajax.open('POST',pagina);
		ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		/*ajax.setRequestHeader("Content-length", params.length);
		ajax.setRequestHeader("Connection", "close");*/
		ajax.onreadystatechange=function()
		{
			  if(ajax.readyState == 4)
			  {
				  if (ajax.status == 200) {
					panel.innerHTML = ajax.responseText;
					setTimeout("EventoFiltromultiple('Lugar','paginalugar');",interval = 1200);
				  }
			  }
		}
}
else if(verificacion==4)
{
		var panel=document.getElementById('Personal');
		var pagina=document.getElementById('paginaEliminar').value;
		var params = "idRegistro="+idRegistro+"&formulario="+document.getElementById('formulario').value+"&idRegistro2="+idRegistro2+"&verificacion="+verificacion;
		ajax=Buscador();
		ajax.open('POST',pagina);
		ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		/*ajax.setRequestHeader("Content-length", params.length);
		ajax.setRequestHeader("Connection", "close");*/
		ajax.onreadystatechange=function()
		{
			  if(ajax.readyState == 4)
			  {
				  if (ajax.status == 200) {
					panel.innerHTML = ajax.responseText;
					setTimeout("EventoFiltromultiple('Personal','paginapersonalr');",interval = 1200);
				  }
			  }
		}
}
else if(verificacion==5)
{
		var panel=document.getElementById('Semestre');
		var pagina=document.getElementById('paginaEliminar').value;
		var params = "idRegistro="+idRegistro+"&formulario="+document.getElementById('formulario').value+"&idRegistro2="+idRegistro2+"&verificacion="+verificacion;
		ajax=Buscador();
		ajax.open('POST',pagina);
		ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		/*ajax.setRequestHeader("Content-length", params.length);
		ajax.setRequestHeader("Connection", "close");*/
		ajax.onreadystatechange=function()
		{
			  if(ajax.readyState == 4)
			  {
				  if (ajax.status == 200) {
					panel.innerHTML = ajax.responseText;
					setTimeout("EventoFiltromultiple('Semestre','paginasemestre');",interval = 1200);
				  }
			  }
		}
}
else if(verificacion==6)
{
		var panel=document.getElementById('Seccion');
		var pagina=document.getElementById('paginaEliminar').value;
		var params = "idRegistro="+idRegistro+"&formulario="+document.getElementById('formulario').value+"&idRegistro2="+idRegistro2+"&verificacion="+verificacion;
		ajax=Buscador();
		ajax.open('POST',pagina);
		ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		/*ajax.setRequestHeader("Content-length", params.length);
		ajax.setRequestHeader("Connection", "close");*/
		ajax.onreadystatechange=function()
		{
			  if(ajax.readyState == 4)
			  {
				  if (ajax.status == 200) {
					panel.innerHTML = ajax.responseText;
					setTimeout("EventoFiltromultiple('Seccion','paginaseccion');",interval = 1200);
				  }
			  }
		}
}
else if(verificacion==7)
{
		var panel=document.getElementById('Jornada');
		var pagina=document.getElementById('paginaEliminar').value;
		var params = "idRegistro="+idRegistro+"&formulario="+document.getElementById('formulario').value+"&idRegistro2="+idRegistro2+"&verificacion="+verificacion;
		ajax=Buscador();
		ajax.open('POST',pagina);
		ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

		/*ajax.setRequestHeader("Content-length", params.length);
		ajax.setRequestHeader("Connection", "close");*/
		ajax.onreadystatechange=function()
		{
			  if(ajax.readyState == 4)
			  {
				  if (ajax.status == 200) {
					panel.innerHTML = ajax.responseText;
					setTimeout("EventoFiltromultiple('Jornada','paginajornada');",interval = 1200);
				  }
			  }
		}
}

		ajax.send(params);
	}
	else
		return false;
}
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Eliminando...</title>
</head>

<body>
Eliminando...
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
	$mensaje="";
	
	if(isset($_POST["idRegistro"]))
	{
		$idRegistro=$_POST["idRegistro"];
		$formulario=$_POST["formulario"];
		$idRegistro2=$_POST["idRegistro2"];
        $verificacion=$_POST["verificacion"];
		//variable que pueden usar para no saturar el explorador
		$temp=1;
		$temp2 = $temp3 = "";
		if($formulario=="encuesta")
		{
			//Verificar si hay registros dependientes de este registro
			$consulta1->Encuesta_cantidad_asignado($idRegistro);
			//`Cantidad`
			$res=$consulta1->Resultado;
			while($row = mysql_fetch_assoc($res)){
					$temp=$row["Cantidad"];
			}
			mysql_free_result($res);
			//Si no existen dependencia, se eliminaran los datos en cascada.
			if($temp==0)
			{
				$temp2=$consulta1->Encuesta_ver_preguntas($idRegistro);
//				`idPregunta`,`Pregunta`,`TipoRespuesta`
				while($row=mysql_fetch_assoc($temp2))
                {
					$consulta1->Respuesta_eliminar($row["idPregunta"]);
					$consulta1->OpcionMultiple_eliminar($row["idPregunta"]);
				}
				mysql_free_result($temp2);
				$consulta1->Pregunta_eliminar($idRegistro);
				$consulta1->Encuesta_eliminar($idRegistro);
				$mensaje="Encuesta eliminada";
			}
			else
				$mensaje="No se pudo eliminar la encuesta porque hay registros que dependen de este";
		}
        else if($formulario=="participante")
        {
            $consulta1->Participante_eliminar_eventos($idRegistro);
            $consulta1->Participante_eliminar_respuestas($idRegistro);
            $consulta1->Participante_eliminar_foto($idRegistro);
            $consulta1->Participante_eliminar($idRegistro);
        }
        else if($formulario=="playera")
        {
            $consulta1->Playera_verificar($idRegistro);
            $res=mysql_fetch_assoc($consulta1->Resultado);
            if($res["COUNT(`Playera_idPlayera`)"]==0)
            {
                            $consulta1->Playera_eliminar($idRegistro);
                            $mensaje="Playera eliminada";
            }
            else
            {
                $mensaje="No se puede eliminar la playera por estar asignado a otro registro.";
            }
        }
        else if($formulario=="evento")
	    {
                $consulta1->Evento_eliminar($idRegistro);
                $consulta1->EventoEducador_eliminar($idRegistro);
                $consulta1->EventoLugar_eliminar($idRegistro);
                $consulta1->EventoParticipante_eliminar($idRegistro);
                $consulta1->EventoPersonal_eliminar($idRegistro);
                $consulta1->EventoSemestre_eliminar($idRegistro);
                $mensaje="Actividad eliminada";
	    } 
else if($formulario=="tipoevento")
	    {
$consulta2=new Consulta;
  $consulta2->TipoEventoCantidad_verificar($idRegistro);
		$res=$consulta2->Resultado;
if(mysql_num_rows($res)==0)
{
                $consulta1->TipoEvento_eliminar($idRegistro);
                $mensaje="Tipo de actividad eliminada";
}
else
{
$mensaje="Tipo de Actividad ya esta asignada a un evento";
}
	    } 
        
else if($formulario=="lugar")
        {
$consulta2=new Consulta;
  $consulta2->Lugar_verificarcantidad($idRegistro);
        $res=$consulta2->Resultado;
if(mysql_num_rows($res)==0)
{
                $consulta1->Lugar_eliminar($idRegistro); 
                $mensaje="Lugar eliminado";
}
else
{
$mensaje="No se puede eliminar porque el lugar esta asignado a un evento";
}
	    } 
        

else if($formulario=="semestre")
{
                $consulta2=new Consulta;
                $consulta2->Semestre_contar($idRegistro);
		$res=$consulta2->Resultado;
		if(mysql_num_rows($res)==0)
{
                $consulta1->Semestre_eliminar($idRegistro); 
                $mensaje="Semestre eliminado";
}
else
{
$mensaje="No se puede eliminar porque el Semestre ya esta relacionado";
}
}

        else if($formulario=="descripciones")
        {
                    $consulta2=new Consulta;
                    $cantidad=0;
                    if($verificacion==1)
                    {
                                   $consulta1->EventoEducador_eliminar_unico($idRegistro,$idRegistro2);
                    }
                    else if($verificacion==2)
                    {
                                    $consulta1->EventoLugar_eliminar_unico($idRegistro,$idRegistro2);
                    }
                    else if($verificacion==3)
                    {
                                    $consulta1->EventoParticipante_eliminar_unico($idRegistro,$idRegistro2);
                    }
                    else if($verificacion==4)
                    {
                                    $consulta1->EventoPersonal_eliminar_unico($idRegistro,$idRegistro2);
                    }
                    else if($verificacion==5)
                    {
                        $consulta2->Evento_ver_Participantesemestre($idRegistro,$idRegistro2);
                        $cantidad=mysql_num_rows($consulta2->Resultado);
                        if($cantidad==0)
                        {
                                $consulta1->EventoSemestre_eliminar_unico($idRegistro,$idRegistro2);
                        }
                    }
                    else if($verificacion==6)
                    {
                        $consulta1->EventoSeccion_eliminar_unico($idRegistro,$idRegistro2);
                    }
                    else if($verificacion==7)
                    {
                        $consulta1->EventoJornada_eliminar_unico($idRegistro,$idRegistro2);
                    }
                    if($cantidad>0&&($verificacion==7||$verificacion==6||$verificacion==5))
                    {
                    $mensaje="Participante Asignado no se puede eliminar la asignacion";
                    }
                    else
                    {
                                    $mensaje="Asignacion eliminada";
                    }
        }
        else if($formulario=="educador")
        {
$consulta2=new Consulta;
  $consulta2->EventoEducador_verificar_asignado($idRegistro);
        $res=$consulta2->Resultado;
		if(mysql_num_rows($res)==0)
{
            $consulta1->Educador_eliminar($idRegistro);
}
else
{
$mensaje="No se puede eliminar porque el Educador ya esta relacionado";
}
        }
else if($formulario=="personal")
        {
$consulta2=new Consulta;
  $consulta2->Personal_ver_actividades($idRegistro);
        $res=$consulta2->Resultado;
		if(mysql_num_rows($res)==0)
{
            $consulta1->Personal_eliminar($idRegistro);
}
else
{
$mensaje="No se puede eliminar porque el Personal ya esta relacionado";
}
        }
        else if($formulario=="GrupoEvento")
        {
            $consulta1->GrupoEvento_cantidades_asigandos_enParticipante($idRegistro);
            $res=$consulta1->Resultado;
    		while($row = mysql_fetch_assoc($res)){
					$temp=$row["Cantidad"];
			}
			mysql_free_result($res);
            if($temp==0)
    		{
                $consulta1->GrupoEvento_eliminar($idRegistro);
                $consulta1->TipoEventoCantidad_eliminar($idRegistro);
                 $mensaje="Eliminando Evento";
    		}
            else
            {
                $mensaje="No se pudo eliminar el evento porque hay registros que dependen de este";
            }
        }
        else if($formulario=="detalle")
        {
            session_start();
            $idGrupoEvento=$_SESSION['codGE'];
            $consulta1->GrupoEvento_detalle_eliminar($idRegistro,$idGrupoEvento);
        }
        else if($formulario=="Patrocinador")
        {
            $consulta1->Patrocinador_cantidades_asigandos($idRegistro);
            $res=$consulta1->Resultado;
			while($row = mysql_fetch_assoc($res)){
					$temp=$row["Cantidad"];
			}
			mysql_free_result($res);
            if($temp==0)
    		{
                $consulta1->Eliminar_parocinador($idRegistro);
                $mensaje="Eliminando patrocinador";
    		}
            else
            {
                $mensaje="No se pudo eliminar el patrocinador porque hay registros que dependen de este";                
            }
        }
            
    }
	
	echo '<br/><br/><p align="center">'.$mensaje.'</p>';
?>

</body>
</html>	
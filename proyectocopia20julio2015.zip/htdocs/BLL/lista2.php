<?php
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	$consulta1=new Consulta;
	$select = $_POST["consulta"];
	$etiqueta = $_POST["etiqueta"];
	$idLista = $_POST["idLista"];
	$funcion = $_POST["funcion"];
	echo '<select name="'.$idLista.'" id="'.$idLista.'" onchange="'.$funcion.'">'."\n";
    exho'<option disabled selected> -- Seleccione un semestre -- </option>';
	$consulta1->consultar($select);
	$res=$consulta1->Resultado;
	while($row= mysql_fetch_assoc($res)){
		echo '<option value="'.$row["id"].'">'.$row["nombre"].'</option>'."\n";
	}
	echo '<option value= "100">Todos... </option>
        <option value="+">Agregar otro.</option>'."\n";
	echo '</select>';
?>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
    if(isset($_POST["consulta"]))
	    $select = $_POST["consulta"];
    else
        $select=$consulta1->consultar2($_POST["NoConsulta"]);
	$idLista = $_POST["idLista"];
	$funcion = $_POST["funcion"];
	echo '<select name="'.$idLista.'" id="'.$idLista.'" onchange="'.$funcion.'">'."\n";
	$consulta1->consultar($select);
	$resultado1=$consulta1->Resultado;
	while($rowR= mysql_fetch_assoc($resultado1)){
		echo '<option value="'.$rowR["id"].'">'.$rowR["nombre"].'</option>'."\n";
	}
echo '<option value="-">Actualizar</option>'."\n";
	echo '<option value="+">Agregar otro.</option>'."\n";
	echo '</select>';
?>
/* Modal***************************************************************************** */
    /*Función que se llama desde la página del formulario (ej: pagina.php)*/
function procesar(pagina,parametros){
	/*var parametros = "id="+ $('#idDato').val()+"&nombre="+$('#nombreDato').val();*/
	ProcesarPaginaPostConParametros(pagina,parametros,"modal");
}
function openVentana(idLista,pagina,parametros){
	if(document.getElementById(idLista)!=null && document.getElementById(idLista).value=="+")
	{
		$(".ventana").slideDown("slow");
		//ProcesarPaginaGetConParametros('\'pagina.php\'','');
		//parametros: url,idLista,idDiv
		var param="url="+pagina+"&idLista="+idLista+"&"+parametros;
		ProcesarPaginaPostConParametros(pagina,param,"modal");
	}
}
function closeVentana(ingresado,pagina,consulta,idLista,divLista){
	$(".ventana").slideUp("fast");
/*			var consulta="SELECT `id`, `Nombre` FROM `Prueba`";
	deben ser id y Nombre colocar as id y as Nombre si las columnas se llaman diferente
	var idLista="lista";*/
	if(ingresado==1)
	{
		var funcion="openVentana(\'"+idLista+"\','"+pagina+"','idDiv="+divLista+"');";
		var parametros="consulta="+consulta+"&idLista="+idLista+"&funcion="+funcion;
		//Verificar la direccion de la pagina /BLL/lista.php    ../ => retroceder una carpeta
		ProcesarPaginaPostConParametros("../../BLL/lista.php",parametros,divLista);
	}
}
function closeVentanaper(ingresado,pagina,consulta,idLista,divLista){
	$(".ventana").slideUp("fast");
/*			var consulta="SELECT `id`, `Nombre` FROM `Prueba`";
	deben ser id y Nombre colocar as id y as Nombre si las columnas se llaman diferente
	var idLista="lista";*/
	if(ingresado==1)
	{
		var funcion="openAc(\'"+idLista+"\','"+pagina+"','idDiv="+divLista+"'),cargar(this.value,'Personal_ingresar.php'),openVentana(\'"+idLista+"\','"+pagina+"','idDiv="+divLista+"');";
		var parametros="consulta="+consulta+"&idLista="+idLista+"&funcion="+funcion;
		//Verificar la direccion de la pagina /BLL/lista.php    ../ => retroceder una carpeta
		ProcesarPaginaPostConParametros("../../BLL/lista3.php",parametros,divLista);
	}
}
function openAc(idLista,pagina,parametros){
	if(document.getElementById(idLista)!=null && document.getElementById(idLista).value=="-")
	{
		$(".ventana").slideDown("slow");
		//ProcesarPaginaGetConParametros('\'pagina.php\'','');
		//parametros: url,idLista,idDiv
		var param="url="+pagina+"&idLista="+idLista+"&"+parametros;
		ProcesarPaginaPostConParametros(pagina,param,"modal");
	}
}
function ingresarDatos(pagina,parametros)
{
	var param="url="+pagina+"&"+parametros;
	ProcesarPaginaPostConParametros(pagina,param,"modal");
}
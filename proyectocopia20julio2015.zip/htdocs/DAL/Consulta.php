<?php
/*
c
NOTA!!!!!!!!!!!! PARA EJECUTAR UNA CONSULTA DE VER LOS DATOS DE LA BASE DE DATOS "SELECT" usen
ar_
function nombreFuncion(){
        $this->Consulta="SELECT * FROM TABLA";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    
CUALQUIER OTRO TIPO DE CONSULTA (insert,update, etc)

function nombreFuncion(){
        $this->Consulta="INSERT INTO TABLA";
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    
    
EL CAMBIO ESTA EN LA EJECUCION DE LA CONSULTA.


favor de escribir todos las nuevas funciones que vayan creando o editando para saber si no se muestra bien una pagina es por la nueva funcion agregada
    asi evitarnos trabajo por gusto buscando cual es el error y solo podemos dejarlo como comentario para seguir trabajando.
    
    
    nombre de las funcionnes:
    Usuario_ver
    participante_nuevo
    semestre_ver
    Participante_ver_eventos
    Encuesta_ver
    Encuesta_nueva
	Encuesta_ver_datos
	Encuesta_ver_preguntas
	Encuesta_cantidad_asignado
	Encuesta_eliminar
	Pregunta_nueva
	Pregunta_ver_opciones
	Pregunta_ver_respuestas
	Pregunta_ver_respuestas_multiples
	Pregunta_eliminar
	OpcionMultiple_nueva
	OpcionMultiple_eliminar
	Respuesta_nueva
	Respuesta_eliminar
	TipoEvento_insertar
	TipoEvento_ver
	TipoEvento_ver_datoso
    EventoParticipante_insertar
    EventoEducador_insertar
	EventoPersonal_insertar
    Educador_ver
	Lugar_ver
	Personal_insertar
	Evento_insertar
	Evento_ver
	GrupoEvento_ver
	RegistroLugares_insertarPersonal_ver
    Participante_ver
	patrocinador_ver
	Eliminar_parocinador
	Actualizar_patrocinador
	Insertar_patrocinador
	TipoEvento_ver2
	Insertar_GrupoEvento
	Insertar_TipoEventoCantidad
	TipoEvento_ver_nombre
	TipoEvento_actualizar
	TipoEvento_eliminar
	GrupoEvento_ver
    Insertar_Gastos
    Listar_Patrocinadores
    Listar_GrupoEvento
    Listar_Gastos
    Actualizar_GrupoEvento
    Xep:Participante_ver_eventos
    veengas:TipoEventoCantidad_ver
    xep:Participante_encuestado
    Raul: Usuario_IngresarUsuario
    Raul: Ingresar_TipoGasto
    Raul: TipoGasto_Listar
    Xep:Participante_ver_datos_usuario
    Raul: Usuario_VerificarUsuario
    Raul: TipoGasto_Verificartipogasto
    xep:GrupoEvento_ver_detalle_habilitados
    xep:GrupoEvento_ver_eventos_habilitados
    venegas:GrupoEvento_eliminar
    xep:Evento_ver_detalle
    venegas:GrupoEvento_ver_diploma
    Raul: listar_TipoGasto
    Raul: listar_Usuarios
    Raul:Gasto_Reporte_general
    Raul:Gasto_Reporte_especifico
    xep:Participante_ver_filtro
    Raul:TipoGasto_seleccionar
    Raul:TipoGasto_listarporid
    Raul:TipoGasto_eliminar
    Raul:TipoGasto_actualizar
    Raul:Gasto_seleccionar
    Raul:Gasto_eliminar
    Raul:Gasto_actualizar
    Raul:Usuarios_seleccionar
    Raul:Usuarios_eliminar
    Raul:Usuarios_actualizar
    venegas:Participante_diploma_todos
    venegas:Participante_ver_nombre
    xep:Participante_detalle
    xep:Participante_entregar_playera
    xep:Participante_entregar_certificado
    xep:Participante_entregar_inscripcion
    venegas:Posiciones_actualizar
    venegas:Posiciones_ver
    venegas:Participante_diploma_semestre
    xep:Participante_reporte
    venegas:Participante_ver_su_tipoEvento
    venegas:Posiciones_actualizar_tipoEvento
    venegas:Posiciones_ver_tipoEvento
    Raul:Patrocinador_Reporte_general
    Raul:Patrocinador_Reporte_especifico
    xep:prueba_nuevo
    xep:prueba_ver
    venegas:GrupoEvento_filtrar
    Raul:Jornada_verificarJornada
    Raul:Ingresar_Jornada
    Raul:listar_Jornada
    Raul:Jornada_seleccionar
    Raul:Jornada_actualizar
    Raul:Jornada_listarporid
    Raul:Jornada_eliminar
    Raul:seccion_verificarSeccion
    Raul:Ingresar_Seccion
    Raul:listar_Seccion
    Raul:Seccion_seleccionar
    Raul:Seccion_actualizar
    Raul:Seccion_VerificarSeccionNombre
    Raul:Seccion_listarporid
    Raul:Seccion_eliminar
    venegas:GrupoEvento_reporte_general
    venegas:GrupoEvento_reporte_detalle
    venegas:GrupoEvento_detalle_eliminar
    venegas:Patrocinador_cantidades_asigandos
    venegas:GrupoEvento_cantidades_asigandos_enParticipante
    xep:Jornada_ver2
    XEP:seccion_ver2
    xep:Participante_actualizar
    xep:Jornada_verificar2
    xep:Jornada_nueva
    Raul:Jornada_VerificarJornadaNombre
    Raul:TipoGasto_VerificarTipoGastoNombre
    xep:Seccion_verificar2
    venegas:GrupoEvento_verificar_nombre
    venegas:GrupoEvento_verificar_nombre2
    venegas:Patrocinador_verificar_nombre
    venegas:Patrocinador_verificar_nombre2
    venegas:Actividad_mostrar
    venegas:TipoEventoCantidad_eliminar
    venegas:TipoEventoCantidad_editar
    venegas:Entregar_certificado
    xep:Seccion_nueva
    xep:Encuesta_contestado
    xep:Participante_validacion
    xep:Participante_validacion2
    xep:Participante_eliminar_eventos
    xep:Participante_eliminar_respuestas
    xep:Participante_eliminar
    xep:Participante_eliminar_foto
    xep:Participante_eventos
    xep:TipoEventoCantidad_asignadas
    xep:TipoEvento_ver_lista
    xep:consultar2
    xep:Evento_disponibles_participante
    xep:Evento_lugar_disponible
    xep:EventoParticipante_nuevo
    xep:EventoParticipante_eliminar2
    xep:Encuesta_verificar_titulo
    xep:Playera_ver
    xep:Playera_validacion
    xep:Playera_nueva
    xep:Playera_validacion2
    xep:Playera_detalle
    xep:Playera_actualizar
    xep:Participante_playeras
    xep:Playera_disponibles_participante
    xep:Playera_verificar
    xep:Playera_eliminar
    xep:ParticipantePlayera_nueva
    xep:ParticipantePlayera_eliminar
    xep:Participante_por_semestre
    
    nombre de las funciones comentariadas:
    
    
    
    
    
    OJO: los nombres de las funciones tienen que tener el siguiente formato:
    NombreTabla_funcion()
    para una futura corrección.
    */
class Consulta extends Servidor{
    var $Consulta="";
    var $Resultado="";
    var $c;
    function __construct()
    {
        $this->conectar();
        $this->c=$this->conexion;
	}
	function consultar($Consulta1){
		$this->Consulta=$Consulta1;
		$this->Resultado = mysql_query($this->Consulta,$this->c);

		 if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
    function consultar2($NoConsulta){
        $this->Consulta="";
        switch($NoConsulta)
        {
            case 1:
                return "SELECT `idTipoEvento` as `id`, `Nombre` as `nombre` FROM `TipoEvento` WHERE `Estado`=1 order by `idTipoEvento`";
                break;
        }
	}
//Prueba
    function prueba_ver()
    {
        $this->Consulta="SELECT `id`, `Nombre` FROM `Prueba`";
		$this->Resultado = mysql_query($this->Consulta,$this->c);

		 if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function prueba_nuevo($id,$nombre)
    {
        $this->Consulta="INSERT INTO `Prueba` (`id`, `Nombre`) VALUES ('".$id."', '".$nombre."');";
		$this->Resultado=mysql_query($this->Consulta,$this->c);
		 /*if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}*/
    }
// Usuario
    function Usuario_ver()
    {
        $this->Resultado = TRUE;
    }
//Playera
    function Playera_ver($filtro,$idGrupo)
    {
        $this->Consulta="SELECT `idPlayera`, `Playera`, `Costo`, `EstadoPlayera` as `Habilitado` FROM `Playera` WHERE `Playera` like '%$filtro%' and `GrupoEvento_idGrupoEvento`=".$idGrupo;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
    function Playera_verificar($idPlayera)
    {
        $this->Consulta="SELECT COUNT(`Playera_idPlayera`) FROM `ParticipantePlayera` WHERE `Playera_idPlayera`=".$idPlayera;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
    function Playera_eliminar($idPlayera)
    {
        $this->Consulta="DELETE FROM `Playera` WHERE `idPlayera`=".$idPlayera;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
        }
    }
    function Playera_actualizar($idPlayera,$playera,$estadoPlayera,$costo)
    {
        $this->Consulta="UPDATE `Playera` SET `Playera`='".$playera."',`Costo`=".$costo.",`EstadoPlayera`=".$estadoPlayera." WHERE `idPlayera`=".$idPlayera;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
        }
    }
    function Playera_nueva($playera,$costo,$idGrupo)
    {
        $this->Consulta="INSERT INTO `Playera` (`idPlayera`, `Playera`,`Costo`, `GrupoEvento_idGrupoEvento`, `EstadoPlayera`) VALUES (NULL, '".$playera."',".$costo.", ".$idGrupo.", '1');";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
    function Playera_disponibles_participante($idParticipante,$idGrupo)
    {
        $this->Consulta="SELECT `idPlayera`, `Playera`,p.`Costo`
FROM 
    `Playera` as p left join `ParticipantePlayera` on `idPlayera`=`Playera_idPlayera`
WHERE
	`EstadoPlayera`=1 and
        `GrupoEvento_idGrupoEvento`=".$idGrupo." and
        `idPlayera` not in
        (select `Playera_idPlayera` from `ParticipantePlayera` where `Participante_idParticipante`=".$idParticipante.")";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
        }
    }
    function Playera_detalle($idPlayera)
    {
        $this->Consulta="SELECT `idPlayera`, `Playera`,`Costo`, `GrupoEvento_idGrupoEvento`, `EstadoPlayera` FROM `Playera` WHERE `idPlayera`=".$idPlayera;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
        }
    }
    function Playera_validacion($playera,$idGrupo)
    {
        $this->Consulta="SELECT COUNT(`idPlayera`) as `Cantidad` FROM `Playera` WHERE `Playera` like '".$playera."' and `GrupoEvento_idGrupoEvento`=".$idGrupo;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
    function Playera_validacion2($idPlayera,$playera,$idGrupo)
    {
        $this->Consulta="SELECT COUNT(`idPlayera`) as `Cantidad` FROM `Playera` WHERE `Playera` like '".$playera."' and `GrupoEvento_idGrupoEvento`=".$idGrupo;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
        }
    }

function Playera_ver_tipo($idGrupo)
    {
        $this->Consulta="SELECT `idPlayera`, `Playera`, `Costo`, `EstadoPlayera` as `Habilitado` FROM `Playera` WHERE `GrupoEvento_idGrupoEvento`=".$idGrupo;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }


//ParticipantePlayera
    function ParticipantePlayera_nueva($idParticipante,$idPlayera,$CE)
    {
        $costoE=0;
        if($CE==1)
        {
            $this->Consulta="SELECT `Costo` FROM `Playera` WHERE `idPlayera`=".$idPlayera;
            $this->Resultado = mysql_query($this->Consulta,$this->c);
            $rr=mysql_fetch_assoc($this->Resultado);
            $costoE=$rr["Costo"];
        }
        $this->Consulta="INSERT INTO `ParticipantePlayera`(`Participante_idParticipante`, `Playera_idPlayera`, `Costo`) VALUES (".$idParticipante.",".$idPlayera.",".$costoE.")";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    function ParticipantePlayera_eliminar($idParticipante,$idPlayera)
    {
        $this->Consulta="DELETE FROM `ParticipantePlayera` WHERE `Participante_idParticipante`=".$idParticipante." and `Playera_idPlayera`=".$idPlayera;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
        }
    }
// Participante

function playera_semestre($id,$grupo){
$this->Consulta="select S.Semestre,(SELECT COUNT(`idParticipante`)   FROM `Participante` inner join ParticipantePlayera on ParticipantePlayera.Participante_idParticipante=Participante.idParticipante WHERE `GrupoEvento_idGrupoEvento`=G.idGrupoEvento and `EstadoParticipante`=1 and `Semestre_idSemestre`= S.idSemestre) AS totalParticipante,(SELECT COUNT(`idParticipante`)   FROM `Participante` inner join ParticipantePlayera on ParticipantePlayera.Participante_idParticipante=Participante.idParticipante WHERE `GrupoEvento_idGrupoEvento`=G.idGrupoEvento and `EstadoParticipante`=1 and Genero=1 and `Semestre_idSemestre`= S.idSemestre) AS TotalHombres, (SELECT COUNT(`idParticipante`)   FROM `Participante`  inner join ParticipantePlayera on ParticipantePlayera.Participante_idParticipante=Participante.idParticipante WHERE `GrupoEvento_idGrupoEvento`=G.idGrupoEvento and `EstadoParticipante`=1 and Genero=0 and `Semestre_idSemestre`= S.idSemestre) AS TotalMujeres from GrupoEvento as G
inner join Participante as P on P.GrupoEvento_idGrupoEvento=G.idGrupoEvento
inner join Semestre as S on P.Semestre_idSemestre=S.idSemestre
where G.idGrupoEvento='".$grupo."' and S.idSemestre=".$id;
    		$this->Resultado = mysql_query($this->Consulta,$this->c);
        	if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

function playera_semestre_talla($id,$grupo,$talla,$playera,$genero){
$this->Consulta=" SELECT * FROM `Playera` inner join 
ParticipantePlayera on ParticipantePlayera.Playera_idPlayera=Playera.idPlayera inner join
Participante on Participante.idParticipante=ParticipantePlayera.Participante_idParticipante 
where Playera.GrupoEvento_idGrupoEvento=".$grupo." and Participante.Semestre_idSemestre=".$id." and Playera.idPlayera=".$playera." and Participante.Genero=".$genero." and Participante.Talla='".$talla."'";
    		$this->Resultado = mysql_query($this->Consulta,$this->c);
        	if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

    function Participante_playeras($idParticipante)
    {
        $this->Consulta="SELECT `Participante_idParticipante`, `Playera_idPlayera`,`Playera`, pp.`Costo` FROM `ParticipantePlayera` as pp inner join `Playera` as p on `Playera_idPlayera`=`idPlayera` WHERE `Participante_idParticipante`=".$idParticipante;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
        }
    }
    function Participante_eventos($idParticipante)
    {
        $this->Consulta="Select 
    `idParticipante`,
        `idEvento`,
        TipoEvento.Nombre as `Tipo de actividad`,
	Evento.Nombre as Actividad,
    Lugar.Nombre as `Lugar`,
	DATE_FORMAT(Evento.Fecha,'%d/%m/%Y') as Fecha,
	Evento.HoraInicio as `Hora de inicio`,
	Evento.HoraFinal as `Hora final`,
    EventoParticipante.Costo as `Costo extras`
From
	Participante inner join
	EventoParticipante on Participante.idParticipante=EventoParticipante.Participante_idParticipante  inner join
	Evento on Evento.idEvento=EventoParticipante.Evento_idEvento inner join
        TipoEvento on TipoEvento.idTipoEvento=Evento.TipoEvento_idTipoEvento inner join
        Lugar on EventoParticipante.Lugar_idLugar=Lugar.idLugar
WHERE
	Participante.idParticipante='".$idParticipante."' Order by Evento.Fecha,Evento.HoraInicio";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
    function Participante_eliminar_eventos($idParticipante)
    {
        $this->Consulta="DELETE FROM `EventoParticipante` WHERE `Participante_idParticipante`=".$idParticipante;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
        }
    }
    function Participante_eliminar_respuestas($idParticipante)
    {
        $this->Consulta="DELETE FROM `Respuesta` WHERE `Participante_idParticipante`=".$idParticipante;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
        }
    }
    function Participante_eliminar_foto($idParticipante)
    {
        $this->Consulta="SELECT `Foto` FROM `Participante` WHERE `idParticipante` =".$idParticipante;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (file_exists($_SERVER['DOCUMENT_ROOT']."/fotos/".$this->Resultado["Foto"])) {
            unlink($_SERVER['DOCUMENT_ROOT']."/fotos/".$this->Resultado["Foto"]);
        } /*else {
        echo 'Could not delete '.$filename.', file does not exist';
        }*/
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
        }
    }
    function Participante_eliminar($idParticipante)
    {
        $this->Consulta="DELETE FROM `Participante` WHERE `idParticipante`=".$idParticipante;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    function Participante_validacion($nombre,$carne,$idGrupo)
    {
        $this->Consulta="SELECT 'nombre' as dato, COUNT(`idParticipante`) as cantidad  FROM `Participante` WHERE `GrupoEvento_idGrupoEvento`=".$idGrupo." and `Nombre` like '".$nombre."'
UNION ALL
SELECT 'carne', COUNT(`idParticipante`) FROM `Participante` WHERE `GrupoEvento_idGrupoEvento`=".$idGrupo." and `Carne` = ".$carne;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
    /*Verificar si el participante no esta duplicado (editar participante)*/
    function Participante_validacion2($nombre,$carne,$idGrupo,$idParticipante,$usuario)
    {
        $this->Consulta="SELECT 'nombre' as dato, COUNT(`idParticipante`) as cantidad  FROM `Participante` WHERE `GrupoEvento_idGrupoEvento`=".$idGrupo." and `idParticipante`!=".$idParticipante." and `Nombre` like '".$nombre."'
UNION ALL
SELECT 'carne', COUNT(`idParticipante`) FROM `Participante` WHERE `GrupoEvento_idGrupoEvento`=".$idGrupo." and `idParticipante`!=".$idParticipante." and `Carne` = ".$carne."
UNION ALL
SELECT 'usuario', COUNT(`idParticipante`) FROM `Participante` WHERE `GrupoEvento_idGrupoEvento`=".$idGrupo." and `idParticipante`!=".$idParticipante." and `UsuarioParticipante` like '".$usuario."'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
        }
    }

    function participante_nuevo($Nombre,$Carnet,$Semestre,$idFoto,$Talla,$Usuario,$genero,$playera,$grupo,$jornada,$seccion){
        $this->Consulta="INSERT INTO `Participante`
            (`Nombre`, `Carne`, `Semestre_idSemestre`, `Foto`, `Talla`, `Genero`, `PlayeraEntregada`, `CertificadoEntregado`, 
            `GrupoEvento_idGrupoEvento`, `EstadoParticipante`, `Jornada_idJornada`, `Seccion_idSeccion`, `UsuarioParticipante`)
        VALUES ('".$Nombre."', '".$Carnet."', '".$Semestre."', '".$idFoto."', '".$Talla."', '".$genero."', '".$playera."', '0','".$grupo."',
            '1', '".$jornada."', '".$seccion."', '".$Usuario."')";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
        else
        {
            $this->Consulta="SELECT LAST_INSERT_ID() as id;";
            $this->Resultado = mysql_query($this->Consulta,$this->c);
        }
    }
    function Participante_ver_filtro($filtro,$idGrupoEvento){
		$this->Consulta="SELECT `idParticipante`, `Nombre`,`Carne` AS `Carné`, Semestre.Semestre, `Talla` AS `Talla de la playera`, `Genero` AS `Género`, `EstadoParticipante` AS `Habilitado` 
        FROM
            `Participante` inner join `Semestre` on Participante.Semestre_idSemestre = Semestre.idSemestre
        WHERE
            `Nombre` like '%$filtro%' AND
            `GrupoEvento_idGrupoEvento` =".$idGrupoEvento;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
    function Participante_detalle($idParticipante,$idGrupo){
        $this->Consulta="SELECT `idParticipante`, Participante.`Nombre`, `Carne`, `Semestre_idSemestre`,`Semestre`.Semestre, `Foto`, `Talla`, `Genero`, `PlayeraEntregada`, `CertificadoEntregado`, `GrupoEvento_idGrupoEvento`, `EstadoParticipante`, `Jornada_idJornada`,`Jornada`.Jornada, `Seccion_idSeccion`,`Seccion`.Seccion, `UsuarioParticipante`
FROM
    `Participante`inner join
	`Semestre` on Participante.Semestre_idSemestre=Semestre.idSemestre inner join
        `Jornada` on Participante.Jornada_idJornada=Jornada.idJornada inner join
        `Seccion` on Participante.Seccion_idSeccion=Seccion.idSeccion
WHERE
	`GrupoEvento_idGrupoEvento`=".$idGrupo." and
        `idParticipante`=".$idParticipante;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Participante_entregar_playera($idParticipante){
        $this->Consulta="UPDATE `Participante` SET `PlayeraEntregada` = 1 WHERE `Participante`.`idParticipante` = ".$idParticipante;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Participante_entregar_certificado($idParticipante){
        $this->Consulta="UPDATE `Participante` SET `CertificadoEntregado` = 1 WHERE `Participante`.`idParticipante` =".$idParticipante;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Participante_actualizar($idParticipante,$nombre,$carne,$idSemestre,$talla,$genero,$playera,$certificado,$estado,$idJornada,$idSeccion,$usuario){
        $this->Consulta="UPDATE `Participante` SET `Nombre`='".$nombre."',`Carne`='".$carne."',`Semestre_idSemestre`='".$idSemestre."',`Talla`='".$talla."',`Genero`='".$genero."',`PlayeraEntregada`='".$playera."',`CertificadoEntregado`='".$certificado."',`EstadoParticipante`='".$estado."',`Jornada_idJornada`='".$idJornada."',`Seccion_idSeccion`='".$idSeccion."',`UsuarioParticipante`='".$usuario."' WHERE `idParticipante`=".$idParticipante;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Participante_reporte($idGrupoEvento)
    {
        $this->Consulta="SELECT '' as `id`, 'Participantes' as `Dato`, COUNT(`idParticipante`) AS `Total` FROM `Participante` WHERE `EstadoParticipante` = 1 and  `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento." 
UNION ALL
SELECT '', 'Hombres', COUNT(`idParticipante`) AS `Hombres` FROM `Participante` WHERE `EstadoParticipante` = 1 and `Genero`=1 and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'Mujeres', COUNT(`idParticipante`) AS `Mujeres` FROM `Participante` WHERE `EstadoParticipante` = 1 and `Genero`=0 and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'XS', COUNT(`idParticipante`) AS `XS` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Talla`='XS' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'HXS', COUNT(`idParticipante`) AS `XS` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=1 and `Talla`='XS' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'MXS', COUNT(`idParticipante`) AS `XS` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=0 and `Talla`='XS' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'S', COUNT(`idParticipante`) AS `S` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Talla`='S' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'HS', COUNT(`idParticipante`) AS `S` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=1 and `Talla`='S' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'MS', COUNT(`idParticipante`) AS `S` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=0 and `Talla`='S' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'M', COUNT(`idParticipante`) AS `M` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Talla`='M' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'HM', COUNT(`idParticipante`) AS `M` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=1 and `Talla`='M' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'MM', COUNT(`idParticipante`) AS `M` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=0 and `Talla`='M' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'L', COUNT(`idParticipante`) AS `L` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Talla`='L' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'HL', COUNT(`idParticipante`) AS `L` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=1 and `Talla`='L' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'ML', COUNT(`idParticipante`) AS `L` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=0 and `Talla`='L' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'XL', COUNT(`idParticipante`) AS `XL` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Talla`='XL' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'HXL', COUNT(`idParticipante`) AS `XL` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=1 and `Talla`='XL' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'MXL', COUNT(`idParticipante`) AS `XL` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=0 and `Talla`='XL' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'XXL', COUNT(`idParticipante`) AS `XXL` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Talla`='XXL' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'HXXL', COUNT(`idParticipante`) AS `XXL` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=1 and `Talla`='XXL' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'MXXL', COUNT(`idParticipante`) AS `XXL` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `Genero`=0 and `Talla`='XXL' and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'PlayeraT', COUNT(`idParticipante`) AS `Cantidad` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT '', 'PlayeraE', COUNT(`idParticipante`) AS `Cantidad` FROM `Participante` inner join ParticipantePlayera on idParticipante=Participante_idParticipante WHERE `EstadoParticipante` = 1 and `PlayeraEntregada`=1 and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento."
UNION ALL
SELECT `idSemestre`, `Semestre`.Semestre,COUNT(`idParticipante`) FROM `Participante` inner join `Semestre` on `Semestre_idSemestre`=`idSemestre` WHERE `EstadoParticipante`=1 and `EstadoSemestre`=1 and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento." GROUP BY `idSemestre`
UNION ALL
SELECT '', 'Certificado', COUNT(`idParticipante`) AS `Mujeres` FROM `Participante` WHERE `EstadoParticipante` = 1 and `CertificadoEntregado`=1 and `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
            
    		die($message);
		}
    }
    function Participante_por_semestre($idSemestre,$idGrupo)
    {
        echo $idSemestre.':'.$idGrupo;
        $this->Consulta="SELECT `idParticipante`, `Nombre`, `Carne` as `Carné`, `Talla`, `Genero` as `Género`, j.Jornada, s.Seccion as `Sección`
        FROM
            `Participante` as p inner join
                Seccion as s on p.Seccion_idSeccion=s.idSeccion inner join
                Jornada as j on p.Jornada_idJornada=j.idJornada
        WHERE
        	`EstadoParticipante`=1 and
                `GrupoEvento_idGrupoEvento`=".$idGrupo." and
                `Semestre_idSemestre`=".$idSemestre;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
//Semestre

function Semestre_verificar($nombre){
        $this->Consulta="SELECT * 
FROM Semestre
WHERE Semestre ='".$nombre."'";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}
function Semestre_verificar_editar($nombre,$id){
        $this->Consulta="SELECT * 
FROM Semestre
WHERE Semestre ='".$nombre."'
and idSemestre !=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}


	function semestre_ver(){
        $this->Consulta="SELECT idSemestre as id,Semestre FROM Semestre where EstadoSemestre=1 order by id asc";
		$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

    function Semestre_ver_detalle($id)
     {
        $this->Consulta="SELECT idSemestre, Semestre as 'Semestre', EstadoSemestre as 'Habilitado' FROM Semestre WHERE Semestre LIKE  '%$id%' order by idSemestre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

     function Semestre_ver_datos($id)
     {
        $this->Consulta="SELECT * FROM Semestre WHERE idSemestre=".$id." order by idSemestre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;

    		die($message);
		}
     }
     function Semestre_nuevo($semestre)
     {
        $this->Consulta="INSERT INTO `Semestre` ( `Semestre`) VALUES ('".$semestre."')";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

  function Semestre_eliminar($q)
    {
    	$this->Consulta=("DELETE FROM Semestre WHERE idSemestre ='$q'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}


function Semestre_insertar($sem,$estado){
		$this->Consulta=("INSERT INTO `Semestre`(`Semestre`, `EstadoSemestre`) VALUES ('".$sem."', '".$estado."');");
		$this->Resultado=mysql_query($this->Consulta,$this->c);
		 if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}


function Semestre_contar($q){
    	$this->Consulta="Select *  from EventoSemestre 
where Semestre_idSemestre=".$q;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

    function Participante_ver_eventos($Usuario)
    {
    $this->Consulta="SELECT 
    Participante.idParticipante,
    Evento.idEvento,
    Encuesta.idEncuesta,
    Evento.Nombre AS `Actividad`,
    TipoEvento.Nombre AS `Tipo de actividad`,
    GrupoEvento.Nombre AS `Evento`,
    DATE_FORMAT(Evento.Fecha, \"%d-%m-%Y\") as Fecha,
    Evento.HoraInicio as `Hora inicial`,
    Evento.HoraFinal as `Hora final`,
    EventoParticipante.Asistencia AS `Asistido`,
    EventoParticipante.Encuestado
FROM
    Participante inner join
    EventoParticipante on Participante.idParticipante=EventoParticipante.Participante_idParticipante inner join
    Evento on Evento.idEvento=EventoParticipante.Evento_idEvento inner join
    TipoEvento on TipoEvento.idTipoEvento=Evento.TipoEvento_idTipoEvento inner join
    GrupoEvento on GrupoEvento.idGrupoEvento=Evento.GrupoEvento_idGrupoEvento inner join
    Encuesta on Encuesta.idEncuesta=Evento.Encuesta_idEncuesta
WHERE
    `EstadoParticipante`=1 and Participante.`UsuarioParticipante` like '".$Usuario."'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Participante_ver_datos_usuario($usuario)
    {
    $this->Consulta="SELECT `idParticipante`, `Participante`.`Nombre` as `Participante`, `Carne`, `Semestre_idSemestre`,Semestre.Semestre, `Foto`, `Talla`, `Genero`, `PlayeraEntregada`, `CertificadoEntregado`, `GrupoEvento_idGrupoEvento`,GrupoEvento.Nombre, `EstadoParticipante`, `Jornada_idJornada`,Jornada.Jornada, `Seccion_idSeccion`,Seccion.Seccion, `UsuarioParticipante`
FROM
    `Participante` inner join
        `GrupoEvento` on `Participante`.`GrupoEvento_idGrupoEvento`=`GrupoEvento`.`idGrupoEvento` inner join
        `Semestre` on Participante.`Semestre_idSemestre`=Semestre.idSemestre inner join
        `Seccion` on Participante.`Seccion_idSeccion`=Seccion.idSeccion inner join
        `Jornada` on Participante.`Jornada_idJornada`=Jornada.idJornada
WHERE
	`EstadoParticipante`=1 and `UsuarioParticipante` like '".$usuario."'";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Participante_encuestado($idParticipante,$idEvento)
    {
        $this->Consulta="UPDATE `EventoParticipante` SET `Encuestado`=1 WHERE `Participante_idParticipante`=".$idParticipante." AND `Evento_idEvento`=".$idEvento;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }
//Encuesta,Pregunta,OpcionMultiple,respuesta
   function Encuesta_ver($filtro)
    {
        $this->Consulta="SELECT `idEncuesta`, @n := @n + 1 AS `No.`, `TituloEncuesta` AS `Encuesta`,`Descripcion` AS `Descripción`,`EstadoEncuesta` AS `Habilitado` FROM (select @n:=0) initvars, `Encuesta` WHERE `TituloEncuesta` LIKE '%$filtro%'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Encuesta_verificar_titulo($titulo)
    {
        $this->Consulta="SELECT COUNT(`idEncuesta`) as `cantidad` FROM `Encuesta` WHERE `TituloEncuesta` like '".$titulo."'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }
    function Encuesta_nueva($titulo,$descripcion)
    {
        $this->Consulta="INSERT INTO `Encuesta` (`TituloEncuesta`, `Descripcion`) VALUES ('".$titulo."', '".$descripcion."')";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
        else
        {
            $this->Consulta="SELECT LAST_INSERT_ID() as id";
            $this->Resultado = mysql_query($this->Consulta,$this->c);
            if (!$this->Resultado) {
                $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
            	$message .= '<br>Consulta completa: ' . $this->Consulta;
        		die($message);
		    }
        }
    }
	//uso en:Encuesta_resultado.php
    function Encuesta_ver_datos($idEncuesta)
    {
        $this->Consulta="SELECT `TituloEncuesta`,`Descripcion` FROM `Encuesta` WHERE `idEncuesta`=".$idEncuesta." LIMIT 1";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Encuesta_ver_preguntas($idEncuesta)
    {
        $this->Consulta="SELECT `idPregunta`,`Pregunta`,`TipoRespuesta` FROM `Pregunta` WHERE `Encuesta_idEncuesta`=".$idEncuesta." ORDER BY `idPregunta` ASC";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
		}
    }
    //uso en /BLL/eliminar.php función para verificar a cuantos eventos esta asignado esta encuesta.
    function Encuesta_cantidad_asignado($idEncuesta){
        $this->Consulta="SELECT COUNT(`idEvento`) AS `Cantidad` FROM `Evento` WHERE `Encuesta_idEncuesta`=".$idEncuesta;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Encuesta_eliminar($idEncuesta)
    {
        $this->Consulta="DELETE FROM `Encuesta` WHERE `idEncuesta`=".$idEncuesta;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Encuesta_contestado($idParticipante,$idEvento)
    {
        //UPDATE `EventoParticipante` SET `Encuestado`=1 WHERE `Participante_idParticipante`=1 and `Evento_idEvento`=1
        $this->Consulta="UPDATE `EventoParticipante` SET `Encuestado`=1 WHERE `Participante_idParticipante`=".$idParticipante." and `Evento_idEvento`=".$idEvento;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }
    function Pregunta_nueva($pregunta,$TipoRespuesta,$idEncuesta)
    {
        $this->Consulta="INSERT INTO `Pregunta` (`Pregunta`, `TipoRespuesta`, `Encuesta_idEncuesta`) VALUES ('".$pregunta."', '".$TipoRespuesta."', '".$idEncuesta."')";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
        else
        {
            $this->Consulta="SELECT LAST_INSERT_ID() as id";
            $this->Resultado = mysql_query($this->Consulta,$this->c);
            if (!$this->Resultado) {
                $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
                $message .= '<br>Consulta completa: ' . $this->Consulta;
        		die($message);
		    }
        }
    }
    function Pregunta_ver_opciones($idPregunta)
    {
        $this->Consulta="SELECT `idOpcionMultiple`,`Opcion` FROM `OpcionMultiple` WHERE `Pregunta_idPregunta`=".$idPregunta." ORDER BY `idOpcionMultiple` ASC";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
		}
    }
    function Pregunta_ver_respuestas($idPregunta)
    {
        $this->Consulta="SELECT `Valor`, COUNT( `Valor` ) AS `TotalRespuestas` FROM `Respuesta` WHERE `Pregunta_idPregunta`=".$idPregunta;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
		}
    }
    function Pregunta_ver_respuestas_multiples($idOpcionMultiple)
    {
        $this->Consulta="SELECT `Valor` , COUNT( `Valor` ) AS `Cantidad` FROM `Respuesta` WHERE `Valor` = ".$idOpcionMultiple;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
    	}
    }
    function Pregunta_eliminar($idEncuesta)
    {
        $this->Consulta="DELETE FROM `Pregunta` WHERE `Encuesta_idEncuesta`=".$idEncuesta;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function OpcionMultiple_nueva($opcion,$idPregunta)
    {
        $this->Consulta="INSERT INTO `OpcionMultiple` (`Opcion`, `Pregunta_idPregunta`) VALUES ('".$opcion."', '".$idPregunta."')";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }
    function OpcionMultiple_eliminar($idPregunta)
    {
        $this->Consulta="DELETE FROM `OpcionMultiple` WHERE `Pregunta_idPregunta`=".$idPregunta;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }
    function Respuesta_nueva($idPregunta,$respuesta,$idParticipante)
    {
        $this->Consulta="INSERT INTO `Respuesta` (`idRespuesta`, `Valor`, `Pregunta_idPregunta`, `Participante_idParticipante`) VALUES (NULL, '".$respuesta."', '".$idPregunta."', '".$idParticipante."');";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
		}
    }
    function Respuesta_eliminar($idPregunta)
    {
        $this->Consulta="DELETE FROM `Respuesta` WHERE `Pregunta_idPregunta`=".$idPregunta;
        if (!mysql_query($this->Consulta,$this->c)) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
//TipoEvento
    function TipoEvento_insertar($nombre,$estado)
	{
		$this->Consulta=("INSERT INTO `TipoEvento`(`Nombre`, `Estado`) VALUES ('".$nombre."', '".$estado."')");
		$this->Resultado=mysql_query($this->Consulta,$this->c);
		 if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
    function TipoEvento_ver(){
        $this->Consulta="SELECT * FROM TipoEvento where Estado=1 order by Nombre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

    function TipoEvento_ver_lista($idGrupo)
    {
        $this->Consulta="SELECT `TipoEvento_idTipoEvento` as `id`, `TipoEvento`.Nombre `nombre`
FROM
    `TipoEventoCantidad` inner join
        `TipoEvento` on `TipoEventoCantidad`.`TipoEvento_idTipoEvento`=`TipoEvento`.idTipoEvento
WHERE
	`TipoEvento`.Estado=1 and `GrupoEvento_idGrupoEvento`=".$idGrupo;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }

function TipoEventoCantidad_verificar($id){
        $this->Consulta="SELECT * 
FROM TipoEventoCantidad
WHERE TipoEvento_idTipoEvento =".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

function TipoEvento_verificar($nombre){
        $this->Consulta="SELECT * 
FROM TipoEvento
WHERE Nombre ='".$nombre."'";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

function TipoEvento_verificar_editar($id,$nombre){
        $this->Consulta="SELECT * 
FROM TipoEvento
WHERE idTipoEvento!=".$id." and Nombre ='".$nombre."'";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);

        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}


   function TipoEvento_ver_datos($id){
        $this->Consulta="SELECT * FROM TipoEvento where idTipoEvento=".$id."";
		$this->Resultado = mysql_query($this->Consulta,$this->c);
       if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
//TerminaTipoEvento
//asignaciones
function Jornada_verificacion_simple($id,$jor){
        $this->Consulta="SELECT * 
FROM  `EventoJornada` 
WHERE Evento_idEvento =".$id."
AND Jornada_idJornada=".$jor;
		$this->Resultado = mysql_query($this->Consulta,$this->c);
       if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

function Seccion_verificacion_simple($id,$sec){
        $this->Consulta="SELECT * 
FROM  `EventoSeccion` 
WHERE Evento_idEvento =".$id."
AND Seccion_idSeccion=".$sec;
		$this->Resultado = mysql_query($this->Consulta,$this->c);
       if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

function Semestre_verificacion_simple($id,$sem){
        $this->Consulta="SELECT * 
FROM  `EventoSemestre` 
WHERE Evento_idEvento =".$id."
AND Semestre_idSemestre =".$sem;
		$this->Resultado = mysql_query($this->Consulta,$this->c);
       if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

function Personal_ver_simple($id,$per){
        $this->Consulta="SELECT * 
FROM  `EventoPersonal` 
WHERE Evento_idEvento =".$id."
AND Personal_idPersonal =".$per;
		$this->Resultado = mysql_query($this->Consulta,$this->c);
       if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

 function Personal_ver_grupo($id){
        $this->Consulta="SELECT * 
FROM  `EventoPersonal` 
INNER JOIN Personal ON EventoPersonal.Personal_idPersonal = Personal.idPersonal
WHERE Personal.GrupoEvento_idGrupoEvento =".$id;
		$this->Resultado = mysql_query($this->Consulta,$this->c);
       if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

function EventoLugar_verificacion_asignados_especifico($id,$lu,$fecha,$horai,$horaf)
    {
            $this->Consulta="SELECT * 
FROM EventoLugar
INNER JOIN Evento ON EventoLugar.Evento_idEvento = Evento.idEvento
WHERE Evento.GrupoEvento_idGrupoEvento =".$id."
AND EventoLugar.Lugar_idLugar =".$lu."
AND Evento.Fecha =  '".$fecha."'
AND (
Evento.HoraInicio
BETWEEN  '".$horai."'
AND  '".$horaf."'
OR Evento.HoraFinal
BETWEEN  '".$horai."'
AND  '".$horaf."'
)";
        	$this->Resultado=mysql_query($this->Consulta,$this->c);
	   	    if (!$this->Resultado) {
                $message  = '<br>Educador ya asignado';
        	/*$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;*/
    		die($message);
		}
    }


function Evento_ver_Lugar_simple($id,$lu)
    {
            $this->Consulta="SELECT * 
FROM EventoLugar
Where Lugar_idLugar=".$lu." and Evento_idEvento=".$id;
        	$this->Resultado=mysql_query($this->Consulta,$this->c);
	   	    if (!$this->Resultado) {
                $message  = '<br>Educador ya asignado';
        	/*$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;*/
    		die($message);
		}
    }

function Lugar_eliminar($q)
    {
    	$this->Consulta=("DELETE FROM Lugar WHERE idLugar ='$q'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

function Lugar_verificarcantidad($id){
$this->Consulta="SELECT * 
FROM Lugar
WHERE idLugar = ".$id;
//AND GrupoEvento_idGrupoEvento =".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

function EventoEducador_verificacion_asignados_especifico($id,$edu,$grupo)
    {
            $this->Consulta="SELECT * 
FROM  `EventoEducador` 
INNER JOIN Evento ON EventoEducador.Evento_idEvento = Evento.idEvento
INNER JOIN GrupoEvento ON GrupoEvento.idGrupoEvento = Evento.GrupoEvento_idGrupoEvento
WHERE Evento_idEvento =".$id."
AND Educador_idEducador =".$edu."
AND Evento.GrupoEvento_idGrupoEvento =".$grupo;
        	$this->Resultado=mysql_query($this->Consulta,$this->c);
	   	    if (!$this->Resultado) {
                $message  = '<br>Educador ya asignado';
        	/*$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;*/
    		die($message);
		}
    }
function Educador_verificar_asignado($id)
    {
            $this->Consulta="SELECT EventoEducador.Educador_idEducador, Educador.Nombre AS  'Nombre del Educador', Educador.Telefono, Educador.Correo, Educador.GeneroEducador AS  'Género'
FROM  `EventoEducador` 
INNER JOIN Educador ON EventoEducador.Educador_idEducador = Educador.idEducador
WHERE Evento_idEvento =".$id;
        	$this->Resultado=mysql_query($this->Consulta,$this->c);
	   	    if (!$this->Resultado) {
                $message  = '<br>Educador ya asignado';
        	/*$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;*/
    		die($message);
		}
    }

function EventoEducador_verificar_asignado($id)
    {
            $this->Consulta="SELECT EventoEducador.Educador_idEducador, Educador.Nombre AS  'Nombre del Educador', Educador.Telefono as 'Teléfono', Educador.Correo, Educador.GeneroEducador AS  'Género'
FROM  `EventoEducador` 
INNER JOIN Educador ON EventoEducador.Educador_idEducador = Educador.idEducador
WHERE Educador_idEducador =".$id;
        	$this->Resultado=mysql_query($this->Consulta,$this->c);
	   	    if (!$this->Resultado) {
                $message  = '<br>Educador ya asignado';
        	/*$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;*/
    		die($message);
		}
    }


function EventoEducador_insertar($idevento, $ideducador)
    {
            $this->Consulta="INSERT INTO `EventoEducador`(`Educador_idEducador`, `Evento_idEvento`) VALUES ('".$ideducador."', '".$idevento."');";
        	$this->Resultado=mysql_query($this->Consulta,$this->c);
	   	    if (!$this->Resultado) {
                $message  = '<br>Educador ya asignado';
        	/*$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;*/
    		die($message);
		}
    }
function semestre_asignar($idevento,$idsemestre){
        $this->Consulta="INSERT INTO `EventoSemestre`(`Evento_idEvento`, `Semestre_idSemestre`) VALUES ('".$idevento."', '".$idsemestre."');";
		$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

function jornada_asignar($idevento,$idjornada){
        $this->Consulta="INSERT INTO `EventoJornada`(`Evento_idEvento`, `Jornada_idJornada`) VALUES ('".$idevento."', '".$idjornada."');";
		$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
    function Seccion_nueva($seccion)
    {
        $this->Consulta="INSERT INTO `Seccion` ( `Seccion`) VALUES ('".$seccion."')";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
function seccion_asignar($idevento,$idseccion){
        $this->Consulta="INSERT INTO `EventoSeccion`(`Evento_idEvento`, `Seccion_idSeccion`) VALUES ('".$idevento."', '".$idseccion."');";
		$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
    //para combobox
    function seccion_ver2(){
        $this->Consulta="SELECT  `idSeccion` AS  `id` ,  `Seccion` FROM  `Seccion` WHERE  `EstadoSeccion` =1";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

function Personal_verificar($id, $nombre)
   {
$this->Consulta="SELECT COUNT( * ) AS  'Conteo'
FROM Personal
WHERE Nombre =  '".$nombre."'
AND GrupoEvento_idGrupoEvento =".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
   }

function Personal_verificar_editar($id, $nombre,$per)
   {
$this->Consulta="SELECT COUNT( * ) AS  'Conteo'
FROM Personal
WHERE Nombre =  '".$nombre."'
and idPersonal != ".$per."
AND GrupoEvento_idGrupoEvento =".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
   }

function EventoPersonal_insertar($idEvento,$idPer,$Asis,$idLugar){
        $this->Consulta="INSERT INTO `EventoPersonal`(`Evento_idEvento`, `Personal_idPersonal`, `Asistencia`, `Lugar_idLugar`) VALUES (".$idEvento.",".$idPer.",".$Asis.",".$idLugar.");";
		$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

function Personal_contar_genero1($q){
    	$this->Consulta="Select Count(*) as Conteo 
from Personal 
where GeneroPersonal=1 and GrupoEvento_idGrupoEvento=".$q;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

function Personal_contar_genero0($q){
    	$this->Consulta=("Select Count(*) as Conteo 
from Personal 
where GeneroPersonal=0 and GrupoEvento_idGrupoEvento='$q'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

function Personal_contar_activo($q){
    	$this->Consulta="Select idPersonal, Nombre as 'Personal Activo'
from Personal
where EstadoPersonal=1 and GrupoEvento_idGrupoEvento=".$q." order by Nombre asc" ;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

function Personal_ver_descripcion2($id, $idgrupo){
$this->Consulta="SELECT Personal.Nombre,`Carnet`,`Telefono`,Jornada.Jornada, Seccion.Seccion FROM `Personal`  
INNER JOIN  `GrupoEvento` ON  `GrupoEvento`.idGrupoEvento =  `Personal`.GrupoEvento_idGrupoEvento 
INNER JOIN  `Seccion` ON  `Seccion`.idSeccion =  `Personal`.Seccion_idSeccion
INNER JOIN  `Jornada` ON  `Jornada`.idJornada =  `Personal`.Jornada_idJornada
WHERE Personal.idPersonal=".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

function Personal_eliminar($id)
     {
        $this->Consulta="DELETE FROM `Personal` WHERE idPersonal=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function Personal_ver_actividades($id){
$this->Consulta="SELECT Personal.Nombre as 'Nombre del Personal', Evento.Nombre as 'Nombre de la actividad', Evento.Imagen, DATE_FORMAT(`Evento`.Fecha, '%d/%m/%Y') as 'Fecha' FROM `Personal`   
INNER JOIN  `EventoPersonal` ON  EventoPersonal.Personal_idPersonal =  Personal.idPersonal
INNER JOIN  `Evento` ON  Evento.idEvento =  EventoPersonal.Evento_idEvento
WHERE Personal.idPersonal=".$id;
$this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

function Personal_ver_datos_modal($id){
$this->Consulta="SELECT * FROM `Personal`   
INNER JOIN  `Seccion` ON  `Seccion`.idSeccion =  `Personal`.Seccion_idSeccion
INNER JOIN  `Jornada` ON  `Jornada`.idJornada =  `Personal`.Jornada_idJornada
WHERE Personal.idPersonal=".$id;
$this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

function Personal_actualizar($id,$nom,$carnet,$tel,$disponible,$genero,$grupoid,$seccion,$jor)
	{
		$this->Consulta="UPDATE `Personal` SET `Nombre`='".$nom."',`Carnet`='".$carnet."',`Telefono`='".$tel."',`EstadoPersonal`=".$disponible." ,`GeneroPersonal`=".$genero.",`GrupoEvento_idGrupoEvento`=".$grupoid." , `Seccion_idSeccion`=".$seccion.", `Jornada_idJornada`=".$jor." WHERE idPersonal=".$id;
        	        if (!mysql_query($this->Consulta,$this->c)) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

function Personal_ver_datos($id)
     {
        $this->Consulta="SELECT * FROM Personal WHERE IdPersonal=".$id."";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }


function Semestre_actualizar($id,$sem,$disponible){
$this->Consulta="UPDATE `Semestre` SET `Semestre`='".$sem."',`EstadoSemestre`=".$disponible." WHERE idSemestre=".$id."";
        if (!mysql_query($this->Consulta,$this->c)) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}


function Lugar_asignar($idevento,$idlugar)
     {

        $this->Consulta="INSERT INTO `EventoLugar`(`Evento_idEvento`, `Lugar_idLugar`) VALUES (".$idevento.",".$idlugar.")";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function Lugar_actualizar($idlugar,$nombre,$capacidad,$disponible)
    {
        $this->Consulta="UPDATE `Lugar` 
                                    SET `Nombre`='".$nombre."',`Capacidad`='".$capacidad."',`Disponible`='".$disponible."' WHERE idLugar=".$idlugar."";
        if (!mysql_query($this->Consulta,$this->c)) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
//terminaasignareducador
//Educador
  
      function Educador_ver()
     {
        $this->Consulta="SELECT * FROM Educador order by Nombre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

      function Educador_verificar_nombre($nombre)
     {
        $this->Consulta="SELECT * FROM Educador where Nombre='".$nombre."' order by Nombre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

      function Educador_verificar_nombre_editar($id,$nombre)
     {
        $this->Consulta="SELECT * FROM Educador where idEducador!=".$id." and Nombre='".$nombre."' order by Nombre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function Educador_ver_detalle($id)
     {
        $this->Consulta="SELECT  `Educador`.idEducador,  `Educador`.Nombre AS  'Nombre del educador',  `Educador`.Telefono as 'Teléfono',  `Educador`.Correo,  `TipoEvento`.Nombre AS 'Tipo de actividad',  `Educador`.EstadoEducador AS 'Habilitado', `Educador`.HojaDeVida as 'Hoja de vida'
FROM  `Educador` 
INNER JOIN  `Personal` ON  `Educador`.Personal_idPersonal =  `Personal`.idPersonal
INNER JOIN  `TipoEvento` ON  `Educador`.TipoEvento_idTipoEvento =  `TipoEvento`.idTipoEvento
WHERE  `Educador`.Nombre LIKE '%$id%'";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function Educador_ver_datos($id)
     {
        $this->Consulta="SELECT  `Educador`.idEducador,  `Educador`.Nombre AS  'Nombre del Educador',  `Educador`.Telefono,  `Educador`.Correo,  `TipoEvento`.idTipoEvento, `TipoEvento`.Nombre AS 'Tipo del Evento',  `Educador`.Empresa,  `Educador`.PaisOrigen,  `Personal`.idPersonal, `Personal`.Nombre AS  'Nombre del Encargado',  `Educador`.EstadoEducador AS 'Habilitado', `Educador`.HojaDeVida
FROM  `Educador` 
INNER JOIN  `Personal` ON  `Educador`.Personal_idPersonal =  `Personal`.idPersonal
INNER JOIN  `TipoEvento` ON  `Educador`.TipoEvento_idTipoEvento =  `TipoEvento`.idTipoEvento
WHERE  idEducador= ".$id."";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function Educador_verificar_asignado_hora($id,$grupo,$fecha,$horai,$horaf)
    {
            $this->Consulta="SELECT E.idEducador, E.Nombre from Educador as E
where (E.idEducador not in(select Educador_idEducador as idEducador
FROM  `EventoEducador` 
WHERE Evento_idEvento =".$id."))
and
((SELECT count(*)
FROM  `EventoEducador` as EP
inner join Evento as E on EP.Evento_idEvento=E.idEvento
WHERE
E.GrupoEvento_idGrupoEvento=".$grupo."
AND  E.Fecha =  '.$Fecha.'
AND  ((E.HoraInicio
BETWEEN  '".$horai."'
AND  '".$horaf."')
or  (E.HoraFinal
BETWEEN  '".$horai."'
AND  '".$horaf."')))=0)";
        	$this->Resultado=mysql_query($this->Consulta,$this->c);
	   	    if (!$this->Resultado) {
$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }

function Educador_insertar($nombre,$telefono,$correo,$idtipoevento,$empresa,$pais,$idpersonal,$hojadevida)
{
$this->Consulta="INSERT INTO `Educador`(`Nombre`, `Telefono`, `Correo`, `TipoEvento_idTipoEvento`, `Empresa`, `PaisOrigen`, `Personal_idPersonal`, `HojaDeVida`) VALUES ('".$nombre."',".$telefono.",'".$correo."',".$idtipoevento.",'".$empresa."','".$pais."',".$idpersonal.",'".$hojadevida."')";
        if (!mysql_query($this->Consulta,$this->c)) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

function Educador_actualizar($idlugar,$nombre,$tel,$correo,$listaeve,$empresa,$pais,$listaenc,$estado,$hojadevida){
$this->Consulta="UPDATE `Educador` SET `Nombre`='".$nombre."',`Telefono`=".$tel.",`Correo`='".$correo."',`TipoEvento_idTipoEvento`=".$listaeve.",`Empresa`='".$empresa."',`PaisOrigen`='".$pais."',`Personal_idPersonal`=".$listaenc.",`EstadoEducador`=".$estado.", `HojaDeVida`='".$hojadevida."'  WHERE idEducador=".$idlugar."";
        if (!mysql_query($this->Consulta,$this->c)) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

function Lugar_ver()
     {
        $this->Consulta="SELECT * FROM Lugar order by Nombre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function Lugar_verificar($nombre)
     {
        $this->Consulta="SELECT * FROM Lugar where Nombre='".$nombre."' order by Nombre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }
function Lugar_verificar_editar($nombre,$id)
     {
        $this->Consulta="SELECT * FROM Lugar where Nombre='".$nombre."' and idLugar!=".$id." order by Nombre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }
     
function Lugar_ver_detalle($id)
     {
        $this->Consulta="SELECT idLugar, Nombre, Capacidad, Disponible as 'Habilitado' FROM Lugar WHERE Nombre LIKE '%$id%'";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function Lugar_verificacion($id,$fech,$horainicio)
     {
        $this->Consulta="SELECT * FROM `Lugar` 
INNER JOIN  `EventoLugar` ON  `Lugar`.idLugar =  `EventoLugar`.Lugar_idLugar
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoLugar`.Evento_idEvento
where `Lugar`.idLugar=".$id." and `Evento`.Fecha='".$fech."' and `Evento`.HoraInicio='".$horainicio."'";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }
function Lugar_verificacion_capacidad($id)
     {
        $this->Consulta="SELECT  `Lugar`.Capacidad FROM  `Lugar`
WHERE  `Lugar`.idLugar =".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }
function Lugar_ver_datos($id)
     {
        $this->Consulta="SELECT * FROM Lugar WHERE idLugar=".$id."";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);

        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

//TerminaEducador marco, tienes  un error con las comillas, por favor corrige eso y luego quita el comentario

    function Personal_insertar($nombre,$carnet,$tel,$idFoto,$genero,$estado,$grupoid,$seccion,$jor)
    {
            $this->Consulta="INSERT INTO `Personal`(`Nombre`, `Carnet`, `Telefono`, `Foto`, `GeneroPersonal`, `EstadoPersonal`, `GrupoEvento_idGrupoEvento`, `Seccion_idSeccion`, `Jornada_idJornada`) VALUES ('".$nombre."',".$carnet.",".$tel.",".$idFoto.",".$genero.",".$estado.",".$grupoid.",".$seccion.",".$jor.");";
        	$this->Resultado=mysql_query($this->Consulta,$this->c);
	   	if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }

   function Personal_ver_detalle($id,$idgrupo)
     {
        $this->Consulta="SELECT `Personal`.idPersonal, `Personal`.Nombre as 'Nombre del personal', `Personal`.Carnet as 'Carné', `Personal`.Telefono as 'Teléfono', `Personal`.GeneroPersonal as 'Género', `Seccion`.Seccion as 'Sección', `Jornada`.Jornada, `Personal`.EstadoPersonal as 'Disponible' FROM `Personal` 
INNER JOIN  `GrupoEvento` ON  `GrupoEvento`.idGrupoEvento =  `Personal`.GrupoEvento_idGrupoEvento 
INNER JOIN  `Seccion` ON  `Seccion`.idSeccion =  `Personal`.Seccion_idSeccion
INNER JOIN  `Jornada` ON  `Jornada`.idJornada =  `Personal`.Jornada_idJornada
WHERE `Personal`.Nombre LIKE '%$id%' AND GrupoEvento_idGrupoEvento=".$idgrupo;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

    function Evento_insertar($nombre, $idtipoevento, $fecha, $hinicio, $hfinal, $idgrupo, $idpersonal, $idencuesta, $costo,$descripcion,$imagen)
    {
        $this->Consulta="INSERT INTO `Evento` (`Nombre`, `DescripcionEvento`, `TipoEvento_idTipoEvento`, `Fecha`, `HoraInicio`, `HoraFinal`, `GrupoEvento_idGrupoEvento`, `Personal_idPersonal_Encargado`, `Encuesta_idEncuesta`,`Costo`,`Imagen`) 
                                           VALUES ('".$nombre."', '".$descripcion."','".$idtipoevento."', '".$fecha."', '".$hinicio."', '".$hfinal."', ".$idgrupo.", '".$idpersonal."', '".$idencuesta."', '".$costo."','".$imagen."');";
		$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Evento_lugar_disponible($idEvento)
    {
        $this->Consulta="SELECT L.idLugar,L.Nombre as `Lugar`,L.Capacidad,(L.Capacidad-(SELECT COUNT(`Lugar_idLugar`) FROM `EventoParticipante` WHERE `Lugar_idLugar`=EL.`Lugar_idLugar`)) as `Disponible`
FROM `EventoLugar` as EL inner join
    `Lugar` as L on EL.`Lugar_idLugar`=L.idLugar
WHERE
    L.Disponible=1 and
	EL.`Evento_idEvento`=".$idEvento;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
   function Evento_verificar($id, $nombre)
   {
$this->Consulta="SELECT COUNT( * ) AS  'Conteo'
FROM Evento
WHERE Nombre =  '".$nombre."'
AND GrupoEvento_idGrupoEvento =".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
   }
function Evento_verificar_editar($id, $nombre,$idg)
   {
$this->Consulta="SELECT * 
FROM  `Evento` 
WHERE Nombre =  '".$nombre."'
AND GrupoEvento_idGrupoEvento =".$idg."
AND idEvento !=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
   }

   function Evento_disponibles_participante($idParticipante,$idGrupo,$idTipoEvento)
   {
       $this->Consulta="SELECT E1.`idEvento`,E1.`Nombre` as `Actividad`,E1.`DescripcionEvento` as `Descripción`,E1.`Fecha`,E1.`HoraInicio` as `Hora de inicio`,E1.`HoraFinal` as `Hora final`,E1.`Costo` as `Costo extra`
FROM `Evento` as E1 inner join
    `TipoEvento` as TE1 on E1.`TipoEvento_idTipoEvento`=TE1.idTipoEvento left join
        `EventoJornada` EJ1 on E1.idEvento=EJ1.Evento_idEvento left join
        `EventoSeccion` ES1 on E1.idEvento=ES1.Evento_idEvento
WHERE
    `EstadoEvento`=1 and
        `GrupoEvento_idGrupoEvento`=".$idGrupo." and
        TE1.idTipoEvento=".$idTipoEvento." and
        E1.idEvento not in
        (
        SELECT E2.idEvento 
	FROM `EventoParticipante` as EP2 inner join 
		Evento E2 on EP2.`Evento_idEvento`=E2.idEvento 
	where
        	E2.EstadoEvento=1 and
		EP2.`Participante_idParticipante`=".$idParticipante." and
        	E2.`TipoEvento_idTipoEvento`=".$idTipoEvento."
        ) and
        E1.`Fecha` not in
        (
        	SELECT E3.Fecha
		FROM `EventoParticipante` as EP3 inner join 
			Evento E3 on EP3.`Evento_idEvento`=E3.idEvento 
		where 
			E3.EstadoEvento=1 and
			EP3.`Participante_idParticipante`=".$idParticipante." and
        		E3.`TipoEvento_idTipoEvento`=".$idTipoEvento." and
                	(E1.`HoraInicio` between E3.`HoraInicio` and E3.`HoraFinal` or
                	E1.`HoraFinal` between E3.`HoraInicio` and E3.`HoraFinal` or
                	E3.`HoraInicio` between E1.`HoraInicio` and E1.`HoraFinal` or
                	E3.`HoraFinal` between E1.`HoraInicio` and E1.`HoraFinal`)
        ) and
        (
        	EJ1.Jornada_idJornada=(SELECT `Jornada_idJornada` FROM `Participante` WHERE `idParticipante`=".$idParticipante." LIMIT 1) or
        	(EJ1.Jornada_idJornada is null and EJ1.Evento_idEvento is null)
        ) and
        (
        	ES1.Seccion_idSeccion=(SELECT `Seccion_idSeccion` FROM `Participante` WHERE `idParticipante`=".$idParticipante." LIMIT 1) or
                (ES1.Seccion_idSeccion is null and ES1.Evento_idEvento is null)
        )
ORDER BY
	E1.`Fecha`,E1.`HoraInicio`";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
   }
   function EventoParticipante_nuevo($idParticipante,$idEvento,$idLugar,$extra)
   {
       $c1=0;
       if($extra==1)
       {
            $this->Consulta="SELECT `Costo` FROM `Evento` WHERE `idEvento`=".$idEvento;
            $this->Resultado = mysql_query($this->Consulta,$this->c);
            $costo=mysql_fetch_assoc($this->Resultado);
            $c1=$costo["Costo"];
       }
        $this->Consulta="INSERT INTO `EventoParticipante`(`Participante_idParticipante`, `Evento_idEvento`, `Lugar_idLugar`, `Costo`) VALUES (".$idParticipante.",".$idEvento.",".$idLugar.",".$c1.")";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
   }
   function EventoParticipante_eliminar2($idParticipante,$idEvento)
   {
        $this->Consulta="DELETE FROM `EventoParticipante` WHERE `Participante_idParticipante`=".$idParticipante." and `Evento_idEvento`=".$idEvento;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
   }
   
function EventoParticipante_comprobar($id,$evento)
    {
        $this->Consulta="SELECT  `EventoParticipante`.Participante_idParticipante,  `Participante`.Nombre AS  'Nombre del Participante',  `Participante`.Carne,  `Semestre`.Semestre,  `Participante`.Foto,  `Lugar`.Nombre AS 'Nombre del Lugar',  `EventoParticipante`.Asistencia
FROM  `EventoParticipante` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoParticipante`.Evento_idEvento
INNER JOIN  `Participante` ON  `EventoParticipante`.Participante_idParticipante =  `Participante`.idParticipante
INNER JOIN  `Semestre` ON  `Participante`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `EventoSemestre` ON  `EventoSemestre`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `Lugar` ON  `EventoParticipante`.Lugar_idLugar =  `Lugar`.idLugar
WHERE  `EventoSemestre`.Semestre_idSemestre =  `Participante`.Semestre_idSemestre
AND  `EventoParticipante`.Participante_idParticipante=".$id." AND `EventoParticipante`.Evento_idEvento=".$evento;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }

function EventoParticipante_comprobar2($id,$evento)
    {
        $this->Consulta="SELECT  `EventoParticipante`.Participante_idParticipante,  `Participante`.Nombre AS  'Nombre del Participante',  `Participante`.Carne,  `Semestre`.Semestre,  `Participante`.Foto,  `Lugar`.Nombre AS 'Nombre del Lugar',  `EventoParticipante`.Asistencia
FROM  `EventoParticipante` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoParticipante`.Evento_idEvento
INNER JOIN  `Participante` ON  `EventoParticipante`.Participante_idParticipante =  `Participante`.idParticipante
INNER JOIN  `Semestre` ON  `Participante`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `Lugar` ON  `EventoParticipante`.Lugar_idLugar =  `Lugar`.idLugar
WHERE  `EventoParticipante`.Participante_idParticipante =".$id."
AND  `EventoParticipante`.Evento_idEvento =".$evento;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }

function EventoParticipante_comprobar3($id,$evento)
    {
        $this->Consulta="SELECT  `EventoParticipante`.Participante_idParticipante,  `Participante`.Nombre AS  'Nombre del Participante',  `Participante`.Carne,  `Semestre`.Semestre,  `Participante`.Foto,  `Lugar`.Nombre AS 'Nombre del Lugar',  `EventoParticipante`.Asistencia
FROM  `EventoParticipante` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoParticipante`.Evento_idEvento
INNER JOIN  `Participante` ON  `EventoParticipante`.Participante_idParticipante =  `Participante`.idParticipante
INNER JOIN  `Semestre` ON  `Participante`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `Lugar` ON  `EventoParticipante`.Lugar_idLugar =  `Lugar`.idLugar
WHERE  `EventoParticipante`.Participante_idParticipante =".$id."
AND  `Evento`.TipoEvento_idTipoEvento=".$evento;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
function TipoEventoCantidad_ver_grupoper($grupo,$tipo)
    {
        $this->Consulta="SELECT * 
FROM TipoEventoCantidad
WHERE TipoEvento_idTipoEvento =".$tipo."
and GrupoEvento_idGrupoEvento=".$grupo;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }

//Necesarias
function Evento_verificar_fechahif($ide, $fecha,$horai,$horaf)
   {
$this->Consulta="SELECT * 
FROM  `Evento` 
WHERE  `Evento`.idEvento !=".$ide."
AND  `Evento`.Fecha =  '".$fecha."'
AND  `Evento`.HoraInicio
BETWEEN  '".$horai."'
AND  '".$horaf."'
AND  `Evento`.HoraFinal
BETWEEN  '".$horai."'
AND  '".$horaf."'";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
   }

function Evento_verificar_costo($ide, $tipoevento,$idParticipante)
   {
$this->Consulta="SELECT  `Evento`.Costo,  `TipoEventoCantidad`.Cantidad
FROM  `Evento` 
INNER JOIN  `TipoEventoCantidad` ON  `Evento`.GrupoEvento_idGrupoEvento =  `TipoEventoCantidad`.GrupoEvento_idGrupoEvento
INNER JOIN  `GrupoEvento` ON  `Evento`.GrupoEvento_idGrupoEvento =  `GrupoEvento`.idGrupoEvento
INNER JOIN  `EventoParticipante` ON  `Evento`.idEvento =  `EventoParticipante`.Evento_idEvento
WHERE  `Evento`.idEvento =".$ide."
AND  `EventoParticipante`.Participante_idParticipante =".$idParticipante."
AND  `TipoEventoCantidad`.TipoEvento_idTipoEvento =".$tipoevento;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
   }
   function Evento_ver_detalle($idEvento)
   {
        $this->Consulta="SELECT `idEvento`, `Evento`.Nombre AS `Evento`, `DescripcionEvento`, `TipoEvento`.Nombre AS `TipoEvento`, DATE_FORMAT(Evento.Fecha,'%d/%m/%Y') as 'Fecha', `HoraInicio`, `HoraFinal`, `GrupoEvento`.Nombre AS `GrupoEvento`, `Personal_idPersonal_Encargado`, `Encuesta_idEncuesta`, `Costo`, `Imagen`, `EstadoEvento` \n"
    . "FROM \n"
    . "`Evento` INNER JOIN\n"
    . "`TipoEvento` ON `Evento`.TipoEvento_idTipoEvento = `TipoEvento`.idTipoEvento INNER JOIN\n"
    . "`GrupoEvento` ON `GrupoEvento`.idGrupoEvento = `Evento`.GrupoEvento_idGrupoEvento\n"
    . "WHERE"
    . "    `idEvento`=".$idEvento;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
   }
    function Evento_ver()
     {
        $this->Consulta="SELECT * FROM Evento order by Nombre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }
    function Evento_ver_datos($id)
     {
        $this->Consulta="SELECT  `Evento`.idEvento,  `Evento`.Nombre,  `Evento`.DescripcionEvento,  `Evento`.TipoEvento_idTipoEvento,
 `TipoEvento`.Nombre AS  'NombreTipoEvento',  `Evento`.Fecha,  `Evento`.HoraInicio,  `Evento`.HoraFinal, `Evento`.GrupoEvento_idGrupoEvento,
  `GrupoEvento`.Nombre AS  'GrupoEventoNombre',  `Evento`.Personal_idPersonal_Encargado,  `Personal`.Nombre as 'NombrePersonal',  `Evento`.Encuesta_idEncuesta,  `Encuesta`.TituloEncuesta,  `Evento`.Costo, `Evento`.Imagen,  `Evento`.EstadoEvento
FROM  `Evento` 
INNER JOIN  `Personal` ON  `Evento`.Personal_idPersonal_Encargado =  `Personal`.idPersonal
INNER JOIN  `Encuesta` ON  `Evento`.Encuesta_idEncuesta =  `Encuesta`.idEncuesta
INNER JOIN  `TipoEvento` ON  `Evento`.TipoEvento_idTipoEvento =  `TipoEvento`.idTipoEvento
INNER JOIN  `GrupoEvento` ON  `Evento`.GrupoEvento_idGrupoEvento =  `GrupoEvento`.idGrupoEvento
WHERE  `Evento`.idEvento =".$id."";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function Evento_ver_datos2($id)
     {
        $this->Consulta="SELECT  `Evento`.idEvento,  `Evento`.Nombre,  `Evento`.DescripcionEvento,  `Evento`.TipoEvento_idTipoEvento,
 `TipoEvento`.Nombre AS  'NombreTipoEvento',  `Evento`.Fecha,  `Evento`.HoraInicio,  `Evento`.HoraFinal, `Evento`.GrupoEvento_idGrupoEvento,
  `GrupoEvento`.Nombre AS  'GrupoEventoNombre',  `Evento`.Personal_idPersonal_Encargado,  `Personal`.Nombre as 'NombrePersonal',  `Evento`.Encuesta_idEncuesta,   `Evento`.Costo, `Evento`.Imagen,  `Evento`.EstadoEvento
FROM  `Evento` 
INNER JOIN  `Personal` ON  `Evento`.Personal_idPersonal_Encargado =  `Personal`.idPersonal
INNER JOIN  `TipoEvento` ON  `Evento`.TipoEvento_idTipoEvento =  `TipoEvento`.idTipoEvento
INNER JOIN  `GrupoEvento` ON  `Evento`.GrupoEvento_idGrupoEvento =  `GrupoEvento`.idGrupoEvento
WHERE  `Evento`.idEvento =".$id."";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function Evento_ver_datos_simple($id,$grupo)
     {
        $this->Consulta="SELECT * 
FROM Evento
WHERE GrupoEvento_idGrupoEvento=".$grupo." and Nombre ='".$id."'";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
     }
function Evento_ver_grupo($tipo,$grupo)
     {
        $this->Consulta="SELECT *
FROM Evento
WHERE TipoEvento_idTipoEvento =".$tipo."
AND GrupoEvento_idGrupoEvento =".$grupo;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
     }

function Evento_ver_grupo_solo($grupo)
     {
        $this->Consulta="SELECT `Evento`.idEvento, `Evento`.Nombre AS  'Nombre Actividad', `Evento`.DescripcionEvento,  DATE_FORMAT(`Evento`.Fecha, '%d/%m/%Y') as 'Fecha', 
                                    `Evento`.HoraInicio, `Evento`.HoraFinal, `Evento`.Imagen
FROM Evento
WHERE GrupoEvento_idGrupoEvento =".$grupo;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
     }

function Educador_vertipo($id)
     {
        $this->Consulta="SELECT  `Educador`.idEducador,  `Educador`.Nombre
        FROM  `Educador` 
        INNER JOIN  `TipoEvento` ON  `Educador`.TipoEvento_idTipoEvento =  `TipoEvento`.idTipoEvento
        INNER JOIN  `Evento` ON  `TipoEvento`.idTipoEvento =  `Evento`.TipoEvento_idTipoEvento
       where `Evento`.idEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }

    function Evento_actualizar($id,$nombre,$tipo,$fecha,$horai,$horaf,$grupo,$personal,$encuesta,$costo,$descripcion,$imagen)
    {
        $this->Consulta="UPDATE `Evento` 
                                    SET `Nombre`='".$nombre."',`TipoEvento_idTipoEvento`='".$tipo."',`Fecha`='".$fecha."',
                                    `HoraInicio`='".$horai."',`HoraFinal`='".$horaf."',`GrupoEvento_idGrupoEvento`='".$grupo."',`Personal_idPersonal_Encargado`='".$personal."',
                                    `Encuesta_idEncuesta`='".$encuesta."', `Costo`='".$costo."', `DescripcionEvento`='".$descripcion."', `Imagen`='".$imagen."' WHERE idEvento=".$id."";
        if (!mysql_query($this->Consulta,$this->c)) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }

     function Evento_vertipo()
     {
        $this->Consulta="SELECT  `Evento`.idEvento,  `Evento`.Nombre, `Educador`.idEducador
        FROM  `Evento` 
        INNER JOIN  `TipoEvento` ON  `Evento`.TipoEvento_idTipoEvento =  `TipoEvento`.idTipoEvento
        INNER JOIN  `Educador` ON  `TipoEvento`.idTipoEvento =  `Educador`.TipoEvento_idTipoEvento";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
function TipoEvento_ver_participantes($tipo,$grupo){
        $this->Consulta="select * from TipoEvento as TE
inner join Evento as E on E.TipoEvento_idTipoEvento = TE.idTipoEvento
inner join EventoParticipante as EP on EP.Evento_idEvento = E.idEvento
where TE.idTipoEvento=".$tipo."
and E.GrupoEvento_idGrupoEvento=".$grupo;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
function participante_ver_grupo($grupo){
        $this->Consulta="select * from Participante
where GrupoEvento_idGrupoEvento=".$grupo;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
function participante_ver_grupo_asistencia($grupo){
        $this->Consulta="SELECT P.idParticipante, P.Nombre, P.Carne, S.Semestre, J.Jornada, Se.Seccion
FROM  `Participante` AS P
INNER JOIN Semestre AS S ON S.idSemestre = P.Semestre_idSemestre
INNER JOIN Jornada AS J ON J.idJornada = P.Jornada_idJornada
INNER JOIN Seccion AS Se ON Se.idSeccion = P.Seccion_idSeccion
WHERE P.GrupoEvento_idGrupoEvento =".$grupo."
ORDER BY P.Jornada_idJornada, P.Semestre_idSemestre, P.Seccion_idSeccion";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
function participante_ver_grupo_jornada($grupo,$jor){
        $this->Consulta="SELECT P.idParticipante, P.Nombre, P.Carne, S.Semestre, J.Jornada, Se.Seccion
FROM  `Participante` as P
INNER JOIN Semestre AS S ON S.idSemestre = P.Semestre_idSemestre
INNER JOIN Jornada AS J ON J.idJornada = P.Jornada_idJornada
INNER JOIN Seccion AS Se ON Se.idSeccion = P.Seccion_idSeccion 
WHERE P.GrupoEvento_idGrupoEvento =".$grupo."
AND P.Jornada_idJornada =".$jor;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
function participante_ver_grupo_semestre($grupo,$jor){
        $this->Consulta="SELECT P.idParticipante, P.Nombre, P.Carne, S.Semestre, J.Jornada, Se.Seccion
FROM  `Participante` as P
INNER JOIN Semestre AS S ON S.idSemestre = P.Semestre_idSemestre
INNER JOIN Jornada AS J ON J.idJornada = P.Jornada_idJornada
INNER JOIN Seccion AS Se ON Se.idSeccion = P.Seccion_idSeccion 
WHERE P.GrupoEvento_idGrupoEvento =".$grupo."
AND P.Semestre_idSemestre=".$jor;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
function participante_ver_grupo_seccion($grupo,$jor){
        $this->Consulta="SELECT P.idParticipante, P.Nombre, P.Carne, S.Semestre, J.Jornada, Se.Seccion
FROM  `Participante` as P
INNER JOIN Semestre AS S ON S.idSemestre = P.Semestre_idSemestre
INNER JOIN Jornada AS J ON J.idJornada = P.Jornada_idJornada
INNER JOIN Seccion AS Se ON Se.idSeccion = P.Seccion_idSeccion 
WHERE P.GrupoEvento_idGrupoEvento =".$grupo."
AND P.Seccion_idSeccion=".$jor;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}


function participante_ver_grupo_jornada2($grupo,$jor,$eve){
        $this->Consulta="SELECT P.idParticipante, P.Nombre, P.Carne, S.Semestre, J.Jornada, Se.Seccion,Ep.Asistencia
FROM  `Participante` AS P
INNER JOIN Semestre AS S ON S.idSemestre = P.Semestre_idSemestre
INNER JOIN Jornada AS J ON J.idJornada = P.Jornada_idJornada
INNER JOIN Seccion AS Se ON Se.idSeccion = P.Seccion_idSeccion
INNER JOIN EventoParticipante AS Ep ON P.idParticipante = Ep.Participante_idParticipante
WHERE P.GrupoEvento_idGrupoEvento =".$grupo."
AND Ep.Evento_idEvento =".$eve."
AND P.Jornada_idJornada =".$jor;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
function participante_ver_grupo_semestre2($grupo,$jor,$eve){
        $this->Consulta="SELECT P.idParticipante, P.Nombre, P.Carne, S.Semestre, J.Jornada, Se.Seccion,Ep.Asistencia
FROM  `Participante` AS P
INNER JOIN Semestre AS S ON S.idSemestre = P.Semestre_idSemestre
INNER JOIN Jornada AS J ON J.idJornada = P.Jornada_idJornada
INNER JOIN Seccion AS Se ON Se.idSeccion = P.Seccion_idSeccion
INNER JOIN EventoParticipante AS Ep ON P.idParticipante = Ep.Participante_idParticipante
WHERE P.GrupoEvento_idGrupoEvento =".$grupo."
AND Ep.Evento_idEvento =".$eve."
AND P.Semestre_idSemestre =".$jor;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
function participante_ver_grupo_seccion2($grupo,$jor,$eve){
        $this->Consulta="SELECT P.idParticipante, P.Nombre, P.Carne, S.Semestre, J.Jornada, Se.Seccion,Ep.Asistencia
FROM  `Participante` AS P
INNER JOIN Semestre AS S ON S.idSemestre = P.Semestre_idSemestre
INNER JOIN Jornada AS J ON J.idJornada = P.Jornada_idJornada
INNER JOIN Seccion AS Se ON Se.idSeccion = P.Seccion_idSeccion
INNER JOIN EventoParticipante AS Ep ON P.idParticipante = Ep.Participante_idParticipante
WHERE P.GrupoEvento_idGrupoEvento =".$grupo."
AND Ep.Evento_idEvento =".$eve."
AND P.Seccion_idSeccion =".$jor;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
    //Descripcionesevento todas las busquedas se hacen por idEvento
    function Evento_ver_educador($id)
    {
        $this->Consulta="SELECT  `Educador`.idEducador,  `Educador`.Nombre as 'Nombre del educador',  `Educador`.Telefono,  `Educador`.Correo,  `Educador`.Empresa,  `Educador`.PaisOrigen as 'País de origen'
                        FROM  `EventoEducador` 
                        INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoEducador`.Evento_idEvento
                        INNER JOIN  `Educador` ON  `EventoEducador`.Educador_idEducador =  `Educador`.idEducador
                        WHERE Educador.EstadoEducador=1 and `Evento`.idEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }

 function Evento_ver_TipoEvento($id)
    {
        $this->Consulta="SELECT * 
FROM  `TipoEvento` 
INNER JOIN  `Evento` ON  `TipoEvento`.idTipoEvento =  `Evento`.TipoEvento_idTipoEvento
WHERE  `Evento`.idEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }

    function Evento_ver_Participante($id)
    {
        $this->Consulta="SELECT  `Evento`.Nombre,  `EventoParticipante`.Participante_idParticipante,  `Participante`.Nombre AS  'Nombre del participante',  `Participante`.Carne as 'Carné',  `Semestre`.Semestre,  `Participante`.Foto, `Lugar`.Nombre AS  'Nombre del lugar', EventoParticipante.Costo,  `EventoParticipante`.Asistencia
FROM  `EventoParticipante` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoParticipante`.Evento_idEvento
INNER JOIN  `Participante` ON  `EventoParticipante`.Participante_idParticipante =  `Participante`.idParticipante
INNER JOIN  `Semestre` ON  `Participante`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `Lugar` ON  `EventoParticipante`.Lugar_idLugar =  `Lugar`.idLugar
WHERE  `Evento`.idEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
function Evento_ver_Participantesemestre($id,$sem)
    {
        $this->Consulta="SELECT * 
FROM  `Participante` 
INNER JOIN EventoParticipante ON EventoParticipante.Participante_idParticipante = Participante.idParticipante
INNER JOIN Evento ON EventoParticipante.Evento_idEvento = Evento.idEvento
INNER JOIN EventoSemestre ON EventoSemestre.Evento_idEvento = EventoSemestre.Semestre_idSemestre
WHERE Evento.idEvento =".$id."
AND EventoSemestre.Semestre_idSemestre =".$sem;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }

function Evento_ver_Participante_simple($id)
    {
        $this->Consulta="SELECT * 
FROM  `Participante` 
INNER JOIN EventoParticipante ON EventoParticipante.Participante_idParticipante = Participante.idParticipante
INNER JOIN Evento ON EventoParticipante.Evento_idEvento = Evento.idEvento
WHERE Evento.idEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }

function Evento_ver_Participante_asistencia($id)
    {
        $this->Consulta="SELECT * 
FROM  `Participante` 
INNER JOIN EventoParticipante ON EventoParticipante.Participante_idParticipante = Participante.idParticipante
INNER JOIN Evento ON EventoParticipante.Evento_idEvento = Evento.idEvento
WHERE EventoParticipante.Asistencia =1
AND Evento.idEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
function Evento_ver_Participante_verificadion($id,$evento,$fecha,$horai,$horaf)
    {
        $this->Consulta="SELECT P.idParticipante,P.Nombre, P.Carne AS  'Carné', S.Semestre, J.Jornada, Sec.Seccion
FROM Participante AS P
INNER JOIN Semestre AS S ON S.idSemestre = P.Semestre_idSemestre
INNER JOIN Jornada AS J ON J.idJornada = P.Jornada_idJornada
INNER JOIN Seccion AS Sec ON Sec.idSeccion = P.Seccion_idSeccion
LEFT JOIN EventoSemestre AS ES ON ES.Semestre_idSemestre = P.Semestre_idSemestre
LEFT JOIN EventoJornada AS EJ ON EJ.Jornada_idJornada = P.Jornada_idJornada
Left Join EventoSeccion as ESec on ESec.Seccion_idSeccion=P.Seccion_idSeccion
WHERE P.EstadoParticipante =1
AND P.GrupoEvento_idGrupoEvento =".$id."
and (P.`Semestre_idSemestre` in (SELECT `Semestre_idSemestre` FROM `EventoSemestre` WHERE `Evento_idEvento`=".$evento.")
or (SELECT Count(*) FROM `EventoSemestre` WHERE `Evento_idEvento`=".$evento.")=0)
and (P.`Jornada_idJornada` in (SELECT `Jornada_idJornada` FROM `EventoJornada` WHERE `Evento_idEvento`=".$evento.")
or (SELECT Count(*) FROM `EventoJornada` WHERE `Evento_idEvento`=".$evento.")=0)
and (P.`Seccion_idSeccion` in (SELECT `Seccion_idSeccion` FROM `EventoSeccion` WHERE `Evento_idEvento`=".$evento.")
or (SELECT Count(*) FROM `EventoSeccion` WHERE `Evento_idEvento`=".$evento.")=0)
and (P.idParticipante not in(SELECT `Participante_idParticipante` as idParticipante FROM `EventoParticipante` WHERE Evento_idEvento=".$evento."))
and ((SELECT Count(*)
FROM  `EventoParticipante` as EP
inner join Evento as E on EP.Evento_idEvento=E.idEvento
WHERE  E.idEvento !=".$evento."
and E.GrupoEvento_idGrupoEvento=".$id."
AND  E.Fecha =  '".$fecha."'
AND  ((E.HoraInicio
BETWEEN  '".$horai."'
AND  '".$horaf."')
or  (E.HoraFinal
BETWEEN  '".$horai."'
AND  '".$horaf."')))=0)";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
function Evento_ver_Participante2($id)
    {
        $this->Consulta="SELECT  `EventoParticipante`.Participante_idParticipante,  `Participante`.Nombre AS  'Nombre del Participante',  `Participante`.Carne,  `Semestre`.Semestre,  `Participante`.Foto,  `Lugar`.Nombre AS 'Nombre del Lugar',  `EventoParticipante`.Asistencia
FROM  `EventoParticipante` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoParticipante`.Evento_idEvento
INNER JOIN  `Participante` ON  `EventoParticipante`.Participante_idParticipante =  `Participante`.idParticipante
INNER JOIN  `Semestre` ON  `Participante`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `EventoSemestre` ON  `EventoSemestre`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `Lugar` ON  `EventoParticipante`.Lugar_idLugar =  `Lugar`.idLugar
WHERE  `EventoSemestre`.Semestre_idSemestre =  `Participante`.Semestre_idSemestre
AND  `EventoParticipante`.Evento_idEvento=".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
        }
    }

function TipoEvento_ver_eventoparticipante($ide,$tipo)
    {
        $this->Consulta="SELECT  `Evento`.Nombre,  `EventoParticipante`.Participante_idParticipante,  `Participante`.Nombre AS  'Nombre del Participante',  `Participante`.Carne,  `Semestre`.Semestre,  `Participante`.Foto, `Lugar`.Nombre AS  'Nombre del Lugar',  `EventoParticipante`.Asistencia,  `TipoEvento`.Nombre AS  'Tipo del Evento'
FROM  `EventoParticipante` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoParticipante`.Evento_idEvento
INNER JOIN  `TipoEvento` ON  `TipoEvento`.idTipoEvento =  `Evento`.TipoEvento_idTipoEvento
INNER JOIN  `Participante` ON  `EventoParticipante`.Participante_idParticipante =  `Participante`.idParticipante
INNER JOIN  `Semestre` ON  `Participante`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `Lugar` ON  `EventoParticipante`.Lugar_idLugar =  `Lugar`.idLugar
WHERE  `TipoEvento`.idTipoEvento =".$tipo."
AND  `Evento`.idEvento =".$ide;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
    
function Evento_ver_Participante3($id)
    {
        $this->Consulta="SELECT  `Participante`.idParticipante,  `Participante`.Nombre AS  'Nombre del participante', `Participante`.Foto
FROM  `Participante` 
INNER JOIN  `Semestre` ON  `Participante`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `EventoSemestre` ON  `EventoSemestre`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoSemestre`.Evento_idEvento
WHERE  `EventoSemestre`.Semestre_idSemestre =  `Participante`.Semestre_idSemestre
AND  `Evento`.idEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
    }
    }

function Evento_ver_Participante4($id)
    {
        $this->Consulta="SELECT  `Participante`.idParticipante,  `Participante`.Nombre AS  'Nombre del participante', `Participante`.Foto
FROM  `Participante` where GrupoEvento_idGrupoEvento=".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
    }
    }


function Evento_ver_Participante_comprobar()
    {
        $this->Consulta="SELECT count(*) as 'Conteo'

FROM  `EventoParticipante` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoParticipante`.Evento_idEvento
INNER JOIN  `Participante` ON  `EventoParticipante`.Participante_idParticipante =  `Participante`.idParticipante
INNER JOIN  `Semestre` ON  `Participante`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `EventoSemestre` ON  `EventoSemestre`.Semestre_idSemestre =  `Semestre`.idSemestre
INNER JOIN  `Lugar` ON  `EventoParticipante`.Lugar_idLugar =  `Lugar`.idLugar
WHERE  `EventoSemestre`.Semestre_idSemestre =  `Participante`.Semestre_idSemestre";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
    }
    }
function Evento_ver_Participante_comprobar2($id)
    {
        $this->Consulta="SELECT count(*) as 'Conteo'
FROM  `EventoParticipante`
WHERE  Lugar_idLugar=".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
    }
    }
 function Evento_ver_Lugar($id)
    {
        $this->Consulta="SELECT  `EventoLugar`.Lugar_idLugar,  `Lugar`.Nombre as 'Nombre del lugar',  `Lugar`.Capacidad
FROM  `EventoLugar` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoLugar`.Evento_idEvento
INNER JOIN  `Lugar` ON  `Lugar`.idLugar =  `EventoLugar`.Lugar_idLugar
WHERE Lugar.Disponible=1 and `Evento`.idEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }

 function Evento_ver_Semestre($id)
    {
        $this->Consulta="SELECT  `EventoSemestre`.Semestre_idSemestre,  `Semestre`.Semestre AS  'Semestres permitidos'
FROM  `EventoSemestre` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoSemestre`.Evento_idEvento
INNER JOIN  `Semestre` ON  `Semestre`.idSemestre =  `EventoSemestre`.Semestre_idSemestre
WHERE Semestre.EstadoSemestre=1 and  `Evento`.idEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }

 function Evento_ver_Seccion($id)
    {
        $this->Consulta="SELECT  `EventoSeccion`.Seccion_idSeccion,  `Seccion`.Seccion AS  'Secciones permitidas'
FROM  `EventoSeccion` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoSeccion`.Evento_idEvento
INNER JOIN  `Seccion` ON  `Seccion`.idSeccion =  `EventoSeccion`.Seccion_idSeccion
WHERE Seccion.EstadoSeccion=1 and  `Evento`.idEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
 function Evento_ver_Jornada($id)
    {
        $this->Consulta="SELECT  `EventoJornada`.Jornada_idJornada,  `Jornada`.jornada AS  'Jornadas permitidas'
FROM  `EventoJornada` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoJornada`.Evento_idEvento
INNER JOIN  `Jornada` ON  `Jornada`.idJornada =  `EventoJornada`.Jornada_idJornada
WHERE Jornada.EstadoJornada=1 and `Evento`.idEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }


 function Evento_ver_Personal($id)
    {
        $this->Consulta="SELECT  `EventoPersonal`.Personal_idPersonal,  `Personal`.Nombre as 'Nombre del personal',  `Personal`.Carnet as 'Carné',  `Personal`.Telefono,  `Personal`.Foto
FROM  `EventoPersonal` 
INNER JOIN  `Evento` ON  `Evento`.idEvento =  `EventoPersonal`.Evento_idEvento
INNER JOIN  `Personal` ON  `Personal`.idPersonal =  `EventoPersonal`.Personal_idPersonal
WHERE  Personal.EstadoPersonal=1 and `Evento`.idEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
   function Evento_ver_completo($id)
    {
        $this->Consulta="SELECT  `Evento`.Nombre AS  'Nombre Actividad',  `TipoEvento`.Nombre AS  'Tipo Actividad',  `Participante`.Nombre AS  'Nombre del Participante',  `Educador`.Nombre AS  'Nombre del Educador', `Lugar`.Nombre AS  'Lugar', `Semestre`.Semestre
FROM  `Evento` 
INNER JOIN  `EventoParticipante` ON  `Evento`.idEvento =  `EventoParticipante`.Evento_idEvento
INNER JOIN  `TipoEvento` ON  `Evento`.TipoEvento_idTipoEvento =  `TipoEvento`.idTipoEvento
INNER JOIN  `Participante` ON  `EventoParticipante`.Participante_idParticipante =  `Participante`.idParticipante
INNER JOIN  `EventoEducador` ON  `Evento`.idEvento =  `EventoEducador`.Evento_idEvento
INNER JOIN  `Educador` ON  `EventoEducador`.Educador_idEducador =  `Educador`.idEducador
INNER JOIN  `EventoLugar` ON  `Evento`.idEvento =  `EventoLugar`.Evento_idEvento
INNER JOIN  `Lugar` ON  `EventoLugar`.Lugar_idLugar =  `Lugar`.idLugar
INNER JOIN  `EventoSemestre` ON  `Evento`.idEvento =  `EventoSemestre`.Evento_idEvento
INNER JOIN  `Semestre` ON  `EventoSemestre`.Semestre_idSemestre =  `Semestre`.idSemestre
WHERE  `Evento`.idEvento =".$id." order by `Evento`.Nombre asc";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
        }
    }
    
    //Terminadescripcionesevento 
//Eliminar Asignaciones
function Educador_eliminar($id)
     {
        $this->Consulta="DELETE FROM `Educador` WHERE idEducador=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function Evento_eliminar($id)
     {
        $this->Consulta="DELETE FROM `Evento` WHERE idEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function EventoEducador_eliminar($id)
     {
        $this->Consulta="DELETE FROM `EventoEducador` WHERE Evento_idEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function EventoLugar_eliminar($id)
     {
        $this->Consulta="DELETE FROM `EventoLugar` WHERE Evento_idEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function EventoParticipante_eliminar($id)
     {
        $this->Consulta="DELETE FROM `EventoParticipante` WHERE Evento_idEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function EventoPersonal_eliminar($id)
     {
        $this->Consulta="DELETE FROM `EventoPersonal` WHERE Evento_idEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function EventoSemestre_eliminar($id)
     {
        $this->Consulta="DELETE FROM `EventoSemestre` WHERE Evento_idEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }
function EventoSemestre_eliminar_unico($id,$se)
     {
        $this->Consulta="DELETE FROM `EventoSemestre` WHERE Evento_idEvento=".$id." and Semestre_idSemestre=".$se;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function EventoEducador_eliminar_unico($id,$edu)
     {
        $this->Consulta="DELETE FROM `EventoEducador` WHERE Evento_idEvento=".$id." and Educador_idEducador=".$edu;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function EventoPersonal_eliminar_unico($id,$per)
     {
        $this->Consulta="DELETE FROM `EventoPersonal` WHERE Evento_idEvento=".$id." and Personal_idPersonal=".$per;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function EventoLugar_eliminar_unico($id,$lu)
     {
        $this->Consulta="DELETE FROM `EventoLugar` WHERE Lugar_idLugar=".$lu." and Evento_idEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function EventoParticipante_eliminar_unico($id,$par)
     {
        $this->Consulta="DELETE FROM `EventoParticipante` WHERE Participante_idParticipante=".$par." and Evento_idEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

function EventoJornada_eliminar_unico($id,$par)
     {
        $this->Consulta="DELETE FROM `EventoJornada` WHERE Jornada_idJornada=".$par." and Evento_idEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }
function EventoSeccion_eliminar_unico($id,$par)
     {
        $this->Consulta="DELETE FROM `EventoSeccion` WHERE Seccion_idSeccion=".$par." and Evento_idEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }

//TerminaeliminarAsignaciones
    function Evento_ver_descripcion($filtro,$id)
    {
        $this->Consulta="SELECT `idEvento`,`Nombre`,DATE_FORMAT(`Evento`.Fecha, '%d/%m/%Y') as 'Fecha',`HoraInicio` as 'Hora de inicio',`HoraFinal` as 'Hora de finalización' FROM `Evento` WHERE `Nombre` LIKE '%$filtro%' And `GrupoEvento_idGrupoEvento`=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
function Evento_ver_descripcion_tipoevento($filtro,$id)
    {
        $this->Consulta="SELECT `Evento`.idEvento, `Evento`.Nombre AS  'Nombre Actividad', `Evento`.DescripcionEvento,`TipoEvento`.Nombre AS  'Tipo',  DATE_FORMAT(`Evento`.Fecha, '%d/%m/%Y') as 'Fecha', 
                                    `Evento`.HoraInicio, `Evento`.HoraFinal, `GrupoEvento`.Nombre AS  'Nombre del Evento',
                                    `Personal`.Nombre, `Evento`.Imagen
                        FROM  `Evento` 
                                    INNER JOIN  `TipoEvento` ON  `Evento`.TipoEvento_idTipoEvento =  `TipoEvento`.idTipoEvento
                                    INNER JOIN  `GrupoEvento` ON  `Evento`.GrupoEvento_idGrupoEvento =  `GrupoEvento`.idGrupoEvento
                                    INNER JOIN  `Personal` ON  `Evento`.Personal_idPersonal_Encargado =  `Personal`.idPersonal
                                    WHERE `TipoEvento`.idTipoEvento = ".$filtro." And `GrupoEvento`.idGrupoEvento=".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    
function Evento_ver_descripcion_evento($id)
    {
        $this->Consulta="SELECT `Evento`.idEvento, `Evento`.Nombre AS  'Nombre Actividad', `Evento`.DescripcionEvento as 'Descripción',`TipoEvento`.Nombre AS  'Tipo', `Evento`.Fecha, 
                                    `Evento`.HoraInicio, `Evento`.HoraFinal, `GrupoEvento`.Nombre AS  'Nombre del Evento',
                                    `Personal`.Nombre, `Encuesta`.TituloEncuesta, `Evento`.Imagen
                        FROM  `Evento` 
                                    INNER JOIN  `TipoEvento` ON  `Evento`.TipoEvento_idTipoEvento =  `TipoEvento`.idTipoEvento
                                    INNER JOIN  `GrupoEvento` ON  `Evento`.GrupoEvento_idGrupoEvento =  `GrupoEvento`.idGrupoEvento
                                    INNER JOIN  `Personal` ON  `Evento`.Personal_idPersonal_Encargado =  `Personal`.idPersonal
                                    INNER JOIN  `Encuesta` ON  `Evento`.Encuesta_idEncuesta =  `Encuesta`.idEncuesta 
                                    WHERE TipoEvento.Estado=1 and `GrupoEvento`.idGrupoEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
function Evento_ver_descripcion_evento2($id)
    {
        $this->Consulta="SELECT `Evento`.idEvento, `Evento`.Nombre AS  'Nombre Actividad', `Evento`.DescripcionEvento as 'Descripción',`TipoEvento`.Nombre AS  'Tipo', `Evento`.Fecha, 
                                    `Evento`.HoraInicio, `Evento`.HoraFinal, `GrupoEvento`.Nombre AS  'Nombre del Evento',
                                    `Personal`.Nombre
                        FROM  `Evento` 
                                    INNER JOIN  `TipoEvento` ON  `Evento`.TipoEvento_idTipoEvento =  `TipoEvento`.idTipoEvento
                                    INNER JOIN  `GrupoEvento` ON  `Evento`.GrupoEvento_idGrupoEvento =  `GrupoEvento`.idGrupoEvento
                                    INNER JOIN  `Personal` ON  `Evento`.Personal_idPersonal_Encargado =  `Personal`.idPersonal
                                    WHERE TipoEvento.Estado=1 and `GrupoEvento`.idGrupoEvento=".$id;
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
     function GrupoEvento_ver()
     {
        $this->Consulta="SELECT * FROM GrupoEvento order by Nombre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }
    function GrupoEvento_ver_detalle_habilitados()
     { 
        //$this->Consulta="SET NAMES 'utf8'";
        //$this->Resultado = mysql_query($this->Consulta,$this->c);
        
        //$this->Consulta="SET lc_time_names = 'es_GT'";
        //$this->Resultado = mysql_query($this->Consulta,$this->c);
        $this->Consulta="SELECT `idGrupoEvento`, `Nombre`, 
        (SELECT DAYNAME(`FechaInicio`)) as diainicio, (select DAY(`FechaInicio`)) as numinicio, (SELECT MONTHNAME(`FechaInicio`)) as mesinicio, (select YEAR(`FechaInicio`)) as anoinicio, 
        (SELECT DAYNAME(`FechaFinal`)) as diafinal, (select DAY(`FechaFinal`)) as numfinal, (SELECT MONTHNAME(`FechaFinal`)) as mesfinal, (select YEAR(`FechaFinal`)) as anofinal, 
        `CostoInscripcion`, `DescripcionGrupoEvento`, `EstadoGrupoEvento`, (SELECT COUNT(`idParticipante`)  
        FROM `Participante` WHERE `GrupoEvento_idGrupoEvento`=`t1`.`idGrupoEvento` and `EstadoParticipante`=1) AS `totalParticipante`, (SELECT COUNT(`idEvento`) FROM `Evento` WHERE `GrupoEvento_idGrupoEvento`=`t1`.`idGrupoEvento` and `EstadoEvento`=1) AS `TotalActividades`
                        FROM 
                            `GrupoEvento` AS `t1`
                        WHERE 
	                        `EstadoGrupoEvento`=1";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }
    function GrupoEvento_ver_eventos_habilitados($idGrupoEvento)
    {
        $this->Consulta="SELECT `idEvento`,`Nombre`,`DescripcionEvento`,`TipoEvento_idTipoEvento`,`Fecha`,`HoraInicio`,`HoraFinal`,`Imagen` FROM `Evento` WHERE `GrupoEvento_idGrupoEvento`= ".$idGrupoEvento." AND `EstadoEvento` = 1";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
 function GrupoEvento_ver_rangofecha($grupo,$fecha)
    {
        $this->Consulta="SELECT * 
FROM GrupoEvento
WHERE idGrupoEvento =".$grupo."
AND FechaInicio <=  '".$fecha."'
AND FechaFinal >=  '".$fecha."'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }//fin de grupo evento

      function RegistroLugares_insertar($nombre,$capacidad,$estado)
	{
		$this->Consulta=("INSERT INTO `Lugar` (`Nombre`, `Capacidad`, `Disponible`) VALUES ('".$nombre."', '".$capacidad."', '".$estado."')");
		$this->Resultado=mysql_query($this->Consulta,$this->c);
		if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
		/*if(mysql_num_rows($this->Resultado)<=0)
        {
          print 'No se pudo realizar la actividad';  
        }
        else
        {
			print 'Se realizo con éxito';
		}*/
	}
     function Personal_ver()
     {
        $this->Consulta="SELECT * FROM Personal order by Nombre asc";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }
     
function Personal_ver_idgrupo($id)
     {
        $this->Consulta="SELECT * 
FROM Personal
WHERE GrupoEvento_idGrupoEvento =".$id."
AND EstadoPersonal =1
ORDER BY Nombre ASC";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     } 

     function Participante_ver()
     {
        $this->Consulta="SELECT * FROM Participante order by Carne asc";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
     }
     //participante
     function EventoParticipante_insertar($idparticipante, $idevento, $costo, $lugar)
    {
            $this->Consulta=("INSERT INTO `EventoParticipante` (`Participante_idParticipante`,`Evento_idEvento`,`Costo`,`Lugar_idLugar`) VALUES ('".$idparticipante."', '".$idevento."', '".$costo."','".$lugar."');");
            $this->Resultado=mysql_query($this->Consulta,$this->c);
       	    if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
     
function EventoParticipante_Asistencia($idparticipante, $idevento)
    {
            $this->Consulta="UPDATE `EventoParticipante` SET `Asistencia`=1 WHERE `EventoParticipante`.Evento_idEvento=".$idevento." and `EventoParticipante`.Participante_idParticipante=".$idparticipante;
            $this->Resultado=mysql_query($this->Consulta,$this->c);
       	    if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }

    function patrocinador_ver($q)
    {
        $this->Consulta=("SELECT idPatrocinador, Nombre, Telefono as 'Teléfono', Empresa, Cenas as Comidas, `DescripcionPatrocinio` as 'Descripción', `EstadoPatrocinador` as 'Habilitado' FROM `Patrocinador` where Nombre like '%$q%'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    
    function Eliminar_parocinador($q)
    {
		$this->Consulta=("DELETE FROM Patrocinador WHERE idPatrocinador ='$q'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
	
	function Actualizar_patrocinador($nombre,$telefono,$empresa,$cenas,$desc,$estado,$id)
	{
		$this->Consulta=("UPDATE Patrocinador SET Nombre='".$nombre."',Telefono='".$telefono."', Empresa='".$empresa."',Cenas='".$cenas."',DescripcionPatrocinio='".$desc
        ."',EstadoPatrocinador='".$estado."'  WHERE idPatrocinador='$id'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
		
	}
    function Insertar_patrocinador($nombre,$telefono,$empresa,$cenas,$desc)
    {
		$this->Consulta="INSERT INTO Patrocinador( Nombre, Telefono, Empresa, Cenas, DescripcionPatrocinio) VALUES('".$nombre."','".$telefono."','".$empresa."','".$cenas."','".$desc."')";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
	}
    function TipoEvento_ver2()
    {
        $this->Consulta="SELECT * FROM `TipoEvento` where Estado=1";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
    function TipoEventoCantidad_asignadas($idParticipante,$idGrupo)
    {
        $this->Consulta="SELECT `TipoEventoCantidad`.TipoEvento_idTipoEvento, `TipoEventoCantidad`.GrupoEvento_idGrupoEvento,TipoEvento.Nombre as `Tipo de actividad`, `TipoEventoCantidad`.`Cantidad` as `Permitidas`
        ,(SELECT COUNT(`Participante_idParticipante`) FROM `EventoParticipante` inner join `Evento` on `Evento`.idEvento = `EventoParticipante`.Evento_idEvento WHERE `Participante_idParticipante`=".$idParticipante." and `Evento`.TipoEvento_idTipoEvento=`TipoEventoCantidad`.TipoEvento_idTipoEvento) as `Asignadas`
        , (SELECT IFNULL(SUM(`EventoParticipante`.`Costo`),0) FROM `EventoParticipante` inner join `Evento` on `Evento`.idEvento = `EventoParticipante`.Evento_idEvento WHERE `Participante_idParticipante`=".$idParticipante." and `Evento`.TipoEvento_idTipoEvento=`TipoEventoCantidad`.TipoEvento_idTipoEvento) as Total 
FROM
    `TipoEventoCantidad` inner join
    `TipoEvento` on TipoEvento.idTipoEvento=TipoEventoCantidad.`TipoEvento_idTipoEvento`
WHERE
	`TipoEvento`.Estado=1 and `TipoEventoCantidad`.`GrupoEvento_idGrupoEvento`=".$idGrupo;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    
    function Insertar_GrupoEvento($nombre,$fecha1,$fecha2,$costo,$descripcion,$diploma)
    {
		$this->Consulta="INSERT INTO GrupoEvento(Nombre,FechaInicio, FechaFinal, CostoInscripcion,DescripcionGrupoEvento,Diploma) VALUES('".$nombre."','".$fecha1."','".$fecha2."','".$costo."','".$descripcion."','".$diploma."')";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
		if (!$this->Resultado) 
		{
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
        else
        {
            $this->Consulta="SELECT LAST_INSERT_ID() as id";
            $this->Resultado = mysql_query($this->Consulta,$this->c);
            if (!$this->Resultado) {
                $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
                $message .= '<br>Consulta completa: ' . $this->Consulta;
        		die($message);
		    }
        }
	}
    
    function Insertar_TipoEventoCantidad($idTipoEvento,$idGrupoEvento,$Cantidad)
    {
		$this->Consulta="INSERT INTO `TipoEventoCantidad` (`TipoEvento_idTipoEvento`, `GrupoEvento_idGrupoEvento`, `Cantidad`) VALUES ('".$idTipoEvento."', '".$idGrupoEvento."', '".$Cantidad."');";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
    	{
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
		
	}

	function TipoEvento_ver_nombre($nombre){
        $this->Consulta=("SELECT idTipoEvento, Nombre, Estado as 'Habilitado' FROM TipoEvento WHERE Nombre like '%$nombre%'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

         function TipoEvento_actualizar2($id,$nom,$disponible){
         $this->Consulta="UPDATE `TipoEvento` SET `Nombre`=''".$nom."'',`Estado`=".$disponible." WHERE idTipoEvento=".$id."";
         if (!mysql_query($this->Consulta,$this->c)) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
        }

	function TipoEvento_actualizar($nombre,$estado,$id)
	{
		$this->Consulta=("UPDATE TipoEvento SET Nombre='".$nombre."',Estado='".$estado."'  WHERE idTipoEvento='$id'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}

	}
    function TipoEvento_eliminar($id)
    {
	$this->Consulta="DELETE FROM TipoEvento WHERE idTipoEvento =".$id;
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
    
    function GrupoEvento_ver1($filtro)
    {
        $this->Consulta=("SELECT * FROM GrupoEvento WHERE Nombre  LIKE '%$filtro%'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }

    
    function Insertar_gasto($nodocumento,$idTipoGasto,$descripcion,$monto,$patrocinador,$grupoevento)
    {
        $this->Consulta="INSERT INTO Gasto (`NoDocumento`,`Descripcion`,`Monto`,`Patrocinador_idPatrocinador`,`GrupoEvento_idGrupoEvento`,`TipoGasto_idTipoGasto`) VALUES ('".$nodocumento."', '".$descripcion."', '".$monto."', '".$patrocinador."', '".$grupoevento."', '".$idTipoGasto."');";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
    	{
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    
    function Listar_Patrocinadores()
    {
        $this->Consulta=("SELECT idPatrocinador as id, Nombre as nombre FROM Patrocinador WHERE EstadoPatrocinador=1");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
		}
    }
    
    function Listar_GrupoEvento()
    {
        $this->Consulta=("SELECT * FROM GrupoEvento where EstadoGrupoEvento =1");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
		}
    }
    
    function Listar_Gastos($filtro,$idevento)
    {
        $this->Consulta=("SELECT Gasto.idGasto, Gasto.NoDocumento AS  'No. de documento', TipoGasto.TipoGasto AS 'Tipo de gasto', Gasto.Descripcion as 'Descripción', Gasto.Monto, Patrocinador.Nombre AS Patrocinador, GrupoEvento.Nombre AS Evento
                          FROM Gasto
                          INNER JOIN TipoGasto ON Gasto.TipoGasto_idTipoGasto = TipoGasto.idTipoGasto
                          INNER JOIN Patrocinador ON Gasto.Patrocinador_idPatrocinador = Patrocinador.idPatrocinador
                          INNER JOIN GrupoEvento ON Gasto.GrupoEvento_idGrupoEvento = GrupoEvento.idGrupoEvento WHERE TipoGasto.TipoGasto  LIKE '%$filtro%' and Gasto.GrupoEvento_idGrupoEvento='".$idevento."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
		}
    }
    
    function GrupoEvento_actualizar($Nombre,$Costo,$Descripcion,$Diploma,$Estado,$id)
    {
		$this->Consulta=("UPDATE GrupoEvento SET Nombre='".$Nombre."',CostoInscripcion='".$Costo."', DescripcionGrupoEvento='".$Descripcion."',Diploma='".$Diploma."',EstadoGrupoEvento='".$Estado."'  WHERE idGrupoEvento='$id'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}	
	}
    
    function GrupoEvento_verDetalle($idGrupoEvento)
    {
        $this->Consulta=("SELECT TipoEvento.idTipoEvento,  TipoEvento.Nombre, Cantidad 
                            FROM TipoEventoCantidad
                            INNER JOIN TipoEvento ON TipoEventoCantidad.TipoEvento_idTipoEvento = TipoEvento.idTipoEvento
                            WHERE GrupoEvento_idGrupoEvento = '$idGrupoEvento'"
                         );
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Usuario_IngresarUsuario($nombre,$usr,$password,$tipo)
    {
        $this->Consulta="INSERT INTO Usuario (`Nombre`,`Usuario`,`Contrasena`,`Estado`,`Administrador`) VALUES ('".$nombre."', '".$usr."', '".$password."', '1', '".$tipo."');";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
        {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;

    		die($message);
		}            
    }
    
    function Ingresar_TipoGasto($TipoGasto)
    {
        $this->Consulta="INSERT INTO TipoGasto (`TipoGasto`) VALUES ('".$TipoGasto."');";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
        {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    
    function TipoGasto_Listar()
    {
        $this->Consulta="SELECT idTipoGasto as id, TipoGasto as nombre From  TipoGasto WHERE EstadoTipoGasto=1";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
        {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    
    function Usuario_VerificarUsuario($usuario)
    {
        $this->Consulta="Select Count(*) as col1 from Usuario where Usuario='$usuario'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        $fila=mysql_fetch_assoc($this->Resultado);
        if($fila[col1]<1)
        {
            return 0;
        }
        else
        {
            return 1;
        }	
    }
    
    function TipoGasto_Verificartipogasto($tipogasto)
    {
        $this->Consulta="Select Count(*) as col1 from TipoGasto where TipoGasto='$tipogasto'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        $fila=mysql_fetch_assoc($this->Resultado);
        if($fila[col1]<1)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
    
    function GrupoEvento_ver2($filtro)
    {
        $this->Consulta=("SELECT Nombre,DATE_FORMAT(FechaInicio,'%d-%m-%Y') as FechaInicio,DATE_FORMAT(FechaFinal,'%d-%m-%Y') as FechaFinal,CostoInscripcion FROM GrupoEvento WHERE idGrupoEvento =$filtro");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
		}
    }
    
    function GrupoEvento_eliminar($q)
    {
    	$this->Consulta=("DELETE FROM GrupoEvento WHERE idGrupoEvento ='$q'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}

    
    function GrupoEvento_ver_diploma($id)
    {
        
        $this->Consulta=("select Diploma FROM GrupoEvento where idGrupoEvento=$id");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}        
    }
    
    function listar_TipoGasto($filtro)
    {
        $this->Consulta=("SELECT `idTipoGasto`,`TipoGasto` as Nombre,`EstadoTipoGasto` as Habilitado FROM TipoGasto WHERE TipoGasto  LIKE '%$filtro%'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
		}
    }
    
    function listar_Usuarios($filtro)
    {
        $this->Consulta=("SELECT idUsuario, Nombre, Usuario, Administrador as 'Tipo de usuario', Estado as Habilitado FROM Usuario WHERE Usuario  LIKE '%$filtro%'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
    	}
    }
    
    function Gasto_Reporte_general($evento)
    {
        $this->Consulta=("SELECT TipoGasto.idTipoGasto, TipoGasto.TipoGasto, SUM( Gasto.Monto ) AS Total
                          FROM Gasto
                          INNER JOIN TipoGasto ON Gasto.TipoGasto_idTipoGasto = TipoGasto.idTipoGasto
                          WHERE Gasto.GrupoEvento_idGrupoEvento =  '$evento'
                          GROUP BY Gasto.TipoGasto_idTipoGasto");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    
    }
    
    function Gasto_Reporte_especifico($evento,$tipogasto)
    {
        $this->Consulta=("SELECT Nodocumento, Descripcion, Monto, Patrocinador.Nombre
                          FROM  `Gasto` 
                          INNER JOIN Patrocinador ON Gasto.Patrocinador_idPatrocinador= Patrocinador.idPatrocinador
                          WHERE GrupoEvento_idGrupoEvento =  '$evento'
                          AND TipoGasto_idTipogasto =  '$tipogasto'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function TipoGasto_seleccionar($idtipogasto)
    {
        $this->Consulta=("SELECT * FROM  `TipoGasto`
                          WHERE idTipoGasto =  '$idtipogasto'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function TipoGasto_listarporid($id)
    {
        $this->Consulta=("SELECT * FROM `Gasto` WHERE TipoGasto_idTipoGasto ='".$id."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
          
    }
    
    function TipoGasto_eliminar($q)
    {
        $this->Consulta=("DELETE FROM `TipoGasto` WHERE idTipoGasto ='".$q."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
		}
	}
    
    function TipoGasto_actualizar($id,$descripcion,$estado)
    {
        $this->Consulta=("UPDATE `TipoGasto` SET `TipoGasto`='".$descripcion."', `EstadoTipoGasto`='".$estado."' WHERE idTipoGasto='".$id."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }
    
    function Gasto_seleccionar($idgasto)
    {
        $this->Consulta=("SELECT Gasto.idGasto, Gasto.NoDocumento, TipoGasto.idTipoGasto AS IdTipoGasto, TipoGasto.TipoGasto AS NombreTipo_Gasto  , Gasto.Descripcion, Gasto.Monto,
                          Patrocinador.idPatrocinador, Patrocinador.Nombre AS Patrocinador, GrupoEvento.Nombre AS Evento
                          FROM Gasto
                          INNER JOIN TipoGasto ON Gasto.TipoGasto_idTipoGasto = TipoGasto.idTipoGasto
                          INNER JOIN Patrocinador ON Gasto.Patrocinador_idPatrocinador = Patrocinador.idPatrocinador

                          INNER JOIN GrupoEvento ON Gasto.GrupoEvento_idGrupoEvento = GrupoEvento.idGrupoEvento WHERE  Gasto.idGasto='".$idgasto."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Gasto_eliminar($q)
    {
        $this->Consulta=("DELETE FROM `Gasto` WHERE IdGasto ='".$q."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
    
    function Gasto_actualizar($id,$documento,$idtipogasto,$descripcion,$monto,$idpatrocinador)
    {
        $this->Consulta=("UPDATE `Gasto` SET `NoDocumento`='".$documento."', `Descripcion`='".$descripcion."', `Monto`='".$monto."',
                         `Patrocinador_idPatrocinador`='".$idpatrocinador."', `TipoGasto_idTipoGasto`='".$idtipogasto."'  WHERE IdGasto='".$id."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }
    
    function Usuarios_seleccionar($idusuario)
    {
        $this->Consulta=("SELECT Nombre, Usuario, Contrasena, Estado FROM  `Usuario`
                          WHERE IdUsuario =  '$idusuario'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Usuario_eliminar($q)
    {
        $this->Consulta=("DELETE FROM `Usuario` WHERE IdUsuario ='".$q."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
	}
    

    function Usuarios_actualizar($id,$nombre,$contrasena,$estado)
    {
        $this->Consulta=("UPDATE `Usuario` SET `Nombre`='".$nombre."', `Contrasena`='".$contrasena."', `Estado`='".$estado."' WHERE idUsuario=".$id."");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }
    
    function Participante_diploma_todos($idGrupoEvento,$filtro)
    {
        $this->Consulta=("SELECT P.idParticipante, P.Nombre, S.Semestre from Participante as P 
                            inner join Semestre as S on S.idSemestre=P.Semestre_idSemestre
                            where P.GrupoEvento_idGrupoEvento='$idGrupoEvento' and P.Nombre like '%$filtro%'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
		}
    }
    
    function Participante_ver_nombre($id)
    {
        $this->Consulta=("select Nombre from Participante where idParticipante =$id" );
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
		}
    }
    
    function Posiciones_actualizar($x,$y,$id)
    {
        $this->Consulta=("UPDATE GrupoEvento set X='.$x.',Y='.$y.' where idGrupoEvento= $id");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
    	}
    }
    
     function Posiciones_ver($id)
    {
        $this->Consulta=("SELECT X,Y from GrupoEvento where idGrupoEvento=$id");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
     function Participante_diploma_semestre($id,$idGrupoEvento,$filtro)
     {
        $this->Consulta=("SELECT idParticipante, Nombre  FROM  Participante where Semestre_idSemestre='$id' and GrupoEvento_idGrupoEvento='$idGrupoEvento' and Nombre like '%$filtro%'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
     }
     
     function Participante_ver_su_tipoEvento($id,$idGrupoEvento,$filtro)
     {
        $this->Consulta=("SELECT E.idEvento , E.Nombre,SEC_TO_TIME(TIMESTAMPDIFF(SECOND, E.HoraInicio, E.HoraFinal)) as 'Duración' FROM Participante as P
                                inner join EventoParticipante on idParticipante=Participante_idParticipante
                                inner join Evento as E on Evento_idEvento=idEvento        
                                where P.idParticipante='$id' and P.GrupoEvento_idGrupoEvento='$idGrupoEvento' and E.Nombre like '%$filtro%'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
     }
     
      function Posiciones_actualizar_tipoEvento($x,$y,$id)
    {
        $this->Consulta=("UPDATE GrupoEvento set CordeXtipoEvento='.$x.',CordeYtipoEvento='.$y.' where idGrupoEvento= $id");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Posiciones_ver_tipoEvento($id)
    {
        $this->Consulta=("SELECT CordeXtipoEvento,CordeYtipoEvento from GrupoEvento where idGrupoEvento=$id");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Patrocinador_Reporte_general($evento)
    {
        $this->Consulta=("SELECT Patrocinador.idPatrocinador, Patrocinador.Nombre, SUM( Gasto.Monto ) AS Total
                          FROM Gasto
                          INNER JOIN Patrocinador ON Gasto.Patrocinador_idPatrocinador = Patrocinador.idPatrocinador
                          WHERE Gasto.GrupoEvento_idGrupoEvento =  '$evento'
                          GROUP BY Gasto.Patrocinador_idPatrocinador");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    
    }
    
    function Patrocinador_Reporte_especifico($evento,$patrocinador)
    {
        $this->Consulta=("SELECT Nodocumento, Descripcion, Monto, TipoGasto.TipoGasto
                          FROM  `Gasto` 
                          INNER JOIN TipoGasto ON Gasto.TipoGasto_idTipoGasto = TipoGasto.idTipoGasto
                          WHERE GrupoEvento_idGrupoEvento =  '$evento'
                          AND Patrocinador_idPatrocinador =  '$patrocinador'");

        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
     function GrupoEvento_filtrar($filtro)
    {
        $this->Consulta=(" SELECT idGrupoEvento,Nombre,DATE_FORMAT(FechaInicio,'%d-%m-%Y') as 'Inicia',DATE_FORMAT(FechaFinal,'%d-%m-%Y') as 'Finaliza',CostoInscripcion as 'Inscripción',DescripcionGrupoEvento as 'Descripción', `EstadoGrupoEvento` as 'Habilitado' 
                        FROM GrupoEvento where Nombre like '%$filtro%'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Jornada_VerificarJornada($jornada)
    {
        $this->Consulta="Select Count(*) as col1 from Jornada where Jornada='$jornada'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        $fila=mysql_fetch_assoc($this->Resultado);
        if($fila[col1]<1)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
    function Jornada_verificar2($jornada)
    {
        $this->Consulta="SELECT COUNT(`idJornada`) as `Cantidad` FROM `Jornada` WHERE `Jornada` like '".$jornada."'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    function Jornada_nueva($jornada)
    {
        $this->Consulta="INSERT INTO Jornada (`Jornada`) VALUES ('".$jornada."');";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
        {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }
    function Ingresar_Jornada($jornada)
    {
        $this->Consulta="INSERT INTO Jornada (`Jornada`) VALUES ('".$jornada."');";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
        {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    
    function listar_Jornada($filtro)
    {
        $this->Consulta=("SELECT `idJornada`,`Jornada`,`EstadoJornada` as Habilitado FROM Jornada WHERE Jornada  LIKE '%$filtro%'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
    	}
    }
    //para los combobox
    function Jornada_ver2()
    {
        $this->Consulta=("SELECT  `idJornada` AS `id` ,  `Jornada` FROM  `Jornada` WHERE  `EstadoJornada` =1 ORDER BY `idJornada` ASC");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    function Jornada_seleccionar($idjornada)
    {
        $this->Consulta=("SELECT * FROM  `Jornada`
                          WHERE idJornada =  '$idjornada'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Jornada_actualizar($id,$jornada,$estado)
    {
        $this->Consulta=("UPDATE `Jornada` SET `Jornada`='".$jornada."', `EstadoJornada`='".$estado."' WHERE idJornada='".$id."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
		}
    }
    
    function Jornada_listarporid($id)
    {
        $this->Consulta=("SELECT * FROM `Participante` WHERE Jornada_idJornada ='".$id."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
          
    }
    
    function Jornada_eliminar($q)
    {
        $this->Consulta=("DELETE FROM `Jornada` WHERE idJornada ='".$q."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
		}
	}
    
function Seccion_ver(){
		$this->Consulta="SELECT * FROM Seccion order by Seccion asc";
    		$this->Resultado = mysql_query($this->Consulta,$this->c);
        	if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}
    function Seccion_verificar2($seccion)
    {
        $this->Consulta="Select Count(*) as cantidad from Seccion where Seccion like '".$seccion."'";
    	$this->Resultado = mysql_query($this->Consulta,$this->c);
    	if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function Seccion_VerificarSeccion($seccion)
    {
        $this->Consulta="Select Count(*) as col1 from Seccion where Seccion='$seccion'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        $fila=mysql_fetch_assoc($this->Resultado);
        if($fila[col1]<1)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
    
    function Ingresar_Seccion($seccion)
    {
        $this->Consulta="INSERT INTO Seccion (`Seccion`) VALUES ('".$seccion."');";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
        {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }
    
    function listar_Seccion($filtro)
    {
        $this->Consulta=("SELECT `idSeccion`,`Seccion` as 'Sección',`EstadoSeccion` as Habilitado FROM Seccion WHERE Seccion  LIKE '%$filtro%'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
    	}
    }
    

function Jornada_ver(){
		$this->Consulta="SELECT * FROM Jornada order by Jornada asc";
    		$this->Resultado = mysql_query($this->Consulta,$this->c);
        	if (!$this->Resultado) {
        	$message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
    		$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
}

    function Seccion_seleccionar($id)
    {
        $this->Consulta=("SELECT * FROM  `Seccion`
                          WHERE idSeccion =  '$id'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Seccion_actualizar($id,$seccion,$estado)
    {
        $this->Consulta=("UPDATE `Seccion` SET `Seccion`='".$seccion."', `EstadoSeccion`='".$estado."' WHERE idSeccion='".$id."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
		}
    }
    
    function Seccion_VerificarSeccionNombre($seccion,$id)
    {
        $this->Consulta="Select Count(*) as col1 from `Seccion` where `idSeccion` <> '$id' and `Seccion` = '$seccion'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        $fila=mysql_fetch_assoc($this->Resultado);
        if($fila[col1]<1)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
    
    function Seccion_listarporid($id)
    {
        $this->Consulta=("SELECT * FROM `Participante` WHERE Seccion_idSeccion ='".$id."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
          
    }
    
    function Seccion_eliminar($q)
    {
        $this->Consulta=("DELETE FROM `Seccion` WHERE idSeccion ='".$q."' ");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
		}
	}

    
    function GrupoEvento_reporte_general()
    {  
        $this->Consulta=("Select idGrupoEvento, Nombre, date_format(FechaInicio,'%m-%d-%Y') as FechaInicio, date_format(FechaFinal,'%m-%d-%Y') as FechaFinal, CostoInscripcion,(SELECT COUNT(`idParticipante`)  
                            FROM `Participante` WHERE `GrupoEvento_idGrupoEvento`=G.idGrupoEvento and `EstadoParticipante`=1) AS `totalParticipante`, (SELECT COUNT(`idEvento`) FROM `Evento` WHERE `GrupoEvento_idGrupoEvento`=G.idGrupoEvento and `EstadoEvento`=1) AS TotalActividades,(SELECT COUNT(`idPersonal`) FROM `Personal` WHERE `GrupoEvento_idGrupoEvento`=G.idGrupoEvento and `EstadoPersonal`=1) AS totalpersonal
                            ,(SELECT SUM(`Monto`) FROM `Gasto` WHERE `GrupoEvento_idGrupoEvento`=G.idGrupoEvento ) AS totalgastos,( SELECT (G.CostoInscripcion*(SELECT COUNT( P.idParticipante ) FROM Participante AS P
                            WHERE P.GrupoEvento_idGrupoEvento = G.idGrupoEvento))) as Ingresos,(Select SUM(Ep.Costo) from GrupoEvento as G1 
                            INNER JOIN Evento AS E ON E.GrupoEvento_idGrupoEvento = G1.idGrupoEvento
                            INNER JOIN EventoParticipante AS Ep ON Ep.Evento_idEvento = E.idEvento
                            where E.GrupoEvento_idGrupoEvento=G.idGrupoEvento) as Ingreso2 
                            from GrupoEvento as G");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
    	}
	}
    
    function GrupoEvento_reporte_detalle($codigo)
    {
        $this->Consulta=("SELECT E.idEvento,E.Nombre AS  'Nombre del evento', T.Nombre AS  'Tipo de evento', DATE_FORMAT( E.Fecha,  '%m-%d-%Y' ) AS Fecha, E.HoraInicio AS inicio, SEC_TO_TIME( TIMESTAMPDIFF( 
                        SECOND , E.HoraInicio, E.HoraFinal ) ) AS  'Duración', E.Costo, Ed.Nombre AS Educador, P.Nombre AS Personal,(SELECT COUNT(`idParticipante`)  
                                FROM `Participante` WHERE `GrupoEvento_idGrupoEvento`=G.idGrupoEvento and `EstadoParticipante`=1) AS `totalParticipante`, (SELECT COUNT(`idEvento`) FROM `Evento` WHERE `GrupoEvento_idGrupoEvento`=G.idGrupoEvento and `EstadoEvento`=1) AS TotalActividades
                                ,(SELECT COUNT(`idPersonal`) FROM `Personal` WHERE `GrupoEvento_idGrupoEvento`=G.idGrupoEvento and `EstadoPersonal`=1) AS totalpersonal,(SELECT SUM(`Monto`) FROM `Gasto` WHERE `GrupoEvento_idGrupoEvento`=G.idGrupoEvento ) AS totalgastos,( SELECT (G.CostoInscripcion*(SELECT COUNT( P.idParticipante ) FROM Participante AS P
WHERE P.GrupoEvento_idGrupoEvento = G.idGrupoEvento))) as Ingresos,(Select SUM(Ep.Costo) from GrupoEvento as G1 
INNER JOIN Evento AS E ON E.GrupoEvento_idGrupoEvento = G1.idGrupoEvento
INNER JOIN EventoParticipante AS Ep ON Ep.Evento_idEvento = E.idEvento
where E.GrupoEvento_idGrupoEvento=G.idGrupoEvento) as Ingreso2
                        FROM  `GrupoEvento` AS G
                        INNER JOIN Evento AS E ON E.GrupoEvento_idGrupoEvento = G.idGrupoEvento
                        INNER JOIN TipoEvento AS T ON E.TipoEvento_idTipoEvento = T.idTipoEvento
                        LEFT JOIN EventoEducador AS EE ON EE.Evento_idEvento = E.idEvento
                        LEFT JOIN Educador Ed ON EE.Educador_idEducador = Ed.idEducador
                        INNER JOIN Personal AS P ON E.Personal_idPersonal_Encargado = P.idPersonal
                        WHERE G.idGrupoEvento =$codigo
                        order by E.idEvento");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
     function GrupoEvento_detalle_eliminar($idTipoEvento,$idGrupoEvento)
    {
        $this->Consulta=("DELETE FROM `TipoEventoCantidad` WHERE `TipoEvento_idTipoEvento`= '$idTipoEvento' and `GrupoEvento_idGrupoEvento`='$idGrupoEvento'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Patrocinador_cantidades_asigandos($id)
    {
        $this->Consulta=("SELECT COUNT(idGasto) as Cantidad from Gasto where Patrocinador_idPatrocinador=$id");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }    
    }
    
    function GrupoEvento_cantidades_asigandos_enParticipante($id)
    {
        $this->Consulta=("SELECT COUNT(idParticipante) as Cantidad from Participante where GrupoEvento_idGrupoEvento=$id");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }    
    }
    
    function Jornada_VerificarJornadaNombre($jornada,$id)
    {
        $this->Consulta="SELECT COUNT(*) as col1 FROM `Jornada` WHERE `idJornada` <> '$id' AND `Jornada` ='$jornada'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        $fila=mysql_fetch_assoc($this->Resultado);
        if($fila[col1]<1)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }

    function TipoGasto_VerificarTipoGastoNombre($tipo,$id)
    {
        $this->Consulta="SELECT COUNT(*) as col1 FROM `TipoGasto` WHERE `idTipoGasto` <> '$id'AND `TipoGasto` ='$tipo'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        $fila=mysql_fetch_assoc($this->Resultado);
        if($fila[col1]<1)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
    
    function GrupoEvento_verificar_nombre($nombre)
    {
        $this->Consulta=("SELECT COUNT(idGrupoEvento) as Cantidad from GrupoEvento where Nombre='$nombre'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Patrocinador_verificar_nombre($nombre)
    {
        $this->Consulta=("SELECT COUNT(idPatrocinador) as Cantidad from Patrocinador where Nombre='$nombre'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Actividad_mostrar($id)
     {
        $this->Consulta=("SELECT concat_ws(', duración:',E.Nombre,SEC_TO_TIME(TIMESTAMPDIFF(SECOND, E.HoraInicio, E.HoraFinal))) as 'Todo' FROM Evento  as E   where idEvento='$id'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
     }
     

    function GrupoEvento_verificar_nombre2($idGrupoEvento,$nombre)
    {
        $this->Consulta=("SELECT COUNT(idGrupoEvento) as Cantidad FROM GrupoEvento WHERE idGrupoEvento <> '$idGrupoEvento' AND Nombre ='$nombre'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function Patrocinador_verificar_nombre2($idPatrocinador,$nombre)
    {
        $this->Consulta=("SELECT COUNT(*) as Cantidad FROM `Patrocinador` WHERE `idPatrocinador` <> '$idPatrocinador'AND `Nombre` ='$nombre'");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }
    
    function patrocinador_verificar_nombre3($nombre)
    {
        $this->Consulta="Select Count(*) as col1 from Patrocinador where Nombre='$nombre'";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        $fila=mysql_fetch_assoc($this->Resultado);
        if($fila[col1]<1)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
    
    function Patrocinador_ingresarnombre($nombre)
    {
        $this->Consulta="INSERT INTO Patrocinador (`Nombre`) VALUES ('".$nombre."');";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
        {
            $message  = '<br>Consulta inválida: ' . mysql_error() . "\n";
        	$message .= '<br>Consulta completa: ' . $this->Consulta;
    		die($message);
		}
    }
    function TipoEventoCantidad_ver($idGrupoEvento)
    {
        $this->Consulta="SELECT tec.TipoEvento_idTipoEvento, te.Nombre, tec.Cantidad
                FROM TipoEventoCantidad AS tec
                INNER JOIN TipoEvento AS te ON tec.TipoEvento_idTipoEvento = te.idTipoEvento
                WHERE tec.GrupoEvento_idGrupoEvento =$idGrupoEvento";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
        {
            $message  = 'Ocurrió un error en el servidor.';
    		die($message);
		}
    }
    
   
    function TipoEventoCantidad_editar($idGrupoEvento,$idTipoEvento,$cantidad)
    {
        $this->Consulta="UPDATE TipoEventoCantidad SET Cantidad=$cantidad WHERE TipoEvento_idTipoEvento=$idTipoEvento and GrupoEvento_idGrupoEvento=$idGrupoEvento";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
        {
            $message  = 'Ocurrió un error en el servidor.';
        	die($message);
		}
    }
    
    function TipoEventoCantidad_eliminar($idGrupoEvento)
    {
        $this->Consulta="delete from TipoEventoCantidad where GrupoEvento_idGrupoEvento=$idGrupoEvento";
        $this->Resultado = mysql_query($this->Consulta,$this->c);
        if (!$this->Resultado) 
        {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
		}
    }
    
    function Idgrupoevento_ver_su_tipoEvento($idGrupoEvento)
     {
        $this->Consulta=("SELECT `idEvento`, `Nombre` FROM `Evento` WHERE `EstadoEvento`=1 AND `GrupoEvento_idGrupoEvento`=$idGrupoEvento");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
     }
    
    function Evento_ver_su_actividad($id,$idgrupo)
    {
        $this->Consulta=("SELECT EP.Participante_idParticipante, P.Nombre, E.Nombre AS 'Actividad', SEC_TO_TIME(TIMESTAMPDIFF(SECOND, E.HoraInicio, E.HoraFinal)) as 'Duración' FROM EventoParticipante as EP 
                          inner join  Participante AS P ON EP.Participante_idParticipante = P.idParticipante
                          inner join Evento AS E on EP.Evento_idEvento=E.idEvento
                          Where EP.Evento_idEvento=$id and E.GrupoEvento_idGrupoEvento=$idgrupo");
        $this->Resultado = mysql_query($this->Consulta,$this->c);
         if (!$this->Resultado) 
         {
            $message  = 'Ocurrió un error en el servidor.';
            die($message);
        }
    }

}
?>
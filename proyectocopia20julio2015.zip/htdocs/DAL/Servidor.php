<?php
class Servidor{
	var $servidor="sql304.hostingla.in";
	var $usuario="hos7_15945417";
	var $contraseña="citein1234";
	var $conexion;

	function conectar(){
		$s=$this->servidor;
		$u=$this->usuario;
		$c=$this->contraseña;
		$this->conexion=mysql_connect($s,$u,$c);
		if (!$this->conexion) {
    		die('No se pudo conectar al servidor: ' . mysql_error());
		}
                else{
//                    echo "<br>Servidor conectado<br>";
                    $seleccionbd=mysql_select_db("hos7_15945417_citein",$this->conexion);
                    if (!$seleccionbd) {
                        die('No se pudo seleccionar la base de datos: ' . mysql_error());
                    }
                    /*else{
                        echo "<br>Base de datos seleccionado<br>";
                    }*/
               }
	}
}
?>
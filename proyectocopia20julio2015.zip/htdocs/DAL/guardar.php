<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Guardando...</title>
<script src="../../../BLL/ajax.js" language="JavaScript"></script>
</head>
<body>
Guardando...
<?php
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
    /*
    Instrucciones para usar esta página:
    1. Todos los elementos que tenga su página (textbox,botones, etc.) deberá estar en un "form"
    y en el encabezado tendra que ser de la siguiente manera:
        form id="form1" name="form1" method="post" action="<?php echo htmlspecialchars("/DAL/guardar.php") ?> ">
    el atributo action es el que tendra la dirección de esta página.
    
    2. Para saber que página quiere usar esta página, deberan agregar un campo oculto en su página especificando el nombre de su página ej:
        <input type="hidden" name="formulario" value="crear encuesta" />
    en el atributo value tendra el nombre de la página que es usada luego en el if como se puede ver más abajo.
    
    3. Para asignar una página de redireccionamiento luego de haber guardado los datos tendran que agregar otro campo oculto ej:
        <input type="hidden" name="redireccionar" value="direción de la página" />
    y automaticamente redireccionará a la página deseada.
    */
    $direccion="citein.hostingla.in";
	$direccion=$_POST["redireccionar"];
	$formulario=$_POST["formulario"];
    
	if($formulario=="crear encuesta")
	{
	// define variables and set to empty values
		$titulo = $descripcion = "";
		$cont = $cont2 = $contPreguntas = $contOpciones = $preguntasTotales = 0;
		if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
			$contPreguntas=$_POST["contPreguntas"];
			/*if (empty($_POST["texto_titulo"])) {
		   		$errorTitulo = "El título es requerido.";
			}
			else {
				$titulo = test_input($_POST["texto_titulo"]);
		    	// check if name only contains letters and whitespace
				if (!preg_match("/^[a-zA-Z1-9ÑñáéíóúÁÉÍÓÚ ]*$/",$titulo)) {
	    			$errortitulo = "Ingrese solamente letras y espacios.";
				}
				else{
					++$cont;
				}
			}
			if(empty($_POST["texto_descripcion"])){
	   			$descripcion="";
			f	++$cont;
			}
			else{
				$descripcion = test_input($_POST["texto_descripcion"]);
/*				if (!preg_match("/^[a-zA-Z0-9ÑñáéíóúÁÉÍÓÚ ]*$/",$descripcion)) {
	    		 	$errorDescripcion='La descripción no es válida';
				 }
				else{
					++$cont;
	//			}
			}*/
			$titulo = test_input($_POST["texto_titulo"]);
			$descripcion = test_input($_POST["texto_descripcion"]);
			/*if($cont==2)
			{*/
				$enviar=true;
				$consulta1->Encuesta_nueva($titulo,$descripcion);
				$idEnc=0;
				while ($fila = mysql_fetch_assoc($consulta1->Resultado)) {
				    $idEnc = $fila["id"];
				}
				// Liberar los recursos asociados con el conjunto de resultados
				// Esto se ejecutado automáticamente al finalizar el script.
				mysql_free_result($consulta1->Resultado);
				
				$contPreguntas=$_POST["contPreguntas"];
				$idPreg;
				for($cont=1;$cont<=$contPreguntas;$cont++)
				{
					$idPreg=$_POST["p".$cont];
					//si existe una pregunta (textbox de pregunta)
					if(isset($idPreg))
					{
						//select:tipo de pregunta A:texto,M:opción múltiple
						if(isset($_POST["s".$cont]))
						{
							$consulta1->Pregunta_nueva($idPreg,$_POST["s".$cont],$idEnc);
							while ($fila = mysql_fetch_assoc($consulta1->Resultado)) {
							    $idPreg = $fila["id"];
							}
							//pregunta de opción múltiple
							if($_POST["s1"]=="M")
							{
								//contador de opciones (opciones totales);
								$contOpciones=$_POST["c".$cont];
								$opcionTemp;
								for($cont2=1;$cont2<=$contOpciones;$cont2++)
								{
									$opcionTemp=$_POST[$cont2."t".$cont];
									if(isset($opcionTemp))
									{
										if(!empty($opcionTemp)&&$opcionTemp!="Opción")
										{
											$consulta1->OpcionMultiple_nueva($opcionTemp,$idPreg);
										}
									}
								}
							}
							++$preguntasTotales;
						}//Select:tipo de pregunta
					}//TextBox pregunta
				}//for preguntas
	    	//}//titulo y descripcion validos
		}//Metodo post
	}
	else if($formulario=="responder encuesta")
	{
		$idEncuesta=$_POST["idEncuesta"];
		$idParticipante=$_POST["idParticipante"];
		$idEvento=$_POST["idEvento"];
		$consulta1->Encuesta_ver_preguntas($idEncuesta);
		$preguntas=$consulta1->Resultado;
		while ($fila = mysql_fetch_assoc($preguntas)) {
			//`idPregunta`,`Pregunta`,`TipoRespuesta
			$consulta1->Respuesta_nueva($fila["idPregunta"],$_POST[$fila["idPregunta"]],$idParticipante);
		}
		$consulta1->Encuesta_contestado($idParticipante,$idEvento);
		mysql_free_result($preguntas);
		
		$direccion=$direccion."?usuario=".$_POST["usuario"];
	}
    /*
	else if($formulario=="Insertar GrupoEventos")
    {
        $contev=$conted=0;
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            
            $target_dir = "uploads/";
            $target_name=basename($_FILES["fileToUpload"]["name"]);
        	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        	$uploadOk = 1;
        	$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
                if(isset($_POST["submit"])) 
                {
                    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
                    if($check !== false) 
                	{
                        echo "El archivo es una imagen - " . $check["mime"] . ". ";
                        $uploadOk = 1;
                    } else 
                	{
                        echo "El archivo no es una imagen.";
                        $uploadOk = 0;
                    }
                	
                }
                // Check if file already exists
                if (file_exists($target_file)) 
                {
                    echo "El archivo ya existe.";
                    $uploadOk = 0;
                }
                // Check file size
                if ($_FILES["fileToUpload"]["size"] > 1000000) 
                {
                    echo "El archivo es muy pesado, escoge uno menos pesado";
                    $uploadOk = 0;
                }
                // Allow certain file formats
                if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                && $imageFileType != "gif" ) 
                {
                    echo "Disculpe, solo se permiten archivos con extención JPG, JPEG, PNG y GIF ";
                    $uploadOk = 0;
                }
                // Check if $uploadOk is set to 0 by an error
                if ($uploadOk == 0) 
                {
                    echo "Disculpe, no se pudo cargar su archivo.";
                // if everything is ok, try to upload file
                } else 
                {
                    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
                	{
                        echo "    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
                    } else 
                	{
                        echo "Disculpe, se ha producido un herror al intentar subir su archivo";
                    }
                }

            
            
            
		    $nombre = $_POST["text_nombre"];
			$fecha1 = $_POST["text_fech1"];
			$fecha2 = $_POST["text_fech2"];
			$costo  = $_POST["text_inscripcion"];
            $descripcion=$_POST["descripcion"];
			echo '<br>el nombre capturado es: '.$nombre."<br>";
			echo 'fecha 1 capturado es: '.$imageFileType."<br>";
			echo 'fecha 2 capturado es: '.$fecha2."<br>";
			echo 'costo capturado es: '.$costo."<br>";
            echo 'descripcion es:'.$descripcion."<br>";
            echo 'nombre imagen:'.$target_name."<br>";
			
			$nuevoID=0;
			$consulta1->Insertar_GrupoEvento($nombre,$fecha1,$fecha2,$costo,$descripcion,$diploma);
			
            
            while($row1=mysql_fetch_assoc($consulta1->Resultado))
			{
				$nuevoID=$row1["id"];
				
			}
			$consulta1->TipoEvento_ver2();
			$tipos=$consulta1->Resultado;
			while ($row = mysql_fetch_assoc($tipos))
            {
					$consulta1->Insertar_TipoEventoCantidad($row['idTipoEvento'],$nuevoID,$_POST[$row['idTipoEvento']]);				
			}
        }		
		
	}*/
   

else if($formulario=="Ingresar TipoEvento")
{
 if(isset($_POST["texto_nombre"]))
 {
                $nombre=$_POST["texto_nombre"];
                $consulta1->TipoEvento_insertar($nombre,1);
 }
            else
            {
                echo '<br> No Existe nombre';
            }
 ?>
            <meta http-equiv="Refresh" content="3;url=http://citein.hostingla.in/UL/Evento/TipoEvento_ingresar.php">
             <?php
}

else if($formulario=="Ingresar Lugar")
{
 if(isset($_POST["texto_nombre"]))
 {
                $nombre=$_POST["texto_nombre"];
 }
            else
            {
                echo '<br> No Existe nombre';
            }
 if(isset($_POST["texto_capacidad"]))
 {
                $capacidad=$_POST["texto_capacidad"];
 }
            else
            {
                echo '<br> No Existe nombre';
            }
$consulta1->RegistroLugares_insertar($nombre, $capacidad, '1');
 ?>
            <meta http-equiv="Refresh" content="3;url=http://citein.hostingla.in/UL/Evento/Lugar_ver.php">
             <?php
}

else if($formulario=="Actualizar TipoEvento")
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if(isset($_POST["idTipoEvento"]))
                $id=$_POST["idTipoEvento"];
            else
                echo '<br> No existe el Registro';
            if(isset($_POST["Nombre"]))
                $nom=$_POST["Nombre"];
            else
                echo '<br> No existe el Nombre ';
            if(isset($_POST["Disponible2"]))
                $disponible=$_POST["Disponible2"];
            else
                echo '<br> No existe el registro ';
            
        echo '<br>Datos'.$id;
        echo '<br>Datos'.$nom;
        $consulta1->TipoEvento_actualizar($nom,$disponible,$id);    	
        }
    }

 else if($formulario=="Ingresar Semestre")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            if(isset($_POST["Nombre"]))
                $sem=$_POST["Nombre"];
            else
                echo '<br> No existe el registro';
            if(isset($_POST["Disponible2"]))
                $estado=$_POST["Disponible2"];
            else
                echo '<br> No existe el registro';
            echo"datos".$sem.$estado;
 	    $consulta1->Semestre_insertar($sem,$estado);
 header("Location: http:/UL/Evento/Semestre_ver.php");
        }
    }

  else if($formulario=="Actualizar Semestre")
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if(isset($_POST["idSemestre"]))
                $id=$_POST["idSemestre"];
            else
                echo '<br> No existe el Registro';
            if(isset($_POST["Semestre"]))
                $sem=$_POST["Semestre"];
            else
                echo '<br> No existe el Semestre ';
            if(isset($_POST["Disponible2"]))
                $disponible=$_POST["Disponible2"];
            else
                echo '<br> No existe el dato ';
            
        echo '<br>Datos'.$id;
        echo '<br>Datos'.$sem;
        $consulta1->Semestre_actualizar($id,$sem,$disponible);    	
        }
    }

else if($formulario=="Actualizar Educador")   
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {

$target_dir = "../UL/Evento/uploads/";
        $hojadevida=basename($_FILES["fileToUpload"]["name"]);
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
 if (file_exists($target_file)) 
        {
            echo "El archivo ya existe.";
            $uploadOk = 0;
        }
        // verificar el tamaño del archivo
        if ($_FILES["fileToUpload"]["size"] > 1000000) 
        {
            echo "El archivo es muy pesado, escoge uno menos pesado";
            $uploadOk = 0;
        }
        // formato de archivos permitidos
        if($imageFileType != "pdf" && $imageFileType != "PDF") 
        {
            echo "Disculpe, solo se permiten archivos con extención PDF ";
            $uploadOk = 0;
        }
       if ($uploadOk == 0) 
        {
            echo "Disculpe, no se pudo cargar su archivo.";
        // if everything is ok, try to upload file    
        }
       else{
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
                {
                    echo "    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
                } 
                else 
                {
                    echo "Disculpe, se ha producido un error al intentar subir su archivo";
                }
            }

            if(isset($_POST["idEducador"]))
                $idlugar=$_POST["idEducador"];
            else
                echo '<br> No existe el lugar';
            if(isset($_POST["Nombre2"]))
                $nombre=$_POST["Nombre2"];
            else
                echo '<br> No existe el Nombre ';
            if(isset($_POST["Telefono"]))
                $tel=$_POST["Telefono"];
            else
                echo '<br> No existe el dato ';
            if(isset($_POST["Correo"]))
                $correo=$_POST["Correo"];
            else
                echo '<br> No existe el dato ';
	    if(isset($_POST["listaeventos"]))
                $listaeve=$_POST["listaeventos"];
            else
                echo '<br> No existe el dato ';            
	    if(isset($_POST["Empresa"]))
                $empresa=$_POST["Empresa"];
            else
                echo '<br> No existe la empresa ';
	    if(isset($_POST["Pais"]))
                $pais=$_POST["Pais"];
            else
                echo '<br> No existe el País ';
	    if(isset($_POST["ListaEncargado"]))
                $listaenc=$_POST["ListaEncargado"];
            else
                echo '<br> No existe el Encargado ';
	    if(isset($_POST["Estado2"]))
                $estado=$_POST["Estado2"];
            else
                echo '<br> No existe el Nombre ';
if($hojadevida=="")
{
$hojadevida="";
}
        echo '<br>Datos'.$idLugar;
        echo '<br>Datos'.$nombre;
        $consulta1->Educador_actualizar($idlugar,$nombre,$tel,$correo,$listaeve,$empresa,$pais,$listaenc,$estado,$hojadevida);    	
        }
 ?>
            <meta http-equiv="Refresh" content="3;url=http://citein.hostingla.in/UL/Evento/Educador_ver.php">
             <?php
    }

else if($formulario=="Ingresar Educador")   
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
$target_dir = "../UL/Evento/uploads/";
        $hojadevida=basename($_FILES["fileToUpload"]["name"]);
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
 if (file_exists($target_file)) 
        {
            echo "El archivo ya existe.";
            $uploadOk = 0;
        }
        // verificar el tamaño del archivo
        if ($_FILES["fileToUpload"]["size"] > 1000000) 
        {
            echo "El archivo es muy pesado, escoge uno menos pesado";
            $uploadOk = 0;
        }
        // formato de archivos permitidos
        if($imageFileType != "pdf" && $imageFileType != "PDF") 
        {
            echo "Disculpe, solo se permiten archivos con extención PDF ";
            $uploadOk = 0;
        }
       if ($uploadOk == 0) 
        {
            echo "Disculpe, no se pudo cargar su archivo.";
        // if everything is ok, try to upload file    
        }
       else{
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
                {
                    echo "    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
                } 
                else 
                {
                    echo "Disculpe, se ha producido un error al intentar subir su archivo";
                }
            }
            if(isset($_POST["Nombre"]))
                $nombre=$_POST["Nombre"];
            else
                echo '<br> No existe el Nombre ';
            if(isset($_POST["Telefono"]))
                $tel=$_POST["Telefono"];
            else
                echo '<br> No existe el dato ';
            if(isset($_POST["Correo"]))
                $correo=$_POST["Correo"];
            else
                echo '<br> No existe el dato ';
	    if(isset($_POST["listaeventos"]))
                $listaeve=$_POST["listaeventos"];
            else
                echo '<br> No existe el dato ';            
	    if(isset($_POST["Empresa"]))
                $empresa=$_POST["Empresa"];
            else
                echo '<br> No existe la empresa ';
	    if(isset($_POST["Pais"]))
                $pais=$_POST["Pais"];
            else
                echo '<br> No existe el País ';
	    if(isset($_POST["NombreEncargado"]))
                $listaenc=$_POST["NombreEncargado"];
            else
                echo '<br> No existe el Encargado ';
        $consulta1->Educador_insertar($nombre,$tel,$correo,$listaeve,$empresa,$pais,$listaenc,$hojadevida);    	
        }
        ?>
            <meta http-equiv="Refresh" content="3;url=http://citein.hostingla.in/UL/Evento/Educador_ingresar.php">
             <?php
    }
    
    
    else if($formulario=="Evento Participante")
    {
        $contAsignacion=$cont=$idparticipante2=0;
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
               
            $contAsignacion=$_POST["contAsignacion"];	
	 $idevento=$_POST["idEvento"];
            for($cont=1;$cont<=$contAsignacion;$cont++)
            {
            if(isset($_POST["texto_costo".$cont]))
                    $costo=$_POST["texto_costo".$cont];
                    else
                    echo '<br> No existe el costo'.$cont;
            if(isset($_POST["lugar".$cont]))
                    $lugar=$_POST["lugar".$cont];
                    else
                    echo '<br> No existe el lugar'.$cont;
            if(isset($_POST["Participante".$cont]))
                    $idparticipante=$_POST["Participante".$cont];
                    else
                    echo '<br> No existe el Participante'.$cont;
                   $consulta1->EventoParticipante_insertar($idparticipante, $idevento, $costo, $lugar);
                    $costo=0;
                    $idevento=0;
            }       
   ?>
            <meta http-equiv="Refresh" content="3;url=http://citein.hostingla.in/UL/Evento/Evento_ver.php">
             <?php

        }
    }
    
    else if($formulario=="evento asistencia")
    {
        $pagDescripcion='\'../UL/Evento/Evento_ver_descripcion.php\'';
       if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            $idEvento=$_POST["idevento"];
            $idParticipante=$_POST["ideparticipante"];
            echo ''.$idEvento;
            echo ''.$idParticipante;
            $consulta1->EventoParticipante_Asistencia($idParticipante, $idEvento);
            //AbrirPagina('.$idEvento.','.$pagDescripcion.');
            echo    '<span style="cursor:pointer"; onclick="AbrirPagina('.$idEvento.','.$pagDescripcion.');">Continuar</span ">';
        }
    }

else if($formulario=="Actualizar Personal")
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if(isset($_POST["idPersonal"]))
                $id=$_POST["idPersonal"];
            else
                echo '<br> No existe el Registro';
            if(isset($_POST["Nombre"]))
                $nom=$_POST["Nombre"];
            else
                echo '<br> No existe el Nombre ';
            if(isset($_POST["Carnet"]))
                $carnet=$_POST["Carnet"];
            else
                echo '<br> No existe el Carnet ';
	    if(isset($_POST["Telefono"]))
                $tel=$_POST["Telefono"];
            else
                echo '<br> No existe el telefono ';
	    if(isset($_POST["Disponible2"]))
                $disponible=$_POST["Disponible2"];
            else
                echo '<br> No existe el registro ';
	    if(isset($_POST["Genero"]))
                $genero=$_POST["Genero"];
            else
                echo '<br> No existe el registro ';     
	    if(isset($_POST["Seccion"]))
                $seccion=$_POST["Seccion"];
            else
                echo '<br> No existe el registro ';
	    if(isset($_POST["Jornada"]))
                $jor=$_POST["Jornada"];
            else
                echo '<br> No existe el registro '; 
	    if(isset($_POST["GrupoEvento"]))
                $grupoid=$_POST["GrupoEvento"];
            else
                echo '<br> No existe el registro ';       

        echo '<br>Datos'.$id;
        echo '<br>Datos'.$nom;
        $consulta1->Personal_actualizar($id,$nom,$carnet,$tel,$disponible,$genero,$grupoid,$seccion,$jor);    	
        }
    }

    else if($formulario=="Actualizar Evento")
    {
        $descripcion="";
        
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
                $descripcion=$_POST["Descripcion"];
                $imagen=$_POST["archivoimagen"];
         //INICIA codigo para guardar imagen en la carpeta
        $target_dir = "../UL/Evento/uploads/";
        
        $diploma=basename($_FILES["fileToUpload"]["name"]);
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        // verificar si la lo que se cargó es una imagen
        if(isset($_POST["fileToUpload"])) 
        {
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if($check !== false) 
            {
                echo "El archivo es una imagen - " . $check["mime"] . ". ";
                $uploadOk = 1;
            } else 
            {
                echo "El archivo no es una imagen.";
                $uploadOk = 0;
            }
             // verificar si la imagen ya existe o no
        if (file_exists($target_file)) 
        {
            echo "El archivo ya existe.";
            $uploadOk = 0;
        }
        // verificar el tamaño del archivo
        if ($_FILES["fileToUpload"]["size"] > 1000000) 
        {
            echo "El archivo es muy pesado, escoge uno menos pesado";
            $uploadOk = 0;
        }
        // formato de archivos permitidos
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) 
        {
            echo "Disculpe, solo se permiten archivos con extención JPG, JPEG, PNG y GIF ";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) 
        {
            echo "Disculpe, no se pudo cargar su archivo.";
        // if everything is ok, try to upload file
        } else 
        {
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
        	{
                echo "    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
                
            } else 
        	{
                echo "Disculpe, se ha producido un herror al intentar subir su archivo";
            }
        }    
        }
       
//terminaimagen
            if(isset($_POST["idEvento"]))
                $ideve=$_POST["idEvento"];
            else
                echo '<br> No existe el Evento';
            if(isset($_POST["Nombre"]))
                $nombre=$_POST["Nombre"];
            else
                echo '<br> No existe Nombre ';
            if(isset($_POST["listaeventos"]))
                $tipoeve=$_POST["listaeventos"];
            else
                echo '<br> No existe el Evento ';
            if(isset($_POST["Fecha"]))
                $fecha=$_POST["Fecha"];
            else
                echo '<br> No existe la Fecha ';

$hi=$_POST["Nombre_horainicio"];
$mini=$_POST["Nombre_mininicio"];

if($hi=="Hora")
{
$horai=$_POST["HoraInicio"];
}
else
{
 if($mini<10)
{
$horai=$hi.$mini."000";
}
else
{
                $horai=$hi.$mini."00";
}
}

$hf=$_POST["Nombre_horafinal"];
$minf=$_POST["Nombre_minfinal"];
if($hf=="Hora")
{
$horaf=$_POST["HoraFinal"];
}
else
{
if($minf<10)
{
$horaf=$hf.$minf."0"."00";
}
else
{
                $horaf=$hf.$minf."00";
}
}
            if(isset($_POST["ListaGrupoEvento"]))
                $grupo=$_POST["ListaGrupoEvento"];
            else
                echo '<br> Error en el dato  ';
            if(isset($_POST["NombreEncargado"]))
                $encargado=$_POST["NombreEncargado"];
            else
                echo '<br> No existe Nombre  de Encargado';
            if(isset($_POST["Encuesta"]))
                $idencuesta=$_POST["Encuesta"];
            else
                echo '<br> No existe la Encuesta ';
            if(isset($_POST["Costo"]))
                $costo=$_POST["Costo"];
            else
                echo '<br> No existe el Costo ';

        $consulta1->Evento_actualizar($ideve,$nombre,$tipoeve,$fecha,$horai,$horaf,$grupo,$encargado,$idencuesta,$costo,$descripcion,$diploma); 
         ?>
            <meta http-equiv="Refresh" content="3;url=http://citein.hostingla.in/UL/Evento/Evento_ver.php">
             <?php   	
        }
    }

else if($formulario=="Insertar Evento")
    {
        $descripcion="";
        $conteo="";
        $consulta2=new Consulta;
       $pagAsignaredu='\'../UL/Evento/asignaciones.php\'';
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
        $descripcion=$_POST["Descripcion"];
         //INICIA codigo para guardar imagen en la carpeta
        $target_dir = "../UL/Evento/uploads/";
        $diploma=basename($_FILES["fileToUpload"]["name"]);
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        // verificar si la lo que se cargó es una imagen
        if(isset($_POST["fileToUpload"])) 
        {
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if($check !== false) 
            {
                echo "El archivo es una imagen - " . $check["mime"] . ". ";
                $uploadOk = 1;
            } else 
            {
                echo "El archivo no es una imagen.";
                $uploadOk = 0;
            }
            
        }
        // verificar si la imagen ya existe o no
        if (file_exists($target_file)) 
        {
            echo "El archivo ya existe.";
            $uploadOk = 0;
        }
        // verificar el tamaño del archivo
        if ($_FILES["fileToUpload"]["size"] > 1000000) 
        {
            echo "El archivo es muy pesado, escoge uno menos pesado";
            $uploadOk = 0;
        }
        // formato de archivos permitidos
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) 
        {
            echo "Disculpe, solo se permiten archivos con extención JPG, JPEG, PNG y GIF ";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) 
        {
            echo "Disculpe, no se pudo cargar su archivo.";
        // if everything is ok, try to upload file    
        }
//terminaimagen
            if(isset($_POST["Nombre"]))
                $nombre=$_POST["Nombre"];
            else
                echo '<br> No existe Nombre ';
            if(isset($_POST["listaeventos"]))
                $tipoeve=$_POST["listaeventos"];
            else
                echo '<br> No existe el Evento ';
            if(isset($_POST["Fecha"]))
                $fecha=$_POST["Fecha"];
            else
                echo '<br> No existe la Fecha ';
            if(isset($_POST["HoraInicio"]))
                $horai=$_POST["HoraInicio"];
            else
                echo '<br> Error en el dato ';
            if(isset($_POST["HoraFinal"]))
                $horaf=$_POST["HoraFinal"];
            else
                echo '<br> Error en el dato ';
            if(isset($_POST["GrupoEvento"]))
                $grupo=$_POST["GrupoEvento"];
            else
                echo '<br> Error en el dato  ';
            if(isset($_POST["NombreEncargado"]))
                $encargado=$_POST["NombreEncargado"];
            else
                echo '<br> No existe Nombre  de Encargado';
            if(isset($_POST["Encuesta"]))
                $idencuesta=$_POST["Encuesta"];
            else
                echo '<br> No existe la Encuesta ';
            if(isset($_POST["Costo"]))
                $costo=$_POST["Costo"];
            else
                $costo=0;
        $consulta1->Evento_verificar($grupo,$nombre);
        $row = mysql_fetch_assoc($consulta1->Resultado);
        if($row["Conteo"]==0)
        { 
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
                {
                    echo "    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
                } 
                else 
                {
                    echo "Disculpe, se ha producido un herror al intentar subir su archivo";
                }
                $parametros='\'NombreEvento='.$nombre.'\'';
                $consulta2->Evento_insertar($nombre,$tipoeve,$fecha,$horai,$horaf,$grupo,$encargado,$idencuesta,$costo,$descripcion,$diploma);
                echo    '<span style="cursor:pointer"; onclick="AbrirPaginaPostConParametros('.$pagAsignaredu.','.$parametros.');">Continuar</span ">';
        }
        else
        {
                echo "Ya existe un evento similar en este Grupo pruebe otra vez";
               ?>
            <meta http-equiv="Refresh" content="3;url=http://citein.hostingla.in/UL/Evento/Evento_ingresar.php">
             <?php
        }
        }
    }

    
 else if($formulario=="Actualizar Lugar")
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if(isset($_POST["idLugar"]))
                $idlugar=$_POST["idLugar"];
            else
                echo '<br> No existe el lugar';
            if(isset($_POST["Nombre"]))
                $nombre=$_POST["Nombre"];
            else
                echo '<br> No existe el Nombre ';
            if(isset($_POST["Capacidad"]))
                $capacidad=$_POST["Capacidad"];
            else
                echo '<br> No existe el dato ';
            if(isset($_POST["Disponible2"]))
                $disponible=$_POST["Disponible2"];
            else
                echo '<br> No existe el dato ';
            
        echo '<br>Datos'.$idLugar;
        echo '<br>Datos'.$nombre;
        $consulta1->Lugar_actualizar($idlugar,$nombre,$capacidad,$disponible);    	
        }
    }
else if($formulario=="Asignar Completo")
    {
        $contAsignacionPersonal=$contAsignacionSeccion=$contAsignacionJornada=$contAsignacionSemestre=$contAsignacionEducador=$contAsignacionLugar=$cont=0;
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
           $Asis=0;
           $idEvento=$_POST["idEvento"];
           $contAsignacionPersonal=$_POST["contAsignacionPersonal"];
           $contAsignacionLugar=$_POST["contAsignacionLugar"];
           $contAsignacionSemestre=$_POST["contAsignacionSemestre"];
           $contAsignacionEducador=$_POST["contAsignacionEducador"];
           $contAsignacionSeccion=$_POST["contAsignacionSeccion"];
           $contAsignacionJornada=$_POST["contAsignacionJornada"];
           
           if($contAsignacionPersonal>0)
           {
                for($cont=1;$cont<=$contAsignacionPersonal;$cont++)
                {
                    if(isset($_POST["Listalugares"]))
                        $idLugar=$_POST["Listalugares"];
                    else
                        echo '<br> No existe Lugar';
                        
                     if(isset($_POST["personal".$cont]))   
                        $idPer=$_POST["personal".$cont];
                    else
                        echo '<br> No existe Personal'.$cont;
                     $consulta1->EventoPersonal_insertar($idEvento,$idPer,$Asis,$idLugar);
                }
                $cont=0;
           }
           if($contAsignacionLugar>0)
           {
            for($cont=1;$cont<=$contAsignacionLugar;$cont++)
            {
                if(isset($_POST["lugar".$cont]))
                    $idLug=$_POST["lugar".$cont];
                else
                    echo '<br> No existe evento '.$cont;
                
                $consulta1->Lugar_asignar($idEvento,$idLug);
            }
             $cont=0;
           }
           if($contAsignacionSemestre>0)
           {
               for($cont=1;$cont<=$contAsignacionSemestre;$cont++)
                {
                if(isset($_POST["semestre".$cont]))
                    $idsem=$_POST["semestre".$cont];
                else
                    echo '<br> No existe Semestre '.$cont;
                $consulta1->semestre_asignar($idEvento,$idsem);    	
                }
                 $cont=0;
           }
           if($contAsignacionEducador>0)
           {
                for($cont=1;$cont<=$contAsignacionEducador;$cont++)
                {
                if(isset($_POST["educador".$cont]))
                    $idEdu=$_POST["educador".$cont];
                else
                    echo '<br> No existe educador '.$cont;
                $consulta1->EventoEducador_insertar($idEvento,$idEdu);  	
                }
                 $cont=0;
           }
           if($contAsignacionSeccion>0)
           {
                for($cont=1;$cont<=$contAsignacionSeccion;$cont++)
                {
                if(isset($_POST["seccion".$cont]))
                    $idseccion=$_POST["secion".$cont];
                else
                    echo '<br> No existe Seccion '.$cont;
                $consulta1->seccion_asignar($idEvento,$idseccion);      
                }
                 $cont=0;
           }
           if($contAsignacionJornadar>0)
           {
                for($cont=1;$cont<=$contAsignacionJornadar;$cont++)
                {
                if(isset($_POST["jornada".$cont]))
                    $idjornada=$_POST["jornada".$cont];
                else
                    echo '<br> No existe Jornada '.$cont;
                $consulta1->jornada_asignar($idEvento,$idjornada);      
                }
                 $cont=0;
           }
        }
          ?>
            <meta http-equiv="Refresh" content="3;url=http://citein.hostingla.in/UL/Evento/Evento_ingresar.php">
             <?php
    }
    else if($formulario=="Registro_gastos")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $nodocumento=$_POST["nodocumento"];
            $tipogasto=$_POST["TipoGasto"];
            $descripcion=$_POST["descripcion"];
            $monto=$_POST["monto"];
            $patrocinador=$_POST["Patrocinador"];
            $eventogrupo=$_POST["EventoGrupo"];
            $consulta1->Insertar_gasto($nodocumento,$tipogasto,$descripcion,$monto,$patrocinador,$eventogrupo);
            header("Location: http:/UL/Gastos/Gastos_ver.php");
        }
    }
    
    else if($formulario=="editar_gastos")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $nodocumento=$_POST["nodocumento"];
            $tipogasto=$_POST["TipoGasto"];
            $descripcion=$_POST["descripcion"];
            $monto=$_POST["monto"];
            $patrocinador=$_POST["Patrocinador"];
            $id=$_POST["idgasto"];
            $consulta1->Gasto_actualizar($id,$nodocumento,$tipogasto,$descripcion,$monto,$patrocinador);
            header("Location: http:/UL/Gastos/Gastos_ver.php");
        }
    }
    
    else if($formulario=="eliminar_gastos")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $id=$_POST["idgasto"];
            $consulta1->Gasto_eliminar($id);
            ?>
            <meta http-equiv="Refresh" content="3;url=http:/UL/Gastos/Gastos_ver.php">
            <?php
        }
    }
    
    else if($formulario=="Registrar_usuario")
    {
         if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $nombre=$_POST["nombre"];
            $usuario=$_POST["user"];
            $contrasena=$_POST["password"];
            $tipousuario=$_POST["TipoUsuario"];
            if($consulta1->Usuario_VerificarUsuario($usuario)==0)
            {
            $consulta1->Usuario_IngresarUsuario($nombre,$usuario,$contrasena,$tipousuario);
            header("Location: http:/UL/Usuarios/Usuario_ver.php");
            }
            else
            {
            ?>
            //<H2>El usuario elegido ya existe</H2>
            <meta http-equiv="Refresh" content="1;url=http:/UL/Usuarios/Usuario_ingresar.php">
            <?php
            }
        }
    }
    
    else if($formulario=="Eliminar_Usuario")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $id=$_POST["idusuario"];
            $consulta1->Usuario_eliminar($id);
            ?>
            <meta http-equiv="Refresh" content="3;url=http:/UL/Usuarios/Usuario_ver.php">
            <?php
        }
    }
    
    else if($formulario=="editar_usuario")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $id=$_POST["idusuario"];
            $nombre=$_POST["nombre"];
            $contrasena=$_POST["pass"];
            $estado=$_POST["estado"];
            $consulta1->Usuarios_actualizar($id,$nombre,$contrasena,$estado);
            header("Location: http:/UL/Usuarios/Usuario_ver.php");
        }
    }
    
    else if($formulario=="Ingresar_TipoGasto")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $TipoGasto=$_POST["TipoGasto"];
            if($consulta1->TipoGasto_Verificartipogasto($TipoGasto)==0)
            {
                $consulta1->Ingresar_TipoGasto($TipoGasto);
                header("Location: http:/UL/Gastos/TipoGasto_ver.php");

            }
            else
            {
                header("Location: http:/UL/Gastos/TipoGasto_error.php");
                ?>
                //<H2>El tipo de gasto ya existe</H2>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Gastos/TipoGasto_ingresar.php">
                <?php
            }
        }
    }
    
    else if($formulario=="editar_TipoGasto")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $TipoGasto=$_POST["descTipoGasto"];
            $idTipoGasto=$_POST["idTipoGasto"];
            $estado=$_POST["estado"];
            if($consulta1->TipoGasto_VerificarTipoGastoNombre($TipoGasto,$idTipoGasto)==0)
            {
                $consulta1->TipoGasto_actualizar($idTipoGasto, $TipoGasto, $estado);
                header("Location: http:/UL/Gastos/TipoGasto_ver.php");
            }
            else
            {
                header("Location: http:/UL/Gastos/TipoGasto_error.php");
                ?>
                <H2>El tipo de gasto ya existe</H2>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Gastos/TipoGasto_ver.php">
                <?
            }
        }
    }
    
    else if($formulario=="eliminar_TipoGasto")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
           $idTipoGasto=$_POST["idtipogasto"];
           $consulta1->TipoGasto_listarporid($idTipoGasto);
           $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
            {
                $consulta1->TipoGasto_eliminar($idTipoGasto);
                ?>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Gastos/TipoGasto_ver.php">
                <?   
            }
            else if(mysql_num_rows($res)>0)
            {
                 ?>
                <H3>El tipo de gasto no se puede eliminar por estar</H3>
                <h3>relacionado con otras tablas</h3>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Gastos/TipoGasto_ver.php">
                <?php
            }
        }
    }
    
    else if($formulario=="GrupoEvento_actualizar")
    {
        $contador=0;
        $diploma="";
         //INICIA codigo para guardar imagen en la carpeta
        $target_dir = "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/UL/DIPLOMA/DiplomaImagen/"; 
        $diploma=basename($_FILES["fileToUpload"]["name"]);
            if($diploma=="")
            {
                 if (!empty($_POST["listaImagenes"]))
                {
                $diploma=$_POST["listaImagenes"];
                ++$contador;
                }
            
            }
            else
            if($diploma!="")
            {
        
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        // verificar si la lo que se cargó es una imagen
        if(isset($_POST["fileToUpload"])) 
        {
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if($check !== false) 
            {
                echo "El archivo es una imagen - " . $check["mime"] . ". ";
                $uploadOk = 1;
            } else 
            {
                echo "El archivo no es una imagen.";
                $uploadOk = 0;
            }
            
        }
        // verificar si la imagen ya existe o no
        if (file_exists($target_file)) 
        {
            echo "El archivo ya existe.";
            $uploadOk = 0;
        }
        // verificar el tamaño del archivo
        if ($_FILES["fileToUpload"]["size"] > 1000000) 
        {
            echo "El archivo es muy pesado, escoge uno menos pesado";
            $uploadOk = 0;
        }
        // formato de archivos permitidos
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) 
        {
            echo "Disculpe, solo se permiten archivos con extención JPG, JPEG, PNG y GIF ";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) 
        {
            echo "Disculpe, no se pudo cargar su archivo.";
        // if everything is ok, try to upload file
        } else 
        {
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
            {
                echo "    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
                ++$contador;
            } else 
        	{
                echo "Disculpe, se ha producido un herror al intentar subir su archivo";
            }
        }
      
        }
        
        
            
            if (!empty($_POST["Nombre"]))
    		{
                $Nombre=$_POST["Nombre"];
                ++$contador;
    		}
            if (!empty($_POST["FechaInicio"]))
        	{
                $Fecha1=$_POST["FechaInicio"];
                ++$contador;
        	}
            if (!empty($_POST["FechaFinal"]))
            {
                $Fecha2=$_POST["FechaFinal"];
                    ++$contador;
        	}
            if (!empty($_POST["CostoInscripcion"]))
            {
                $costo=$_POST["CostoInscripcion"];
                ++$contador;
            }
            if (!empty($_POST["descripcion"]))
            {
                $descripcion=$_POST["descripcion"];
                ++$contador;
            }
            if (!empty($_POST["text_estado"]))
            {
                $estado=$_POST["text_estado"];
                echo 'estado recibido: '.$estado;
                if($estado=="Activar")
                {
                    $estado=1;
                }
                else if($estado=="Desactivar") {$estado=0;}
                ++$contador;
            }
           
            
            
            $id=$_POST["cod"];
            if($contador==7)
            {
                $consulta1->GrupoEvento_actualizar($Nombre,$Fecha1,$Fecha2,$costo,$descripcion,$diploma,$estado,$id);
                /*echo $consulta1->Consulta;
                echo 'nombre: '.$Nombre.'<br>';
                 echo 'fecha1: '.$Fecha1.'<br>';
                  echo 'fecha2: '.$Fecha2.'<br>';
                   echo 'costo: '.$costo.'<br>';
                    echo 'descripcion: '.$descripcion.'<br>';
                     echo 'diploma: '.$diploma.'<br>';
                      echo 'estado: '.$estado.'<br>';*/
                
                 ?>
            <meta http-equiv="Refresh" content="3;url=http://citein.hostingla.in/UL/GRUPO_EVENTOS/GrupoEvento_ver.php">
             <?php
            }
            else
            {
                echo 'llene todos los campos';
               // echo '<script language="javascript">alert("Llene todos los campos");</script>'; 
                ?>
            <meta http-equiv="Refresh" content="3;url=http://citein.hostingla.in/UL/GRUPO_EVENTOS/GrupoEvento_Editar.php">
             <?php
            }
        
    }
    
    else if($formulario=="Ingresar_Jornada")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $jornada=$_POST["jornada"];
            if($consulta1->Jornada_VerificarJornada($jornada)==0)
            {
                $consulta1->Ingresar_Jornada($jornada);
                header("Location: http:/UL/Jornada/Jornada_ver.php");
            }
            else
            {
                header("Location: http:/UL/Jornada/Jornada_error.php")
                ?>
                <H2>La jornada ya existe</H2>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Jornada/Jornada_ingresar.php">
                <?php
            }
        }
    }
    
    else if($formulario=="editar_Jornada")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $Jornada=$_POST["Jornada"];
            $idJornada=$_POST["idJornada"];
            $estado=$_POST["estado"];
            if($consulta1->Jornada_VerificarJornadaNombre($Jornada,$idJornada)==0)
            {
                $consulta1->Jornada_actualizar($idJornada, $Jornada, $estado);
                header("Location: http:/UL/Jornada/Jornada_ver.php");
            }
            else
            {
                header("Location: http:/UL/Jornada/Jornada_error.php")
                ?>
                <H2>La jornada ya existe</H2>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Jornada/Jornada_ver.php">
                <?
            }
        }
    }
    
    else if($formulario=="eliminar_Jornada")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
           $idjornada=$_POST["idjornada"];
           $consulta1->Jornada_listarporid($idjornada);
           $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
            {
                $consulta1->Jornada_eliminar($idjornada);
                ?>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Jornada/Jornada_ver.php">
                <?   
            } 
            else if(mysql_num_rows($res)>0)
            {
                 ?>
                <H3>La jornada no se puede eliminar por estar</H3>
                <h3>relacionada con otras tablas</h3>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Jornada/Jornada_ver.php">
                <?php
            }
        }
    }
    
        else if($formulario=="Ingresar_Seccion")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $seccion=$_POST["seccion"];
            if($consulta1->Seccion_VerificarSeccion($seccion)==0)
            {
                $consulta1->Ingresar_Seccion($seccion);
                header("Location: http:/UL/Seccion/Seccion_ver.php");
            }
            else
            {
                header("Location: http:/UL/Seccion/Seccion_error.php");
                ?>
                <H2>La sección ya existe</H2>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Seccion/Seccion_ingresar.php">
                <?php
            }
        }
    }
    
    else if($formulario=="editar_Seccion")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $seccion=$_POST["seccion"];
            $idSeccion=$_POST["idSeccion"];
            $estado=$_POST["estado"];
            if($consulta1->Seccion_VerificarSeccionNombre($seccion,$idSeccion)==0)
            {
                $consulta1->Seccion_actualizar($idSeccion, $seccion, $estado);
                header("Location: http:/UL/Seccion/Seccion_ver.php");
            }
            else
            {
                header("Location: http:/UL/Seccion/Seccion_error.php");
                ?>
                <H2>La sección ya existe</H2>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Seccion/Seccion_ver.php">
                <?
            }
        }
    }
    
    else if($formulario=="eliminar_Seccion")
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
           $idseccion=$_POST["idseccion"];
           $consulta1->Seccion_listarporid($idseccion);
           $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
            {
                $consulta1->Seccion_eliminar($idseccion);
                ?>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Seccion/Seccion_ver.php">
                <?   
            } 
            else if(mysql_num_rows($res)>0)
            {
                 ?>
                <H3>La sección no se puede eliminar por estar</H3>
                <h3>relacionada con otras tablas</h3>
                <meta http-equiv="Refresh" content="3;url=http:/UL/Seccion/Seccion_ver.php">
                <?php
            }
        }
    }
    else if($formulario=="Patrocinador_editar")
    {
                
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
    	{
           
				$nombre = $_POST["text_nombre"];
				$telefon = $_POST["text_telefono"];
				$empresa=$_POST["text_empresa"];
                $cenas = $_POST["text_cenas"];
				$estado = $_POST["text_estado"];
                if($estado=='Activar')
                {
                    $estado=1;
                }
                else 
                if($estado=='Desactivar')
                {
                    $estado=0;
                }
            
            $descripcion=$_POST['descripcion'];    		
			$nuevoId=$_POST['id'];
            /*
				echo 'nombre:'.$nombre.'<br>';
				echo 'telefono:'.$telefon.'<br>';
				echo 'empresa:'.$empresa.'<br>';
				echo 'cenas:'.$cenas.'<br>';
				echo 'descrip:'.$descripcion.'<br>';
				echo 'Estado:'.$estado.'<br>';
				echo 'iddd:'.$nuevoId.'<br>';*/
                $consulta1->Patrocinador_verificar_nombre2($nuevoId,$nombre);
                $res=$consulta1->Resultado;

                while($row = mysql_fetch_assoc($res))
                {
    					$temp=$row["Cantidad"];                        
    			}
           
    			mysql_free_result($res);
                if($temp==0)
        		{
    				$x=$consulta1->Actualizar_patrocinador($nombre,$telefon,$empresa,$cenas,$descripcion,$estado,$nuevoId);
    				header("Location: http:/UL/PATROCINADOR/Patrocinador_ver.php");
        		}
                else
                {
                    echo'<script> alert("Ya existe un registro con el mismo nombre, por favor cámbielo ");</script>';
                }
					
		}
					
    }

	function test_input($data) 
    {

	   $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}
?>

<center>
<font face="Arial"><b>Redireccionando...<br><br>
</center>

<script>
setTimeout("window.location.href="+<?php echo '"\"'.$direccion.'\""';?>,500);
</script>

</body>
</html>
<?php
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";    
    $serv=new Servidor;    
    $id_foto=date('YmdHis');//Extraemos la fecha del servidor    
	$consulta="INSERT INTO `hos7_15945417_citein`.`prueba` (`idPrueba` ,`Nombre` ,`Telefono`)VALUES (".$id_foto.", 'pagina', NULL)";
    if(!$serv->conexion)
        $serv->conectar();
	$inserta_foto=mysql_query($consulta,$serv->conexion);
	//este funciona tambien-> $filename = "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/fotos/".$id_foto.'.jpg';
	//se concatena la direccion de la carpeta donde se va a guardar con el id de la foto y la extencion
    $filename = "../fotos/".$id_foto.'.jpg';// este funciona
    move_uploaded_file($_FILES['webcam']['tmp_name'], $filename);

	//$url= 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['REQUEST_URI']).'/'.$filename;//generamos la respuesta como la ruta completa
    
    //Se genera la direccion url de la imagen.
	//echo 'http://'.$_SERVER['HTTP_HOST'].'/fotos/'.$id_foto.'jpg';//imprimimos la ruta de la fotografia.	
    echo $id_foto;//retornamos el id de la foto.
?>
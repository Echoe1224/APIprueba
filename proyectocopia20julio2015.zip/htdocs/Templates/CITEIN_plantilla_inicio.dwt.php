<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../UL/CITEIN/estilos_inicio.css"  />
<link rel="stylesheet" href="../UL/CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../UL/CITEIN/main.js"></script>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
?>
<!-- TemplateBeginEditable name="doctitle" -->
<title>Documento sin título</title>
<!-- TemplateEndEditable -->
<!-- TemplateBeginEditable name="head" -->
*
*
**********************************Libreias  u otras cosas de encabeza AQUÍ*************************************
*
*
<!-- TemplateEndEditable -->
</head>

<body>
<div id="wrapper">
    <div id="header"><!-- Encabezado             ------------------------------------------>
      <header class="primary-header group">
          <div style="float:left; color:#FFF;">
        	<img height="30px;" src="../UL/CITEIN/Universidad.png" alt="UMESQ" style="float:left;" />
             CITEIN
          </div>
        <nav class="nav primary-nav">
            <a href="../index.php"><i class="icon icon-home"></i> Inicio</a>   /
            <a href="../pagina/participante.php"><i class="icon icon-accessibility"></i> Participante</a>   /   
            <a href="javascript:login();"><i class="icon icon-enter"></i> Iniciar Sesión</a>
          </nav>
        </header>
    </div>
    <div id="content">
    <!-- Contenido            ------------------------------------------------->
        <div class="modal-container">
			<div id="modal" class="modal"></div>
		</div>
    <!-- TemplateBeginEditable name="Contenido" -->
        *
        *
        **********************************Código fuente AQUÍ*************************************
        *
        *
    <!-- TemplateEndEditable -->
    </div>
    <div id="footer">
          <label style="color:#999;">CITEIN 2015</label>
          <br/>
          <label style="color:#999; text-align:right;">UNIVERSIDAD MESOAMERICANA</label>
    </div>
</div>
<script>
	function login()
	{
		abrirMPost("","../UL/Login/login.php");
	}
</script>
</body>
</html>

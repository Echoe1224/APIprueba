<?php
function menu()
{
?>
	    <nav class="menu">
        <ul>
            <li><a href="../Inicio/inicio.php"><span class="primero"><i class="icon icon-home"></i></span>CITEIN</a>
	            <?php if($_SESSION['tipo']==1){ ?>
	            <ul class="primero">
                    <li><a href="../GRUPO_EVENTOS/GrupoEvento_ver.php">Eventos</a></li>
                </ul>
                <?php } ?>
            </li>
        <?php
        if($_SESSION['tipo']==1 || $_SESSION['tipo']==2)
        {
        ?>
<!-- Menú Evento -->
            <li><a href="../Evento/Evento_ver.php"><span class="segundo"><i class="icon icon-table2"></i></span>ACTIVIDAD</a>
                <ul class="segundo">
                    <li><a href="../Evento/Evento_ver.php">Actividades</a></li>
                    <li><a href="../Evento/Educador_ver.php" >Educadores</a></li>
                    <li><a href="../Encuesta/Encuesta_ver.php" >Encuestas</a></li>
                </ul>
            </li>
<!-- Menú Participante -->
            <li><a href="../Participante/Participante_ver.php"><span class="tercero"><i class="icon icon-accessibility"></i></span>PARTICIPANTE</a>
                <ul class="tercero">
                    <li><a href="../Participante/Participante_ver.php">Participantes</a></li>
                    <li><a href="../Playera/Playera_ver.php">Playeras</a></li>
                </ul>
            </li>
<!-- Menú Administrador -->
            <?php if($_SESSION['tipo']==1){ ?>
            <!--<li><a href="../Usuarios/Usuario_ver.php"><span class="cuarto"><i class="icon icon-user-tie"></i></span>ADMINISTRADOR</a>
                
            </li>-->
            <?php } ?>
<!-- Menú Personal -->
            <li><a href="../Evento/Personal_ver.php"><span class="quinto"><i class="icon icon-user"></i></span>PERSONAL</a>
                <ul class="quinto">
                    <li><a href="../Evento/Personal_ver.php">Personal</a></li>
                    <?php if($_SESSION['tipo']==1){ ?>
                    <li><a href="../Usuarios/Usuario_ver.php">Usuarios</a></li>
                    <li><a href="../Gastos/Gastos_ver.php">Gastos</a></li>
                    <li><a href="../PATROCINADOR/Patrocinador_ver.php">Patrocinadores</a></li>
                    <?php } ?>
                </ul>
            </li>
<!-- Menú Reportes -->
            <li><a href="../Reporte/GrupoEvento_reporte.php"><span class="sexto"><i class="icon icon-file-text2"></i></span>REPORTES</a>
                <ul class="sexto">
                    <li><a href="../Reporte/GrupoEvento_reporte.php">Reporte de eventos</a></li>
                    <li><a href="../Reporte/Evento_reporte.php">Reporte de actividades</a></li>
                    <li><a href="../Reporte/Participante_reporte.php">Reporte de participantes</a></li>
                    <li><a href="../Reporte/Personal_reporte.php">Reporte de personal</a></li>
                    <li><a href="../Reporte/Patrocinador_reporte.php">Reporte de patrocinadores</a></li>
                    <li><a href="../Reporte/Gastos_reporte.php">Reporte de gastos</a></li>
                </ul>
            </li>
<!-- Menú Mantenimiento -->
            <li><a href="#"><span class="septimo"><i class="icon icon-equalizer2"></i></span>MANTENIMIENTO</a>
                <ul class="septimo">
                    <li><a href="../Evento/Semestre_ver.php">Semestres</a></li>
                    <li><a href="../Jornada/Jornada_ver.php">Jornadas</a></li>
                    <li><a href="../Seccion/Seccion_ver.php">Secciones</a></li>
                    <li><a href="../Evento/TipoEvento_ver.php">Tipos de actividad</a></li>
                    <li><a href="../Evento/Lugar_ver.php" >Lugares</a></li>
                    <?php if($_SESSION['tipo']==1){ ?>
                    <li><a href="../Gastos/TipoGasto_ver.php">Tipos de gasto</a></li>
                    <?php } ?>
                    
                </ul>
            </li>
        <?php  
        }
        if($_SESSION['tipo']==3)
        {
        ?>
        <li><a href="#"><span class="septimo"><i class="icon icon-equalizer2"></i></span>REPORTES</a>
                <ul class="septimo">                    
                    <li><a href="../Reporte/Evento_reporte.php">Reporte de actividades</a></li>
                    <li><a href="../Reporte/Participante_reporte.php">Reporte de participantes</a></li>
                </ul>
            </li>
        <?php
        }
    
        if($_SESSION['tipo']==4)
        {
        ?>
        <li><a href="/UL/Participante/Participante_ver.php"><span class="septimo"><i class="icon icon-equalizer2"></i></span>REGISTRO DE PARTICIPANTES</a>
                <ul class="septimo">
                <li><a href="/UL/Participante/Participante_ver.php">Participantes</a></li>
                <li><a href="../Playera/Playera_ver.php">Playeras</a></li>
                </ul>
            </li>
        <?php
        }
        
        if($_SESSION['tipo']==5)
        {
        ?>
        <li><a href="/UL/Evento/Evento_ver2.php"><span class="septimo"><i class="icon icon-equalizer2"></i></span>CONTROL DE ASISTENCIA</a>
                <ul class="septimo">
                <li><a href="/UL/Evento/Evento_ver2.php">Control de asistencia</a></li>
                </ul>
            </li>
        <?php
        }
         if($_SESSION['tipo']==6)
        {
        ?>
        <li><a href="/UL/GRUPO_EVENTOS/GrupoEvento_ver_restingido.php"><span class="septimo"><i class="icon icon-equalizer2"></i></span>IMPRESIÓN DE DIPLOMAS</a>
                <ul class="septimo">
                <li><a href="/UL/GRUPO_EVENTOS/GrupoEvento_ver_restingido.php">Impresión de asistencia</a></li> 
                </ul>
            </li>
        <?php
        }
        ?>
            
        </ul>
    </nav>
<?php
}
?>
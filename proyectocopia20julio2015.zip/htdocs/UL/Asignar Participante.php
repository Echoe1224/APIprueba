<?php
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	$consulta1=new Consulta;
// define variables and set to empty values
$errorcosto = "";
$costo = "";
$cont=0;
$sinErrores="f";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["texto_costo"])) {
	   	$errorcosto = "El costo es requerido";
		$sinErrores="f";
	}
	else {
		$costo = test_input($_POST["texto_costo"]);
	    // check if name only contains letters and whitespace
		if (!preg_match("/^[0-9]*$/",$costo)) {
    		$errorcosto = "Ingrese solamente números sin espacios.";
			$sinErrores="f";
			}
	}
	
	if($sinErrores=="v")
	{
		
		$consulta1->ControlParticipante_insertar($idlugar, $nombre, $capacidad, '1');
	}
}

function test_input($data) {
   $data = trim($data); 	
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<style type="text/css">
	.error {color: #FF0000;}
		#results {
			margin: 20px;
			padding: 20px;
			padding-top:0px;
			border: 1px solid;
			background: #ccc;
		}
    </style>
    
</head>

<body bgcolor="#006633" text="#FFFFFF">
  	<h1 style="text-align:left"><img src="../Logo-Meso-Color.png" width="150" height="141" alt="TextAlt">CITEIN</h1>
	<h1 style="text-align:center">Asignar Participante</h1>
		<form name="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">            
       	  <table width="800" height="183" border="0" align="center" style="background:#333333">
        		<td width="358" valign="top" nowrap="nowrap">
<!--  *********************************************************Formulario**************************************************** -->                
                <p><span class="error">* Campos requeridos.</span></p>
                <p>Grupo  Evento:
                  <select name="Nombre_grupoevento" id="Nombre_grupoevento" selectedvalue=>
                    <?php
				$consulta1->GrupoEvento_ver();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['idGrupoEvento'].">".$row['Nombre']."</option>";
				}
				?>
                  </select>
</p>
                <p>Participante:
                  <select name="Nombre_participante" id="Nombre_participante" selectedvalue=>
                    <?php
				$consulta1->Participante_ver();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['idParticipante'].">".$row['Nombre']."</option>";
				}
				?>
                  </select>
                </p>
                <p>
                  <label for="texto_costo">Costo de Inscripión: </label>
                  <input name="texto_costo" type="text" id="texto_costo" value="<?php echo $costo;?>" size="50" maxlength="45">
                  <span class="error">* <?php echo $errorcosto;?></span> </p>
                <p>Playera Entregada:
                  <select name="Nombre_playera" id="Nombre_playera" selectedvalue=>
                  <option value="0">Elija una opción</option>
  				   
					<option value="1">Entregada</option>
                    <option value="0">No Entregada</option>
                  </select>
</p>
                <p>Certificado Entregado:
                  <select name="Nombre_certificado" id="Nombre_certificado" selectedvalue=>
                    <option value="0">Elija una opción</option>
  				   
					<option value="1">Entregado</option>
                    <option value="0">No Entregado</option>
                  </select>
</p>
                <p>Pagado:
                  <select name="Nombre_tipoevento5" id="Nombre_tipoevento5" selectedvalue=>
                    <option value="0">Elija una opción</option>
                    
  				   <option value="1">Cancelado</option>
                   <option value="0">No Cancelado</option>
                  </select>
<br/>
                </p>
        		<p><br/>
        		</p>
        		<p>&nbsp;</p>
        		<div id="boton_guardar">
                <input type="submit" name="boton_guardar" id="boton_guardar" value="Guardar"> 
                <input type="button" name="boton_cancelar" id="boton_cancelar" value="Cancelar" onClick="almacenar_captura()">
                </div>
                </td>
                <td width="190" align="center" valign="top">
<!-- ********************************Lugar donde se desplegara la imagen tomada******************************** -->

<div id="boton_recapturar" style="display:none">
		  <input value="Tomar Otra" onclick="adjuntarCamara()" type="button">
				</div>
                <p><br/>
                </p>
<!-- ********************************Configurar la toma de fotografía********************************************* -->
                <div style="text-align: center;" id="my_camera"></div>
				<!-- Primero, se incluirá la librería de javascrip "webcam.js" --> 
				<script type="text/javascript" src="webcam.js"></script> 
				<!-- configurar la camara (tamaño, formato, calidad) --> 
				<script language="JavaScript">
				Webcam.set({
					width: 320,
					height: 240,
					image_format: 'jpeg',
					jpeg_quality: 90
				});
				</script>
                <!-- botones -->
				<div id="boton_activar_camara"></div>
        		<div id="boton_capturar" style="display:none">
				<input type="button" onClick="capturar()" value="Capturar">
                </div>                
        		<div id="boton_capturado" style="display:none">
				<input value="Tomar Otra" onclick="otra_captura()" type="button">
				<input value="Guardar Foto" onclick="guardar_captura()" type="button">
				</div>
                
        		<!-- Codigo para manejar la captura y desplegar localmente -->
		        <script language="JavaScript">
				function adjuntarCamara(){
					Webcam.attach('#my_camera');
					//document.getElementById('results').style.display = 'none';
					document.getElementById('boton_activar_camara').style.display = 'none';
					document.getElementById('boton_recapturar').style.display = 'none';
					document.getElementById('boton_capturar').style.display = '';
					document.getElementById('results').style.display = 'none';				
				}
				function capturar() {
					// congelar la camara para que el usuario pueda ver la captura.
					Webcam.freeze();
					// swap button sets
					document.getElementById('boton_capturar').style.display = 'none';
					document.getElementById('boton_capturado').style.display = '';
				}
				function otra_captura() {
					// cancelar la captura y activar la camara en vivo.
					Webcam.unfreeze();
					// swap buttons back
					document.getElementById('boton_capturar').style.display = '';
					document.getElementById('boton_capturado').style.display = 'none';
				}
				function guardar_captura() {
					// actualmente se ha hecho una captura y se ha desplegado.
					Webcam.snap( function(data_uri) {
						// desplegar los resultados en la pagina.
						//document.getElementById('results').innerHTML = '<h2>Fotografía:</h2>' + '<img src="'+data_uri+'"/>';
						// Ocultar botones para que ya no se pueda tomar ninguna fotografía desde de haber guardado.
						document.getElementById('boton_capturar').style.display = 'none';
						document.getElementById('boton_capturado').style.display = 'none';
						document.getElementById('boton_recapturar').style.display = '';
						document.getElementById('results').style.display = '';
						//document.getElementById('results').style.display = '';
						/*document.getElementById('results').innerHTML = 
    			        		'<h2>Foto del participante</h2>' + 
								'<img src="'+data_uri+'"/>';*/
						document.getElementById('foto').src=data_uri;
						document.getElementById('data_uri').value=data_uri;
						Webcam.reset();
						} );
				}
				function almacenar_captura(){
					Webcam.upload(var_temp, 'http://citein.hostingla.in/DAL/guardar_foto.php', function(code, text) {
    	    	            // Upload complete!
		        	        // 'code' will be the HTTP response code from the server, e.g. 200
        		    	    // 'text' will be the raw response content
							
			        	} );	
				}
				</script>
      		</td>
      </table>
</form>
</body>
</html>
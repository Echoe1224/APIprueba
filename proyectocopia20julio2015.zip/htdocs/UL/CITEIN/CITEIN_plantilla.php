<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CITEIN_plantilla</title>
<link rel="stylesheet" href="estilos.css"  />
<link rel="stylesheet" href="fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="main.js"></script>
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
        <header>
		<nav class="menu">
			<ul>
				<li><a href="#"><span class="primero"><i class="icon icon-home"></i></span>CITEIN</a></li>
				<li><a href="#"><span class="segundo"><i class="icon icon-table2"></i></span>EVENTOS</a>
					<ul>
						<li><a href="#">Ver eventos</a></li>
						<li><a href="#">Crear evento</a></li>
					</ul>
				</li>
				<li><a href="#"><span class="tercero"><i class="icon icon-accessibility"></i></span>PARTICIPANTES</a>
					<ul>
						<li><a href="#">Ver participantes</a></li>
						<li><a href="../Registrar_Participante.php">Nuevo participante</a></li>
					</ul>
                </li>
				<li><a href="#"><span class="cuarto"><i class="icon icon-user"></i></span>PERSONAL</a>
					<ul>
						<li><a href="#">Ver personal</a></li>
						<li><a href="#">Nuevo personal</a></li>
					</ul>
                </li>
				<li><a href="#"><span class="quinto"><i class="icon icon-exit"></i></span>Cerrar Sesión</a></li>
			</ul>
		</nav>
        </header>
        </div>

<div class="contenedor">
	<div class="contenido">
    
    </div>
    
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
</html>

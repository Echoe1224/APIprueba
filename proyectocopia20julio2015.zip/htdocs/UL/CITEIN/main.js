// JavaScript Document
$(document).ready(function()
{
    if($('.menu').length)
    {
    var altura = $('.menu').offset().top;
	$(window).on('scroll', function()
	{
		if ( $(window).scrollTop() > altura ){
			$('.menu').addClass('menu-fixed');
		}
		else {
			$('.menu').removeClass('menu-fixed');
		}
	});
	}
});
$(document).ready(function(e) 
{
	$('#to-the-top').on('click',  function(e) 
	{
		e.preventDefault();
		$("html, body").animate({
		'scrollTop': 0
		}, 2000);
	});
});
/*$(document).ready(function()
{
	if($('.modal-container').length)
	{
	$('.modal-container').on('click', function()
	{
		cerrarM();
	});
	}
});*/
/*Para páginas modales*/
var body,
    modal_container = $('.modal-container');
function abrirMGet(param,pagina)
{
	$(".modal-container").slideDown("slow");
	ProcesarPaginaGetConParametros(pagina,param,"modal");
	toggleModal();
}
function abrirMPost(param,pagina)
{
	$(".modal-container").slideDown("slow");
	ProcesarPaginaPostConParametros(pagina,param,"modal");
	toggleModal();
}
function cerrarM()
{
	$(".modal-container").slideUp("slow");
	toggleModal();
}
function toggleModal()
{
	if($('#wrapper').length)
		body=$('#wrapper').parent();
	else if($('.contenido').length)
		body=$('.contenido').parent().parent();
	else
		body=$('body');
	body.toggleClass('body-locked');
	modal_container.toggleClass('dp-block');
}
//Imprimir
function imprimir(element)
	{
		var contenidoImpresion=document.getElementById(element).innerHTML;
		var originalContents = document.body.innerHTML;
		document.body.innerHTML = contenidoImpresion;
		window.print();
		document.body.innerHTML = originalContents;
	}
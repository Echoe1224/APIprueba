<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Listado de eventos</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/Templates/menu.php";*/
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<link rel="icon" type="image/ico" href="../../favicon.ico" />
<!-- InstanceBeginEditable name="head" -->
<?php
   
    $diploma='';
	$codigoActividad=0;

    
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
			if($_POST['lista_actividad']!='')
			{
				$codigoActividad=$_POST['lista_actividad'];
			}
		
            $ejex=$ejey='';
            //---------Nombre participante--------------
			session_start();
			
            $filtro=$_POST['idRegistro'];
			$filtro2=$_POST['idParticipante'];
			$_SESSION['mycod']=$filtro;
			if($filtro!='')
			{
				$consulta1->Participante_ver_nombre($filtro);
				$ver = mysql_fetch_assoc($consulta1->Resultado);
				$NombreParticipante=$ver['Nombre'];
				
			}
			elseif($filtro2!='')
			{
				$consulta1->Participante_ver_nombre($filtro2);
				$ver = mysql_fetch_assoc($consulta1->Resultado);
				$NombreParticipante=$ver['Nombre'];
				$filtro=$filtro2;
			}
            
            //---------Imagen diploma--------------
            $codigo=$_SESSION['codGE'];
            $consulta1->GrupoEvento_ver_diploma($codigo);
			$row = mysql_fetch_assoc($consulta1->Resultado);
			$diploma=$row['Diploma'];
			$UrlDiploma='../../UL/DIPLOMA/DiplomaImagen/'.$diploma;
			//-------Recuperar posiciones nombre----------
			$consulta1->Posiciones_ver($codigo);
			$row = mysql_fetch_assoc($consulta1->Resultado);
            $ejex=$row['X'];
            $ejey=$row['Y'];;
			//-------Recuperar posiciones de actividad
			$consulta1->Posiciones_ver_tipoEvento($codigo);
			$pos = mysql_fetch_assoc($consulta1->Resultado);
            $XtE=$pos['CordeXtipoEvento'];
            $YtE=$pos['CordeYtipoEvento'];
			
//<a href="Diploma_imagen.php?codigo='.$codigo.'&X='.$ejex.'&Y='.$ejey.'&nombre='.$NombreParticipante.'&pag='.$diploma.'" target="_blank" style="text-decoration:none; color:#000"><img src="../../UL/DIPLOMA/icons/print_s.png" border="0">Vista Preliminar</a>
			
		}
?>
<script type="text/javascript" src="http://jqueryjs.googlecode.com/files/jquery-1.3.1.min.js" > </script> 
<style type="text/css" media="print">
    @page 
    {
        size:landscape;   /* auto is the initial value */
        margin: 5mm;  /* this affects the margin in the printer settings */
		
		
    }

</style>
<style>
	#Posicion_mouse
{
    z-index:100;
    position:absolute;    
    color:#093;
    font-size:24px;
    font-weight:bold;
    left:300px;
    top:300px;
}
	#DivSiguiente
	{
		display:none;
	}
	#DivSig
	{
		display:none;
	}

	#mostrar2
	{
		display:none;
	}
	

</style>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript">
	function printDiv() {
		var printContents = $(".right_container").html();
		var originalContents = document.body.innerHTML;
		document.body.innerHTML = printContents;
		window.print();
		document.body.innerHTML = originalContents;
	}
    function imprSelec(muestra)
	{
		var ficha=document.getElementById(muestra);
		var ventimp=window.open(' ','popimpr');
		ventimp.document.write(ficha.innerHTML);
		ventimp.document.close();
		ventimp.print();
		ventimp.close();
	}
	  
      
</script>

<link rel="stylesheet" href="../../UL/CITEIN/modal.css" />

<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        			
		        <div class="modal-container">
			<div id="modal" class="modal"></div>
		</div>
        
    
        	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
<input type="hidden" name="idParticipante" id="idParticipante" value="<?php echo $filtro?>">

<h2 align="center">Seleccione una actividad a imprimir sobre el diploma</h2>
                    <br />
        			<div align="center"><hr width="80%"></div>
                    <br />
                    <br />
                    <br />

<div align="center">
    <label for="lista_actividad">Lista de actividades: </label>
        <select name="lista_actividad" id="lista_actividad">
            <option disabled selected> -- Seleccione una actividad -- </option>
			<?php
            $consulta1->Participante_ver_su_tipoEvento($filtro,$codigo);
            while ($row = mysql_fetch_assoc($consulta1->Resultado)) 
            { 
                echo "<option  value=".$row['idEvento'].">".$row['Nombre']."</option>";
            }    
            
            ?>
        </select>
  </div>
  
				<!-- Boton para abrir página modal -->
  <?php
  echo '<a style="text-decoration:none; color:#000; cursor:pointer;"  onClick="javascript:abrirVentana(\'idParticipante='.$filtro.'&ejex='.$ejex.'&ejey='.$ejey.'&nombre='.$NombreParticipante.'&diploma='.$diploma.'&x='.$XtE.'&y='.$YtE.'\');"><img src="../../UL/DIPLOMA/icons/print_s.png" border="0">Vista preliminar</a>  ';
   ?> 
        

</form>

<script>
	var body = $('body'),
    modal_container = $('.modal-container');
	function abrirVentana(param)
	{
		param="idActividad="+document.getElementById('lista_actividad').value+"&"+param;
		$(".modal-container").slideDown("slow");
		ProcesarPaginaPostConParametros("NUEVO.php",param,"modal");
		toggleModal();
	}
	function cerrarVentana()
	{
		$(".modal-container").slideUp("slow");
		toggleModal();
	}
	function toggleModal() {
        body.toggleClass('body-locked');
        modal_container.toggleClass('dp-block');
    }
</script>


		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
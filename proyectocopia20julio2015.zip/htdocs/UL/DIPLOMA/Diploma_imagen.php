<?php
    $id=$_GET['codigo'];
    $nombre=$_GET['nombre'];
    $ejex=$_GET['X'];
    $ejey=$_GET['Y'];
    $diploma=$_GET['pag'];
 
            
    ini_set('display_errors', 1); // set to 0 when not debugging
    error_reporting(E_ALL);
    $fichero =('DiplomaImagen/'.$diploma);
    $im = imagecreatefromjpeg($fichero);
    $negro = imagecolorallocate($im, 0x00, 0x00, 0x00);
    $archivo_fuente='TipoLetra/AlexBrush-Regular.ttf';
    
    imagefttext($im, 40, 0, $ejex, $ejey, $negro, $archivo_fuente, $nombre);
    
    // Imprimir la imagen al navegador
    header('Content-Type: image/jpeg');
    
    imagejpeg($im);
    imagedestroy($im);
?>
<?php
   include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
    $consulta1=new Consulta;
    
 	$id=$_POST['codigo'];
    $idActividad=$_POST['idActividad'];
    $idParticipante=$_POST['idParticipante'];
    //----- entregar diploma-----
    $consulta1->Participante_entregar_certificado($idParticipante);
    //-------- Coordenadas del nombre del participante-----------
    $ejex=$_POST['ejex']-30;
    $ejey=$_POST['ejey']-85;
    $nombre=$_POST['nombre'];
    $diploma=$_POST['diploma'];
	session_start();
    //-------- Coordenadas de la actividad del participante-----------
	$XtE=$_POST['x'];
	$YtE=$_POST['y'];
	/*
	echo 'idActividad:'.$idActividad.'<br>';
	echo 'ejex:'.$ejex.'<br>';
	echo 'ejey:'.$ejey.'<br>';
	echo 'ActividadX:'.$XtE.'<br>';
	echo 'ActividadY:'.$YtE.'<br>';
	echo 'nombre:'.$nombre.'<br>';
	echo 'diploma:'.$diploma.'<br>';
	*/

   	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A imprimir</title>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<style>
 .diploma 
    {
            max-width:100%; 
                
    }
</style>


<div align="right"><span style="cursor:pointer;" onclick="cerrarVentana();" title="Cerrar">X</span></div>

</head>

<body>

<p style="text-align:center; cursor:pointer;">
        <a class="boton-link" href="javascript:printDiv()" onclick="cerrarVentana()"><i class="icon icon-printer"></i> Imprimir</a>
    </p>
<form id="formDiploma" name="formDiploma" method="POST" action="">

    
    <div id="diploma" class="right_container" />
        <img class=" diploma"  id="image"  src = "Diploma_imagen.php/?codigo=<?php echo $id?>&X=<?php echo $ejex?>&Y=<?php echo $ejey?>&nombre=<?php echo $nombre ?>&pag=<?php echo $diploma?>"  />
        <p id="text" style="color:#000; position:absolute; font-family:Edwardian Script ITC; font-size:35px; font-weight: bold;  left:<?php echo $XtE; ?>px; top:<?php echo $YtE; ?>px; z-index: 100;">
            <?php
            //------------------Imprimir la actividad seleccionanda en la página Diploma.php---------------
    		$consulta1->Actividad_mostrar($idActividad);
			$row = mysql_fetch_assoc($consulta1->Resultado);
			echo $row['Todo'].'hrs';
        	?>
        </p>
    </div>
    
    </form>
</body>
</html>
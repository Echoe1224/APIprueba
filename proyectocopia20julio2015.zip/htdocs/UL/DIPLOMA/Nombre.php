<?php
		include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
		include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
			$consulta1=new Consulta;
			$diploma='';
            $x=$y=0;

            session_start();
            $codigo= $_SESSION['CE'];
            
	    	    $consulta1->GrupoEvento_ver_diploma($codigo);
    			$row = mysql_fetch_assoc($consulta1->Resultado);
    			$diploma=$row['Diploma'];
    			$UrlDiploma='../../UL/DIPLOMA/DiplomaImagen/'.$diploma;
    		
    			$x=$_POST['EjeX']-0;
    			$y=$_POST['EjeY']-27;
				$_SESSION['myX']=$x;
				$_SESSION['myY']=$y;
			//------Recibir el nombre del participante-----
			
				$participante_especifico=$_POST['texto_nombre'];
				$actividades=$_POST['texto_actividades'];
				if($participante_especifico=='' && $actividades=='')
				{
					$nuevoParticipante=$_POST['nombre'];
					$nuevaActividad=$_POST['actividad'];
					$participante_especifico=$nuevoParticipante;
					$actividades=$nuevaActividad;
				}
				//echo 'nombre: '.$participante_especifico;
				$_SESSION['participante_nombre']=$participante_especifico;
				$_SESSION['participante_actividades']=$actividades;
  			
    			echo'<p><b>Nota:</b>Por favor doble click para capturar la posición del texto y otro para mostrar el mimo</p>';
    
            
			
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script>
var x,y=0;
function showCoords(event) 
{
     x = event.clientX;
     y = event.clientY;
    var coords = "En esta posición aparecerá su texto"
    document.getElementById("Posicion_mouse").innerHTML = coords;
	
}
 function onEnviar()
 {
       document.getElementById("EjeX").value=x;
	   document.getElementById("EjeY").value=y;
    }
	function DarClick()
	{
		document.getElementById('Recargar').click();
	}
	
</script>
<style>
	#Posicion_mouse
{
    z-index:100;
    position:absolute;    
    color:#093;
    font-size:24px;
    font-weight:bold;
    left:<?php echo $x;?>;
    top:<?php echo $y;?>;
    
}

</style>
<title>Coordenadas de nombre</title>
</head>

<body>

        <form  method="POST" name="myForm" onSubmit="onEnviar()">
<input type="hidden" name="EjeX" id="EjeX" value="<?php echo $ejex ?>">
<input type="hidden" name="EjeY" id="EjeY" value="<?php echo $ejey ?>">
<p style="text-align:right">
<input type="hidden" name="nombre" id="nombre" value="<?php echo $participante_especifico ?>">
<input type="hidden" name="actividad" id="actividad" value="<?php echo $actividades ?>">
	<input type="button" name="tipo" id="tipo" value="Siguiente" onclick="window.open('Eventos.php?cod=<?php echo $codigo ?>')" />
</p>
			<div id="Posicion_mouse"></div>
            <div class="right_content">
     			<img src="<?php echo $UrlDiploma ?>" alt="Esperando imagen" title="image" id="xd" onclick="showCoords(event)" ondblclick="DarClick()" />
        
			</div>
            <p style="text-align:center">
                <input type="submit" value="Recargar" name="Recargar" id="Recargar" />
            </p>

</form>
			
</body>
</html>
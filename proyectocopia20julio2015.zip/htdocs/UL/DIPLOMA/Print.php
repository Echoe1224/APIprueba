<?php
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
    $consulta1=new Consulta;
	
 			$codigo=$_GET['cod'];
			$consulta1->GrupoEvento_ver_diploma($codigo);
			$row = mysql_fetch_assoc($consulta1->Resultado);
			$diploma=$row['Diploma'];
			$UrlDiploma='../../UL/DIPLOMA/DiplomaImagen/'.$diploma;
			
			session_start();
			//-----Coordenadas de las actividades del participante-------
			$eventoX=$_SESSION['myX2'];
			$eventoY=$_SESSION['myY2'];
			/*
			echo 'X1: '.$eventoX.'<br>';
			echo 'Y1: '.$eventoY.'<br>';*/
			
			//-----Coordenadas del nombre del participante-------
			$nombreX=$_SESSION['myX'];
			$nombreY=$_SESSION['myY'];
			/*
			echo 'X2: '.$nombreX.'<br>';
			echo 'Y2: '.$nombreY.'<br>';*/
			
			//-----Recibir el nombre del participante y sus actividades-----
			$nombre_participante=$_SESSION['participante_nombre'];
			$actividad_participante=$_SESSION['participante_actividades'];
			/*echo 'nombre: '.$nombre_participante.'<br>';
			echo 'actividad: '.$actividad_participante.'<br>';*/
			
			
			
   	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A imprimir</title>
<style type="text/css" media="print">
    @page 
    {
        size:landscape;   /* auto is the initial value */
        margin: 5mm;  /* this affects the margin in the printer settings */
    	
		
    }
</style>
<style>
#text
{
	z-index: 100;
	position:absolute;
	color: #000;
	font-family: "Edwardian Script ITC";
	font-size: 35px;
	font-weight: bold;
	left: <?php echo $eventoX; ?>px;
	top: <?php echo $eventoY; ?>px;

}
#text2
{
	z-index: 100;
	position:absolute;
	color: #000;
	font-family: "Edwardian Script ITC";
	font-size: 35px;
	font-weight: bold;
	left: <?php echo $nombreX; ?>px;
	top: <?php echo $nombreY; ?>px;

}

#container
{

    position:relative;
}

#image
{    
    position:absolute;

}



</style>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript">
     $(document).ready(function()
     {
          $('#imprimir').click(function()
          {
               printDiv();
               function printDiv() 
               {
                    var printContents = $(".right_content").html();
                    var originalContents = document.body.innerHTML;
                    document.body.innerHTML = printContents;
                    window.print();
                    document.body.innerHTML = originalContents;
               }
    
          });
    });
      
</script>

</head>

<body>
<form >

    <p style="text-align:center">
        <a name="imprimir" id="imprimir" style="padding-left:50px; color:#333; text-decoration:none"><img src="../../UL/DIPLOMA/icons/Print.ico" border="0">Imprirmir</a>
    </p>
    <div id="container" class="right_content">
    <img id="image" src="<?php echo $UrlDiploma ?>"/>
    <p id="text">
        <?php
			echo $actividad_participante;	
        	?>
    </p>
    <p id="text2">
        <?php
			echo $nombre_participante;	
        	?>
    </p>
</div>

    </form>
</body>
</html>
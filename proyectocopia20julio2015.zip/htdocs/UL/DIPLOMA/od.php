<?php
    $id=$_GET['codigo'];
    $nombre='Probando';
    $ejex=100;
    $ejey=100;
    $diploma=$_GET['pag'];
 
            
    ini_set('display_errors', 1); // set to 0 when not debugging
    error_reporting(E_ALL);
    $fichero =('Diploma_imagen.php/?X=325&Y=355&nombre=Juan Venegas Pablo&pag=diploma1.jpg');
    $im = imagecreatefromjpeg($fichero);
    $negro = imagecolorallocate($im, 0x00, 0x00, 0x00);
    $archivo_fuente='TipoLetra/AlexBrush-Regular.ttf';
    
    imagefttext($im, 40, 0, $ejex, $ejey, $negro, $archivo_fuente, $nombre);
    
    // Imprimir la imagen al navegador
    header('Content-Type: image/jpeg');
    
    imagejpeg($im);
    imagedestroy($im);
?>
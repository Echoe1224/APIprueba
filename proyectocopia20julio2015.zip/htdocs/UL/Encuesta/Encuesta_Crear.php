<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Crear una encuesta</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>
<?php
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	$consulta1=new Consulta;
    $consulta1->Usuario_ver();
    $Admin=$consulta1->Resultado;
?>
<!-- InstanceBeginEditable name="head" -->
<style type="text/css">
.Respuesta {
	border: 1px solid #CCC;
	padding: 3px;
	margin: 3px;
}
.pregunta {
	margin: 10px;
	padding: 10px;
	border: 1px solid #999;
	box-shadow:0px 4px 3px rgba(0,0,0,.5);
}
</style>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
        <header>
		<nav class="menu">
			<ul>
				<li><a href="../inicio.php"><span class="primero"><i class="icon icon-home"></i></span>CITEIN</a></li>
				<li><a href="#"><span class="segundo"><i class="icon icon-table2"></i></span>EVENTOS</a>
					<ul>
						<li><a href="#">Ver eventos</a></li>
						<li><a href="#">Crear evento</a></li>
					</ul>
				</li>
				<li><a href="#"><span class="tercero"><i class="icon icon-accessibility"></i></span>PARTICIPANTES</a>
					<ul>
						<li><a href="#">Ver participantes</a></li>
						<li><a href="../Registrar_Participante.php">Nuevo participante</a></li>
					</ul>
                </li>
                <?php if($Admin==TRUE){ ?>
				<!-- Opciones para administrador -->
                <li><a href="#"><span class="cuarto"><i class="icon icon-user"></i></span>OTROS</a>
					<ul>
						<li><a href="#">Tipo evento</a></li>
                        <ul>
							<li><a href="#">Tipo evento</a></li>
                        </ul>
						<li><a href="#">Nuevo tipo evento</a></li>
                        <li><a href="#">Nuevo tipo evento</a></li>
					</ul>
                </li>
                <?php } ?>
				<li><a href="#"><span class="cuarto"><i class="icon icon-user"></i></span>PERSONAL</a>
					<ul>
						<li><a href="#">Ver personal</a></li>
						<li><a href="#">Nuevo personal</a></li>
					</ul>
                </li>
				<li><a href="#"><span class="quinto"><i class="icon icon-exit"></i></span>Cerrar Sesión</a></li>
			</ul>
		</nav>
        </header>
        </div>

<div class="contenedor">
	<div class="contenido">
    <!-- InstanceBeginEditable name="Contenido" -->
	<form id="form1" method="post" action="<?php echo htmlspecialchars("/DAL/guardar.php");?>" autocomplete="off">
    <input type="hidden" name="formulario" value="crear encuesta" />
    <input type="hidden" name="redireccionar" value="'http://citein.hostingla.in/UL/Encuesta/Encuesta_Crear.php'" />
  		<p>
		    <label for="texto_titulo">Título de la encuesta:</label>
		    <input name="texto_titulo" onfocus="if (this.value=='Título') this.value = ''" value="Título" type="text" accesskey="t" id="texto_titulo" pattern="[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ., ]{1,65}" required title="Se necesita un título de la encuesta" size="70" maxlength="65" />
		</p>
		<p>
		    <label for="texto_descripcion">Descripción:    <br />
		      <br />
		    </label>
			<textarea name="texto_descripcion" cols="60" rows="5" id="texto_descripcion" accesskey="d"></textarea>
		</p>
  <h3>Crear preguntas</h3>
  <input type="hidden" name="contPreguntas" id="contPreguntas" value="1" />
  <label for="preguntas"></label>
  <br/>
	<div class="pregunta" id="1">
    	<p>
	      <label for="texto_pregunta">Pregunta:</label>
    	  <input name="p1" type="text" onfocus="if (this.value=='¿Alguna pregunta?') this.value = ''" id="p1" value="¿Alguna pregunta?" size="78" maxlength="100" pattern="[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ¿? ]{3,100}" required title="Solo se aceptan números, letras y los caracteres ¿?." />
	    </p>
    	<p>
			<label for="lista_tipo_pregunta">Tipo de pregunta: </label>
			<select id="s1" name="s1" onchange="cambiarTipoPregunta(this.parentNode.parentNode.id,this.value)">
				<option value="A" selected="selected">Texto</option>
				<option value="M">Opción Múltiple</option>
	      </select>
    	</p>
	    <p id="respuesta 1">
    		<label><span class="Respuesta">Respuesta.</span></label>
        	<input type="hidden" name="c1" id="c1" value="2"/>
	    </p>
    	<p>
		    <input type="button" name="boton_eliminar_pregunta" id="boton_eliminar_pregunta" value="Quitar pregunta" onclick="quitarPregunta(this.parentNode.parentNode.id)" />
	    </p>
	</div>
	<p><br/>
	  <input type="button" name="boton_agregar_pregunta" id="boton_agregar_pregunta" onclick="agregarPregunta(document.getElementById 			('boton_agregar_pregunta').parentNode.parentNode.id)" value = "Agregar pregunta + ¿?" />
	</p>
	<p>
	  <script language="javascript">
  var contPreguntas=2;
  var contOpciones=2;
  	/*
			Nombre de los elementos
			textBoxPregunta= 'p' + contPreguntas
			lista o select= 's' + contPreguntas
			contador de opciones oculto= 'c' + contPreguntas
			radio= contOpciones + 'r' + contPreguntas
			textBoxOpción= contOpciones + 't' + contPreguntas		
			link= contOpciones + 'l' + contPreguntas
		*/
	function agregarPregunta(padre)
	{
		//Cuadro de la pregunta DIV
		var eCuadro=document.createElement("DIV");
		eCuadro.id=contPreguntas.toString();
		eCuadro.setAttribute("class","pregunta");
		//textbox y label de la pregunta LABEL,INPUT:text dentro de un párrafo P
			var ePregunta=document.createElement("P");
				//LABEL pregunta
				var ePLabel=document.createElement("LABEL");
				var textoLabel=document.createTextNode("Pregunta: ");
				ePLabel.appendChild(textoLabel);
				ePLabel.setAttribute("for","textBox2");
			ePregunta.appendChild(ePLabel);
				//TEXTBOX pregunta
				var ePTexto=document.createElement("INPUT");
				ePTexto.setAttribute("type","text");
				ePTexto.setAttribute("value","¿Alguna pregunta?");
				ePTexto.setAttribute("size","78");
				ePTexto.setAttribute("maxlength","100");
				ePTexto.setAttribute("onfocus","if (this.value=='¿Alguna pregunta?') this.value = ''");
				ePTexto.setAttribute("pattern","[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ¿?., ]{3,100}");
				ePTexto.setAttribute("required","true");
				//ePTexto.setAttribute("pattern",".{6,}"); 6 o mas caracteres mínimos.
				ePTexto.setAttribute("title","Sólo se aceptan números, letras y los caracteres ¿?.");
				ePTexto.name='p'+contPreguntas;
				ePTexto.id='p'+contPreguntas;
			ePregunta.appendChild(ePTexto);
		eCuadro.appendChild(ePregunta);
		//Label y comboBox del tipo de pregunta dentro de un párrafo P,LABEL,SELECT
			var eTipo=document.createElement("P");
				//LABEL LISTA
				var eTLabel = document.createElement("LABEL");
					var textoTLabel = document.createTextNode("Tipo de pregunta: ");
					eTLabel.appendChild(textoTLabel);
			eTipo.appendChild(eTLabel);
			//SELECT o lista
			var eTLista = document.createElement("SELECT");
				eTLista.setAttribute("onchange","cambiarTipoPregunta(this.parentNode.parentNode.id,this.value)");
				eTLista.name='s'+contPreguntas;
				eTLista.id='s'+contPreguntas;
				//Items de los comboBox OPTION
				var eLOpcion = document.createElement("OPTION");
					eLOpcion.value="A";
					var eLOTexto = document.createTextNode("Texto");
					eLOpcion.appendChild(eLOTexto);
				var eLOpcion2 = document.createElement("OPTION");
					eLOpcion2.value="M";
					var eLOTexto2 = document.createTextNode("Opción Múltiple");
					eLOpcion2.appendChild(eLOTexto2);
				eTLista.appendChild(eLOpcion);
				eTLista.appendChild(eLOpcion2);
			eTipo.appendChild(eTLista);
		eCuadro.appendChild(eTipo);
			var eRespuesta=document.createElement("P");
				eRespuesta.id= 'respuesta '+ contPreguntas;
			//LABEL respuesta
			var eRLabel=document.createElement("LABEL");
					var eRLSpan = document.createElement("SPAN");
						eRLSpan.setAttribute("class","Respuesta");
						var eRLSTexto = document.createTextNode("Respuesta");
						eRLSpan.appendChild(eRLSTexto);
					eRLabel.appendChild(eRLSpan);
				eRespuesta.appendChild(eRLabel);
					var eRCont=document.createElement("INPUT");
						eRCont.setAttribute("type","hidden");
						eRCont.name='c'+contPreguntas;
						eRCont.id='c'+contPreguntas;
						eRCont.value=1;
				eRespuesta.appendChild(eRCont);
		eCuadro.appendChild(eRespuesta);
				//HIDDEN contador de opciones
			
			var eEliminar=document.createElement("P");
				var eEBoton=document.createElement("INPUT");
				eEBoton.setAttribute("type","button");
				eEBoton.setAttribute("value","Quitar pregunta");
				eEBoton.setAttribute("onclick","quitarPregunta(this.parentNode.parentNode.id)");
			eEliminar.appendChild(eEBoton);
		eCuadro.appendChild(eEliminar);
		
		var ePadre=document.getElementById(padre);
		ePadre.insertBefore(eCuadro,document.getElementById('boton_agregar_pregunta').parentNode);
		document.getElementById('contPreguntas').value=contPreguntas;
		//siempre de último el contador de preguntas
		contPreguntas++;
	}
	function quitarPregunta(padre)
	{
		if(confirm('¿Esta seguro de eliminar la pregunta?'))
		{
			var pregunta=document.getElementById(padre);
			pregunta.remove();
		}
	}
	function cambiarTipoPregunta(padre,tipoPregunta)
	{
		/*
			Nombre de los elementos
			textBoxPregunta= 'p' + contPreguntas
			lista o select= 's' + contPreguntas
			contador de opciones oculto= 'c' + contPreguntas
			radio= contOpciones + 'r' + contPreguntas
			textBoxOpción= contOpciones + 't' + contPreguntas		
			link= contOpciones + 'l' + contPreguntas
		*/
		var ePadre=document.getElementById(padre);
		ePadre.removeChild(document.getElementById('respuesta '+padre));
		var eRespuesta=document.createElement("P");
			eRespuesta.id='respuesta '+padre;
			var eRCont=document.createElement("INPUT");
						eRCont.setAttribute("type","hidden");
						eRCont.name='c'+padre;
						eRCont.id='c'+padre;
						eRCont.value=2;
			eRespuesta.appendChild(eRCont);
		if(tipoPregunta=="M")
		{
		//Opción1
			//radio de la opción
				var eORadio = document.createElement("INPUT");
					eORadio.setAttribute("type", "radio");
					eORadio.id='1r'+padre;
			eRespuesta.appendChild(eORadio);
			//Textbox para la opción.
				var eOTexto = document.createElement("INPUT");
					eOTexto.setAttribute("type","text");
					eOTexto.value="Opción";
					eOTexto.setAttribute("onfocus","if (this.value=='Opción') this.value = ''");
					eOTexto.setAttribute("size","50");
					eOTexto.setAttribute("maxlength","45");
					eOTexto.setAttribute("pattern","[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ., ]{1,45}");
					eOTexto.setAttribute("required","true");
					//eOTexto.setAttribute("pattern",".{6,}"); 6 o mas caracteres mínimos.
					eOTexto.setAttribute("title","Solo se aceptan letras y números.");
					eOTexto.id='1t'+padre;
					eOTexto.name='1t'+padre;
			eRespuesta.appendChild(eOTexto);
			//un link para eliminar la opción
				var eOEliminar = document.createElement("A");
					eOEliminar.setAttribute("href","javascript:void");
					eOEliminar.setAttribute("onclick","quitarOpcion(this.id)");
					eOEliminar.id='1l'+padre;
					var eOETexto=document.createTextNode("x");
						eOEliminar.appendChild(eOETexto);
			eRespuesta.appendChild(eOEliminar);
			eRespuesta.appendChild(document.createElement("BR"));
		//Opción 2
			//radio de la opción
				var eORadio = document.createElement("INPUT");
					eORadio.setAttribute("type", "radio");
					eORadio.id='2r'+padre;
			eRespuesta.appendChild(eORadio);
			//Textbox para la opción.
				var eOTexto = document.createElement("INPUT");
					eOTexto.setAttribute("type","text");
					eOTexto.value="Opción";
					eOTexto.setAttribute("onfocus","if (this.value=='Opción') this.value = ''");
					eOTexto.setAttribute("size","50");
					eOTexto.setAttribute("maxlength","45");
					eOTexto.setAttribute("pattern","[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ,. ]{1,45}");
					eOTexto.setAttribute("required","true");
					//eOTexto.setAttribute("pattern",".{6,}"); 6 o mas caracteres mínimos.
					eOTexto.setAttribute("title","Solo se aceptan letras y números.");
					eOTexto.id='2t'+padre;
					eOTexto.name='2t'+padre;
			eRespuesta.appendChild(eOTexto);
			//un link para eliminar la opción
				var eOEliminar = document.createElement("A");
					eOEliminar.setAttribute("href","javascript:void");
					eOEliminar.setAttribute("onclick","quitarOpcion(this.id)");
					eOEliminar.id='2l'+padre;
					var eOETexto=document.createTextNode("x");
						eOEliminar.appendChild(eOETexto);
			eRespuesta.appendChild(eOEliminar);
			//Link para agregar otra opción
				var eOAgregar = document.createElement("A");
					eOAgregar.setAttribute("href","javascript:void");
					eOAgregar.setAttribute("onclick","agregarOpcion(this.parentNode.parentNode.id)");
					var eOATexto=document.createTextNode("Agregar otro");
						eOAgregar.appendChild(eOATexto);
			eRespuesta.appendChild(document.createElement("BR"));
			eRespuesta.appendChild(eOAgregar);
		}
		else
		{
				var eRLabel=document.createElement("LABEL");
					var eRLSpan = document.createElement("SPAN");
						eRLSpan.setAttribute("class","Respuesta");
						var eRLSTexto = document.createTextNode("Respuesta");
						eRLSpan.appendChild(eRLSTexto);
					eRLabel.appendChild(eRLSpan);
			eRespuesta.appendChild(eRLabel);
		}
		ePadre.insertBefore(eRespuesta,ePadre.lastChild);
	}
	function agregarOpcion(padre)
	{
		//padre=no. de pregunta
		var ePadre=document.getElementById('respuesta '+padre);
		/*contOpciones=ePadre.childNodes.length-3;
		var eQuitar=ePadre.childNodes.item(contOpciones).id;
		contOpciones=eQuitar.substring(0,eQuitar.indexOf('l'))*1+1;*/
		var eContOpciones=document.getElementById('c'+padre);
/*		var c=ePadre.childNodes;
		var i=0;
		var txt="";
		for(i=0;i<c.length;c++){
			txt=txt+c[i].id+',';
		}
		alert(txt);*/
		contOpciones=(eContOpciones.value*1)+1;
		eContOpciones.value=contOpciones;
		//radio
			var eORadio = document.createElement("INPUT");
			eORadio.setAttribute("type", "radio");
			eORadio.id=contOpciones+'r'+padre;
			//TextBox de la opción
			var eOTexto = document.createElement("INPUT");
			eOTexto.setAttribute("type","text");
			eOTexto.value="Opción";
			eOTexto.setAttribute("onfocus","if (this.value=='Opción') this.value = ''");
			eOTexto.setAttribute("size","50");
			eOTexto.setAttribute("maxlength","45");
			eOTexto.setAttribute("pattern","[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ,. ]{1,45}");
			eOTexto.setAttribute("required","true");
			//eOTexto.setAttribute("pattern",".{6,}"); 6 o mas caracteres mínimos.
			eOTexto.setAttribute("title","Solo se aceptan letras y números.");
			eOTexto.id=contOpciones+'t'+padre;
			eOTexto.name=contOpciones+'t'+padre;
			//Link para eliminar la opción
			var eOEliminar = document.createElement("A");
			eOEliminar.setAttribute("href","javascript:void");
			eOEliminar.setAttribute("onclick","quitarOpcion(this.id)");
			eOEliminar.id=contOpciones+'l'+padre;
				var eHijo3Texto=document.createTextNode("x");
				eOEliminar.appendChild(eHijo3Texto);		
		ePadre.insertBefore(eORadio,ePadre.lastChild);
		ePadre.insertBefore(eOTexto,ePadre.lastChild);
		ePadre.insertBefore(eOEliminar,ePadre.lastChild);
		ePadre.insertBefore(document.createElement("BR"), ePadre.lastChild);
	}
	function quitarOpcion(opcion)
	{
		padre=opcion.substring(opcion.indexOf('l')+1);
		contOpciones=opcion.substring(0,opcion.indexOf('l'));
		var eRespuesta=document.getElementById('respuesta '+padre);
		//debe de haber 10 elementos mínimos, 2 opciones:8 elementos + link de agregarOpcion + campo oculto
		if(eRespuesta.childNodes.length>10)
		{
			var c = eRespuesta.childNodes;
			//eliminar <br>
		    for (var i = 0; i < c.length; i++)
        		if(c[i].id==opcion)
					eRespuesta.childNodes.item(i+1).remove();
			eRespuesta.removeChild(document.getElementById(contOpciones+'r'+padre));
			eRespuesta.removeChild(document.getElementById(contOpciones+'t'+padre));
			eRespuesta.removeChild(document.getElementById(contOpciones+'l'+padre));
		}
		else
			alert('No se puede tener menos de 2 opciones');
	}
	
	function validarFormulario()
	{
		/*
			Nombre de los elementos
			textBoxPregunta= 'p' + contPreguntas
			lista o select= 's' + contPreguntas
			contador de opciones oculto= 'c' + contPreguntas
			radio= contOpciones + 'r' + contPreguntas
			textBoxOpción= contOpciones + 't' + contPreguntas		
			link= contOpciones + 'l' + contPreguntas
		*/
		if (document.getElementById('texto_titulo').value=='Título') document.getElementById('texto_titulo').value = ''
		var i=0;
		var elementTemp;
		for(i=1;i<contPreguntas;i++)
		{
			elementTemp=document.getElementById('p'+i);//DIV de la pregunta (caja de cada pregunta) Padre.
			if(elementTemp!=null)
			{
				if (elementTemp.value=='¿Alguna pregunta?'){
					elementTemp.value = '';
				}
				if(document.getElementById('s'+i)!=null && document.getElementById('s'+i).value=="M")
				{
					var contOpciones=document.getElementById('c'+i).value*1;
					var ii=0;
				
					for(ii=1;ii<=contOpciones;ii++)
					{
						elementTemp=document.getElementById(ii+'t'+i);
						if (elementTemp!=null && elementTemp.value=='Opción') elementTemp.value = '';
					}
				}
			}
		}
		document.getElementById('boton_enviar2').click();
	}
    </script>
	  </p>
	<p>
	  <input type="button" onclick="javascript: validarFormulario()" name="boton_enviar" id="boton_enviar" value="Crear encuesta"/>
    <input type="button" name="boton_cancelar" id="boton_cancelar" value="Cancelar" /></p>
	<div style="display:none">
	  <input type="submit" name="boton_enviar2" id="boton_enviar2" value="Enviar" />
	</div>
	<p>&nbsp;</p>
    </form>
	<!-- InstanceEndEditable -->
    
    </div>
    
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>

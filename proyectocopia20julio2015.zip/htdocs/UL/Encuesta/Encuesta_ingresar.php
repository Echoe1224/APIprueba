<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Crear una encuesta</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<!-- <script src="../UL/CITEIN/jquery-1.11.3.js"></script>-->
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>

<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="agregar.js"></script>
<style type="text/css">
.Respuesta {
	border: 1px solid #CCC;
	padding: 3px;
	margin: 3px;
}
.pregunta {
	margin: 10px;
	padding: 10px;
	border: 1px solid #999;
	box-shadow:0px 4px 3px rgba(0,0,0,.5);
}
</style>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
<form id="form1" method="post" action="<?php echo htmlspecialchars("/DAL/guardar.php");?>" autocomplete="off">
    <input type="hidden" name="formulario" value="crear encuesta" />
    <input type="hidden" name="redireccionar" value="../../UL/Encuesta/Encuesta_ver.php" />
    	<h2>Crear encuesta</h2>
        <hr>
        <br />
  		<p>
		    <label for="texto_titulo">Título de la encuesta:</label>
		    <input name="texto_titulo" placeholder="Título de la encuesta" type="text" accesskey="t" id="texto_titulo" pattern="[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ., ]{1,65}" required title="Se necesita un título de la encuesta" size="70" maxlength="65" onblur="verificarE();" />
		<p id="existe" style="color:#F00;"></p>
        </p>
		<p>
		    <label for="texto_descripcion">Descripción:    <br />
		      <br />
		    </label>
			<textarea name="texto_descripcion" cols="60" rows="5" id="texto_descripcion" accesskey="d"></textarea>
		</p>
  <h3>Crear preguntas</h3>
  <input type="hidden" name="contPreguntas" id="contPreguntas" value="1" />
  <label for="preguntas"></label>
  <br/>
	<div class="pregunta" id="1">
    	<p>
	      <label for="texto_pregunta">Pregunta:</label>
    	  <input name="p1" type="text" placeholder="¿Alguna pregunta?" id="p1" size="78" maxlength="100" pattern="[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ¿?,. ]{3,100}" required title="Solo se aceptan números, letras y los caracteres ¿?." />
	    </p>
    	<p>
			<label for="lista_tipo_pregunta">Tipo de pregunta: </label>
			<select id="s1" name="s1" onchange="cambiarTipoPregunta(this.parentNode.parentNode.id,this.value)">
				<option value="A" selected="selected">Texto</option>
				<option value="M">Opción Múltiple</option>
	      </select>
    	</p>
	    <p id="respuesta 1">
    		<label><span class="Respuesta">Respuesta.</span></label>
        	<input type="hidden" name="c1" id="c1" value="2"/>
	    </p>
    	<p>
		    <input type="button" name="boton_eliminar_pregunta" id="boton_eliminar_pregunta" value="Quitar pregunta" onclick="quitarPregunta(this.parentNode.parentNode.id)" />
	    </p>
	</div>
	<p><br/>
	  <input type="button" name="boton_agregar_pregunta" id="boton_agregar_pregunta" onclick="agregarPregunta(document.getElementById 			('boton_agregar_pregunta').parentNode.parentNode.id)" value = "Agregar pregunta + ¿?" />
	</p>
	<div style="display:none">
	  <input type="submit" name="boton_enviar2" id="boton_enviar2" value="Enviar" />
	</div>
    </form>
    <table width="200" border="0" cellspacing="5">
      <tr>
        <td><input type="button" onclick="javascript: validarFormulario()" name="boton_enviar" id="boton_enviar" value="Crear encuesta"/></td>
        <td>
        	<form id="form2" name="form2" method="post" action="Encuesta_ver.php">
		        <input type="submit" name="boton_cancelar" id="boton_cancelar" value="Cancelar" />
            </form>
        </td>
      </tr>
    </table>
    
    <script>
	function verificarE()
	{
		var t=document.getElementById('texto_titulo').value;
		if(t.length>0)
		{
			ProcesarPaginaGetConParametros("Encuesta_verificar.php","titulo="+t,"existe");
			var check=setInterval(function(){
				var m=document.getElementById('mensaje');
				if(m!=null)
				{
					clearInterval(check);
					if(m.innerHTML!="")
						document.getElementById('texto_titulo').value="";
				}},interval=500);
		}
	}
	</script>
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
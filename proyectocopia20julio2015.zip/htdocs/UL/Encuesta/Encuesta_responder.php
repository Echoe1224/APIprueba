<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<title>Responder la encuesta</title>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
?>
<link rel="stylesheet" href="../UL/CITEIN/estilos.css" /> 
<style type="text/css">

.pregunta {
	margin: 10px;
	padding: 10px;
	border: 1px solid #999;
	box-shadow:0px 4px 3px rgba(0,0,0,.5);
}
</style>
</head>

<body bgcolor="#F1F1F1">
<div class="paginaEmergente">
<div align="right"><span style="cursor:pointer;" onclick="cerrarVentana();">X</span></div>
<?php
if(isset($_POST["idEncuesta"]) && isset($_POST["idParticipante"]))
{
	$idEncuesta=$_POST["idEncuesta"];
	$idParticipante=$_POST["idParticipante"];
	$idEvento=$_POST["idEvento"];
	$consulta1->Encuesta_ver_datos($idEncuesta);
	//`TituloEncuesta`,`Descripcion`
	$Existe=false;
	//Verificar si existe la encuesta y desplegar el título y la descripción.
	$fila = mysql_fetch_assoc($consulta1->Resultado);
	$Existe=true;
	?>
	<div align="center"><h1><?php echo $fila["TituloEncuesta"];?></h1></div>
	<p style="margin:10px;" align="left"><?php echo $fila["Descripcion"];?></p>
	<?php
	// Liberar los recursos asociados con el conjunto de resultados
	// Esto se ejecutado automáticamente al finalizar el script.
	mysql_free_result($consulta1->Resultado);
	if($Existe)
	{
		echo "\n";
		?>
		<form id="form1" name="form1" method="post" action="<?php echo htmlspecialchars("../DAL/guardar.php")?>">
		<input type="hidden" name="formulario" value="responder encuesta" />
		<input type="hidden" name="idEncuesta" value="<?php echo $idEncuesta;?>" />
		<input type="hidden" name="idParticipante" value="<?php echo $idParticipante;?>" />
		<input type="hidden" name="idEvento" value="<?php echo $idEvento;?>" />
        <input type="hidden" name="redireccionar" value="../../pagina/participante.php" />
        <input type="hidden" name="usuario" value="<?php echo $_POST["usuario"];?>" />
		<?php 
		echo "\n";
		$consulta1->Encuesta_ver_preguntas($idEncuesta);
		$preguntas=$consulta1->Resultado;
		$contPreguntas=1;
		while ($fila = mysql_fetch_assoc($preguntas))
		{
			echo "\n";
			?>
            <div class="pregunta">
			<p align="left"><?php echo $contPreguntas.'. '.$fila["Pregunta"];?></p>
            <?php
			if($fila["TipoRespuesta"]=="M")
			{
				$consulta1->Pregunta_ver_opciones($fila["idPregunta"]);
				$contOpciones=1;
				?>
				<p>
                <?php
				echo "\n";
				while ($fila2 = mysql_fetch_assoc($consulta1->Resultado))
				{
					?>
                    <label>
						<input type="radio" name="<?php echo $fila["idPregunta"];?>" value="<?php echo $fila2["idOpcionMultiple"];?>" id="<?php echo $fila["idPregunta"]."_".$contOpciones;?>" required="required" />
					<?php echo $fila2["Opcion"];?></label>
                    <?php
					echo "\n";
					++$contOpciones;
				}
				?>
                </p>
                <?php
				echo "\n";
			}
			else
			{
				?>
                <input type="text" name="<?php echo $fila["idPregunta"];?>" id="<?php echo $fila["idPregunta"];?>" size="101" maxlength="100" pattern="[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ,. ]{1,100}" title="Solo se aceptan números y letras." required="required" />
                <?php
				echo "\n";
			}
			++$contPreguntas;
			?>
            </div>
            <?php
		}
		// Liberar los recursos asociados con el conjunto de resultados
		// Esto se ejecutado automáticamente al finalizar el script.
		mysql_free_result($preguntas);
		?>
		<p>
			<input class="boton" type="submit" name="boton_enviar" id="boton_enviar" value="Enviar" />
		</p>
		</form>
        <?php
		echo "\n";
	}
}
else
{
	echo '<br><h1 align="center">Debe seleccionar una encuesta válida.</h1>';
}
?>
</div>
</body>
</html>
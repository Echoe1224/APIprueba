<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Resultados de la encuesta</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<!-- <script src="../UL/CITEIN/jquery-1.11.3.js"></script>-->
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<link rel="stylesheet" href="../CITEIN/encuesta.css"  />
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar.</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
      <a style="padding-left:50px; color:#333; text-decoration:none" href="Encuesta_ver.php"><i class="icon icon-undo2"></i> Atrás</a>
<?php
if(isset($_POST["idRegistro"]))
	$idEncuesta=$_POST['idRegistro'];
else
	$idEncuesta=0;
$consulta1->Encuesta_ver_datos($idEncuesta);
if(mysql_num_rows($consulta1->Resultado)<=0){
	?>
	<div align="center"><h1>Seleccione una encuesta.</h1></div>
<?php
}
else
{
	?>
	<form id="form1" name="form1" method="post" action="">
	<?php
//Despliegue del título y la descripción
	while ($fila = mysql_fetch_assoc($consulta1->Resultado)) {
		$Existe=true;
		?>
	  <div align="center">
      	<h2>Resultados de la encuesta:</h2>
      	<h3><?php echo $fila["TituloEncuesta"];?></h3>
      </div>
	  <p align="left"><?php echo $fila["Descripcion"];?></p>
	  <br/>
	  <?php
	}
//Despliegue de las preguntas de la encuesta
	$consulta1->Encuesta_ver_preguntas($idEncuesta);
	if(mysql_num_rows($consulta1->Resultado)<=0){
			echo '<h2 align="center">La encuesta no tiene preguntas.</h2>';
			echo "\n";
	}
	$preguntas=$consulta1->Resultado;
	$cont=1;
	//Desplegar las preguntas
	while ($fila = mysql_fetch_assoc($preguntas)) {
	//`idPregunta`,`Pregunta`,`TipoRespuesta
	?>
	<h2><?php echo $cont.'. '. $fila["Pregunta"]; ?></h2>
	<ul class='votacion'>
		<?php
        $suma=0;
        /*Si es una pregunta abierta*/
        if($fila["TipoRespuesta"]=='A')
        {
			echo "<li>\n";
			$consulta1->Pregunta_ver_respuestas($fila["idPregunta"]);
			$cont2=1;
			while ($fila2 = mysql_fetch_assoc($consulta1->Resultado)) {
				//`Valor` COUNT( `Valor` ) AS `TotalRespuestas`
				echo '<div style="font-weight:bold;" class="fl">• '.$fila2["Valor"].'</div>';
				echo "\n";
				++$cont2;
			}
			echo "</li>\n";
        }
        else
        {
			echo "<li>\n";
			$consulta1->Pregunta_ver_respuestas($fila["idPregunta"],$_SESSION['idGrupoEvento']);
			while ($fila2 = mysql_fetch_assoc($consulta1->Resultado)) {
				//`Valor` COUNT( `Valor` ) AS `TotalRespuestas`
				$suma=$fila2["TotalRespuestas"];
			}
			$consulta1->Pregunta_ver_opciones($fila["idPregunta"]);
			$opciones=$consulta1->Resultado;
			while ($fila2 = mysql_fetch_assoc($opciones)) {
				//`idOpcionMultiple`,`Opcion`
				$consulta1->Pregunta_ver_respuestas_multiples($fila2["idOpcionMultiple"]);
				//Diferentes opciones que tiene la pregunta.
        		while ($fila3 = mysql_fetch_assoc($consulta1->Resultado)) {
					//`Valor` , COUNT( `Valor` ) AS `Cantidad`
					?>
                    <div style="font-weight:bold;" class="fl"><?php echo '• '.$fila2["Opcion"];?></div>
                    <div align="right" class="fr">Votos: <?php echo $fila3["Cantidad"];?></div>
                    <?php
					if($fila3["Cantidad"]==0){
						?>
						<div class="barra" style="width:0%;">0%</div>
						<?php
					}
					else{
						?>
						<div class="barra" style="width:<?php echo (100*$fila3["Cantidad"]/$suma);?>%;"><?php echo round(100*$fila3["Cantidad"]/$suma);?>%</div>
                        <?php
					}
        		}
        	}
			echo "</li>\n";
        }
        echo '<div align="right" class="fr"><span class="fr">Votos totales: '.$suma.'</span></div>';
        ?>
	</ul>
    <?php
	++$cont;
	}
	mysql_free_result($preguntas);
	?>
	</form>
	<div align="left"><a class="boton-link" href="javascript:imprimir('form1')"><i class="icon icon-printer"></i>Imprimir</a></div>
	<?php
	}
?>
	  <!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
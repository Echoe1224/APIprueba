<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
	$titulo=$_GET["titulo"];
	$consulta1->Encuesta_verificar_titulo($titulo);
	//`cantidad`
	$cantidad=mysql_fetch_assoc($consulta1->Resultado);
	if($cantidad["cantidad"]>0)
	{
	?>
		<p id="mensaje">Ya existe una encuesta con el título:<?php echo $titulo;?></p>
    <?php
	}
	else
	{
	?>
		<p id="mensaje"></p>
    <?php
	}
	?>
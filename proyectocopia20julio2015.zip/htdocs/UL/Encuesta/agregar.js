// JavaScript Document
var contPreguntas=2;
var contOpciones=2;
/*
    	Nombre de los elementos
		textBoxPregunta= 'p' + contPreguntas
		lista o select= 's' + contPreguntas
		contador de opciones oculto= 'c' + contPreguntas
		radio= contOpciones + 'r' + contPreguntas
		textBoxOpción= contOpciones + 't' + contPreguntas		
		link= contOpciones + 'l' + contPreguntas
	*/
function agregarPregunta(padre)
{
	//Cuadro de la pregunta DIV
	var eCuadro=document.createElement("DIV");
	eCuadro.id=contPreguntas.toString();
	eCuadro.setAttribute("class","pregunta");
	//textbox y label de la pregunta LABEL,INPUT:text dentro de un párrafo P
		var ePregunta=document.createElement("P");
			//LABEL pregunta
			var ePLabel=document.createElement("LABEL");
			var textoLabel=document.createTextNode("Pregunta: ");
			ePLabel.appendChild(textoLabel);
			ePLabel.setAttribute("for","textBox2");
		ePregunta.appendChild(ePLabel);
			//TEXTBOX pregunta
			var ePTexto=document.createElement("INPUT");
			ePTexto.setAttribute("type","text");
			ePTexto.setAttribute("size","78");
			ePTexto.setAttribute("maxlength","100");
			ePTexto.setAttribute("placeholder","¿Alguna pregunta?");
			ePTexto.setAttribute("pattern","[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ¿?., ]{3,100}");
			ePTexto.setAttribute("required","true");
			//ePTexto.setAttribute("pattern",".{6,}"); 6 o mas caracteres mínimos.
			ePTexto.setAttribute("title","Sólo se aceptan números, letras y los caracteres ¿?.");
			ePTexto.name='p'+contPreguntas;
			ePTexto.id='p'+contPreguntas;
		ePregunta.appendChild(ePTexto);
	eCuadro.appendChild(ePregunta);
	//Label y comboBox del tipo de pregunta dentro de un párrafo P,LABEL,SELECT
		var eTipo=document.createElement("P");
			//LABEL LISTA
			var eTLabel = document.createElement("LABEL");
				var textoTLabel = document.createTextNode("Tipo de pregunta: ");
				eTLabel.appendChild(textoTLabel);
		eTipo.appendChild(eTLabel);
		//SELECT o lista
		var eTLista = document.createElement("SELECT");
			eTLista.setAttribute("onchange","cambiarTipoPregunta(this.parentNode.parentNode.id,this.value)");
			eTLista.name='s'+contPreguntas;
			eTLista.id='s'+contPreguntas;
			//Items de los comboBox OPTION
			var eLOpcion = document.createElement("OPTION");
				eLOpcion.value="A";
				var eLOTexto = document.createTextNode("Texto");
				eLOpcion.appendChild(eLOTexto);
			var eLOpcion2 = document.createElement("OPTION");
				eLOpcion2.value="M";
				var eLOTexto2 = document.createTextNode("Opción Múltiple");
				eLOpcion2.appendChild(eLOTexto2);
			eTLista.appendChild(eLOpcion);
			eTLista.appendChild(eLOpcion2);
		eTipo.appendChild(eTLista);
	eCuadro.appendChild(eTipo);
		var eRespuesta=document.createElement("P");
			eRespuesta.id= 'respuesta '+ contPreguntas;
		//LABEL respuesta
		var eRLabel=document.createElement("LABEL");
				var eRLSpan = document.createElement("SPAN");
					eRLSpan.setAttribute("class","Respuesta");
					var eRLSTexto = document.createTextNode("Respuesta");
					eRLSpan.appendChild(eRLSTexto);
				eRLabel.appendChild(eRLSpan);
			eRespuesta.appendChild(eRLabel);
				var eRCont=document.createElement("INPUT");
					eRCont.setAttribute("type","hidden");
					eRCont.name='c'+contPreguntas;
					eRCont.id='c'+contPreguntas;
					eRCont.value=1;
			eRespuesta.appendChild(eRCont);
	eCuadro.appendChild(eRespuesta);
			//HIDDEN contador de opciones
		
		var eEliminar=document.createElement("P");
			var eEBoton=document.createElement("INPUT");
			eEBoton.setAttribute("type","button");
			eEBoton.setAttribute("value","Quitar pregunta");
			eEBoton.setAttribute("onclick","quitarPregunta(this.parentNode.parentNode.id)");
		eEliminar.appendChild(eEBoton);
	eCuadro.appendChild(eEliminar);
	
	var ePadre=document.getElementById(padre);
	ePadre.insertBefore(eCuadro,document.getElementById('boton_agregar_pregunta').parentNode);
	document.getElementById('contPreguntas').value=contPreguntas;
	//siempre de último el contador de preguntas
	contPreguntas++;
}
function quitarPregunta(padre)
{
	if(confirm('¿Esta seguro de eliminar la pregunta?'))
	{
		var pregunta=document.getElementById(padre);
		pregunta.remove();
	}
}
function cambiarTipoPregunta(padre,tipoPregunta)
{
	/*
		Nombre de los elementos
		textBoxPregunta= 'p' + contPreguntas
		lista o select= 's' + contPreguntas
		contador de opciones oculto= 'c' + contPreguntas
		radio= contOpciones + 'r' + contPreguntas
		textBoxOpción= contOpciones + 't' + contPreguntas		
		link= contOpciones + 'l' + contPreguntas
	*/
	var ePadre=document.getElementById(padre);
	ePadre.removeChild(document.getElementById('respuesta '+padre));
	var eRespuesta=document.createElement("P");
		eRespuesta.id='respuesta '+padre;
		var eRCont=document.createElement("INPUT");
					eRCont.setAttribute("type","hidden");
					eRCont.name='c'+padre;
					eRCont.id='c'+padre;
					eRCont.value=2;
		eRespuesta.appendChild(eRCont);
	if(tipoPregunta=="M")
	{
	//Opción1
		//radio de la opción
			var eORadio = document.createElement("INPUT");
				eORadio.setAttribute("type", "radio");
				eORadio.id='1r'+padre;
		eRespuesta.appendChild(eORadio);
		//Textbox para la opción.
			var eOTexto = document.createElement("INPUT");
				eOTexto.setAttribute("type","text");
				eOTexto.setAttribute("placeholder","Opción");
				eOTexto.setAttribute("size","50");
				eOTexto.setAttribute("maxlength","45");
				eOTexto.setAttribute("pattern","[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ., ]{1,45}");
				eOTexto.setAttribute("required","true");
				//eOTexto.setAttribute("pattern",".{6,}"); 6 o mas caracteres mínimos.
				eOTexto.setAttribute("title","Solo se aceptan letras y números.");
				eOTexto.id='1t'+padre;
				eOTexto.name='1t'+padre;
		eRespuesta.appendChild(eOTexto);
		//un link para eliminar la opción
			var eOEliminar = document.createElement("A");
				eOEliminar.setAttribute("href","javascript:void");
				eOEliminar.setAttribute("onclick","quitarOpcion(this.id)");
				eOEliminar.setAttribute("tittle","Quitar opción");
				eOEliminar.setAttribute("style","text-decoration:none; color:#333;");
				eOEliminar.id='1l'+padre;
				var eOETexto=document.createTextNode(" X");
					eOEliminar.appendChild(eOETexto);
		eRespuesta.appendChild(eOEliminar);
		eRespuesta.appendChild(document.createElement("BR"));
	//Opción 2
		//radio de la opción
			var eORadio = document.createElement("INPUT");
				eORadio.setAttribute("type", "radio");
				eORadio.id='2r'+padre;
		eRespuesta.appendChild(eORadio);
		//Textbox para la opción.
			var eOTexto = document.createElement("INPUT");
				eOTexto.setAttribute("type","text");
				eOTexto.setAttribute("placeholder","Opción");
				eOTexto.setAttribute("size","50");
				eOTexto.setAttribute("maxlength","45");
				eOTexto.setAttribute("pattern","[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ,. ]{1,45}");
				eOTexto.setAttribute("required","true");
				//eOTexto.setAttribute("pattern",".{6,}"); 6 o mas caracteres mínimos.
				eOTexto.setAttribute("title","Solo se aceptan letras y números.");
				eOTexto.id='2t'+padre;
				eOTexto.name='2t'+padre;
		eRespuesta.appendChild(eOTexto);
		//un link para eliminar la opción
			var eOEliminar = document.createElement("A");
				eOEliminar.setAttribute("href","javascript:void");
				eOEliminar.setAttribute("onclick","quitarOpcion(this.id)");
				eOEliminar.setAttribute("tittle","Quitar opción");
				eOEliminar.setAttribute("style","text-decoration:none; color:#333;");
				eOEliminar.id='2l'+padre;
				var eOETexto=document.createTextNode(" X");
					eOEliminar.appendChild(eOETexto);
		eRespuesta.appendChild(eOEliminar);
		//Link para agregar otra opción
			var eOAgregar = document.createElement("A");
				eOAgregar.setAttribute("href","javascript:void");
				eOAgregar.setAttribute("onclick","agregarOpcion(this.parentNode.parentNode.id)");
				eOAgregar.setAttribute("tittle","Agregar otra opción");
				eOAgregar.setAttribute("style","text-decoration:none; color:#333; margin-top:5px;");
				var eOATexto=document.createTextNode("+ Agregar otro");
					eOAgregar.appendChild(eOATexto);
		eRespuesta.appendChild(document.createElement("BR"));
		eRespuesta.appendChild(eOAgregar);
	}
	else
	{
			var eRLabel=document.createElement("LABEL");
				var eRLSpan = document.createElement("SPAN");
					eRLSpan.setAttribute("class","Respuesta");
					var eRLSTexto = document.createTextNode("Respuesta");
					eRLSpan.appendChild(eRLSTexto);
				eRLabel.appendChild(eRLSpan);
		eRespuesta.appendChild(eRLabel);
	}
	ePadre.insertBefore(eRespuesta,ePadre.lastChild);
}
function agregarOpcion(padre)
{
	//padre=no. de pregunta
	var ePadre=document.getElementById('respuesta '+padre);
	/*contOpciones=ePadre.childNodes.length-3;
	var eQuitar=ePadre.childNodes.item(contOpciones).id;
	contOpciones=eQuitar.substring(0,eQuitar.indexOf('l'))*1+1;*/
	var eContOpciones=document.getElementById('c'+padre);
/*		var c=ePadre.childNodes;
	var i=0;
	var txt="";
	for(i=0;i<c.length;c++){
		txt=txt+c[i].id+',';
	}
	alert(txt);*/
	contOpciones=(eContOpciones.value*1)+1;
	eContOpciones.value=contOpciones;
	//radio
		var eORadio = document.createElement("INPUT");
		eORadio.setAttribute("type", "radio");
		eORadio.id=contOpciones+'r'+padre;
		//TextBox de la opción
		var eOTexto = document.createElement("INPUT");
		eOTexto.setAttribute("type","text");
		eOTexto.setAttribute("placeholder","Opción");
		eOTexto.setAttribute("size","50");
		eOTexto.setAttribute("maxlength","45");
		eOTexto.setAttribute("pattern","[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ,. ]{1,45}");
		eOTexto.setAttribute("required","true");
		//eOTexto.setAttribute("pattern",".{6,}"); 6 o mas caracteres mínimos.
		eOTexto.setAttribute("title","Solo se aceptan letras y números.");
		eOTexto.id=contOpciones+'t'+padre;
		eOTexto.name=contOpciones+'t'+padre;
		//Link para eliminar la opción
		var eOEliminar = document.createElement("A");
		eOEliminar.setAttribute("href","javascript:void");
		eOEliminar.setAttribute("onclick","quitarOpcion(this.id)");
		eOEliminar.setAttribute("tittle","Quitar Opción");
		eOEliminar.setAttribute("style","text-decoration:none; color:#333;");
		eOEliminar.id=contOpciones+'l'+padre;
			var eHijo3Texto=document.createTextNode(" X");
			eOEliminar.appendChild(eHijo3Texto);		
	ePadre.insertBefore(eORadio,ePadre.lastChild);
	ePadre.insertBefore(eOTexto,ePadre.lastChild);
	ePadre.insertBefore(eOEliminar,ePadre.lastChild);
	ePadre.insertBefore(document.createElement("BR"), ePadre.lastChild);
}
function quitarOpcion(opcion)
{
	padre=opcion.substring(opcion.indexOf('l')+1);
	contOpciones=opcion.substring(0,opcion.indexOf('l'));
	var eRespuesta=document.getElementById('respuesta '+padre);
	//debe de haber 10 elementos mínimos, 2 opciones:8 elementos + link de agregarOpcion + campo oculto
	if(eRespuesta.childNodes.length>10)
	{
		var c = eRespuesta.childNodes;
		//eliminar <br>
		for (var i = 0; i < c.length; i++)
			if(c[i].id==opcion)
				eRespuesta.childNodes.item(i+1).remove();
		eRespuesta.removeChild(document.getElementById(contOpciones+'r'+padre));
		eRespuesta.removeChild(document.getElementById(contOpciones+'t'+padre));
		eRespuesta.removeChild(document.getElementById(contOpciones+'l'+padre));
	}
	else
		alert('No se puede tener menos de 2 opciones');
}

function validarFormulario()
{
	/*
		Nombre de los elementos
		textBoxPregunta= 'p' + contPreguntas
		lista o select= 's' + contPreguntas
		contador de opciones oculto= 'c' + contPreguntas
		radio= contOpciones + 'r' + contPreguntas
		textBoxOpción= contOpciones + 't' + contPreguntas		
		link= contOpciones + 'l' + contPreguntas
	*/
/*	if (document.getElementById('texto_titulo').value=='Título') document.getElementById('texto_titulo').value = '';*/
	var i=0;
	var elementTemp;
	for(i=1;i<contPreguntas;i++)
	{
		elementTemp=document.getElementById('p'+i);//DIV de la pregunta (caja de cada pregunta) Padre.
		if(elementTemp!=null)
		{
			/*if (elementTemp.value=='¿Alguna pregunta?'){
				elementTemp.value = '';
			}*/
			if(document.getElementById('s'+i)!=null && document.getElementById('s'+i).value=="M")
			{
				var contOpciones=document.getElementById('c'+i).value*1;
				var ii=0;
			
				for(ii=1;ii<=contOpciones;ii++)
				{
					elementTemp=document.getElementById(ii+'t'+i);
					if (elementTemp!=null && elementTemp.value=='Opción') elementTemp.value = '';
				}
			}
		}
	}
	document.getElementById('boton_enviar2').click();
}
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Asignando...</title>
<script src="../../../BLL/ajax.js" language="javascript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>

<body>
<?php
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
   include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		$Consulta1=new Consulta;
        $Consulta2=new Consulta;
        $Consulta3=new Consulta;
$consulta1=new Consulta;

$idEvento=$_GET['filtro'];
$grupoeve=$_GET['grupoevento'];
if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
                 if(isset($_POST["idLugar"]))
                $idLug=$_POST["idLugar"];
            else
                echo '<br> Error en el dato  ';
                $id=$_POST["idEvento"];
                $idEvento=$id;
$grupoeve=$_POST["grupoevento"];
                $Consulta1->Lugar_asignar($id,$idLug);
        }
        $Consulta1->Evento_ver_datos($idEvento);
$comp=mysql_num_rows($Consulta1->Resultado);
if($comp>0)
{  
 $Consulta1->Evento_ver_datos($idEvento);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
}
else
{
 $Consulta1->Evento_ver_datos2($idEvento);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
}
?>


	<div id="lugarAsignado">
<?php
           $Consulta1->Evento_ver_Lugar($idEvento);
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print 'No existen Lugares Asignados';  
            }
            else
            {
    			//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 1;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta1->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
						echo '<td>'.$metadatos->name.'</td>';
						$i++;
					}
					echo '<td>Opciones</td>';
    			print '</tr>';
                echo "\n";
//Datos del dataGridView
				$agregar=false;
                                $contador=1;
                while($row=mysql_fetch_assoc($Consulta1->Resultado))
                {
                    //donde se agregan los datos que se mostraran en cada columna
$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 1;
					while ($i < mysql_num_fields($Consulta1->Resultado))
                    {
    					$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
						//para agregar color a una fila
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistencia")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia".$contador type="checkbox" id="checkboxAsistencia".$contador '.$checkeado.' onclick="javascript: return false;" value="".$row["Participante_idParticipante"] />';
                           ++$contador;
						}
                        else if($metadatos->name=="Imagen")
                        {
                            $foto=$row["Imagen"];
                            if(empty($foto))
                            {
                                $foto="default";
                            }
                            echo '<img  height="100" src="uploads/'.$foto.'" />';
                        }
						else
                        {
							echo $row[$metadatos->name];
                        }
						echo "</td>\n";					
						++$i;
                	}
$pagDescripcion='\'Evento_ver_descripcion.php\'';
					$pagEditar='\'Evento_editar.php\'';
                                         $pagAsignacion='\'Evento_detalle.php\'';
                                         $pagAsignar='\'asignaciones.php\'';
                                        $parametros='\'NombreEvento='.$row["Nombre Actividad"].'\'';
					echo '<td>';
						//Eliminar
						echo	'<span style="cursor:pointer"; onclick="Eliminardoblerepanel('.$idEvento.','.$row["Lugar_idLugar"].',2);"><i class="icon icon-bin"></i>Eliminar</samp>';
						echo "</td>\n";		
			echo "\n";
			print '</tr>';
if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
				}
                print '</table>';
            }   
?>
    </div>

 <form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">

      <label for="lista_lugar">Lugar: </label>
<div id="listaLugar">
      <select name="lista_lugar" id="lista_lugar" onchange="openVentana('lista_lugar','../Modal/Lugar_modal.php','idDiv=listaLugar');">
<option disabled selected=selected value="-">Seleccione una opcion</option>
 <?php
				$Consulta1->Lugar_ver();
				while ($row = mysql_fetch_assoc($Consulta1->Resultado)) {
                    
                    $lugar=$row["idLugar"];
                    $fecha=$Valores['Fecha'];
                    $horai=$Valores['HoraInicio'];
$horaf=$Valores['HoraFinal'];
                    $Consulta2->EventoLugar_verificacion_asignados_especifico($grupoeve,$lugar,$fecha,$horai,$horaf,$idEvento);
                    $comprobacion = $Consulta2->Resultado;      
 $Consulta3->Evento_ver_Lugar_simple($idEvento,$row ['idLugar']);
                    $existentes= $Consulta3->Resultado;               
                    
                    if(mysql_num_rows($comprobacion)==0&&mysql_num_rows($existentes)==0)
                    {
                        echo "<option selected=selected value=".$row['idLugar'].">".$row['Nombre']."</option>";
                    }
				}
echo '<option value="+">Agregar otro</option>';
		 ?>
      </select>
</div>
      <input type="hidden" name="idEvento" id="idEvento" value="<?php echo $idEvento?>"/>
<input type="hidden" name="grupo" id="grupo" value="<?php echo $grupoeve?>"/>
      <input type="button" name="boton_lugar" id="boton_lugar" value="Asignar" onclick="AsignarLugar(document.getElementById('lista_lugar').value,document.getElementById('idEvento').value,document.getElementById('grupo').value);" />
    </form>

</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Asignando...</title>
<script src="../../../BLL/ajax.js" language="javascript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>

<body>
<?php
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
	 include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		$Consulta1=new Consulta;
        $Consulta2=new Consulta;
        
$idEvento=$_GET['filtro'];
if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
                 if(isset($_POST["idSeccion"]))
                $sec=$_POST["idSeccion"];
            else
                echo '<br> Error en el dato  ';
                $id=$_POST["idEvento"];
                $idEvento=$id;
                $Consulta1->seccion_asignar($id,$sec);
        }
        $Consulta1->Evento_ver_datos($idEvento);
        $Valores=mysql_fetch_assoc($Consulta1->Resultado);
?>


	<div id="SeccionAsignada">
<?php
$consulta1=new Consulta;
           $Consulta1->Evento_ver_Seccion($idEvento);
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print 'Se Permiten a todas las Secciones asignarse a la actividad';   
            }
            else
            {
    			//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 1;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta1->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
						echo '<td>'.$metadatos->name.'</td>';
						$i++;
					}
					echo '<td>Opciones</td>';
    			print '</tr>';
                echo "\n";
//Datos del dataGridView
				$agregar=false;
                                $contador=1;
                while($row=mysql_fetch_assoc($Consulta1->Resultado))
                {
                    //donde se agregan los datos que se mostraran en cada columna
$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 1;
					while ($i < mysql_num_fields($Consulta1->Resultado))
                    {
    					$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
						//para agregar color a una fila
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistencia")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia".$contador type="checkbox" id="checkboxAsistencia".$contador '.$checkeado.' onclick="javascript: return false;" value="".$row["Participante_idParticipante"] />';
                           ++$contador;
						}
                        else if($metadatos->name=="Imagen")
                        {
                            $foto=$row["Imagen"];
                            if(empty($foto))
                            {
                                $foto="default";
                            }
                            echo '<img  height="100" src="uploads/'.$foto.'" />';
                        }
						else
                        {
							echo $row[$metadatos->name];
                        }
						echo "</td>\n";					
						++$i;
                	}

					echo '<td>';
						//Eliminar
						echo	'<span style="cursor:pointer"; onclick="Eliminardoblerepanel('.$idEvento.','.$row["Seccion_idSeccion"].',6);"><i class="icon icon-bin"></i>Eliminar</samp>';
						echo "</td>\n";		
			echo "\n";
			print '</tr>';
if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
				}
                print '</table>';
            }   
?>
    </div>
 <form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">

      <label for="lista_seccion">Seccion: </label>
 <div id="listaSeccion">
      <select name="lista_seccion" id="lista_seccion"  onchange="openVentana('lista_seccion','../Modal/seccion_modal.php','idDiv=listaSeccion');">
<option disabled selected=selected value="-">Seleccione una opcion</option>
 <?php
				$Consulta1->Seccion_ver();
				while ($row = mysql_fetch_assoc($Consulta1->Resultado)) {
                    $Consulta2->Seccion_verificacion_simple($idEvento,$row['idSeccion']);
                    $comprobacion = $Consulta2->Resultado;
                     if(mysql_num_rows($comprobacion)==0)
                        {
                            echo "<option selected=selected value=".$row['idSeccion'].">".$row['Seccion']."</option>";
                        }
                        
				}
echo '<option value="+">Agregar otro</option>';
		 ?>
      </select>
</div>
      <input type="hidden" name="idEvento" id="idEvento" value="<?php echo $idEvento?>"/>
      <input type="button" name="boton_lugar" id="boton_lugar" value="Asignar" onclick="AsignasSeccion(document.getElementById('lista_seccion').value,document.getElementById('idEvento').value);" />
    </form>

</body>
</html>
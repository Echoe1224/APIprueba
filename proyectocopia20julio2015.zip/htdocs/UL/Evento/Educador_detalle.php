<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Detalles del Educador</title>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
?>
</head>


<body>


<div align="right"><span style="cursor:pointer;" onclick="cerrarM();" title="Cerrar">X</span></div>
<?php 
        $Consulta1=new Consulta;
        $Consulta2=new Consulta;
        if(isset($_POST["idRegistro"]))
        {
			$idEducador=$_POST['idRegistro'];
        }
		else
        {
			$idEducador=0;
        }
        $Consulta1->Educador_ver_datos($idEducador);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
?>
<H3 align="center">Detalle Educador</H3>

<div class="tablas" align="center">
 <table width="654" border="0" cellspacing="5" align="center">
<tr>
          <td width="157"><p></p></td>
          <td width="282"></td>
        </tr>
    <tr>
      <td>Nombre del educador</td>
      <td><? print $Valores['Nombre del Educador'];?></td>
    </tr>
    <tr>
      <td>Teléfono:</td>
      <td><? print $Valores['Telefono'];?> 
    </td>
    </tr>
    <tr>
      <td>Correo:</td>
      <td><? print $Valores['Correo'];?></td>
    </tr>
    <tr>
      <td>Tipo de actividad;</td>
      <td><? print $Valores['Tipo del Evento'];?></td>
    </tr>
    <tr>
      <td>Empresa;</td>
      <td><? print $Valores['Empresa'];?></td>
    </tr>
    <tr>
      <td>País de origen:</td>
      <td><? print $Valores['PaisOrigen'];?></td>
    </tr>
    <tr>
      <td>Encargado:</td>
      <td><? print $Valores['Nombre del Encargado'];?></td>
    </tr>
    <tr>
      <td>Estado del eduador:</td>
      <td><input type="radio" name="Estado2" <?php if (isset($Valores['Habilitado']) && $Valores['Habilitado']==1) echo "checked";?> value="1" id="Estado2" required="required" onclick="javascript: return false;" >Disponible
    <input type="radio" name="Estado2" <?php if (isset($Valores['Habilitado']) && $Valores['Habilitado']==0) echo "checked";?> value="0" id="Estado2" onclick="javascript: return false;" >No Disponible </td>
    </tr>
    <tr>
      <td>Hoja de vida:</td>
      <td><?php $Imagen=$Valores["HojaDeVida"];
$carpeta="uploads/";
$direccion=$carpeta.$Imagen;
                            if(empty($Imagen))
                            {
                                $Imagen="default.pdf";
                            }

echo '<embed width="500" height="400" src="../../fotos/'.$Imagen.'" />';
?></td>
      <td>&nbsp;</td>
    </tr>

  </table>
</div>
          <script>
		  function abrir()
		  {
			  Filtrar3("grupo=<?php echo $_SESSION['idGrupoEvento'] ?>");
		  }
		  </script>
</body>
<!-- InstanceEnd --></html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Ingresar educador</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"de</script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>
<script src="../../BLL/modal.js" language="JavaScript"></script>
<?php
$hecho=0;
$ernom="";
if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
 if($_POST["boton"]=="Cancelar")
    	header('Location: Educador_ver.php');
	else if(isset($_POST["boton"])=="Guardar")
	{
$target_dir = "../../fotos/";
        $hojadevida=basename($_FILES["fileToUpload"]["name"]);
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
 if (file_exists($target_file)) 
        {
            echo "El archivo ya existe.";
            $uploadOk = 0;
        }
        // verificar el tamaño del archivo
        if ($_FILES["fileToUpload"]["size"] > 1000000) 
        {
            echo "El archivo es muy pesado, escoge uno menos pesado";
            $uploadOk = 0;
        }
        // formato de archivos permitidos
        if($imageFileType != "pdf" && $imageFileType != "PDF") 
        {
            echo "Disculpe, solo se permiten archivos con extención PDF ";
            $uploadOk = 0;
        }
       if ($uploadOk == 0) 
        {
            echo "Disculpe, no se pudo cargar su archivo.";
        // if everything is ok, try to upload file    
        }
       else{
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
                {
                    echo "    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
                } 
                else 
                {
                    echo "Disculpe, se ha producido un error al intentar subir su archivo";
                }
            }

            if(isset($_POST["idRegistro"]))
                $idlugar=$_POST["idRegistro"];
            else
                echo '<br> No existe el lugar';
            if(isset($_POST["Nombre2"]))
                $nombre=$_POST["Nombre2"];
            else
                echo '<br> No existe el Nombre ';
            if(isset($_POST["Telefono"]))
                $tel=$_POST["Telefono"];
            else
                echo '<br> No existe el dato ';
            if(isset($_POST["Correo"]))
                $correo=$_POST["Correo"];
            else
                echo '<br> No existe el dato ';
	    if(isset($_POST["listaeventos"]))
                $listaeve=$_POST["listaeventos"];
            else
                echo '<br> No existe el dato ';            
	    if(isset($_POST["Empresa"]))
                $empresa=$_POST["Empresa"];
            else
                echo '<br> No existe la empresa ';
	    if(isset($_POST["Pais"]))
                $pais=$_POST["Pais"];
            else
                echo '<br> No existe el País ';
	    if(isset($_POST["NombreEncargado"]))
                $listaenc=$_POST["NombreEncargado"];
            else
                echo '<br> No existe el Encargado ';
	    if(isset($_POST["Estado2"]))
                $estado=$_POST["Estado2"];
            else
                echo '<br> No existe el Nombre ';
   $consulta1->Educador_verificar_nombre_editar($idlugar,$nombre);
        $ven = $consulta1->Resultado;
        if(mysql_num_rows($ven)==0)
        {          
    $consulta1->Educador_actualizar($idlugar,$nombre,$tel,$correo,$listaeve,$empresa,$pais,$listaenc,$estado,$hojadevida);
$hecho=1; 
        }
        else
        {
                $ernom="Ya existe un educador con el mismo nombre";
        }   	
        }
}
?>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar un evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Evento seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
<a style="padding-left:50px; color:#333; text-decoration:none" href="Educador_ver.php"><i class="icon icon-undo2"></i> Atrás</a>
        <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    abrir();
                });
         </script>

<body>
<?php 
        $Consulta1=new Consulta;
        $Consulta2=new Consulta;
        if(isset($_POST["idRegistro"]))
        {
			$idEducador=$_POST['idRegistro'];
        }
		else
        {
			$idEducador=0;
        }
        $Consulta1->Educador_ver_datos($idEducador);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
?>
 <?php
	 if($hecho==1)
	 {
		?>
        <h2 align="center"><i class="icon icon-check"></i>Educador actualizado.</h2>
        <div style="display:none">
        <form id="forma" name="forma" method="post" action="Educador_ver.php">
          <input type="hidden" name="idRegistro" id="idRegistro" value="<?php echo $idEducador; ?>"/>
          <input type="submit" name="boton_pag" id="boton_pag" value="" />
        </form>
        </div>
        <script>
			setTimeout("document.getElementById('boton_pag').click();",1000);
		</script>
        <?php
	 }
	else
{
    ?>
 <div class="ventana">
            <div id="modal"></div>
        </div>
<H2 align="center">Editar educador</H2>
 <form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
  <p>
    <input type="hidden" name="formulario" value="Actualizar Educador" />
    <input type="hidden" name="idRegistro" value="<? print $idEducador;?>" />
<div class="tablas" align="center">
 <table width="654" border="0" cellspacing="5" align="center">
<tr>
          <td width="157"><p><span class="error">* Campos requeridos.</span></p></td>
          <td width="282"></td>
          <td width="189">&nbsp;</td>
        </tr>
    <tr>
      <td>Educador:</td>
      <td><input type="text" name="Nombre2" id="Nombre2" value="<? print $Valores['Nombre del Educador'];?>" size="50" maxlength="45" placeholder="Ingrese el nombre del conferencista." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" required title="Se necesita un nombre del conferencista(ingrese solamente letras)"/></td>
      <td><span class="error">*<? print $ernom;?></span></td>
    </tr>
    <tr>
      <td>Teléfono:</td>
      <td><input type="text" name="Telefono" id="Telefono" value="<? print $Valores['Telefono'];?>" size="50" maxlength="8" placeholder="Ingrese un número telefonico" pattern="[0-9]{1,45}" required title="Se necesita un número de teléfono(ingrese solamente números)"/> 
    </td>
      <td>*</td>
    </tr>
    <tr>
      <td>Correo:</td>
      <td><input type="text" name="Correo" id="Correo" value="<? print $Valores['Correo'];?>"  size="50" maxlength="150" placeholder="Ingrese un correo." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ.@0-9 ]{1,45}" required title="Se necesita un correo electronico(ingrese solamente letras)" /></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>Tipo de actividad:</td>
      <td><div id="lista_eventos">
<select name="listaeventos" id="listaeventos"  onchange="openVentana('listaeventos','../Modal/TipoEvento_modal.php','idDiv=lista_eventos');">
 <?php
				$consulta1->TipoEvento_ver_lista($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option value=".$row['id']; if($row["id"]==$Valores["idTipoEvento"]) echo ' selected="selected"'; echo ">".$row['nombre']."</option>";
				}
echo '<option value="+">Agregar otro</option>';
		 ?>
  </select>
</div></td>
      <td>*</td>
    </tr>
    <tr>
      <td>Empresa:</td>
      <td> <input type="text" name="Empresa" id="Empresa" value="<? print $Valores['Empresa'];?>"size="50" maxlength="45" placeholder="Ingrese la empresa donde labora." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ. ]{1,45}" required title="Se necesita un nombre de empresa(ingrese solamente letras)"/></td>
      <td>*</td>
    </tr>
    <tr>
      <td>País de origen:</td>
      <td> <input type="text" name="Pais" id="Pais" value="<? print $Valores['PaisOrigen'];?>"/></td>
      <td>*</td>
    </tr>
    <tr>
      <td>Encargado:</td>
      <td>
<div id="lista_encargado"><select name="NombreEncargado" id="NombreEncargado" onchange="cargar(this.value,'Personal_ingresar.php'),openVentana('NombreEncargado','../Modal/Personal_modal.php','idDiv=lista_encargado');" onFocus='cargarlista()'>
  <?php
    			$consulta1->Personal_ver_idgrupo($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option value=".$row['idPersonal']; if($row["idPersonal"]==$Valores["idPersonal"]) echo ' selected="selected"'; echo ">".$row['Nombre']."</option>";
				}
		 ?>
echo '<option value="+">Agregar otro</option>';
  </select></div></td>
      <td>*</td>
    </tr>
    <tr>
      <td>Estado:</td>
      <td><input type="radio" name="Estado2" <?php if (isset($Valores['Habilitado']) && $Valores['Habilitado']==1) echo "checked";?> value="1" id="Estado2" required="required">Disponible
    <input type="radio" name="Estado2" <?php if (isset($Valores['Habilitado']) && $Valores['Habilitado']==0) echo "checked";?> value="0" id="Estado2">No disponible </td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><input type="file"  name="fileToUpload" id="fileToUpload"></td>
      <td><?php $Imagen=$Valores["Imagen"];
                            if(empty($Imagen))
                            {
                                $Imagen="default.pdf#toolbar=0";
                                $carpeta="../../fotos/";
                            }
                            else
                           {
                             $carpeta="../../fotos/";
                            }
$direccion=$carpeta.$Imagen;
                            echo '<embed  width="500" height="400" src="'.$direccion.'#toolbar=0"/>';?>
</td>
      <td>&nbsp;</td>
    </tr>
<tr>
<td></td><td>
</br><input style="display:inline" type="submit" name="boton" id="boton" value="Guardar" />
           	<input style="display:inline" type="submit" name="boton" id="boton" value="Cancelar" /></td><td></td>
</tr>
  </table>
</div>
</form>
<?php } ?>
          <script>
		  function abrir()
		  {
			  Filtrar3("grupo=<?php echo $_SESSION['idGrupoEvento'] ?>");
		  }
		  </script>
<script language="javascript">
function cargar(numero,pagina)
{
if(numero=='+')
{
var win = window.open(pagina, '_blank'); 
win.focus();
}
}
function cargarlista()
   {
       var eTLista2=document.getElementById('NombreEncargado');
    document.getElementById('NombreEncargado').innerHTML = "";
                <?php  
            	$consulta1->Personal_ver_idgrupo($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
                  if($row['idPersonal']== $Valores["Personal_idPersonal_Encargado"])
                  {
                  ?>
				var eLOpcion2 = document.createElement("OPTION");
				 eLOpcion2.value= <?php echo $row["idPersonal"]; ?>;
                 eLOpcion2.text = "<?php echo $row["Nombre"]; ?>";
                 eTLista2.appendChild(eLOpcion2);
                 eLOpcion2.selected = "true";
                 <?php }
                 else
                 {?>
                     var eLOpcion2 = document.createElement("OPTION");
				 eLOpcion2.value= <?php echo $row["idPersonal"]; ?>;
                 eLOpcion2.text = "<?php echo $row["Nombre"]; ?>";
                 eTLista2.appendChild(eLOpcion2);
				<?php }			
				} ?>
            var eLOpcion3 = document.createElement("OPTION");
            eLOpcion3.value= "+";
            eLOpcion3.text = "Agregar otro";
            eTLista2.appendChild(eLOpcion3);
   }
</script>
			  <!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
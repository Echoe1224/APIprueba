<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Ingresar educador</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"de</script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>
<script src="../../BLL/modal.js" language="JavaScript"></script>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar un evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->

<?php
        $Consulta1=new Consulta;
        $Consulta2=new Consulta;    
?>


<?php
$imagenError=$ernom=$hecho="";
 if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
if($_POST["boton"]=="Cancelar")
    	header('Location: Educador_ver.php');
	else if(isset($_POST["boton"])=="Guardar")
	{
$target_dir = "../../fotos/";
        $hojadevida=basename($_FILES["fileToUpload"]["name"]);
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
 if (file_exists($target_file)) 
        {
            $imagenError=$imagenError."El archivo ya existe.";
            $uploadOk = 0;
        }
        // verificar el tamaño del archivo
        if ($_FILES["fileToUpload"]["size"] > 1000000) 
        {
            $imagenError=$imagenError."El archivo es muy pesado, escoge uno menos pesado";
            $uploadOk = 0;
        }
        // formato de archivos permitidos
        if($imageFileType != "pdf" && $imageFileType != "PDF") 
        {
            $imagenError=$imagenError."Disculpe, solo se permiten archivos con extención PDF ";
            $uploadOk = 0;
        }
       if ($uploadOk == 0) 
        {
            $imagenError=$imagenError."Disculpe, no se pudo cargar su archivo.";
        // if everything is ok, try to upload file    
        }
       else{
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
                {
                    $imagenError=$imagenError."    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
                } 
                else 
                {
                    $imagenError=$imagenError."Disculpe, se ha producido un error al intentar subir su archivo";
                }
            }
            
            if(isset($_POST["Nombre"]))
                $nombre=$_POST["Nombre"];
            else
                echo '<br> No existe el Nombre ';
            if(isset($_POST["Telefono"]))
                $tel=$_POST["Telefono"];
            else
                echo '<br> No existe el dato ';
            if(isset($_POST["Correo"]))
                $correo=$_POST["Correo"];
            else
                echo '<br> No existe el dato ';
	    if(isset($_POST["listaeventos"]))
                $listaeve=$_POST["listaeventos"];
            else
                echo '<br> No existe el dato ';            
	    if(isset($_POST["Empresa"]))
                $empresa=$_POST["Empresa"];
            else
                echo '<br> No existe la empresa ';
	    if(isset($_POST["Pais"]))
                $pais=$_POST["Pais"];
            else
                echo '<br> No existe el País ';
	    if(isset($_POST["NombreEncargado"]))
                $listaenc=$_POST["NombreEncargado"];
            else
                echo '<br> No existe el Encargado ';
                
       $Consulta2->Educador_verificar_nombre($nombre);
        $row = $Consulta2->Resultado;
        if($hojadevida=="")
        {
            $imagenError="";
        }
        if(mysql_num_rows($row)==0)
        {          
        $consulta1->Educador_insertar($nombre,$tel,$correo,$listaeve,$empresa,$pais,$listaenc,$hojadevida);  
$nombre=$tel=$correo=$listaeve=$empresa=$pais=$listaenc=$hojadevida="";
$hecho="Educador ingresado";
        }
        else
        {
                $ernom="Ya existe un educador con el mismo nombre";
        }
    }
        }
?>

 <div class="ventana">
            <div id="modal"></div>
        </div>
        <H2 align="center">Ingresar educador</H2>
<h3 align="center" style="color:#093"><? print $hecho;?></h3>
 <form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
  <p>
    <input type="hidden" name="formulario" value="Ingresar Educador" />
<div class="tablas" align="center">
    <table width="650" border="0" cellspacing="5" align="center">
<tr>
<td><span class="error">* Campos requeridos.</span></td>
<td></td>
<td></td>
</tr>
  <tr>
    <td width="200"><label for="Nombre">Nombre:</label></td>
    <td width="282"><input type="text" name="Nombre" id="Nombre" value="<? print $nombre;?>" size="50" maxlength="45" placeholder="Ingrese el nombre del conferencista." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" required title="Se necesita un nombre del Conferencista(ingrese solamente letras)"/></td>
    <td><span class="error">*<? print $ernom;?></td>
  </tr>
  <tr>
    <td width="200"><label for="Teléfono">
      Teléfono:</label></td>
   <td width="200"><input type="text" name="Telefono" id="Telefono" value="<? print $tel;?>" size="50" maxlength="8" placeholder="Ingrese un número teléfonico" pattern="[0-9]{1,45}" required title="Se necesita un número de teléfono(ingrese solamente números)"/></td>
   <td><span class="error">*</span></td>
  </tr>
  <tr>
   <td width="200"> <label for="Correo">
     Correo:</label></td>
    <td width="200"><input type="text" name="Correo" id="Correo" value="<? print $correo;?>" size="50" maxlength="150" placeholder="Ingrese un correo." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ.@0-9 ]{1,45}" title="Se necesita un correo electronico(ingrese solamente letras)" /></td>
  </tr>
  <tr>
<td width="200"><label for="listaeventos">Tipo de actividad:</label></td>
  <td width="200"><div id="lista_eventos">
<select name="listaeventos" id="listaeventos"  onchange="openVentana('listaeventos','../Modal/TipoEvento_modal.php','idDiv=lista_eventos');">
 <?php
				$consulta1->TipoEvento_ver_lista($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option value=".$row['id']; if($listaeve==$row['id']) echo 'selected="selected"'; echo">".$row['nombre']."</option>";
				}
echo '<option value="+">Agregar otro</option>';
		 ?>
  </select>
</div></td>
     <td width="200"><span class="error">*</span></td>
  </tr>
  <tr>
    <td width="200"><label for="HoraFinal3">Empresa:</label></td>
   <td width="200"><input type="text" name="Empresa" id="Empresa" value="<? print $empresa;?>" size="50" maxlength="45" placeholder="Ingrese la empresa donde labora." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ. ]{1,45}" required title="Se necesita un nombre de empresa(ingrese solamente letras)"/></td>
   <td><span class="error">*</span></td>
  </tr>
  <tr>
  <td width="200"><label for="Pais"><br />
      País de origen: </label></td>
   <td width="200"><input type="text" name="Pais" id="Pais" value="<? print $pais;?>" size="50" maxlength="45" placeholder="Ingrese el país de donde proviene." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" required title="Se necesita un País(ingrese solamente letras)"/>
    <br /></td>
    <td><span class="error">*</span></td>
  </tr>
  </tr>
  <tr>
  <td width="200">Encargado</td>
    <td width="200"><div id="lista_encargado"><select name="NombreEncargado" id="NombreEncargado" onchange="cargar(this.value,'Personal_ingresar.php'),openVentana('NombreEncargado','../Modal/Personal_modal.php','idDiv=lista_encargado');" onFocus='cargar()'>
  <?php
echo '<option value="-">Seleccione un Encargado</option>';
    			$consulta1->Personal_ver_idgrupo($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['idPersonal'].">".$row['Nombre']."</option>";
				}
		 ?>
echo '<option value="+">Agregar otro</option>';
  </select></div></td>
  </tr>
  </tr>
  <tr>
    <td width="200"><label for="Hoja de vida"> Hoja de Vida:</label></td>
    <td width="200"><input type="file"  name="fileToUpload" id="fileToUpload" onchange="onFileSelected(event)">
    <td><span class="error"><? print $imagenError;?></span></td>
  </p>
    <script>
     function onFileSelected(event) 
	{
	  var selectedFile = event.target.files[0];
	  var reader = new FileReader();
	
	  var imgtag = document.getElementById("myimage");
	  imgtag.title = selectedFile.name;
	
	  reader.onload = function(event) {
		imgtag.src = event.target.result;
	  };
	
	  reader.readAsDataURL(selectedFile);
	}
    </script></td>
  </tr>
</table>
    
    <label for="HoraInicio3"></label>
    <br />
    <input type="hidden" name="GrupoEvento" value="<? print $_SESSION['idGrupoEvento'];?>" />
    
<div align="center">    
 <input style="display:inline" type="submit" name="boton" id="boton" value="Guardar" />
              <a href="Educador_ver.php" target="_self"><input type="button" name="boton" id="boton" value="Cancelar" onclick=""/>
               </div>
</p>
</div>
 </form>
<script language="javascript">
function cargar(numero,pagina)
{
if(numero=='+')
{
var win = window.open(pagina, '_blank'); 
win.focus();
}
}
function cargarlista()
   {
       var eTLista2=document.getElementById('NombreEncargado');
    document.getElementById('NombreEncargado').innerHTML = "";
var eLOpcion3 = document.createElement("OPTION");
            eLOpcion3.value= "+";
            eLOpcion3.text = "Seleccione personal encargado";
            eTLista2.appendChild(eLOpcion3);
                <?php  
            	$consulta1->Personal_ver_idgrupo($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {?>
				var eLOpcion2 = document.createElement("OPTION");
				 eLOpcion2.value= <?php echo $row["idPersonal"]; ?>;
                 eLOpcion2.text = "<?php echo $row["Nombre"]; ?>";
                 eTLista2.appendChild(eLOpcion2);
				<?php } ?>
            var eLOpcion3 = document.createElement("OPTION");
            eLOpcion3.value= "+";
            eLOpcion3.text = "Agregar otro";
            eTLista2.appendChild(eLOpcion3);
   }
</script>
	<!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
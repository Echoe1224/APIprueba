﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Editar Evento</title>                            
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>
<?php
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	$consulta1=new Consulta;
    $consulta1->Usuario_ver();
    $Admin=$consulta1->Resultado;
?>
<!-- InstanceBeginEditable name="head" -->

<script src="../../../BLL/ajax.js" language="JavaScript"></script>
<script src="datetimepicker_css.js" language="JavaScript"></script>

<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
<style type="text/css">
.Respuesta {
	border: 1px solid #CCC;
	padding: 3px;
	margin: 3px;
}
.pregunta {
	margin: 10px;
	padding: 10px;
	border: 1px solid #999;
	box-shadow:0px 4px 3px rgba(0,0,0,.5);
}
</style>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
        <header>
		<nav class="menu">
			<ul>
				<li><a href="../inicio.php"><span class="primero"><i class="icon icon-home"></i></span>CITEIN</a></li>
				<li><a href="#"><span class="segundo"><i class="icon icon-table2"></i></span>EVENTOS</a>
					<ul>
						<li><a href="#">Ver eventos</a></li>
						<li><a href="#">Crear evento</a></li>
					</ul>
				</li>
				<li><a href="#"><span class="tercero"><i class="icon icon-accessibility"></i></span>PARTICIPANTES</a>
					<ul>
						<li><a href="#">Ver participantes</a></li>
						<li><a href="../Registrar_Participante.php">Nuevo participante</a></li>
					</ul>
                </li>
                <?php if($Admin==TRUE){ ?>
				<!-- Opciones para administrador -->
                <li><a href="#"><span class="cuarto"><i class="icon icon-user"></i></span>OTROS</a>
					<ul>
						<li><a href="#">Tipo evento</a></li>
                        <ul>
							<li><a href="#">Tipo evento</a></li>
                        </ul>
						<li><a href="#">Nuevo tipo evento</a></li>
                        <li><a href="#">Nuevo tipo evento</a></li>
					</ul>
                </li>
                <?php } ?>
				<li><a href="#"><span class="cuarto"><i class="icon icon-user"></i></span>PERSONAL</a>
					<ul>
						<li><a href="#">Ver personal</a></li>
						<li><a href="#">Nuevo personal</a></li>
					</ul>
                </li>
				<li><a href="#"><span class="quinto"><i class="icon icon-exit"></i></span>Cerrar Sesión</a></li>
			</ul>
		</nav>
        </header>
        </div>

<div class="contenedor">
	<div class="contenido">
    <!-- InstanceBeginEditable name="Contenido" -->
<?php
        $Consulta1=new Consulta;
        $Consulta2=new Consulta;    
?>
 <form id="form1" method="post" action="<?php echo htmlspecialchars("/DAL/guardar.php");?>" enctype="multipart/form-data">
<input type="hidden" name="formulario" value="Insertar Evento" />
  <label for="Nombre">Nombre</label>
  <input type="text" name="Nombre" id="Nombre" value=""/>
  <br />
<label for="Descripcion">Descripcion</label>
 <textarea name="Descripcion" id="Descripcion" cols="45" rows="5" value=""></textarea>
  <br />
  <label for="listaeventos">Lista tipo</label>
  <select name="listaeventos" id="listaeventos">
 <?php
				$Consulta2->TipoEvento_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option selected=selected value=".$row['idTipoEvento'].">".$row['Nombre']."</option>";
				}
		 ?>
  </select>
  <label for="Fecha">Fecha</label>
  <input type="text" name="Fecha" id="Fecha" value="" readonly="readonly"/>
 <img src="images2/cal.gif" onclick="javascript:NewCssCal('Fecha','yyyyMMdd')" style="cursor:pointer"/>
  <br />
  <label for="HoraInicio">HoraInicio</label>
  <input type="text" name="HoraInicio" id="HoraInicio" value=""/>
  <br />
  <label for="HoraFinal">HoraFinal</label>
  <input type="text" name="HoraFinal" id="HoraFinal" value=""/>
  <br />
  <label for="ListaGrupoEvento">Grupo Evento</label>
  <select name="ListaGrupoEvento" id="ListaGrupoEvento">
  <?php
    			$Consulta2->GrupoEvento_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option selected=selected value=".$row['idGrupoEvento'].">".$row['Nombre']."</option>";
				}
		 ?>
  </select>
  <br />
  <label for="NombreEncargado">Encargado</label>
  <select name="NombreEncargado" id="NombreEncargado">
  <?php
    			$Consulta2->Personal_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option selected=selected value=".$row['idPersonal'].">".$row['Nombre']."</option>";
				}
		 ?>
  </select>
    <label for="Encuesta"><br />
    Titulo Encuesta</label>
  <select name="Encuesta" id="Encuesta">
  <?php
    			$Consulta2->Encuesta_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option selected=selected value=".$row['idEncuesta'].">".$row['TituloEncuesta']."</option>";
				}
		 ?>
    </select>
  <label for="Costo">Costo: </label>
  <input type="text" name="Costo" id="Costo" value=""/>
</p>
  <p>
<input type="file"  name="fileToUpload" id="fileToUpload" onchange="onFileSelected(event)">
 <img  height="100" id="myimage" src="">
  </p>
</p>
<script>
	 function onFileSelected(event) 
	{
	  var selectedFile = event.target.files[0];
	  var reader = new FileReader();
	
	  var imgtag = document.getElementById("myimage");
	  imgtag.title = selectedFile.name;
	
	  reader.onload = function(event) {
		imgtag.src = event.target.result;
	  };
	
	  reader.readAsDataURL(selectedFile);
	}
</script>
 <input type="submit" name="Guardar" id="Guardar" value="Enviar" />
</form>
 <input type="submit" name="Cancelar" id="Cancelar" value="Cancelar" />
<!-- InstanceEndEditable -->
    
    </div>
    
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
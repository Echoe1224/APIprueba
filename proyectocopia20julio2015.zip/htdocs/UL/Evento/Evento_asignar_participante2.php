<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Asignando...</title>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>

<body>
<?php
include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
session_start();
			$idEvento=$_GET['filtro'];

        $Consulta1=new Consulta;
        $Consulta2=new Consulta;
        $Consulta3=new Consulta;
        $Consulta4=new Consulta;
        $Consulta5=new Consulta;
$Consulta6=new Consulta;
$Consulta7=new Consulta;

 $pagDescripcion='\'Evento_ver_asignacion.php\'';
 
//$consulta1->EventoParticipante_insertar($idParticipante, $idEvento, $costo, $lugar);

$verifica=$_POST['ver'];

if($verifica==0)
{
if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
		$idParticipante=$_POST["idParticipante"];
		$idEvento=$_POST["idEvento"];
$luga=$_POST["lugar"];
             $Consulta1->EventoParticipante_insertar($idParticipante, $idEvento, $costo, $luga);
        }
}
else if($verifica==1)
{
$idEvento=$_POST["idEvento"];
$luga=$_POST["lugar"];
}
?>

<?php
 $Consulta2->Evento_ver_datos($idEvento);
$comp=mysql_num_rows($Consulta2->Resultado);
if($comp>0)
{  
 $Consulta2->Evento_ver_datos($idEvento);
       $Nombreevento=mysql_fetch_assoc($Consulta2->Resultado);        
}
else
{
 $Consulta2->Evento_ver_datos2($idEvento);
       $Nombreevento=mysql_fetch_assoc($Consulta2->Resultado);        
}
$Consulta1->Evento_ver_Participante($idEvento);
$Cantidadasignados=$Consulta1->Resultado;
                echo '<h4 align="center">Actividad: '.$Nombreevento['Nombre'].'</h4>';
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print 'No existen participantes asignados';  
            }
            else
            {
    			//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 2;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta1->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
						echo '<td>'.$metadatos->name.'</td>';
						$i++;
					}
echo '<td>Opciones</td>';
    			print '</tr>';
                echo "\n";
//Datos del dataGridView
				$agregar=false;
                                $contador=1;
                while($row=mysql_fetch_assoc($Consulta1->Resultado))
                {
                    //donde se agregan los datos que se mostraran en cada columna
                 	$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 2;
					while ($i < mysql_num_fields($Consulta1->Resultado))
                    {
    					$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
						//para agregar color a una fila
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistencia")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia".$contador type="checkbox" id="checkboxAsistencia".$contador '.$checkeado.' onclick="javascript: return false;" value="".$row["Participante_idParticipante"] />';
                           ++$contador;
						}
                        else if($metadatos->name=="Foto")
                        {
                            $foto=$row["Foto"];
                            if(empty($foto))
                            {
                                $foto="default";
                            }
                            echo '<img  height="100" src="../../fotos/'.$foto.'.jpg" />';
                        }
						else
                        {
							echo $row[$metadatos->name];
                        }
						echo "</td>\n";					
						++$i;
                	}
echo '<td>';
echo    '<span style="cursor:pointer"; onclick="Eliminardoblere('.$idEvento.','.$row["Participante_idParticipante"].',3);"><i class="icon icon-bin"></i>Eliminar</samp>';
						echo "</td>\n";		
			echo "\n";
			print '</tr>';
if($agregar)
				$agregar=false;
			else
				$agregar=true;
                
				}
                print '</table>';
            } 
            print '</br>';
?>

<form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">

<input type="hidden" name="idEvento" id="idEvento" value="<? print $idEvento;?>"/>
   <input type="hidden" name="contAsignacion" id="contAsignacion" value="0"/>
 <input type="hidden" name="idGrupoEvento" id="idGrupoEvento" value="<? print $_SESSION['idGrupoEvento'];?>"/> 

                  <input type="hidden" name="contAsignacion" id="contAsignacion" value="1"/>
                  <input type="hidden" name="Nombre_participante" id="Nombre_participante" value="1"/>
      
<h2 align="center">Participantes disponibles</h2>         

  <td><label for="ListaLugar">Lugar de la actividad:</label></td>
     <td><select name="ListaLugar" id="ListaLugar" onchange="cargar(<? print $idEvento;?>, this.value)">
  <?php
echo '<option value="+">Seleccione un lugar</option>';
    			$Consulta1->Evento_ver_Lugar($idEvento);
				while ($row = mysql_fetch_assoc($Consulta1->Resultado)) {
					echo "<option value=".$row['Lugar_idLugar']; if($row["Lugar_idLugar"]==$luga) echo ' selected="selected"'; echo ">".$row['Nombre del lugar']."</option>";
				}
		 ?>
  </select>
<?php 
if($luga>0)
{  
$Consulta3->Lugar_verificarcantidad($luga);
$Capacidad=mysql_fetch_assoc($Consulta3->Resultado);
$Consulta3->Evento_ver_Participante_comprobar2($luga,$idEvento);
$Asig=mysql_num_rows($Consulta3->Resultado); ?>
<table>
<tr>
<td>Capacidad del lugar</td>
<td>Participantes asignados</td>
</tr>
<tr>
<td><? print $Capacidad['Capacidad'];?></td>
<td><? print $Asig;?></td>
</tr>
</table>
<?php }?>
</td>

                	<?php  
if($luga>0)
{  
if($Asig<$Capacidad['Capacidad'])
{
 $Consulta1->Evento_ver_Participante_verificadion($_SESSION['idGrupoEvento'],$idEvento,$Nombreevento['Fecha'],$Nombreevento['HoraInicio'],$Nombreevento['HoraFinal']);
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print 'No hay participantes disponibles';  
            }
            else
            {
    			//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 1;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta1->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
						echo '<td>'.$metadatos->name.'</td>';
						$i++;
					}
					echo '<td>Opciones</td>';
    			print '</tr>';
                echo "\n";
//Datos del dataGridView
				$agregar=false;
                                $contador=1;
                while($row=mysql_fetch_assoc($Consulta1->Resultado))
                {
                    $Consulta4->EventoParticipante_comprobar3($row['idParticipante'],$Nombreevento['TipoEvento_idTipoEvento']);
                    $asignadosper=mysql_num_rows($Consulta4->Resultado);
                    $Consulta5->TipoEventoCantidad_ver_grupoper($_SESSION['idGrupoEvento'],$Nombreevento['TipoEvento_idTipoEvento']);
                    $cantidatipo=mysql_fetch_assoc($Consulta5->Resultado);

                    //donde se agregan los datos que se mostraran en cada columna
$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 1;
					while ($i < mysql_num_fields($Consulta1->Resultado))
                    {
    					$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
						//para agregar color a una fila
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistencia")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia".$contador type="checkbox" id="checkboxAsistencia".$contador '.$checkeado.' onclick="javascript: return false;" value="".$row["Participante_idParticipante"] />';
                           ++$contador;
						}
                        else if($metadatos->name=="Foto")
                        {
                            $foto=$row["Imagen"];
                            if(empty($Foto))
                            {
                                $foto="default.jpg";
                            }
                            echo '<img  height="100" src="../../fotos/'.$foto.'.jpg" />';
                        }
 else if($metadatos->name=="Descripción")
                        {
                            if($row[$metadatos->name].length>40)
                            {
                                 echo  substr($row[$metadatos->name],0,40)."...";
                            }
                            else
                            {
                                echo $row[$metadatos->name];
                            }
                        }
						else
                        {
							echo $row[$metadatos->name];
                        }
						echo "</td>\n";					
						++$i;
                	}
 $parametros='\'idParticipante='.$row["idParticipante"].'&idEvento='.$idEvento.'\'';
                                         $pagAsignacion='\'Evento_asignar_participante.php\'';
					echo '<td>';
			//Responder Encuesta
						//Editar
                         if($asignadosper<$cantidatipo['Cantidad'])
                        {
                                                echo	'<span style="cursor:pointer"; onclick="AsignarParticipante('.$row["idParticipante"].','.$idEvento.','.$luga.');"><i class="icon icon-pencil"></i>Asignar</span>
								<br>';
                        }
                        else
                        {
                            echo    'El participante ha<br>superado la cantidad<br>de actividades<br>permitidas
								<br>';
                        }
						echo "</td>\n";		
                                                //echo''.$row["idParticipante"];
			echo "\n";
			print '</tr>';
if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
				}
                print '</table>';
            }   
}
else
{
echo '<h3 align="left">Capacidad máxima del lugar alcanzada.</h3> ';
}
} 
?>
</form>


</body>
</html>
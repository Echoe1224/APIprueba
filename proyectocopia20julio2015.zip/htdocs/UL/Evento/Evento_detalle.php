<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Detalles de la actividad</title>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
?>
</head>

<body>

<div align="right"><span style="cursor:pointer;" onclick="cerrarM();" title="Cerrar">X</span></div>
<?php
        $Consulta1=new Consulta;
        $Consulta2=new Consulta;
        if(isset($_POST["idRegistro"]))
        {
			$idEvento=$_POST['idRegistro'];
        }
		else
        {
			$idEvento=0;
        }
        $Consulta1->Evento_ver_datos($idEvento);
$comp=mysql_num_rows($Consulta1->Resultado);
if($comp>0)
{  
 $Consulta1->Evento_ver_datos($idEvento);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
}
else
{
 $Consulta1->Evento_ver_datos2($idEvento);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
}
?>
<H3 align="center">Detalle de la actividad</H3>
<div name="centrados" align="center">
<table width="628" border="0" cellspacing="5" align="center">
<input type="hidden" name="idEvento" value="<? print $idEvento;?>" />
  <tr>
    <td width="157"> <label for="Nombre">Nombre de la actividad:</label></td>
  <td width="282" align="left"><H3><? print $Valores['Nombre'];?></h3></td>
 </tr>
  <tr>
<td><label for="Descripcion">Descripción:</label></td>
 <td align="left"><? print $Valores['DescripcionEvento'];?></td>
   </tr>
  <tr>
<td><label for="TipoEventos">Tipo de actividad:</label></td>
  <td align="left"><? print $Valores['NombreTipoEvento'];?></td>
   </tr>
  <tr>
  <td><label for="Fecha">Fecha:</label></td>
  <td align="left"><? $fecha1=$Valores['Fecha'];
print $fecha2=date("d/m/Y",strtotime($fecha1));?></td>
     </tr>
  <tr>
  <td><label for="HoraInicio">Hora de inicio:</label></td>
  <td align="left"><? print $Valores['HoraInicio'];?></td>
     </tr>
  <tr>
  <td><label for="HoraFinal">Hora de finalización:</label></td>
 <td align="left"><? print $Valores['HoraFinal'];?></td>
     </tr>
  <tr>
  <td><label for="EncargadoN">Personal a cargo:</label></td>
  <td align="left"><? print $Valores['NombrePersonal'];?></td>
   </tr>
  <tr>
    <td><label for="TituloEncuesta">Encuesta asignada:</label></td>
  <td align="left"><? if($comp>0)
{
 print  $Valores['TituloEncuesta'];
}
else 
{
echo 'Encuesta no asignada';
}?></td>
     </tr>
  <tr>
  <td><label for="Costo">Costo extra: </label></td>
  <td align="left"><? print $Valores['Costo'];?></td>
   </tr>
  <tr>
<td><label>Imagen de la actividad:</label></td>
<td align="left"><?php $Imagen=$Valores["Imagen"];
                            if(empty($Imagen))
                            {
                                $Imagen="conferencia2.jpg";
                                $carpeta="../../imagenes/";
                            }
                            else
                           {
                             $carpeta="../../fotos/";
                            }
$direccion=$carpeta.$Imagen;
                            echo '<img height="100" src="'.$direccion.'"/>';?></td>
      </tr>
  
</table>
</div>
<script>
	 function onFileSelected(event) 
	{
	  var selectedFile = event.target.files[0];
	  var reader = new FileReader();
	
	  var imgtag = document.getElementById("myimage");
	  imgtag.title = selectedFile.name;
	
	  reader.onload = function(event) {
		imgtag.src = event.target.result;
	  };
	
	  reader.readAsDataURL(selectedFile);
	}
</script>
</body>
<!-- InstanceEnd --></html>	
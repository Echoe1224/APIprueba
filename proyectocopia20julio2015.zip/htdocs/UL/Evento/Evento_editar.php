<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Editando actividad</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>
<script src="../../BLL/modal.js" language="JavaScript"></script>

<link type="text/css" rel="stylesheet" href="../GRUPO_EVENTOS/DatePicker.css"/>
<script type="text/javascript" src="../GRUPO_EVENTOS/DatePicker.js"></script>
<script type="text/javascript">
function init() {
calendar.set("Fecha");
}
</script>
<?php
$fechaError=$errorLista=$imagenError=$hecho=$nombreError="";
$hechoima=0;
  if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if($_POST["boton"]=="Cancelar")
    	header('Location: Evento_ver.php');
	else if(isset($_POST["boton"])=="Guardar")
	{
                $descripcion=$_POST["Descripcion"];
                $imagen=$_POST["archivoimagen"];
         //INICIA codigo para guardar imagen en la carpeta
    $target_dir = "../../fotos/";
        $hojadevida=basename($_FILES["fileToUpload"]["name"]);
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
 if (file_exists($target_file)) 
        {
            $imagenError=$imagenError."El archivo ya existe.";
            $uploadOk = 0;
        }
        // verificar el tamaño del archivo
        if ($_FILES["fileToUpload"]["size"] > 1000000) 
        {
            $imagenError=$imagenError."El archivo es muy pesado, escoge uno menos pesado";
            $uploadOk = 0;
        }
        // formato de archivos permitidos
         if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) 
        {
            $imagenError=$imagenError."Disculpe, solo se permiten archivos con extención JPG, JPEG, PNG y GIF ";
            $uploadOk = 0;
        }
       if ($uploadOk == 0) 
        {
            $imagenError=$imagenError."Disculpe, no se pudo cargar su archivo.";
$hechoima=1;
        // if everything is ok, try to upload file    
        }
       else{
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
                {
                    $imagenError=$imagenError."    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
                } 
                else 
                {
                    $imagenError=$imagenError."Disculpe, se ha producido un error al intentar subir su archivo";
$hechoima=1;
                }
            }
	
       
//terminaimagen
            if(isset($_POST["idRegistro"]))
                $ideve=$_POST["idRegistro"];
            else
                echo '<br> No existe el Evento';
            if(isset($_POST["Nombre"]))
                $nombre=$_POST["Nombre"];
            else
                echo '<br> No existe Nombre ';
            if(isset($_POST["listaeventos"]))
                $tipoeve=$_POST["listaeventos"];
            else
                echo '<br> No existe el Evento ';
            if(isset($_POST["Fecha"]))
                $fecha=$_POST["Fecha"];
            else
                echo '<br> No existe la Fecha ';

$hi=$_POST["Nombre_horainicio"];
$mini=$_POST["Nombre_mininicio"];

if($hi=="Hora")
{
$horai=$_POST["HoraInicio"];
}
else
{
 if($mini<10)
{
$horai=$hi."0".$mini."00";
}
else
{
                $horai=$hi.$mini."00";
}
}

$hf=$_POST["Nombre_horafinal"];
$minf=$_POST["Nombre_minfinal"];
if($hf=="Hora")
{
$horaf=$_POST["HoraFinal"];
}
else
{
if($minf<10)
{
$horaf=$hf."0".$minf."00";
}
else
{
                $horaf=$hf.$minf."00";
}
}
            if(isset($_POST["ListaGrupoEvento"]))
                $grupo=$_POST["ListaGrupoEvento"];
            else
                echo '<br> Error en el dato  ';
            if(isset($_POST["NombreEncargado"]))
                $encargado=$_POST["NombreEncargado"];
            else
                echo '<br> No existe Nombre  de Encargado';
            if(isset($_POST["Encuesta"]))
                $idencuesta=$_POST["Encuesta"];
            else
                echo '<br> No existe la Encuesta ';
            if(isset($_POST["Costo"]))
                $costo=$_POST["Costo"];
            else
                echo '<br> No existe el Costo ';

$consulta1->GrupoEvento_ver_rangofecha($grupo,$fecha);
        $fecharango= mysql_num_rows($consulta1->Resultado);
 $consulta1->Evento_verificar_editar($ideve,$nombre,$_SESSION['idGrupoEvento']);
        $veredi= $consulta1->Resultado;
        if($fecharango==0)
        {
$fechaError="No se puede ingresar la fecha puede que no coincida con el evento que se esta administrando";
        }
else if(mysql_num_rows($veredi)>0)
{
$nombreError="Ya existe una actividad con nombre similar verifique de nuevo";
}

else
{
        $consulta1->Evento_actualizar($ideve,$nombre,$tipoeve,$fecha,$horai,$horaf,$grupo,$encargado,$idencuesta,$costo,$descripcion,$hojadevida); 
$hecho=1;
}
	}
        }
        ?>

<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1" onload="init()">
    <div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Evento seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
<script type="text/javascript">
 $(document).ready(function () {
        yourFunction();
    });
function yourFunction()
    {
         $("#Costo").on("keyup", function()
         {
            var valid = /^\d{0,4}(\.\d{0,2})?$/.test(this.value),
                val = this.value;
            
            if(!valid)
            {
                this.value = val.substring(0, val.length - 1);
            }
        });
    }
</script>

<a style="padding-left:50px; color:#333; text-decoration:none" href="Evento_ver.php"><i class="icon icon-undo2"></i> Atrás</a>
<?php
        $Consulta1=new Consulta;
        $Consulta2=new Consulta;
        if(isset($_POST["idRegistro"]))
        {
			$idEvento=$_POST['idRegistro'];
        }
		else
        {
			$idEvento=0;
        }
            $Consulta1->Evento_ver_datos($idEvento);
$comp=mysql_num_rows($Consulta1->Resultado);
if($comp>0)
{  
 $Consulta1->Evento_ver_datos($idEvento);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
}
else
{
 $Consulta1->Evento_ver_datos2($idEvento);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
}
?>
 <?php
	 if($hecho==1)
	 {
		?>
        <h2 align="center"><i class="icon icon-check"></i>Actividad actualizada.</h2>
        <div style="display:none">
        <form id="forma" name="forma" method="post" action="Evento_ver.php">
<input type="text" name="idRegistro" value="<? print $idEvento;?>" />
          <input type="submit" name="boton_pag" id="boton_pag" value="" />
        </form>
        </div>
        <script>
			setTimeout("document.getElementById('boton_pag').click();",1000);
		</script>
        <?php
	 }
	else
{
    ?>
 <div class="ventana">
            <div id="modal"></div>
        </div>
<H2 align="center">Editar actividad: <? print $Valores['Nombre'];?></H2>
 <form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
<input type="hidden" name="formulario" value="Actualizar Evento" />
<input type="hidden" name="idRegistro" value="<? print $idEvento;?>" />
<div class="tablas" align="center">
 <table width="654" border="0" cellspacing="5" align="center">
<tr>
<td><span class="error">* Campos requeridos.</span></td>
<td></td>
<td></td>
</tr>
   <tr>
     <td><label for="Nombre">Nombre de la actividad:</label></td>
     <td><input type="text" name="Nombre" id="Nombre" value="<? print $Valores['Nombre'];?>" size="50" maxlength="45" placeholder="Ingrese el nombre de la actividad." pattern="[A-Za-z0-9ÑñÁÉÍÓÚáéíóú ]{1,45}" required title="Se necesita un nombre de la actividad(solamente letras y números)"/></td>
     <td><span class="error">*  <?php echo $nombreError; ?></span></td>
   </tr>
   <tr>
     <td><label for="Descripcion">Descripción:</label></td>
     <td><textarea name="Descripcion" id="Descripcion" cols="45" rows="5" value=""><? print $Valores['DescripcionEvento'];?></textarea></td>
     <td><span class="error">* </span></td>
   </tr>
   <tr>
     <td> <label for="listaeventos">Tipo de actividad:</label></td>
     <td><div id="lista_eventos">
<select name="listaeventos" id="listaeventos"  onchange="openVentana('listaeventos','../Modal/TipoEvento_modal.php','idDiv=lista_eventos');">
 <?php
$Consulta2->TipoEvento_ver_lista($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option value=".$row['id']; if($row["id"]==$Valores["TipoEvento_idTipoEvento"]) echo ' selected="selected"'; echo ">".$row['nombre']."</option>";
				}
echo '<option value="+">Agregar otro</option>';
		 ?>
  </select>
</div></td>
     <td>&nbsp;</td>
   </tr>
   <tr>
     <td><label for="Fecha">Fecha:</label></td>
     <td><input type="text" name="Fecha" id="Fecha" value="<? print $Valores['Fecha'];?>" readonly="readonly"/></td>
     <td><span class="error">* <?php echo $fechaError; ?> </span></td>
   </tr>
   <tr>
     <td> <label for="HoraInicio">Hora de inicio:</label></td>
     <td><input type="text" name="HoraInicio" id="HoraInicio" value="<? print $Valores['HoraInicio'];?>" readonly="readonly" size="5"/> 
<select name="Nombre_horainicio" id="Nombre_horainicio" selectedvalue=>
        		    <option value="Hora">Hora</option>
        		    <?php  for($i=0;$i<=23;$i++) { echo "<option value='".$i."'>".$i."</option>"; } ?>
      		    </select>
				Hora
				<select name="Nombre_mininicio" id="Nombre_mininicio" selectedvalue=>
 			 	<option value="0">Min</option>
  				<?php  for($i=00;$i<=59;$i++) { echo "<option value='".$i."'>".$i."</option>"; } ?>
				</select>
				Min</td>
     <td>&nbsp;</td>
   </tr>
   <tr>
     <td><label for="HoraFinal">Hora de finalización:</label></td>
     <td><input type="text" name="HoraFinal" id="HoraFinal" value="<? print $Valores['HoraFinal'];?>" readonly="readonly" size="5"/>
 <select name="Nombre_horafinal" id="Nombre_horafinal" selectedvalue=>
        		    <option value="Hora">Hora</option>
        		    <?php  for($i=0;$i<=23;$i++) { echo "<option value='".$i."'>".$i."</option>"; } ?>
      		    </select>
				Hora
				<select name="Nombre_minfinal" id="Nombre_minfinal" selectedvalue=>
  				<option value="0">Min</option>
  				<?php  for($i=00;$i<=59;$i++) { echo "<option value='".$i."'>".$i."</option>"; } ?>
				</select>
				Min</td>
     <td>&nbsp;</td>
   </tr>
   <tr>
     <td><label for="NombreEncargado">Encargado:</label></td>
     <td><div id="lista_encargado"><select name="NombreEncargado" id="NombreEncargado" onchange="cargar(this.value,'Personal_ingresar.php'),openVentana('NombreEncargado','../Modal/Personal_modal.php','idDiv=lista_encargado');" onFocus='cargarlista()'>
  <?php
    			$consulta1->Personal_ver_idgrupo($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option value=".$row['idPersonal']; if($row["idPersonal"]==$Valores["Personal_idPersonal_Encargado"]) echo ' selected="selected"'; echo ">".$row['Nombre']."</option>";
				}
		 ?>
echo '<option value="+">Agregar otro</option>';
  </select></div></td>
     <td>&nbsp;</td>
   </tr>
   <tr>
     <td><label for="Encuesta">Titulo de la encuesta:</label></td>
     <td><select name="Encuesta" id="Encuesta">
 <?php
echo '<option value="0">Sin Encuesta</option>';
    			$Consulta2->Encuesta_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option value=".$row['idEncuesta']; if($row["idEncuesta"]==$Valores["Encuesta_idEncuesta"]) echo ' selected="selected"'; echo ">".$row['Encuesta']."</option>";
				}
		 ?>
    </select></td>
     <td>&nbsp;</td>
   </tr>
   <tr>
     <td><label for="Costo">Costo adicional Q: </label></td>
     <td> <input type="text" name="Costo" id="Costo" value="<? print $Valores['Costo'];?>" size="50" maxlength="45" placeholder="Ingrese el costo adicional del evento." pattern="[0-9.]{1,6}" title="Ingrese solamente nùmeros"/></td>
     <td></td>
   </tr>
   <tr>
     <td> Imagen de la actividad tiene que ser tipo png:<input type="file"  name="fileToUpload" id="fileToUpload" onchange="onFileSelected(event)"></td>
     <td>
<?php $Imagen=$Valores["Imagen"];
                            if(empty($Imagen))
                            {
                                $Imagen="conferencia2.jpg";
                                $carpeta="../../imagenes/";
                            }
                            else
                           {
                             $carpeta="../../fotos/";
                            }
$direccion=$carpeta.$Imagen;
                            echo '<img height="100" src="'.$direccion.'"/>';?></td>
     <td> <span class="error"><?php echo $imagenError; ?></span></td>
   </tr>
<input type="hidden" name="ListaGrupoEvento" id="ListaGrupoEvento" value="<?php echo $_SESSION['idGrupoEvento'] ?>"/>
 </table>
<script>
	 function onFileSelected(event) 
	{
	  var selectedFile = event.target.files[0];
	  var reader = new FileReader();
	
	  var imgtag = document.getElementById("myimage");
	  imgtag.title = selectedFile.name;
	
	  reader.onload = function(event) {
		imgtag.src = event.target.result;
	  };
	
	  reader.readAsDataURL(selectedFile);
	}
</script>

<div align="center">
<input style="display:inline" type="submit" name="boton" id="boton" value="Guardar" />
           	<input style="display:inline" type="submit" name="boton" id="boton" value="Cancelar" />
</div>
</div>
</form>
<?php } ?>

<script language="javascript">
function cargar(numero,pagina)
{
if(numero=='+')
{
var win = window.open(pagina, '_blank'); 
win.focus();
}
}
function cargarlista()
   {
       var eTLista2=document.getElementById('NombreEncargado');
    document.getElementById('NombreEncargado').innerHTML = "";
                <?php  
            	$consulta1->Personal_ver_idgrupo($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
                  if($row['idPersonal']== $Valores["Personal_idPersonal_Encargado"])
                  {
                  ?>
				var eLOpcion2 = document.createElement("OPTION");
				 eLOpcion2.value= <?php echo $row["idPersonal"]; ?>;
                 eLOpcion2.text = "<?php echo $row["Nombre"]; ?>";
                 eTLista2.appendChild(eLOpcion2);
                 eLOpcion2.selected = "true";
                 <?php }
                 else
                 {?>
                     var eLOpcion2 = document.createElement("OPTION");
				 eLOpcion2.value= <?php echo $row["idPersonal"]; ?>;
                 eLOpcion2.text = "<?php echo $row["Nombre"]; ?>";
                 eTLista2.appendChild(eLOpcion2);
				<?php }			
				} ?>
            var eLOpcion3 = document.createElement("OPTION");
            eLOpcion3.value= "+";
            eLOpcion3.text = "Agregar Otro";
            eTLista2.appendChild(eLOpcion3);
   }
</script>
<!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Filtrando...</title>
<script src="../../../BLL/ajax.js" language="javascript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>

<body>
	<?php
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		$Consulta1=new Consulta;
        $filtro=$_GET['filtro'];
session_start();
        $idgrupoevento=$_SESSION['idGrupoEvento'];
       
//Consulta que se quiere ver en el dataGridView
           $Consulta1->Evento_ver_descripcion($filtro,$idgrupoevento);
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print 'No existen actividades creadas';  
            }
            else
            {
    			//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 1;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta1->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
						echo '<td>'.$metadatos->name.'</td>';
						$i++;
					}
					echo '<td>Opciones</td>';
    			print '</tr>';
                echo "\n";
//Datos del dataGridView
				$agregar=false;
                                $contador=1;
                while($row=mysql_fetch_assoc($Consulta1->Resultado))
                {
                    //donde se agregan los datos que se mostraran en cada columna
$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 1;
					while ($i < mysql_num_fields($Consulta1->Resultado))
                    {
    					$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
						//para agregar color a una fila
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistencia")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia".$contador type="checkbox" id="checkboxAsistencia".$contador '.$checkeado.' onclick="javascript: return false;" value="".$row["Participante_idParticipante"] />';
                           ++$contador;
						}
else if($metadatos->name=="Nombre")
				{
					?>
                    <span style="cursor:pointer;" onclick="abrirMPost('idRegistro='+<?php echo '\''.$row["idEvento"].'\'';?>+'&idGrupo='+<?php echo $idgrupoevento;?>,'Evento_detalle.php');"><?php echo $row[$metadatos->name]; ?></span>
                    <?php
				}
                        else if($metadatos->name=="Imagen")
                        {
                            $foto=$row["Imagen"];
                            if(empty($foto))
                            {
                                $foto="default";
                            }
                            echo '<img  height="100" src="uploads/'.$foto.'" />';
                        }
 else if($metadatos->name=="Descripción")
                        {
                            if($row[$metadatos->name].length>40)
                            {
                                 echo  substr($row[$metadatos->name],0,40)."...";
                            }
                            else
                            {
                                echo $row[$metadatos->name];
                            }
                        }
						else
                        {
							echo $row[$metadatos->name];
                        }
						echo "</td>\n";					
						++$i;
                	}
$pagDescripcion='\'Evento_participante_asistencia2.php\'';
					$pagEditar='\'Evento_editar.php\'';
                                         $pagAsignacion='\'Evento_ver_descripcion.php\'';
                                         $pagAsignar='\'asignaciones.php\'';
                                        $parametros='\'NombreEvento='.$row["Nombre Actividad"].'\'';
					echo '<td>';
			//Responder Encuesta
			echo	'<span style="cursor:pointer"; onclick="AbrirPagina('.$row["idEvento"].','.$pagDescripcion.');"><i class="icon icon-clipboard"></i>Asistencia</span ">
								<br>';
						//Editar
						
                                              /*  echo	'<span style="cursor:pointer"; onclick="AbrirPaginaPostConParametros('.$pagAsignar.','.$parametros.');"><i class="icon icon-file-text"></i>Asistencia</span>
								<br>';*/
                                              /*  echo	'<span style="cursor:pointer"; onclick="AbrirPagina('.$row["idEvento"].','.$pagAsignacion.');"><i class="icon icon-event"></i>Resumen</span>
								<br>';*/
						echo "</td>\n";		
			echo "\n";
			print '</tr>';
if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
				}
                print '</table>';
            }   
            	
				
				
				/*if (!$metadatos) {
					        echo "No hay información disponible<br />\n";
					    }
					    echo "<pre>
						blob:         $metadatos->blob
						max_length:   $metadatos->max_length
						multiple_key: $metadatos->multiple_key
						name:         $metadatos->name
						not_null:     $metadatos->not_null
						numeric:      $metadatos->numeric
						primary_key:  $metadatos->primary_key
						table:        $metadatos->table
						type:         $metadatos->type
						unique_key:   $metadatos->unique_key
						unsigned:     $metadatos->unsigned
						zerofill:     $metadatos->zerofill
						</pre>";*/	
?>
</body>
</html>	
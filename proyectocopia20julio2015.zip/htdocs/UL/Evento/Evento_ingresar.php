<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Ingresar actividad</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"de</script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>
<script src="../../BLL/modal.js" language="JavaScript"></script>

<link type="text/css" rel="stylesheet" href="../GRUPO_EVENTOS/DatePicker.css"/>
<script type="text/javascript" src="../GRUPO_EVENTOS/DatePicker.js"></script>
<script type="text/javascript">
function init() {
calendar.set("Fecha");
}
</script>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1" onload="init()">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Evento seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
<script type="text/javascript">
 $(document).ready(function () {
        yourFunction();
    });
function yourFunction()
    {
         $("#Costo").on("keyup", function()
         {
            var valid = /^\d{0,4}(\.\d{0,2})?$/.test(this.value),
                val = this.value;
            
            if(!valid)
            {
                this.value = val.substring(0, val.length - 1);
            }
        });
    }
</script>
<?php 
 $pagAsignar='\'asignaciones2.php\'';
 $nuevoeven='\'Evento_ingresar.php\'';
$fechaError=$errorLista=$imagenError="";
           $descripcion="";
        $conteo="";
        $consulta2=new Consulta;
        $diploma=$nombre=$tipoeve=$fecha=$horai=$horaf=$grupo=$encargado=$idencuesta=$costo=$descripcion="";
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
 if($_POST["boton"]=="Cancelar")
    	header('Location: Evento_ver.php');
	else if(isset($_POST["boton"])=="Guardar")
	{
        $descripcion=$_POST["Descripcion"];
         //INICIA codigo para guardar imagen en la carpeta
        $target_dir = "../../fotos/";
        $diploma=basename($_FILES["fileToUpload"]["name"]);
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        // verificar si la lo que se cargó es una imagen
        if(isset($_POST["fileToUpload"])) 
        {
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if($check !== false) 
            {
                echo "El archivo es una imagen - " . $check["mime"] . ". ";
                $uploadOk = 1;
            } else 
            {
                $imagenError=$imagenError." El archivo no es una imagen.";
                $uploadOk = 0;
            }
            
        // verificar si la imagen ya existe o no
        if (file_exists($target_file)) 
        {
           $imagenError= $imagenError." El archivo ya existe.";
            $uploadOk = 0;
        }
        // verificar el tamaño del archivo
        if ($_FILES["fileToUpload"]["size"] > 1000000) 
        {
            $imagenError= $imagenError." El archivo es muy pesado, escoge uno menos pesado";
            $uploadOk = 0;
        }
        // formato de archivos permitidos
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) 
        {
            $imagenError= $imagenError." Disculpe, solo se permiten archivos con extención JPG, JPEG, PNG y GIF ";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) 
        {
            $imagenError= $imagenError." Disculpe, no se pudo cargar su archivo.";
        // if everything is ok, try to upload file    
        }
                    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
                {
                    echo "    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
                } 
                else 
                {
                   $imagenError= $imagenError." Disculpe, se ha producido un herror al intentar subir su archivo";
                }
        }
//terminaimagen
            if(isset($_POST["Nombre"]))
                $nombre=$_POST["Nombre"];
            else
                echo '<br> No existe Nombre ';
            if(isset($_POST["listaeventos"]))
                $tipoeve=$_POST["listaeventos"];
            else
                echo '<br> No existe el Evento ';
            if(isset($_POST["Fecha"]))
                $fecha=$_POST["Fecha"];
            else
                echo '<br> No existe la Fecha ';
$hi=$_POST["Nombre_horainicio"];
$mini=$_POST["Nombre_mininicio"];
if($mini<10)
{
$horai=$hi."0".$mini."00";
}
else
{
                $horai=$hi.$mini."00";
}

$hf=$_POST["Nombre_horafinal"];
$minf=$_POST["Nombre_minfinal"];
if($minf<10)
{
$horaf=$hf."0".$minf."00";
}
else
{
                $horaf=$hf.$minf."00";
}
            if(isset($_POST["GrupoEvento"]))
                $grupo=$_POST["GrupoEvento"];
            else
                echo '<br> Error en el dato  ';
            if(isset($_POST["NombreEncargado"]))
                $encargado=$_POST["NombreEncargado"];
            else
                echo '<br> No existe Nombre  de Encargado';
            if(isset($_POST["Encuesta"]))
                $idencuesta=$_POST["Encuesta"];
            else
                $idencuesta=0;
            if(isset($_POST["Costo"]))
                $costo=$_POST["Costo"];
            else
                $costo=0;
        $consulta1->Evento_verificar($grupo,$nombre);
        $row = mysql_fetch_assoc($consulta1->Resultado);
$consulta1->GrupoEvento_ver_rangofecha($grupo,$fecha);
        $fecharango= mysql_num_rows($consulta1->Resultado);
        if($row["Conteo"]==0&& $fecharango>0)
        { 
                $parametros='\'idRegistro='.$nombre.'\'';
                $consulta2->Evento_insertar($nombre,$tipoeve,$fecha,$horai,$horaf,$grupo,$encargado,$idencuesta,$costo,$descripcion,$diploma);
                //echo    '<meta http-equiv="Refresh" content="3;url=http://citein.hostingla.in/UL/Evento/Evento_ingresar.php">';
                //echo    '<span style="cursor:pointer"; onclick="AbrirPaginaPostConParametros('.$pagAsignaredu.','.$parametros.');">Continuar</span ">';
                $conteo++;
        }
        else if($fecharango==0)
        {
$fechaError="No se puede ingresar la fecha puede que no coincida con el evento que se esta administrando";
$errorList="Revise su selección.";
        }
else
{
echo "Ya existe una actividad similar en este evento pruebe otra vez";
}
        }
}
        
?>
 <div class="ventana">
            <div id="modal"></div>
        </div>
<H2 align="center">Ingresar actividad</H2><H4 align="left">Paso 1/2</H4>
 <form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
  <?php if($conteo>0)
 {
$conteo=0;
echo '<h3 align="center">La actividad se a creado con éxito, presione continuar para realizar las asignaciones correspondientes.</h3>';
     echo '<input type="button" name="Asignar" id="Asignar" value="Continuar" onclick="AbrirPaginaPostConParametros('.$pagAsignar.','.$parametros.');" /> </br>';
 }
 else{
 ?>
<div class="tablas" align="center">
 <table width="650" border="0" cellspacing="5" align="center">
<tr>
<td><span class="error">* Campos requeridos.</span></td>
<td></td>
<td></td>
</tr>
   <tr>
     <td><label for="Nombre">Nombre de la actividad:</label></td>
     <td><input type="text" name="Nombre" id="Nombre" value="<?php echo $nombre;?>" size="50" maxlength="45" placeholder="Ingrese el nombre de la actividad." pattern="[A-Za-zÑñ{ÁÉÍÓÚáéíóú 0-9]{1,45}" required title="Se necesita un nombre de la actividad(solamente letras y números)"/></td>
     <td><span class="error">* </span></td>
   </tr>
   <tr>
     <td><label for="Descripcion">Descripción:</label></td>
     <td><textarea name="Descripcion" id="Descripcion" cols="45" rows="5" value=""><?php echo $descripcion;?></textarea></td>
     <td>&nbsp;</td>
   </tr>
   <tr>
     <td> <label for="listaeventos">Tipo de actividad:</label></td>
     <td><div id="lista_eventos">
<select name="listaeventos" id="listaeventos"  onchange="openVentana('listaeventos','../Modal/TipoEvento_modal.php','idDiv=lista_eventos');">
 <?php
				$consulta1->TipoEvento_ver_lista($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option value=".$row['id']; if($listaeve==$row['id']) echo 'selected="selected"'; echo">".$row['nombre']."</option>";
				}
echo '<option value="+">Agregar otro</option>';
		 ?>
  </select>
</div></td>
     <td><span class="error">* <?php echo $errorLista; ?> </span></td>
   </tr>
<tr>
<td></td>
<td><label for="Fecha">Fechas del Evento: Inicia <?php echo $_SESSION['FechaInicio']?> Termina: <?php echo $_SESSION['FechaFinal']?><br></td>
<td></td>
</tr>
   <tr>
     <td>
     Fecha:</label></td>
     <td><input type="text" name="Fecha" id="Fecha" value="<?php echo $fecha?>" readonly="readonly" required/>
 <?php //<img src="images2/cal.gif" onclick="javascript:NewCssCal('Fecha','yyyyMMdd')" style="cursor:pointer"/> ?>
</td>
     <td><span class="error">* <?php echo $fechaError; ?> </span></td>
   </tr>
   <tr>
     <td> <label for="HoraInicio">Hora de inicio:</label></td>
     <td><input type="hidden" name="HoraInicio" id="HoraInicio" value="<?php echo $horai?>" readonly="readonly" size="10"/> 
<select name="Nombre_horainicio" id="Nombre_horainicio" selectedvalue=>
        		    <option value="0">Hora</option>
        		    <?php  for($i=0;$i<=23;$i++) { echo "<option value='".$i."'>".$i."</option>"; } ?>
      		    </select>
				Hora
				<select name="Nombre_mininicio" id="Nombre_mininicio" selectedvalue=>
 			 	<option value="0">Min</option>
  				<?php  for($i=00;$i<=59;$i++) { echo "<option value='".$i."'>".$i."</option>"; } ?>
				</select>
				Min</td>
     <td></td>
   </tr>
   <tr>
     <td><label for="HoraFinal">Hora de finalizaciòn:</label></td>
     <td><input type="hidden" name="HoraFinal" id="HoraFinal" value="<?php echo $horaf?>" readonly="readonly" size="10"/>
 <select name="Nombre_horafinal" id="Nombre_horafinal" selectedvalue=>
        		    <option value="0">Hora</option>
        		    <?php  for($i=0;$i<=23;$i++) { echo "<option value='".$i."'>".$i."</option>"; } ?>
      		    </select>
				Hora
				<select name="Nombre_minfinal" id="Nombre_minfinal" selectedvalue=>
  				<option value="0">Min</option>
  				<?php  for($i=00;$i<=59;$i++) { echo "<option value='".$i."'>".$i."</option>"; } ?>
				</select>
				Min</td>
     <td>&nbsp;</td>
   </tr>
   <tr>
     <td><label for="NombreEncargado">Encargado:</label></td>
     <td><div id="lista_encargado"><select name="NombreEncargado" id="NombreEncargado" onchange="openAc('NombreEncargado','../Modal/Personal_modal.php','idDiv=lista_encargado'),cargar(this.value,'Personal_ingresar.php'),openVentana('NombreEncargado','../Modal/Personal_modal.php','idDiv=lista_encargado');" onFocus='cargar()'>
  <?php
echo '<option value="-">Seleccione un encargado</option>';
    			$consulta1->Personal_ver_idgrupo($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['idPersonal'].">".$row['Nombre']."</option>";
				}
		 ?>
echo '<option value="+">Agregar otro</option>';
  </select></div></td>
     <td><span class="error">* <?php echo $errorLista; ?></td>
   </tr>
   <tr>
     <td><label for="Encuesta">Titulo de la encuesta:</label></td>
     <td><select name="Encuesta" id="Encuesta">
  <?php
echo '<option value="0">Sin Encuesta</option>';
    			$consulta1->Encuesta_ver();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['idEncuesta'].">".$row['Encuesta']."</option>";
				}
		 ?>
    </select></td>
     <td><span class="error">* <?php echo $errorLista; ?> </td>
   </tr>
   <tr>
     <td><label for="Costo">Costo adicional Q: </label></td>
     <td> <input type="text" name="Costo" id="Costo" value="<?php echo $costo?>" size="50" maxlength="45" placeholder="Ingrese el costo adicional del evento." pattern="[0-9.]{1,6}" title="Ingrese solamente nùmeros"/></td>
     <td><span class="error">* </span></td>
   </tr>
   <tr>
     <td>Ingrese una imagen png:<input type="file"  name="fileToUpload" id="fileToUpload" onchange="onFileSelected(event)"></td>
     <td> <img  height="100" id="myimage" src=""></td>
     <td><span class="error">* <?php echo $imagenError; ?> </span></td>
   </tr>
 </table>
</div>
 <input type="hidden" name="formulario" value="Insertar Evento" />

<input type="hidden" name="ListaGrupoEvento" value="<? print $_SESSION['idGrupoEvento'];?>" />
 <input type="hidden" name="GrupoEvento" id="GrupoEvento" readonly="readonly" value="<? print $_SESSION['idGrupoEvento'];?>"/>

<script>
	 function onFileSelected(event) 
	{
	  var selectedFile = event.target.files[0];
	  var reader = new FileReader();
	
	  var imgtag = document.getElementById("myimage");
	  imgtag.title = selectedFile.name;
	
	  reader.onload = function(event) {
		imgtag.src = event.target.result;
	  };
	
	  reader.readAsDataURL(selectedFile);
	}
</script>
<script language="javascript">
function cargar(numero,pagina)
{
if(numero=='+')
{
var win = window.open(pagina, '_blank'); 
win.focus();
}
}
function cargarlista()
   {
       var eTLista2=document.getElementById('NombreEncargado');
    document.getElementById('NombreEncargado').innerHTML = "";
var eLOpcion3 = document.createElement("OPTION");
 eLOpcion3.value= "-";
 alert('hecho');
            eLOpcion3.text = "Seleccione un encargado";
            eTLista2.appendChild(eLOpcion3);
                <?php  
            	$consulta1->Personal_ver_idgrupo($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {?>
				var eLOpcion2 = document.createElement("OPTION");
				 eLOpcion2.value= <?php echo $row["idPersonal"]; ?>;
                 eLOpcion2.text = "<?php echo $row["Nombre"]; ?>";
                 eTLista2.appendChild(eLOpcion2);
				<?php } ?>
            var eLOpcion3 = document.createElement("OPTION");
            eLOpcion3.value= "+";
            eLOpcion3.text = "Agregar otro";
            eTLista2.appendChild(eLOpcion3);
   }
</script>
<div align="center">
    <input style="display:inline" type="submit" name="boton" id="boton" value="Continuar" />
   <a href="Evento_ver.php" target="_self"><input type="button" name="boton" id="boton" value="Cancelar" onclick=""/>
</div>
     <?php
 } ?>

</form>

	  <!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>	
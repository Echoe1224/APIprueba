<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Asignacion de participantes</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<link rel="stylesheet" href="../CITEIN/estilo2.css" >
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar un evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
<span style="cursor:pointer"; onclick="re();"><i class="icon icon-undo2"></i> Atrás</span>
         <?php 
if(isset($_POST["idRegistro"]))
        {
			$idEvento=$_POST['idRegistro'];
        }
?>
  

 <form id="form1" name="form1" method="post" action="">

        <div class="ventana">
            <div id="modal"></div>
        </div>
 <div>
          		</div>
         	<input type="hidden" name="formulario" id="formulario" value="descripciones" />
 <input type="hidden" name="paginaFiltro" id="paginaFiltro" value="Evento_asignar_participante.php" />
            <input type="hidden" name="paginaEliminar" id="paginaEliminar" value="..\..\BLL\eliminar.php" />
        	<div>
            
               <input type="hidden" name="grupoevento" id="grupoevento" value="<? print $_SESSION['idGrupoEvento'];?>" />
<input type="hidden" name="texto_filtro" id="texto_filtro" value="<? print $idEvento;?>" />
            </div>
            <br/>
<div id="resultados">
<h4>'Asignación de Educadores'</h4>
    	<script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    EventoFiltro();
                });
         </script>
            <div class="dataGridViewDiv" id="Educador"></div>
</div>

 <script language="javascript">

		function AsignarParticipante(idpar,eve,lugar)
		{
			ProcesarPaginaPostConParametros("Evento_asignar_participante.php","idParticipante="+idpar+"&idEvento="+eve+"&lugar="+lugar+"&ver=0","resultados");
		}
function cargar(eve,lugar)
		{
			ProcesarPaginaPostConParametros("Evento_asignar_participante.php","idEvento="+eve+"&lugar="+lugar+"&ver=1","resultados");
		}

		</script>

          </form>
<form style="float:left; display:none;" id="form7" name="form7" method="post" action="Evento_participante_asistencia.php">
          <input type="hidden" name="idRegistro" id="idRegistro" value="<?php echo $idEvento ?>" />
          <input type="submit" name="regresar" id="regresar" value="Editar participantes" />
           <script language="javascript">
           function re()
           {
            var boton=document.getElementById('regresar');
            boton.click();
           }
           </script>
        </form>

<!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
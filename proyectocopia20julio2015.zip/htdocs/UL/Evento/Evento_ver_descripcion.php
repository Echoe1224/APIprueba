﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Descripción</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<link rel="stylesheet" href="../CITEIN/estilo2.css" >
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
<a style="padding-left:50px; color:#333; text-decoration:none" href="Evento_ver.php"><i class="icon icon-undo2"></i> Atrás</a>
<?php
        if(isset($_POST['idRegistro']))
        {
			$idEvento=$_POST['idRegistro'];
        }
		else
        {
			$idEvento=0;
        }
 $Consulta1=new Consulta;
 $Consulta1->Evento_ver_datos($idEvento);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado); 
 $Consulta1->Evento_ver_datos($idEvento);
$comp=mysql_num_rows($Consulta1->Resultado);
if($comp>0)
{  
 $Consulta1->Evento_ver_datos($idEvento);
       $Nombreevento=mysql_fetch_assoc($Consulta1->Resultado);        
}
else
{
 $Consulta1->Evento_ver_datos2($idEvento);
       $Nombreevento=mysql_fetch_assoc($Consulta1->Resultado);        
}
?>

<h2 align="center">Resumen de actividad: <? print $Nombreevento['Nombre'];?></h2>
<input type="hidden" name="idEvento" value="<? print $idEvento;?>" />
  <tr>
<div class="dataGridViewDiv" id="descripciones">
<div>
<h3>Educador asignado:</h3>
<br>
    <?php
		$Consulta3=new Consulta;

           $Consulta3->Evento_ver_educador($idEvento);
           if(mysql_num_rows($Consulta3->Resultado)==0)
            {
              print 'No hay educadores asignados';  
            }
            else
            {
					//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 1;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta3->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						echo '<td>'.$metadatos->name.'</td>';
						$i++;
					}
    			print '</tr>';
                echo "\n";
//Datos del dataGridView
				$agregar=false;
                                $contador=1;
                while($row=mysql_fetch_assoc($Consulta3->Resultado))
                {
                    //donde se agregan los datos que se mostraran en cada columna
                 	$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 1;
					while ($i < mysql_num_fields($Consulta3->Resultado))
                    {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						//para agregar color a una fila
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistencia")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia".$contador type="checkbox" id="checkboxAsistencia".$contador '.$checkeado.' onclick="javascript: return false;" value="".$row["Participante_idParticipante"] />';
                           ++$contador;
						}
                        else if($metadatos->name=="Imagen")
                        {
                            $foto=$row["Imagen"];
                            if(empty($foto))
                            {
                                $foto="default";
                            }
                            echo '<img  height="100" src="uploads/'.$foto.'" />';
                        }
						else
                        {
							echo $row[$metadatos->name];
                        }
						echo "</td>\n";					
						++$i;
                	}
if($agregar)
				$agregar=false;
			else
				$agregar=true;
				}
                print '</table>';
            }

?>
</div>
</br>
<div>
<h3>Lugares asignados:</h3>
<br>
<?php
$Consulta3->Evento_ver_Lugar($idEvento);
           if(mysql_num_rows($Consulta3->Resultado)==0)
            {
              print 'No hay lugares asignados';  
            }
            else
            {
							//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 1;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta3->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						echo '<td>'.$metadatos->name.'</td>';
						$i++;
					}
    			print '</tr>';
                echo "\n";
//Datos del dataGridView
				$agregar=false;
                                $contador=1;
                while($row=mysql_fetch_assoc($Consulta3->Resultado))
                {
                    //donde se agregan los datos que se mostraran en cada columna
                 	$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 1;
					while ($i < mysql_num_fields($Consulta3->Resultado))
                    {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						//para agregar color a una fila
						$clase="filaTablaSinFondo";
						if($agregar)
							$clase="filaTablaConFondo";
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistencia")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia".$contador type="checkbox" id="checkboxAsistencia".$contador '.$checkeado.' onclick="javascript: return false;" value="".$row["Participante_idParticipante"] />';
                           ++$contador;
						}
                        else if($metadatos->name=="Imagen")
                        {
                            $foto=$row["Imagen"];
                            if(empty($foto))
                            {
                                $foto="default";
                            }
                            echo '<img  height="100" src="uploads/'.$foto.'" />';
                        }
						else
                        {
							echo $row[$metadatos->name];
                        }
						echo "</td>\n";					
						++$i;
                	}
if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
				}
                print '</table>';
            }
?>
</div>
</br>
<div>
<h3>Personal asignado:</h3>
<br>
<?php
$Consulta3->Evento_ver_Personal($idEvento);
           if(mysql_num_rows($Consulta3->Resultado)==0)
            {
              print 'No existe Personal asignado';  
            }
            else
            {
				//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 1;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta3->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						echo '<td>'.$metadatos->name.'</td>';
						$i++;
					}
    			print '</tr>';
				echo "\n";
//Datos del dataGridView
				$agregar=false;
                while($row=mysql_fetch_assoc($Consulta3->Resultado))
                {
                    //donde se agregan los datos que se mostraran en cada columna
                 	$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 1;
					while ($i < mysql_num_fields($Consulta3->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						//para agregar color a una fila
						$clase="filaTablaSinFondo";
						if($agregar)
							$clase="filaTablaConFondo";
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistido" || $metadatos->name=="Encuestado")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia2" type="checkbox" id="checkboxAsistencia2" '.$checkeado.' onclick="javascript: return false;" />';
						}
 else if($metadatos->name=="Foto")
                        {
                            $foto=$row["Foto"];
                            if(empty($foto))
                            {
                                $foto="default";
                            }
                            echo '<img  height="100" src="../../fotos/'.$foto.'.jpg" />';
                        }
						else
							echo $row[$metadatos->name];
						echo "</td>\n";						
						++$i;
                	}
if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
				}
                print '</table>';
            }
 ?>
</div>
</br>
<div>
<h3>Semestres asignados:</h3>
<br>
<?php           
$Consulta3->Evento_ver_Semestre($idEvento);
           if(mysql_num_rows($Consulta3->Resultado)==0)
            {
              print 'Se permiten a todos los semestres en la actividad';     
            }
            else
            {
				//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 1;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta3->Resultado)) {
    			$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
				echo '<td>'.$metadatos->name.'</td>';
				$i++;
			}
		print '</tr>';
		echo "\n";
//Datos del dataGridView
				$agregar=false;
                while($row=mysql_fetch_assoc($Consulta3->Resultado))
                {
                    //donde se agregan los datos que se mostraran en cada columna
                 	$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 1;
					while ($i < mysql_num_fields($Consulta3->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						//para agregar color a una fila
						$clase="filaTablaSinFondo";
						if($agregar)
							$clase="filaTablaConFondo";
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistido" || $metadatos->name=="Encuestado")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia2" type="checkbox" id="checkboxAsistencia2" '.$checkeado.' onclick="javascript: return false;" />';
						}
						else
							echo $row[$metadatos->name];
						echo "</td>\n";						
						++$i;
                	}
if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
				}
                print '</table>';
            }

?>
</div>
</br>
<div>
<h3>Jornadas asignadas:</h3>
<br>
<?php      
$Consulta3->Evento_ver_Jornada($idEvento);
           if(mysql_num_rows($Consulta3->Resultado)==0)
            {
              print 'Se permiten a todas las jornadas en la actividad';     
            }
            else
            {
				//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 1;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta3->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						echo '<td>'.$metadatos->name.'</td>';
						$i++;
					}
    			print '</tr>';
				echo "\n";
//Datos del dataGridView
				$agregar=false;
                while($row=mysql_fetch_assoc($Consulta3->Resultado))
                {
                    //donde se agregan los datos que se mostraran en cada columna
                 	$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 1;
					while ($i < mysql_num_fields($Consulta3->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						//para agregar color a una fila
						$clase="filaTablaSinFondo";
						if($agregar)
							$clase="filaTablaConFondo";
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistido" || $metadatos->name=="Encuestado")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia2" type="checkbox" id="checkboxAsistencia2" '.$checkeado.' onclick="javascript: return false;" />';
						}
						else
							echo $row[$metadatos->name];
						echo "</td>\n";						
						++$i;
                	}
if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
				}
                print '</table>';
            }
?>
</div>
</br>
<div>
<h3>Secciones asignadas:</h3>
<br>
<?php      
$Consulta3->Evento_ver_Seccion($idEvento);
           if(mysql_num_rows($Consulta3->Resultado)==0)
            {
              print 'Se permiten a todas las secciones en la actividad';    
            }
            else
            {
				//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 1;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta3->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						echo '<td>'.$metadatos->name.'</td>';
						$i++;
					}
    			print '</tr>';
				echo "\n";
//Datos del dataGridView
				$agregar=false;
                while($row=mysql_fetch_assoc($Consulta3->Resultado))
                {
                    //donde se agregan los datos que se mostraran en cada columna
                 	$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 1;
					while ($i < mysql_num_fields($Consulta3->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						//para agregar color a una fila
						$clase="filaTablaSinFondo";
						if($agregar)
							$clase="filaTablaConFondo";
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistido" || $metadatos->name=="Encuestado")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia2" type="checkbox" id="checkboxAsistencia2" '.$checkeado.' onclick="javascript: return false;" />';
						}
						else
							echo $row[$metadatos->name];
						echo "</td>\n";						
						++$i;
                	}
if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
				}
                print '</table>';
            }
?>
</div>
          		</div>
    	<script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    Filtrar();
                });
         </script>

<div>
</br>
<h3>Participantes asignados:</h3>
<br>
<?php      
$Consulta3->Evento_ver_Participante($idEvento);
           if(mysql_num_rows($Consulta3->Resultado)==0)
            {
              print 'No hay participantes asignados';  
            }
            else
            {
    			//Se agrega el codigo del ancabezado de la tabla
                print'<table class = "tabla">';
				echo "\n";
        		echo '<tr class="dgv-titulo">';
				//$i:desde que columna se empieza a graficar
				$i = 2;
//Encabezado del dataGridView
				while ($i < mysql_num_fields($Consulta3->Resultado)) {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						echo '<td>'.$metadatos->name.'</td>';
						$i++;
					}
    			print '</tr>';
                echo "\n";
//Datos del dataGridView
				$agregar=false;
                                $contador=1;
                while($row=mysql_fetch_assoc($Consulta3->Resultado))
                {
                    //donde se agregan los datos que se mostraran en cada columna
                 	$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
					echo "\n";
					//$i:desde que columna se empieza a graficar
					$i = 2;
					while ($i < mysql_num_fields($Consulta3->Resultado))
                    {
    					$metadatos = mysql_fetch_field($Consulta3->Resultado, $i);
						//para agregar color a una fila
						$clase="filaTablaSinFondo";
						if($agregar)
							$clase="filaTablaConFondo";
						echo '<td>';
					//Columnas que son de tipo booleano.						
						if($metadatos->name=="Asistencia")
						{
						   $checkeado="";
						   if($row[$metadatos->name]!=0)
							$checkeado= "checked=\"checked\"";
						   echo '<input name="checkboxAsistencia".$contador type="checkbox" id="checkboxAsistencia".$contador '.$checkeado.' onclick="javascript: return false;" value="".$row["Participante_idParticipante"] />';
                           ++$contador;
						}
                        else if($metadatos->name=="Foto")
                        {
                            $foto=$row["Foto"];
                            if(empty($foto))
                            {
                                $foto="default";
                            }
                            echo '<img  height="100" src="../../fotos/'.$foto.'.jpg" />';
                        }
						else
                        {
							echo $row[$metadatos->name];
                        }
						echo "</td>\n";					
						++$i;
                	}
			
if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
				}
                print '</table>';
            }  
    
?>
</tr>
<br></br>
<tr>
<form style="float:left;" id="formActividad" name="formActividad" method="post" action="asignaciones2.php">
          <input type="hidden" name="idRegistro" id="idRegistro" value="<?php echo $Nombreevento["Nombre"]; ?>" />
          <input type="submit" name="boton_actividades" id="boton_actividades" value="Editar asignaciones" />
        </form>
</tr>
</div>
<script language="javascript">

		function Asistencia(idParticipante,eve)
		{
			ProcesarPaginaPostConParametros("Evento_Asistencia.php","idParticipante="+idParticipante+"&idEvento="+eve,"resultados");
		}
</script>
</table>
<br></br>
		<!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
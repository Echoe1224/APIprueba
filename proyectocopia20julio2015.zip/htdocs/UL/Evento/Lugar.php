<?php
	$consulta1=new Consulta;
// define variables and set to empty values
$erroridlugar = $errornombre = $errorcapacidad = "";
$idlugar = $nombre = $capacidad = "";
$cont=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["texto_idlugar"])) {
	   	$erroridlugar = "El Identificador del lugar es requerido.";
               $idlugar="";
		//++$cont;
	}
	else {
	       $idlugar= test_input($_POST["texto_idlugar"]);
	    // check if name only contains letters and whitespace
		if (!preg_match("/^[0-9]*$/",$idlugar)) {
    		$erroridlugar = "Ingrese solamente letras y/o números sin espacios.";
			}
		else{
			++$cont;
		}
	}
	if(empty($_POST["texto_nombre"])){
   		$nombre="";
		++$cont;
	}
	else{
	   $nombre = test_input($_POST["texto_nombre"]);
	   if (!preg_match("/^[0-9-a-zA-Z]*$/",$nombre)) {
    	 	$errornombre='Ingrese número o letras.';
		 }
		else{
			++$cont;
		}
	}
	if(empty($_POST["texto_capacidad"])){
   		$capacidad="";
		//++$cont;
	}
	else{
	   $capacidad = test_input($_POST["texto_capacidad"]);
	   if (!preg_match("/^[0-9]*$/",$capacidad)) {
    	 	$errorcapacidad='Ingrese solo números.';
		 }
    else{
		$cont++;
	}
	}
	if($cont==3)
	{
		$consulta1->RegistroLugares_insertar($idlugar, $nombre, $capacidad, '1');
        $idlugar=$nombre=$capacidad=" ";
        $url="http://citein.hostingla.in/UL/opciones.php"; 
        echo "<SCRIPT>window.location='$url';</SCRIPT>"; 
	}
}

function test_input($data) {
   $data = trim($data); 	
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Lista Educadorer</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>

<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    abrir();
                });
         </script>

		<form name="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">            
       	  <table width="800" height="183" border="0" align="center" style="background:#333333">
        		<td width="358" valign="top" nowrap="nowrap">
<!--  *********************************************************Formulario**************************************************** -->                
                <p><span class="error">* Campos requeridos.</span></p>
                <p>
                  <label for="texto_idlugar">Id Lugar: </label>
                  <input name="texto_idlugar" type="text" id="texto_idlugar" value="<?php echo $id;?>" size="50" maxlength="45">
                   <span class="error">* <?php echo $erroridlugar;?></span> <br/>
                </p>
        		<p>
		        <label for="texto_nombre">Nombre: </label>
        		         <input name="texto_nombre" type="text" id="texto_nombre" value="<?php echo $nombre;?>" size="50" maxlength="9">
                  <span class="error">* <?php echo $errornombre;?></span> </p>
        		<p>
        		  <label for="texto_capacidad">Capacidad;   </label> 
                  <input name="texto_capacidad" type="text" id="texto_capacidad" value="<?php echo $capacidad;?>" size="50" maxlength="9">
                  <span class="error">* <?php echo $errorcapacidad;?></span><br/>
        		</p>
        		<p>&nbsp;</p>
        		<div id="boton_guardar">
                <input type="submit" name="boton_guardar" id="boton_guardar" value="Guardar"> 
                <input type="button" name="boton_cancelar" id="boton_cancelar" value="Cancelar" onClick="almacenar_captura()">
                </div>
                </td>
                <td width="190" align="center" valign="top">
      		</td>
      </table>
</form>

<script>
    	  function abrir()
		  {
			  Filtrar3("grupo=<?php echo $_SESSION['idGrupoEvento'] ?>");
		  }
		  </script>
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
</body>
</html>
	
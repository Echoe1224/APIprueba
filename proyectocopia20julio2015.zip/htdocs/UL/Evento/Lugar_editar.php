<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Editar Lugar</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>
 <?php  
 $hecho=0;
$errornombre="";
  if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
if($_POST["boton"]=="Cancelar")
        header('Location: Lugar_ver.php');
	else if(isset($_POST["boton"])=="Guardar")
	{
            if($_POST["boton"]=="Cancelar")
        header('Location: Lugar_ver.php');
    else if(isset($_POST["boton"])=="Guardar")
    {
 if(isset($_POST["idRegistro"]))
                $idLugar=$_POST["idRegistro"];
            else
                echo '<br> No existe el lugar';
            if(isset($_POST["Nombre"]))
                $nombre=$_POST["Nombre"];
            else
                echo '<br> No existe el Nombre ';
            if(isset($_POST["Capacidad"]))
                $capacidad=$_POST["Capacidad"];
            else
                echo '<br> No existe el dato ';
            if(isset($_POST["Disponible2"]))
                $disponible=$_POST["Disponible2"];
            else
                echo '<br> No existe el dato ';
  $consulta1->Lugar_verificar_editar($nombre,$idLugar);
        $veri = $consulta1->Resultado;
        if(mysql_num_rows($veri)==0)
        {                         
        $consulta1->Lugar_actualizar($idLugar,$nombre,$capacidad,$disponible); 
        $hecho=1;
   }
else
{
$errornombre="Ya existe un lugar con el mismo nombre";
}

    }
}
        }
?>   
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->

        <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    abrir();
                });
         </script>

<?php
        
        $Consulta1=new Consulta;
        if(isset($_POST["idRegistro"]))
        {
			$idLugar=$_POST['idRegistro'];
        }
		else
        {
			$idLugar=0;
        }
        $Consulta1->Lugar_ver_datos($idLugar);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
?>
<?php
     if($hecho==1)
     {
		?>
        <h2 align="center"><i class="icon icon-check"></i>Lugar actualizado.</h2>
        <div style="display:none">
        <form id="forma" name="forma" method="post" action="Lugar_ver.php">
          
          <input type="submit" name="boton_pag" id="boton_pag" value="" />
        </form>
        </div>
        <script>
			setTimeout("document.getElementById('boton_pag').click();",1000);
		</script>
        <?php
	 }
	else
{
    ?>

    <div class="tablas" align="center">
<H2 align="center">Editar lugar</H2>
<form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"
<input type="hidden" name="idRegistro" value="<? print $idLugar;?>" />
  <p>
  <table width="600" border="0">
  <tr>
    <td><label for="Nombre">Nombre:</label></td>
    <td><input type="text" name="Nombre" id="Nombre" value="<? print $Valores['Nombre'];?>" size="50" maxlength="50" placeholder="Ingrese el nombre del Lugar" pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ- ]{1,45}" required title="Se necesita un nombre del Lugar"/>
<td><span class="error"> <?php echo $errornombre;?></span></td>
  <br />
</td>
  </tr>
  <tr>
    <td><label for="Capacidad">Capacidad:</label></td>
    <td><input type="text" name="Capacidad" id="Capacidad" value="<? print $Valores['Capacidad'];?>" 
    size="20" maxlength="10" placeholder="Ingrese la capacidad del lugar" pattern="[0-9]{1,45}" required title="Se necesita la capacidad del Lugar(solo números)"
    /></td>
  </tr>
  <tr>
    <td><br /> Estado:</td>
    <td>    <input type="radio" name="Disponible2" <?php if (isset($Valores['Disponible']) && $Valores['Disponible']==1) echo "checked";?> value="1" id="Disponible2">Disponible
    <input type="radio" name="Disponible2" <?php if (isset($Valores['Disponible']) && $Valores['Disponible']==0) echo "checked";?> value="0" id="Disponible2">No disponible
    <br /></td>
  </tr>
  
</table>

  <input type="hidden" name="formulario" value="Actualizar Lugar" />
    <input type="hidden" name="idRegistro" value="<? print $idLugar;?>" />
    
  </p>
  <p>
    <input style="display:inline" type="submit" name="boton" id="boton" value="Guardar" />
               <a href="Lugar_ver.php" target="_self"><input  type="button" name="boton" id="boton" value="Cancelar" onclick=""/>
               </div>
</form>
<?php } ?>
 <script>
		  function abrir()
		  {
			  Filtrar3("grupo=<?php echo $_SESSION['idGrupoEvento'] ?>");
		  }
		  </script>
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
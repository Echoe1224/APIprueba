<?php
	    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";  
        include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";  
		
		$consulta=new Consulta;
        $consulta2=new Consulta;
         if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
			if (!empty($_POST["idRegistro"]))
			{
				$id=$_POST['idRegistro'];
			}
		}
  $consulta2->Lugar_verificarcantidad($idRegistro);
        $res=$consulta2->Resultado;
if(mysql_num_rows($res)==0)
{
   $consulta->Lugar_eliminar($id); 
                $mensaje="Lugar eliminado";
         //       $consulta1->Lugar_eliminar($idRegistro);
}
else
{
$mensaje="No se puede eliminar porque el lugar esta asignado a un evento";
}
	/*	if ($_SERVER["REQUEST_METHOD"] == "POST") 
		{
			if (!empty($_POST["idRegistro"]))
			{
				$id=$_POST['idRegistro'];
				$consulta->Lugar_eliminar($id); 
			}
		}*/
?>

   <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
      <div style="text-align:center">
      <label>¿Está seguro de eliminar el reguistro?</label><br />
      <input type="submit" value="Elimar" />
      </div>
   </form>
   <form action="Lugar_ver.php">
      <div style="text-align:center">
      <input type="submit" value="Cancelar" />
      </div>
   </form>
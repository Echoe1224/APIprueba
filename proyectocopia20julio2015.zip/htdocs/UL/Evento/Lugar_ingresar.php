<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Ingresar nuevo lugar</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>

<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    abrir();
                });
         </script>
<?php
        $Consulta1=new Consulta;
        $Consulta2=new Consulta;  
$errornombre=$hecho="";
 if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
 if($_POST["boton"]=="Cancelar")
    	header('Location: Lugar_ver.php');
	else if(isset($_POST["boton"])=="Guardar")
	{
if(isset($_POST["texto_nombre"]))
 {
                $nombre=$_POST["texto_nombre"];
 }
            else
            {
                echo '<br> No Existe nombre';
            }
 if(isset($_POST["texto_capacidad"]))
 {
                $capacidad=$_POST["texto_capacidad"];
 }
            else
            {
                echo '<br> No Existe nombre';
            }
 $consulta1->Lugar_verificar($nombre);
        $veri = $consulta1->Resultado;
        if(mysql_num_rows($veri)==0)
        {          
$consulta1->RegistroLugares_insertar($nombre, $capacidad, '1');  
$nombre="";
$capacidad="";
$hecho="Lugar ingresado con éxito.";
      }
else
{
$errornombre="* Ya existe un lugar con el mismo nombre";
}
}
}
?>

<H2 align="center">Ingresar lugar</H2>
</br>
<h3 align="center" style="color:#093"><?php echo $hecho;?></h3>
<form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
<div class="tablas" align="center">
<input type="hidden" name="formulario" value="Ingresar Lugar" />
                <table width="600" border="0">
<tr>
<td><span class="error"></span></td>
</tr>
<tr>
<td>		        <label for="texto_nombre">Nombre: </label></td>
<td>     		         <input name="texto_nombre" type="text" id="texto_nombre" value="<?php echo $nombre;?>" size="50" maxlength="45" placeholder="Ingrese el nombre del lugar." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ0-9 -]{1,45}" required title="Se necesita un nombre del lugar (letras y números)"></td>
                  <td><span class="error">*<?php echo $errornombre;?></span> </td>
</tr>
<tr>        		
        		  <td><label for="texto_capacidad">Capacidad:</label> </td>
<td>            <input name="texto_capacidad" type="text" id="texto_capacidad" value="<?php echo $capacidad;?>"size="50" maxlength="5" placeholder="Ingrese el capacidad del lugar." pattern="[0-9]{1,45}" required title="Se necesita una cantidad(solamente números)"></td>
                  <td><span class="error"> <?php echo $errorcapacidad;?></span><br/></td>
</tr>
</table>
<div align="center">
<br/>
    <input style="display:inline" type="submit" name="boton" id="boton" value="Guardar" />
           	<a href="Lugar_ver.php" target="_self"><input  type="button" name="boton" id="boton" value="Cancelar" onclick=""/>
</div>
</div>
</form>

         <script>
    	  function abrir()
		  {
			  Filtrar3("grupo=<?php echo $_SESSION['idGrupoEvento'] ?>");
		  }
		  </script>
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Detalles del personal</title>
<?php
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
?>
</head>


<body>


<div align="right"><span style="cursor:pointer;" onclick="cerrarM();" title="Cerrar">X</span></div>

        <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    abrir();
                });
         </script>

    	<script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    EventoFiltro();
                });
         </script>


<?php  
        $Consulta1=new Consulta;
        $Consulta2=new Consulta;
        if(isset($_POST["idRegistro"]))
        {
            $idPersonal=$_POST['idRegistro'];
        }
		else
        {
			$idPersonal=0;
        }
        $Consulta1->Personal_ver_datos_modal($idPersonal);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
?>

<form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"
<input type="hidden" name="formulario" value="Actualizar Personal" />
<input type="hidden" name="idPersonal" id="idPersonal" value="<?php echo print $_POST["idPersonal"]; ?>>" />
<input type="hidden" name="ListaGrupoEvento" value="<? print $_SESSION['idGrupoEvento'];?>" />
<input type="hidden" name="GrupoEvento" id="GrupoEvento" readonly="readonly" value="<? print $_SESSION['idGrupoEvento'];?>"/>
<table width="800" border="0" align="center">
  <tr>
    <td><label for="Nombre">Nombre del personal:</label></td>
    <td><?php echo $Valores['Nombre'];?></td>
  </tr>
  <tr>
    <td>  Carné:</td>
    <td> <? print $Valores['Carnet'];?></td>
  </tr>
  <tr>
    <td> Teléfono:</td>
    <td> <? print $Valores['Telefono'];?></td>
  </tr>
  <tr>
    <td>Foto del personal:</td>
    <td><?php 
  $Foto= $Valores['Foto'];  
  if(empty($Foto))
                            {
                                $Foto="default";
                            }
    echo '<img  height="100" src="../../fotos/'.$Foto.'.jpg" />'; ?></td>
  </tr>
  <tr>
    <td><br />Género:	</td>
    <td>    <input type="radio" name="Genero" <?php if (isset($Valores['EstadoPersonal']) && $Valores['EstadoPersonal']==1) echo "checked";?> onclick="javascript: return false;" value="1" id="Genero">Masculino
    <input type="radio" name="Genero" <?php if (isset($Valores['EstadoPersonal']) && $Valores['EstadoPersonal']==0) echo "checked";?>onclick="javascript: return false;" value="0" id="Genero">Femenino</td>
  </tr>
  <tr>
    <td>    <br /> Estado del personal:	</td>
    <td>    <input type="radio" name="Disponible2" <?php if (isset($Valores['EstadoPersonal']) && $Valores['EstadoPersonal']==1) echo "checked";?>  onclick="javascript: return false;" value="1" id="Disponible2">Disponible
    <input type="radio" name="Disponible2" <?php if (isset($Valores['EstadoPersonal']) && $Valores['EstadoPersonal']==0) echo "checked";?> onclick="javascript: return false;" value="0" id="Disponible2">No disponible</td>
  </tr>
  <tr>
    <td>   <br /> Sección: </td>
    <td>  <? print $Valores["Seccion"];?>
  </td>
  </tr>
  <tr>
    <td>  <br /> Jornada: </td>
        <td>  <? print $Valores["Jornada"];?>
        </td>
    </tr>
</table>                    					                    
<label for="GrupoEvento"></label>
  <br />
 
</form>
<script>
    	  function abrir()
		  {
			  Filtrar3("grupo=<?php echo $_SESSION['idGrupoEvento'] ?>");
		  }
		  </script></body>
<!-- InstanceEnd --></html>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Editando al personal</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>
<?php  
$hecho=0;
$errorNombre="";
  if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if($_POST["boton"]=="Cancelar")
        header('Location: Personal_ver.php');
    else if(isset($_POST["boton"])=="Guardar")
    {
            if(isset($_POST["idRegistro"]))
                $id=$_POST["idRegistro"];
            else
                echo '<br> No existe el Registro';
            if(isset($_POST["Nombre"]))
                $nom=$_POST["Nombre"];
                //$nom=$Valores['Nombre'];
            else
                echo '<br> No existe el Nombre ';
            if(isset($_POST["Carnet"]))
                $carnet=$_POST["Carnet"];
            else
                echo '<br> No existe el Carnet ';
        if(isset($_POST["Telefono"]))
                $tel=$_POST["Telefono"];
            else
                echo '<br> No existe el telefono ';
        if(isset($_POST["Disponible2"]))
                $disponible=$_POST["Disponible2"];
            else
                echo '<br> No existe el registro ';
        if(isset($_POST["Genero"]))
                $genero=$_POST["Genero"];
            else
                echo '<br> No existe el registro ';     
	    if(isset($_POST["Seccion"]))
                $seccion=$_POST["Seccion"];
            else
                echo '<br> No existe el registro ';
	    if(isset($_POST["Jornada"]))
                $jor=$_POST["Jornada"];
            else
                echo '<br> No existe el registro '; 
	    if(isset($_POST["GrupoEvento"]))
                $grupoid=$_POST["GrupoEvento"];
            else
                echo '<br> No existe el registro ';   
    $consulta1->Personal_verificar_editar($grupoid,$nom,$id);
$veri=mysql_fetch_assoc($consulta1->Resultado);
if($veri['Conteo']==0)
{
        $consulta1->Personal_actualizar($id,$nom,$carnet,$tel,$disponible,$genero,$grupoid,$seccion,$jor); 
        $hecho=1;
}
else
{
$errorNombre="Ya existe un miembro del personal con el mismo nombre en este evento";
}
        }
        }
?>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
    <div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un grupo de eventos a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar grupo de eventos</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    abrir();
                });
         </script>

    	<script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    EventoFiltro();
                });
         </script>

<?php
     if($hecho==1)
     {
		?>
        <h2 align="center"><i class="icon icon-check"></i>Miembro del personal actualizado.</h2>
        <div style="display:none">
        <form id="forma" name="forma" method="post" action="Personal_ver.php">
          <input type="hidden" name="idRegistro" id="idRegistro" value="<?php echo $idPersonal; ?>"/>
          <input type="submit" name="boton_pag" id="boton_pag" value="" />
        </form>
        </div>
        <script>
			setTimeout("document.getElementById('boton_pag').click();",1000);
		</script>
        <?php
	 }
	else
{
    ?>

<?php  
        $Consulta1=new Consulta;
        $Consulta2=new Consulta;
        if(isset($_POST["idRegistro"]))
        {
            $idPersonal=$_POST['idRegistro'];
        }
        $Consulta1->Personal_ver_datos($idPersonal);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
?>
<H2 align="center">Editar miembro del personal</H2>
<form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"
<input type="hidden" name="formulario" value="Actualizar Personal" />
<input type="hidden" name="idRegistro" id="idRegistro" value="<?php echo $idPersonal; ?>"/>
<input type="hidden" name="ListaGrupoEvento" value="<? print $_SESSION['idGrupoEvento'];?>" />
<input type="hidden" name="GrupoEvento" id="GrupoEvento" readonly="readonly" value="<? print $_SESSION['idGrupoEvento'];?>"/>
<div class="tablas" align="center">
<table width="654" border="0" cellspacing="5" align="center">
  <tr>
    <td><label for="Nombre">Nombre del personal:</label></td>
    <td><input type="text" name="Nombre" id="Nombre" value="<?php echo $Valores['Nombre'];?>"
  size="30" maxlength="30" placeholder="Ingrese el nombre del Personal" pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" required title="Se necesita un nombre del personal(solo letras)"/>
  <br /></td>
<td><span class="error"><?php echo $errorNombre;?></span>  </td>
  </tr>
  <tr>
    <td>  Carné:</td>
    <td><input type="text" name="Carnet" id="Carnet" value="<? print $Valores['Carnet'];?>"
  size="30" maxlength="9" placeholder="Ingrese el número de carné" pattern="[0-9]{1,45}" required title="Se necesita un número de carné(solo números)"/>
  <br /></td>
  </tr>
  <tr>
    <td> Telefono:</td>
    <td> <input type="text" name="Telefono" id="Telefono" value="<? print $Valores['Telefono'];?>" 
  size="30" maxlength="8" placeholder="Ingrese el telefono" pattern="[0-9]{1,45}" required title="Se necesita un número telefonico(solo números)"/>
  <br /></td>
  </tr>
  <tr>
    <td>Foto del personal:</td>
    <td><?php 
  $Foto= $Valores['Foto'];  
  if(empty($Foto))
                            {
                                $Foto="default";
                            }
    echo '<img  height="100" src="../../fotos/'.$Foto.'.jpg" />'; ?></td>
  </tr>
  <tr>
    <td><br />Género:	</td>
    <td>    <input type="radio" name="Genero" <?php if (isset($Valores['EstadoPersonal']) && $Valores['EstadoPersonal']==1) echo "checked";?> value="1" id="Genero">Masculino
    <input type="radio" name="Genero" <?php if (isset($Valores['EstadoPersonal']) && $Valores['EstadoPersonal']==0) echo "checked";?> value="0" id="Genero">Femenino</td>
  </tr>
  <tr>
    <td>    <br /> Estado del personal:	</td>
    <td>    <input type="radio" name="Disponible2" <?php if (isset($Valores['EstadoPersonal']) && $Valores['EstadoPersonal']==1) echo "checked";?> value="1" id="Disponible2">Disponible
    <input type="radio" name="Disponible2" <?php if (isset($Valores['EstadoPersonal']) && $Valores['EstadoPersonal']==0) echo "checked";?> value="0" id="Disponible2">No disponible</td>
  </tr>
  <tr>
    <td>   <br /> Sección: </td>
    <td>  <select name="Seccion" id="Seccion">
  		<?php
    			$Consulta2->Seccion_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option selected=selected value=".$row['idSeccion'].">".$row['Seccion']."</option>";
				}
		?>
  </select></td>
  </tr>
  <tr>
    <td>  <br /> Jornada: </td>
        <td>  <select name="Jornada" id="Jornada">
  					<?php
    			$Consulta2->Jornada_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option selected=selected value=".$row['idJornada'].">".$row['Jornada']."</option>";
				}
		?>
  </select></td>
    </tr>
</table>                    	
<label for="GrupoEvento"></label>
  <br />
 <input style="display:inline" type="submit" name="boton" id="boton" value="Guardar" />
               <a href="Personal_ver.php" target="_self"><input type="button" name="boton" id="boton" value="Cancelar" onclick=""/>
</form>
</div>
<?php
    } ?>
<script>
    	  function abrir()
		  {
			  Filtrar3("grupo=<?php echo $_SESSION['idGrupoEvento'] ?>");
		  }
		  </script>
		<!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
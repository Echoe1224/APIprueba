<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Ingresar personal</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<!-- <script src="../UL/CITEIN/jquery-1.11.3.js"></script>-->
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    $consulta2=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>
<script src="../../BLL/modal.js" language="JavaScript"></script>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar.</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Evento seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
         </script>

    <!-- InstanceBeginEditable name="Contenido" -->
    <?php
    $errorFoto ="";
    $fotoerr=0;
    $nombre=$carnet=$tel=$idFoto=$genero=$grupoid=$seccion=$jor="";
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if(isset($_POST["texto_nombre"]))
                $nombre=$_POST["texto_nombre"];
            else
                echo '<br> No existe el Nombre';
            if(isset($_POST["texto_carnet"]))
                $carnet=$_POST["texto_carnet"];
            else
                echo '<br> No existe el Carnet ';
            if(isset($_POST["texto_telefono"]))
                $tel=$_POST["texto_telefono"];
            else
                echo '<br> No existe el telefono';
	    if(empty($_POST["data_uri"]))
            {
              $fotoerr=1;           
            }
            else
           {
                $foto=$_POST["data_uri"];
		$idFoto=date('YmdHis');//Extraemos la fecha del servidor
		$filename = "../../fotos/".$idFoto.'.jpg';//Dirección de la foto.
		file_put_contents($filename, file_get_contents($foto));
           }
                //echo '<br> La fotografía es requerida ';
	    if(isset($_POST["genero"]))
                $genero=$_POST["genero"];
            else
                echo '<br> Ingrese el Genero del Personal ';     
	    if(isset($_POST["Seccion"]))
                $seccion=$_POST["Seccion"];
            else
                echo '<br> Seleccione una Seccion ';
	    if(isset($_POST["Jornada"]))
                $jor=$_POST["Jornada"];
            else
                echo '<br> Seleccione una Jornada '; 
	    if(isset($_POST["ListaGrupoEvento"]))
                $grupoid=$_POST["ListaGrupoEvento"];
            else
                echo '<br> No existe el Grupoevento ';       
if($fotoerr>0){
       $errorFoto="La fotografía es requerida.";
}
//echo "Hola  ".$fotoerr.$foto;
else if($seccion!='+' && $jor!='+'){
$consulta1->Personal_verificar($grupoid,$nombre);
$veri=mysql_fetch_assoc($consulta1->Resultado);
if($veri['Conteo']==0)
{
  $consulta1->Personal_insertar($nombre,$carnet,$tel,$idFoto,$genero,'1',$grupoid,$seccion,$jor);
       $nombre=$carnet=$tel=$idFoto=$genero=$grupoid=$seccion=$jor=$foto="";
        echo '<h3 align="center" style="color:#093">Miembro del personal ingresado con éxito.</h3>';
}
else
{
$errorNombre="Ya existe un miembro del personal con el mismo nombre en este evento";
}
}
else{
    echo '<h3 align="center" style="color:#093">Seleccione una jornada y un semestre.</h3>';
}
        }?> <!--  fin de la funcion insertar  -->  
        
        <?php
        $Consulta1=new Consulta;
        $Consulta2=new Consulta;    
		?>

<div class="ventana">
            <div id="modal"></div>
        </div>        
        <H2 align="center">Ingresar nuevo miembro del personal</H2>
	<form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">     
      <p>
          <input type="hidden" name="ListaGrupoEvento" value="<? print $_SESSION['idGrupoEvento'];?>" />    
      </p>
       <table width="%100" border="0">
         <tr>
           <td><table width="100%" height="100%" border="0" align="center">
            
  <!--  *********************************************************Formulario**************************************************** -->                
            <p><span class="error">* Campos requeridos.</span></p>
                <tr>
                  <td><label for="texto_nombre">Nombre: </label></td>
                  <td><input name="texto_nombre" type="text" id="texto_nombre" value="<?php echo $nombre;?>" size="50" maxlength="45" placeholder="Ingrese el nombre." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" required title="Se necesita un nombre(solamente ingrese letras)"/></td>
                  <td><span class="error">* <?php echo $errorNombre;?></span>  <br/></td>
                </tr>
            	<tr>
		        <td><label for="texto_carnet">Carné: </label></td>
        		<td><input name="texto_carnet" type="text" id="texto_carnet" value="<?php echo $carnet;?>" size="50" maxlength="9"placeholder="Ingrese un número de carnet." pattern="[0-9]{1,45}" required title="Se necesita un número de carnet(solamente ingrese números)"/></td>
                <td><span class="error">* <?php echo $errorCarnet;?></span> <br/></td>                
                </tr>
        		<tr>
        		  <td><label for="texto_telefono">Teléfono: </label></td>
                  <td><input name="texto_telefono" type="text" id="texto_telefono" value="<?php echo $tel;?>" size="50" maxlength="8" placeholder="Ingrese un número de telefono." pattern="[0-9]{1,45}" required title="Se necesita un número de telefono(solamente ingrese números)"/></td>
                  <td><span class="error">* <?php echo $errorTelefono;?></span></p></td>
                </tr>
                 <tr>
<td>                  Sección:</td>
  <td><div id="listaSeccion">               
  <select name="Seccion" id="Seccion" onchange="openVentana('Seccion','../Modal/seccion_modal.php','idDiv=listaSeccion');">
  					<?php
    			$Consulta2->Seccion_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option selected=selected value=".$row['idSeccion'].">".$row['Seccion']."</option>";
				}
                echo '<option value="+">Agregar otro</option>';
		 ?>
  </select>
  </div></td>
  </tr>
  <br />
  <br />
<tr>
  <td>
  Jornada:
  </td>
 <td> <div id="listaJornada">
    <select name="Jornada" id="Jornada" onchange="openVentana('Jornada','../Modal/jornada_modal.php','idDiv=listaJornada');">
      				<?php
    			$Consulta2->Jornada_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option selected=selected value=".$row['idJornada'].">".$row['Jornada']."</option>";
				}
                echo '<option value="+">Agregar otro</option>';
		 ?>
  </select>
  </div>
  </td>
  </tr>         
  <br />
  <tr>
 <td> <br /> Género: </td>
      <td><input type="radio" name="genero" required="required" value="1" id="genero">Masculino
             <input type="radio" name="genero"  value="0" id="genero">Femenino
     <td/>
    <br />
    </tr>

                <tr>
				<td><div id="boton_guardar"></td>
                <td><input type="submit" name="boton_guardar" id="boton_guardar" value="Guardar">
                       <a href="Personal_ver.php" target="_self"><input type="button" name="boton" id="boton" value="Cancelar" onclick=""/>
                 </td>
                </div></td>
                </tr>
      </table></td>
           <td><td width="309" align="center" valign="top">
<!-- ********************************Lugar donde se desplegara la imagen tomada******************************** -->
        <div id="results" align="center" style="width:300px;">
            <h2>Foto del personal</h2>
            <br/>
            <img id="foto" width="100%" src="<?php if(empty($foto)) echo '../../fotos/default.jpg'; else echo $foto; ?>"/>
            <br/>
            <input type="hidden" name="data_uri" id="data_uri" value="<?php echo $foto; ?>">
        </div>
        <div id="boton_activar_camara">
        <input type="button" onClick="adjuntarCamara()" value="Activar cámara">
        </div>
        <p>
          <span class="error">* <?php echo $errorFoto; ?> </span> <br/>
        </p>
<!-- ********************************Configurar la toma de fotografía********************************************* -->
        <div style="text-align: center;" id="my_camera"></div>
        <!-- Primero, se incluirá la librería de javascrip "webcam.js" --> 
        <script type="text/javascript" src="../CITEIN/webcam.js"></script> 
        <!-- configurar la camara (tamaño, formato, calidad) --> 
        <script language="JavaScript">
        Webcam.set({
            width: 320,
            height: 240,
            image_format: 'jpeg',
            jpeg_quality: 90
        });
        </script>
        <!-- botones ************************************************************** -->
        <div id="boton_capturar" style="display:none">
        <input type="button" onClick="capturar()" value="Capturar">
        </div>
<!--        
        <div id="boton_capturar" style="display:none">
        <input type="button" onClick="capturar()" value="Capturar">
        </div>                
        <div id="boton_capturado" style="display:none">
        <input value="Tomar otra" onclick="otra_captura()" type="button">
        <input value="Guardar foto" onclick="guardar_captura()" type="button">
        </div> -->
    </td>

	<!-- Codigo para manejar la captura y desplegar localmente -->
        <script language="JavaScript">
        function adjuntarCamara(){
            Webcam.attach('#my_camera');
            //document.getElementById('results').style.display = 'none';
            document.getElementById('boton_activar_camara').style.display = 'none';
            document.getElementById('boton_capturar').style.display = '';
            document.getElementById('results').style.display = 'none';				
        }
        function capturar() {
            // congelar la camara para que el usuario pueda ver la captura.
            //Webcam.freeze();
			Webcam.snap( function(data_uri) {
                // desplegar los resultados en la pagina.
                //document.getElementById('results').innerHTML = '<h2>Fotografía:</h2>' + '<img src="'+data_uri+'"/>';
                // Ocultar botones para que ya no se pueda tomar ninguna fotografía desde de haber guardado.
                
                document.getElementById('boton_capturar').style.display = 'none';
                document.getElementById('results').style.display = '';
                //document.getElementById('results').style.display = '';
                /*document.getElementById('results').innerHTML = 
                        '<h2>Foto del participante</h2>' + 
                        '<img src="'+data_uri+'"/>';*/
                document.getElementById('foto').src=data_uri;
                document.getElementById('data_uri').value=data_uri;
                Webcam.reset();
                } );
			document.getElementById('boton_activar_camara').style.display = '';
        }
        function otra_captura() {
            // cancelar la captura y activar la camara en vivo.
            Webcam.unfreeze();
            // swap buttons back
            document.getElementById('boton_capturar').style.display = '';
            document.getElementById('boton_capturado').style.display = 'none';
        }
        function guardar_captura() {
            // actualmente se ha hecho una captura y se ha desplegado.
            Webcam.snap( function(data_uri) {
                // desplegar los resultados en la pagina.
                //document.getElementById('results').innerHTML = '<h2>Fotografía:</h2>' + '<img src="'+data_uri+'"/>';
                // Ocultar botones para que ya no se pueda tomar ninguna fotografía desde de haber guardado.
                document.getElementById('boton_capturar').style.display = 'none';
                document.getElementById('boton_capturado').style.display = 'none';
                document.getElementById('boton_recapturar').style.display = '';
                document.getElementById('results').style.display = '';
                document.getElementById('results').style.background="#CCCCCC";
                //document.getElementById('results').style.display = '';
                /*document.getElementById('results').innerHTML = 
                        '<h2>Foto del participante</h2>' + 
                        '<img src="'+data_uri+'"/>';*/
                document.getElementById('foto').src=data_uri;
                document.getElementById('data_uri').value=data_uri;
                Webcam.reset();
                } );
        }
		function redirigir()
		{
			window.location.href = "Participante_ver.php"
		}
        /*function almacenar_captura(){
            Webcam.upload(var_temp, 'http://citein.hostingla.in/DAL/guardar_foto.php', function(code, text) {
                    // Upload complete!
                    // 'code' will be the HTTP response code from the server, e.g. 200
                    // 'text' will be the raw response content
                    
                } );	
        }*/
		</script>

      		</td></td>
         </tr>
       </table>
	</form>
	<!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
<?php
	    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";  
        include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";  
		
		$consulta=new Consulta;
		if ($_SERVER["REQUEST_METHOD"] == "POST") 
		{
			if (!empty($_POST["idRegistro"]))
			{
				$id=$_POST['idRegistro'];
				$consulta->Semestre_eliminar($id); 
			}
		}
?>

   <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
      <div style="text-align:center">
      <label>¿Está seguro de eliminar el reguistro?</label><br />
      <input type="submit" value="Elimar" />
      </div>
   </form>
   <form action="Semestre_ver.php">
      <div style="text-align:center">
      <input type="submit" value="Cancelar" />
      </div>
   </form>
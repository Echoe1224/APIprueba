<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Editar Tipo de Actividades</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>
<?php
$hecho=0;
$ernom="";
if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
 if($_POST["boton"]=="Cancelar")
    	header('Location: TipoEvento_ver.php');
	else if(isset($_POST["boton"])=="Guardar")
	{
            if(isset($_POST["idRegistro"]))
                $id=$_POST["idRegistro"];
            else
                echo '<br> No existe el Registro';
            if(isset($_POST["Nombre"]))
                $nom=$_POST["Nombre"];
            else
                echo '<br> No existe el Nombre ';
            if(isset($_POST["Disponible2"]))
                $disponible=$_POST["Disponible2"];
            else
                echo '<br> No existe el registro ';
   $consulta1->TipoEvento_verificar_editar($id,$nom);
        $ven = $consulta1->Resultado;
        if(mysql_num_rows($ven)==0)
        {          
    $consulta1->TipoEvento_actualizar($nom,$disponible,$id);  
$hecho=1; 
        }
        else
        {
                $ernom="Ya existe un tipo de actividad con el mismo nombre";
        }   	
          	
        }
}
?>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
<a style="padding-left:50px; color:#333; text-decoration:none" href="TipoEvento_ver.php"><i class="icon icon-undo2"></i> Atrás</a>
<?php
        
        $Consulta1=new Consulta;
        if(isset($_POST["idRegistro"]))
        {
			$idTipoEvento=$_POST['idRegistro'];
        }
		else
        {
			$idTipoEvento=0;
        }
        $Consulta1->TipoEvento_ver_datos($idTipoEvento);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);        
?>
<?php
	 if($hecho==1)
	 {
		?>
        <h2 align="center"><i class="icon icon-check"></i>Tipo de Actividad actualizada.</h2>
        <div style="display:none">
        <form id="forma" name="forma" method="post" action="TipoEvento_ver.php">
          <input type="submit" name="boton_pag" id="boton_pag" value="" />
        </form>
        </div>
        <script>
			setTimeout("document.getElementById('boton_pag').click();",1000);
		</script>
        <?php
	 }
	else
{
    ?>
<H2 align="center">Editar tipo de actividad</H2>
 <form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
<input type="hidden" name="formulario" value="Actualizar TipoEvento" />
<input type="hidden" name="idRegistro" value="<? print $idTipoEvento;?>" />
<div class="tablas" align="center">
<table width="300" border="0" cellspacing="5" align="center">
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td>
Nombre:
</td>
<td>
<input type="text" name="Nombre" required="" id="Nombre" value="<? print $Valores['Nombre'];?>"/>
</td>
<td><span class="error"><? print $ernom;?> </td>
<tr>
<td>
Estado:</td>
<td>
    <input type="radio" name="Disponible2" <?php if (isset($Valores['Estado']) && $Valores['Estado']==1) echo "checked";?> value="1" id="Disponible2">Disponible
    <input type="radio" name="Disponible2" <?php if (isset($Valores['Estado']) && $Valores['Estado']==0) echo "checked";?> value="0" id="Disponible2">No Disponible
</td>
<div align="center">    
</table>
</div>
<div align="center">   
<br/> 
<input  type="submit" name="boton" id="boton" value="Guardar" />
           	<input  type="submit" name="boton" id="boton" value="Cancelar" />
</div>
</form>
<?php } ?>
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
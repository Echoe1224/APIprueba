<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Ingresar Tipo de Actividad</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>

<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->

         <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    abrir();
                });
         </script>
<?php
$nombre=$hecho="";
$consulta2=new Consulta;
if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
if($_POST["boton"]=="Cancelar")
    	header('Location: TipoEvento_ver.php');
	else if(isset($_POST["boton"])=="Guardar")
	{
                $nombre=$_POST["texto_nombre"];
 $consulta1->TipoEvento_verificar($nombre);
        $row = $consulta1->Resultado;
if(mysql_num_rows($row)==0)
{
$consulta1->TipoEvento_insertar($nombre,1);
$hecho="Tipo de Actividad Ingresada";
 $consulta1->TipoEvento_verificar($nombre);
        $row =mysql_fetch_assoc($consulta1->Resultado);
$consulta1->GrupoEvento_ver();
while($veric=mysql_fetch_assoc($consulta1->Resultado))
{
$consulta2->Insertar_TipoEventoCantidad($row['idTipoEvento'],$veric['idGrupoEvento'],0);
}
$nombre="";
}
else
{
$errorNombre="* Ya existe un tipo de actividad con el mismo nombre";
}
}
}

?>
<H2 align="center">Ingresar tipo de actividad</H2>
<h3 align="center" style="color:#093"><? print $hecho;?></h3>
<form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data"> 
        <input type="hidden" name="formulario" value="Ingresar TipoEvento" />
<div class="tablas" align="center">
<table width="650" border="0" cellspacing="5" align="center">
<tr>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>
		        <label for="texto_nombre">Nombre: </label></td>
<td>
        		<input name="texto_nombre" type="text" id="texto_nombre" value="<?php echo $nombre;?>" pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ., ]{1,65}" placeholder="Ingrese el nombre del Tipo de Actividades." required="required" title="Se necesita un nombre para el tipo de evento" size="50" maxlength="50">
</td>
<td>
                  <span class="error"> <?php echo $errorNombre;?></span>
</td>
</table>
</div>
<div align="center"> 
<br/>   
        		<input style="display:inline" type="submit" name="boton" id="boton" value="Guardar" />
                <input  type="button" name="boton" id="boton" value="Cancelar" onclick="window.open('TipoEvento_ver.php','_self')"/>
</div>
</form>

          <script>
		  function abrir()
		  {
			  Filtrar3("grupo=<?php echo $_SESSION['idGrupoEvento'] ?>");
		  }
		  </script>
		<!-- InstanceEndEditable -->
		<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Hoja de Vida</title>
</head>
<body>
<?php
  include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";  
		include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";  
		$Consulta=new Consulta;
if(isset($_POST["idRegistro"]))
	{
		$idEducador=$_POST["idRegistro"];
        }
else
{
 $idEducador=0;
}
$Consulta->Educador_ver_datos($idEducador);
$row=mysql_fetch_assoc($Consulta->Resultado);
$foto=$row["HojaDeVida"];
        if(empty($foto))
        {
            $foto="default.pdf";
        }
echo '<embed width="1000" height="640" src="uploads/'.$foto.'" />';
?>
</body>
</html>
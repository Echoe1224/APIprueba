<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Ingresar actividad</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"de</script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>

<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un grupo de eventos a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar grupo de eventos</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
<a style="padding-left:50px; color:#333; text-decoration:none" href="Evento_ver.php"><i class="icon icon-undo2"></i> Atrás</a>
        <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    abrir();
                });
         </script>
<?php
if(isset($_POST["idRegistro"]))
	{
		$idEvento=$_POST["idRegistro"];
        }
        $Consulta1=new Consulta;
        $Consulta2=new Consulta;
        $Consulta3=new Consulta;
        $Consulta1->Evento_ver_datos_simple($idEvento);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);
?>
 <form id="form1" method="post" action="<?php echo htmlspecialchars("/DAL/guardar.php");?>">
<input type="hidden" name="formulario" value="Asignar Completo" />
<input type="hidden" name="contAsignacionEducador" id="contAsignacionEducador" value="0"/>
<input type="hidden" name="contAsignacionLugar" id="contAsignacionLugar" value="0"/>
<input type="hidden" name="contAsignacionSemestre" id="contAsignacionSemestre" value="0"/>
<input type="hidden" name="contAsignacionSeccion" id="contAsignacionSeccion" value="0"/>
<input type="hidden" name="contAsignacionPersonal" id="contAsignacionPersonal" value="0"/>
<input type="hidden" name="contAsignacionJornada" id="contAsignacionJornada" value="0"/>
<input type="hidden" name="idEvento" id="idEvento" value="<? print $Valores['idEvento'];?>"/>
<div class="asignacion" id="0">
<input type="button" name="aasignacion" id="aasignacion" onClick="agregarAsignacionEducador(document.getElementById('aasignacion').parentNode.id)" value = "Agregar conferencista" />
<input type="button" name="aasignacion" id="aasignacion" onClick="agregarAsignacionLugar(document.getElementById('aasignacion').parentNode.id)" value = "Agregar Lugar del Evento" />
<input type="button" name="aasignacion" id="aasignacion" onClick="agregarAsignacionSemestre(document.getElementById('aasignacion').parentNode.id)" value = "Asignar Semestre al Evento" />
<input type="button" name="aasignacion" id="aasignacion" onClick="agregarAsignacionPersonal(document.getElementById('aasignacion').parentNode.id)" value = "Asignar Personal al Evento" />
<input type="button" name="aasignacion" id="aasignacion" onClick="agregarAsignacionSeccion(document.getElementById('aasignacion').parentNode.id)" value = "Asignar Sección al Evento" />
<input type="button" name="aasignacion" id="aasignacion" onClick="agregarAsignacionJornada(document.getElementById('aasignacion').parentNode.id)" value = "Asignar Jornada al Evento" />
                </div>
  <script language="javascript">
var contAsignacion=1;
	var contAsignacionEducador=1;
	var contAsignacionLugar=1;
	var contAsignacionSemestre=1;
	var contAsignacionPersonal=1;
var contAsignacionSeccion=1;
var contAsignacionJornada=1;
    function agregarAsignacionEducador(padre)
    {
    var idevento=document.getElementById('idEvento').value;
 var titulo = document.createElement('h3');
var textoTitulo = document.createTextNode("Conferencista");

           var eCuadro=document.createElement('div');
    	        eCuadro.id=contAsignacionEducador.toString();
				eCuadro.name=contAsignacionEducador.toString();
		eCuadro.setAttribute("class","asignacion");
		document.getElementById('form1').appendChild(eCuadro);
                var eEliminar=document.createElement("P");
				var eEBoton=document.createElement("INPUT");
				eEBoton.setAttribute("type","button");
				eEBoton.setAttribute("value","Eliminar");
				eEBoton.setAttribute("onclick","quitarAsignacion(this.parentNode.parentNode.id)");
titulo.appendChild(textoTitulo);
eCuadro.appendChild(titulo);
               //lista1
               var eTipo=document.createElement("P");
               var eTLabel = document.createElement("LABEL");
		var textoTLabel = document.createTextNode("Educador: ");
		eTLabel.appendChild(textoTLabel);
		eTipo.appendChild(eTLabel);
			//SELECT o lista
			var eTLista = document.createElement("SELECT");
			eTLista.name='educador'+contAsignacionEducador;
		        eTLista.id='educador'+contAsignacionEducador;
              		<?php
				$Consulta2->Educador_vertipo(idevento);
				while ($row = mysql_fetch_assoc($Consulta2->Resultado))
                    {
$Consulta3->Educador_ver();
                    $comprobacion = $Consulta3->Resultado;
                    if(mysql_num_rows($comprobacion)>0)
                    {
                        
                    }
else
                    {?>
				var eLOpcion = document.createElement("OPTION");
				 eLOpcion.value= <?php echo $row["idEducador"]; ?>;
                 eLOpcion.text = "<?php echo $row["Nombre"]; ?>";
                 eTLista.appendChild(eLOpcion);
		<?php }
                   } ?>
                eTipo.appendChild(eTLista);
    	eCuadro.appendChild(eTipo);
        eEliminar.appendChild(eEBoton);
      	eCuadro.appendChild(eEliminar); 
		var ePadre=document.getElementById(padre);
		/*ePadre.insertBefore(eCuadro,document.getElementById('aasignacion').parentNode);*/
        document.getElementById('contAsignacionEducador').value=contAsignacionEducador;
		contAsignacionEducador++;
                contAsignacion++;
	}
    function agregarAsignacionLugar(padre)
    {
var idevento=document.getElementById('idEvento').value;
               var titulo = document.createElement('h3');
                var eCuadro=document.createElement('div');
var textoTitulo = document.createTextNode("Lugar del Evento");
    	        eCuadro.id=contAsignacionLugar.toString();
				eCuadro.name=contAsignacionLugar.toString();
		eCuadro.setAttribute("class","asignacion");
		document.getElementById('form1').appendChild(eCuadro);
                var eEliminar=document.createElement("P");
				var eEBoton=document.createElement("INPUT");
				eEBoton.setAttribute("type","button");
				eEBoton.setAttribute("value","Eliminar");
				eEBoton.setAttribute("onclick","quitarAsignacion(this.parentNode.parentNode.id)");
			eEliminar.appendChild(eEBoton);
titulo.appendChild(textoTitulo);
eCuadro.appendChild(titulo);
               //lista1
               var eTipo=document.createElement("P");
               var eTLabel = document.createElement("LABEL");
		var textoTLabel = document.createTextNode("Lugar: ");
		eTLabel.appendChild(textoTLabel);
		eTipo.appendChild(eTLabel);
			//SELECT o lista
			var eTLista = document.createElement("SELECT");
			eTLista.name='lugar'+contAsignacionLugar;
		        eTLista.id='lugar'+contAsignacionLugar;
                        eTLista.innerHTML = "";
				<?php
				$Consulta2->Lugar_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) 
                {
                    $lugar=$row["idLugar"];
                    $fecha=$Valores['Fecha'];
                    $hora=$Valores['HoraInicio'];
                    $Consulta3->Lugar_verificacion($lugar,$fecha,$hora);
                    $comprobacion = $Consulta3->Resultado;
                    if(mysql_num_rows($comprobacion)>0)
                    {
                        
                    }
                    else
                    {?>
	        			var eLOpcion = document.createElement("OPTION");
			     	    eLOpcion.value= <?php echo $row["idLugar"]; ?>;
                        eLOpcion.text = "<?php echo $row["Nombre"]; ?>";
                        eTLista.appendChild(eLOpcion);

				<?php }
                }?>
                eTipo.appendChild(eTLista);
    	eCuadro.appendChild(eTipo);
eCuadro.appendChild(eEliminar);
		var ePadre=document.getElementById(padre);
		/*ePadre.insertBefore(eCuadro,document.getElementById('aasignacion').parentNode);*/
        document.getElementById('contAsignacionLugar').value=contAsignacionLugar;
		contAsignacionLugar++;
                contAsignacion++;
	}
    function agregarAsignacionSemestre(padre)
    {
 var titulo = document.createElement('h3');
var textoTitulo = document.createTextNode("Semestre");
    var idevento=document.getElementById('idEvento').value;
                var eCuadro=document.createElement('div');
                eCuadro.id=contAsignacionSemestre.toString();
				eCuadro.name=contAsignacionSemestre.toString();
		eCuadro.setAttribute("class","asignacion");
		document.getElementById('form1').appendChild(eCuadro);
                var eEliminar=document.createElement("P");
				var eEBoton=document.createElement("INPUT");
				eEBoton.setAttribute("type","button");
				eEBoton.setAttribute("value","Eliminar");
				eEBoton.setAttribute("onclick","quitarAsignacion(this.parentNode.parentNode.id)");
			eEliminar.appendChild(eEBoton);
titulo.appendChild(textoTitulo);
eCuadro.appendChild(titulo);
               //lista1
               var eTipo=document.createElement("P");
               var eTLabel = document.createElement("LABEL");
		var textoTLabel = document.createTextNode("Semestre: ");
		eTLabel.appendChild(textoTLabel);
		eTipo.appendChild(eTLabel);
			//SELECT o lista
			var eTLista = document.createElement("SELECT");
			eTLista.name='semestre'+contAsignacionSemestre;
		        eTLista.id='semestre'+contAsignacionSemestre;
              		<?php
				$Consulta2->Semestre_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {?>
				var eLOpcion = document.createElement("OPTION");
				 eLOpcion.value= <?php echo $row["id"]; ?>;
                 eLOpcion.text = "<?php echo $row["Semestre"]; ?>";
                 eTLista.appendChild(eLOpcion);
				<?php } ?>
                eTipo.appendChild(eTLista);
    	eCuadro.appendChild(eTipo);
		eCuadro.appendChild(eEliminar);
		var ePadre=document.getElementById(padre);
		/*ePadre.insertBefore(eCuadro,document.getElementById('aasignacion').parentNode);*/
        document.getElementById('contAsignacionSemestre').value=contAsignacionSemestre;
        contAsignacionSemestre++;
		contAsignacion++;
	}
        function agregarAsignacionPersonal(padre)
    {
var titulo = document.createElement('h3');
var textoTitulo = document.createTextNode("Personal");
                var eCuadro=document.createElement('div');
    	        eCuadro.id=contAsignacionPersonal.toString();
		eCuadro.id=contAsignacionPersonal.toString();
               document.getElementById('form1').appendChild(eCuadro);
                var eEliminar=document.createElement("P");
				var eEBoton=document.createElement("INPUT");
				eEBoton.setAttribute("type","button");
				eEBoton.setAttribute("value","Eliminar");
				eEBoton.setAttribute("onclick","quitarAsignacion(this.parentNode.parentNode.id)");
			eEliminar.appendChild(eEBoton);
titulo.appendChild(textoTitulo);
eCuadro.appendChild(titulo);
               var eTipo=document.createElement("P");
               var eTLabel = document.createElement("LABEL");
		var textoTLabel = document.createTextNode("Personal: ");
		eTLabel.appendChild(textoTLabel);
		eTipo.appendChild(eTLabel);
			//SELECT o lista
			var eTLista = document.createElement("SELECT");
			eTLista.name='personal'+contAsignacionPersonal;
		        eTLista.id='personal'+contAsignacionPersonal;
				<?php
				$Consulta2->Personal_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {?>
				var eLOpcion = document.createElement("OPTION");
				 eLOpcion.value= <?php echo $row["idPersonal"]; ?>;
                  eLOpcion.text = "<?php echo $row["Nombre"]; ?>";
                 eTLista.appendChild(eLOpcion);
                    <?php } ?>
                 eTipo.appendChild(eTLista);
    	eCuadro.appendChild(eTipo);

var eTipo=document.createElement("P");
               var eTLabel = document.createElement("LABEL");
		var textoTLabel = document.createTextNode("Lugar de Inscripcion: ");
		eTLabel.appendChild(textoTLabel);
		eTipo.appendChild(eTLabel);
                        var eTLista = document.createElement("SELECT");
			eTLista.name='lugar'+contAsignacionPersonal;
		        eTLista.id='lugar'+contAsignacionPersonal;
                        eTLista.innerHTML = "";
				<?php
				$Consulta2->Lugar_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {?>
				var eLOpcion = document.createElement("OPTION");
				 eLOpcion.value= <?php echo $row["idLugar"]; ?>;
                 eLOpcion.text = "<?php echo $row["Nombre"]; ?>";
                 eTLista.appendChild(eLOpcion);
                 //document.forms.form1.eTLista.options.add (eLOpcion);
				<?php } ?>
                eTipo.appendChild(eTLista);
eCuadro.appendChild(eTipo);

			eCuadro.appendChild(eEliminar);					
		/*var ePadre=document.getElementById(padre);
		ePadre.insertBefore(eCuadro.document.getElementById('aasignacion').parentNode);*/
		document.getElementById('contAsignacionPersonal').value=contAsignacionPersonal;
		contAsignacion++;
	}

function agregarAsignacionSeccion(padre)
    {
    var idevento=document.getElementById('idEvento').value;
 var titulo = document.createElement('h3');
var textoTitulo = document.createTextNode("Seccion");
                var eCuadro=document.createElement('div');
    	        eCuadro.id=contAsignacionSeccion.toString();
				eCuadro.name=contAsignacionSeccion.toString();
		eCuadro.setAttribute("class","asignacion");
		document.getElementById('form1').appendChild(eCuadro);
                var eEliminar=document.createElement("P");
				var eEBoton=document.createElement("INPUT");
				eEBoton.setAttribute("type","button");
				eEBoton.setAttribute("value","Eliminar");
				eEBoton.setAttribute("onclick","quitarAsignacion(this.parentNode.parentNode.id)");
titulo.appendChild(textoTitulo);
eCuadro.appendChild(titulo);
               //lista1
               var eTipo=document.createElement("P");
               var eTLabel = document.createElement("LABEL");
		var textoTLabel = document.createTextNode("Seccion: ");
		eTLabel.appendChild(textoTLabel);
		eTipo.appendChild(eTLabel);
			//SELECT o lista
			var eTLista = document.createElement("SELECT");
			eTLista.name='seccion'+contAsignacionSeccion;
		        eTLista.id='seccion'+contAsignacionSeccion;
              		<?php
				$Consulta2->Seccion_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {?>
				var eLOpcion = document.createElement("OPTION");
				 eLOpcion.value= <?php echo $row["idSeccion"]; ?>;
                 eLOpcion.text = "<?php echo $row["Seccion"]; ?>";
                 eTLista.appendChild(eLOpcion);
				<?php } ?>
                eTipo.appendChild(eTLista);
    	eCuadro.appendChild(eTipo);
        eEliminar.appendChild(eEBoton);
      	eCuadro.appendChild(eEliminar); 
		var ePadre=document.getElementById(padre);
		/*ePadre.insertBefore(eCuadro,document.getElementById('aasignacion').parentNode);*/
        document.getElementById('contAsignacionSeccion').value=contAsignacionSeccion;
		contAsignacionSeccion++;
                contAsignacion++;
	}

function agregarAsignacionJornada(padre)
    {
    var idevento=document.getElementById('idEvento').value;
 var titulo = document.createElement('h3');
var textoTitulo = document.createTextNode("Jornada");
                var eCuadro=document.createElement('div');
    	        eCuadro.id=contAsignacionJornada.toString();
				eCuadro.name=contAsignacionJornada.toString();
		eCuadro.setAttribute("class","asignacion");
		document.getElementById('form1').appendChild(eCuadro);
                var eEliminar=document.createElement("P");
				var eEBoton=document.createElement("INPUT");
				eEBoton.setAttribute("type","button");
				eEBoton.setAttribute("value","Eliminar");
				eEBoton.setAttribute("onclick","quitarAsignacion(this.parentNode.parentNode.id)");
titulo.appendChild(textoTitulo);
eCuadro.appendChild(titulo);
               //lista1
               var eTipo=document.createElement("P");
               var eTLabel = document.createElement("LABEL");
		var textoTLabel = document.createTextNode("Educador: ");
		eTLabel.appendChild(textoTLabel);
		eTipo.appendChild(eTLabel);
			//SELECT o lista
			var eTLista = document.createElement("SELECT");
			eTLista.name='jornada'+contAsignacionJornada;
		        eTLista.id='jornada'+contAsignacionJornada;
              		<?php
				$Consulta2->Jornada_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {?>
				var eLOpcion = document.createElement("OPTION");
				 eLOpcion.value= <?php echo $row["idJornada"]; ?>;
                 eLOpcion.text = "<?php echo $row["Jornada"]; ?>";
                 eTLista.appendChild(eLOpcion);
				<?php } ?>
                eTipo.appendChild(eTLista);
    	eCuadro.appendChild(eTipo);
        eEliminar.appendChild(eEBoton);
      	eCuadro.appendChild(eEliminar); 
		var ePadre=document.getElementById(padre);
		/*ePadre.insertBefore(eCuadro,document.getElementById('aasignacion').parentNode);*/
        document.getElementById('contAsignacionJornada').value=contAsignacionJornada;
		contAsignacionJornada++;
                contAsignacion++;
	}
    function quitarelemento(el)
    {
		var elemento=document.getElementById(el);
		elemento.remove();
    }
    function valores()
    {
        var datolistaed=document.getElementById('educador1').value;
        var datolistaev=document.getElementById('evento1').value;
        var dato=document.getElementById('temporal').value
        alert(contAsignacion+datolistaed+datolistaev+dato)
    }
    
    function quitarAsignacion(padre)
	{
		if(confirm('¿Esta seguro de eliminar la asignación?'))
		{
			var asignacion=document.getElementById(padre);
			asignacion.remove();
		}
	}
    </script>
    <input type="submit" name="boton_enviar2" id="boton_enviar2" value="Enviar" />
</form>
		<!-- InstanceEndEditable -->
<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
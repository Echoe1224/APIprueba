<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Asignaciones de actividades</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="datetimepicker_css.js" language="JavaScript"></script>
<script src="../../BLL/modal.js" language="JavaScript"></script>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
    <div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Evento seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
<a style="padding-left:50px; color:#333; text-decoration:none" href="Evento_ver.php"><i class="icon icon-undo2"></i> Atrás</a>
         <form id="form1" name="form1" method="post" action="">


<?php 
$Consulta1=new Consulta;
$Consulta9=new Consulta;
if(isset($_POST["idRegistro"]))
	{
		$nombreeve=$_POST["idRegistro"];
  $Consulta1->Evento_ver_datos_simple($nombreeve,$_SESSION['idGrupoEvento']);
       $Valores=mysql_fetch_assoc($Consulta1->Resultado);
$idEvento=$Valores['idEvento'];
        }
else
$idEvento=0;
?>
        <div class="ventana">
            <div id="modal"></div>
        </div>
 <div>
            	<h2 align="center">Asignaciones de la actividad: <? print $nombreeve;?></h2><H4 align="left">Paso 2/2</H4>
            	<H4 align="left">&nbsp;</H4>
            	<p align="left">En esta página se asignan los educadores, lugares, personal, semestres, jornadas y secciones para esta actividad.</p>
          		</div>
         	<input type="hidden" name="formulario" id="formulario" value="descripciones" />
            <input type="hidden" name="paginaEliminar" id="paginaEliminar" value="..\..\BLL\eliminar.php" />
        	<div>
            
               <input type="hidden" name="grupoevento" id="grupoevento" value="<? print $_SESSION['idGrupoEvento'];?>" />
<input type="hidden" name="texto_filtro" id="texto_filtro" value="<? print $idEvento;?>" />
            </div>
            <br/>
<div id="EducadorAsignado"> 
  <h3 align="center">Educadores  </h3>
  <p>
    <input type="hidden" name="paginaeducador" id="paginaeducador" value="AsignarEducador.php" />
    <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    EventoFiltromultiple('Educador','paginaeducador');
                });
         </script>
  </p>
  <div class="dataGridViewDiv" id="Educador"></div>
</div>
<div id="LugarAsignado"> 
  <p>&nbsp;</p>
  <h3 align="center">Lugares</h3>
  <h3>
  <input type="hidden" name="paginalugar" id="paginalugar" value="AsignarLugar.php" />
    <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    EventoFiltromultiple('Lugar','paginalugar');
                });
         </script>
  </h3>
  <div class="dataGridViewDiv" id="Lugar"></div>
</div>
<div id="PersonalAsignado"> 
  <p align="center">&nbsp;</p>
  <h3 align="center">Personal  </h3>
  <p>
    <input type="hidden" name="paginapersonalr" id="paginapersonalr" value="asignarpersonal.php" />
    <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    EventoFiltromultiple('Personal','paginapersonalr');
                });
         </script>
  </p>
  <div class="dataGridViewDiv" id="Personal"></div>
</div>
<div id="SemestreAsignado">
<h4>&nbsp;</h4>
<h3 align="center">Semestres</h3>
 <input type="hidden" name="paginasemestre" id="paginasemestre" value="asignarsemestre.php" />
    	<script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    EventoFiltromultiple('Semestre','paginasemestre');
                });
         </script>
            <div class="dataGridViewDiv" id="Semestre"></div>
</div>
<div id="SeccionAsignado"> 
  <p>&nbsp;</p>
  <h3 align="center">Secciones  </h3>
  <p>
    <input type="hidden" name="paginaseccion" id="paginaseccion" value="AsignarSeccion.php" />
    <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    EventoFiltromultiple('Seccion','paginaseccion');
                });
         </script>
  </p>
  <div class="dataGridViewDiv" id="Seccion"></div>
</div>
<div id="JornadaAsignado">
  <p>&nbsp;</p>
  <h3 align="center">Jornadas</h3>
  <h4>&nbsp;</h4>
 <input type="hidden" name="paginajornada" id="paginajornada" value="AsignarJornada.php" />
    	<script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    EventoFiltromultiple('Jornada','paginajornada');
                });
         </script>
            <div class="dataGridViewDiv" id="Jornada"></div>
</div>
 <input type="hidden" name="asignados" id="asignados" value="0" />
<br></br>
<div align="center">
<input type="button" name="Continuar" id="Continuar" value="Continuar" onclick="continuacion()" />
</div>
<div style="display:none">
<a href="Evento_ver.php" target="_self"><input style="display:inline" type="button" name="siguiente" id="siguiente" value="siguiente" onclick=""/>
</div>
 <script language="javascript">

		function AsignarLugar(idLugar,eve,grupo)
		{
			ProcesarPaginaPostConParametros("AsignarLugar.php","idLugar="+idLugar+"&idEvento="+eve+"&grupoevento="+grupo,"Lugar");
		}
        function AsignarEducador(idEducador,eve,grupo)
    	{
			ProcesarPaginaPostConParametros("AsignarEducador.php","idEducador="+idEducador+"&idEvento="+eve+"&grupoevento="+grupo,"Educador");
		}
        function AsignarPersonal(idPersonal,eve,idLug,grupo)
    	{
			ProcesarPaginaPostConParametros("asignarpersonal.php","idPersonal="+idPersonal+"&idEvento="+eve+"&idLug="+idLug+"&grupoevento="+grupo,"Personal");
		}
        function AsignasSemestre(iSem,eve)
    	{
			ProcesarPaginaPostConParametros("asignarsemestre.php","idSemestre="+iSem+"&idEvento="+eve,"Semestre");
		}
function AsignasSeccion(isec,eve)
    	{
			ProcesarPaginaPostConParametros("AsignarSeccion.php","idSeccion="+isec+"&idEvento="+eve,"Seccion");
		}
function AsignasJornada(ijor,eve)
    	{
			ProcesarPaginaPostConParametros("AsignarJornada.php","idJornada="+ijor+"&idEvento="+eve,"Jornada");
		}
        
function continuacion()
{
var boton= document.getElementById('siguiente');

<?php
				$Consulta9->Evento_ver_educador($idEvento);
				$verEducador = mysql_num_rows($Consulta9->Resultado);
mysqli_free_result($Consulta9->Resultado);?>
                var educador = <?php echo $verEducador; ?>;
<?php
$Consulta9->Evento_ver_Lugar($idEvento);
				$verLugar = mysql_num_rows($Consulta9->Resultado);
mysqli_free_result($Consulta9->Resultado);?>
              var lugar= <?php echo $verLugar; ?>;
<?php
$Consulta9->Evento_ver_Personal($idEvento);
				$verPersonal = mysql_num_rows($Consulta9->Resultado);
mysqli_free_result($Consulta9->Resultado);?>
                 var personal= <?php echo $verPersonal ; ?>;
<?php
$Consulta9->Evento_ver_Semestre($idEvento);
				$verSemestre = mysql_num_rows($Consulta9->Resultado);
mysqli_free_result($Consulta9->Resultado);?>
                 var semestre= <?php echo $verSemestre; ?>;
<?php
$Consulta9->Evento_ver_Seccion($idEvento);
				$verSeccion = mysql_num_rows($Consulta9->Resultado);
mysqli_free_result($Consulta9->Resultado);?>
                 var seccion= <?php echo $verSeccion; ?>;
<?php
$Consulta9->Evento_ver_Jornada($idEvento);
				$verJornada = mysql_num_rows($Consulta9->Resultado);
mysqli_free_result($Consulta9->Resultado);?>
                 var jornada= <?php echo $verJornada ; ?>;
				 boton.click();
/*
if(educador>0 && lugar>0 && personal>0 && semestre>0 && seccion>0 && jornada>0)
{
    boton.click();
}
else if(lugar==0)
{
    if(confirm("Esta seguro de abandonar esta página."))
    {
       boton.click();
    }
}
else if(personal==0)
{
    if(confirm("Esta seguro de abandonar esta página."))
    {
       boton.click();
    }
}
else if(semestre==0)
{
    if(confirm("Esta seguro de abandonar esta página."))
    {
       boton.click();
    }
}
else if(seccion==0)
{
    if(confirm("Esta seguro de abandonar esta página."))
    {
       boton.click();
    }
}
else if(jornada==0)
{
    if(confirm("Esta seguro de abandonar esta página."))
    {
       boton.click();
    }
}
else if(educador==0)
{
    if(confirm("Esta seguro de abandonar esta página."))
    {
       boton.click();
    }
	boton.click();
}*/
}

		</script>

          </form>
		<!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
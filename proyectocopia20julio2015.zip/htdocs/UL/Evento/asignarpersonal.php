<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Asignando...</title>
<script src="../../../BLL/ajax.js" language="JavaScript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>

<body>
<?php
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
   include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		$Consulta1=new Consulta;
        $Consulta2=new Consulta;
        
$idEvento=$_GET['filtro'];
$grupoeve=$_GET['grupoevento'];
if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
                 if(isset($_POST["idPersonal"]))
                $idPer=$_POST["idPersonal"];
            else
                echo '<br> Error en el dato  ';

                $id=$_POST["idEvento"];

 if(isset($_POST["idLug"]))
                $lug=$_POST["idLug"];
            else
                 echo '<br> Error en el dato  ';

                $grupoeve=$_POST['grupoevento'];
                $idEvento=$id;
if($idPer>0&&$lug>0)
{
                $Consulta1->EventoPersonal_insertar($id,$idPer,0,$lug);
}
        }
        $Consulta1->Evento_ver_datos($idEvento);
        $Valores=mysql_fetch_assoc($Consulta1->Resultado);
?>


	<div id="personalAsignado">
<?php
$consulta1=new Consulta;
           $Consulta1->Evento_ver_Personal($idEvento);
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print 'No existe personal asignado';  
            }
            else
            {
    		//Se agrega el codigo del ancabezado de la tabla
		print'<table class = "tabla">';
		echo "\n";
		echo '<tr class="dgv-titulo">';
		//$i:desde que columna se empieza a graficar
		$i = 1;
//Encabezado del dataGridView
		while ($i < mysql_num_fields($Consulta1->Resultado)) {
				$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				echo '<td>'.$metadatos->name.'</td>';
				$i++;
			}
			echo '<td>Opciones</td>';
		print '</tr>';
		echo "\n";
//Datos del dataGridView
		$agregar=false;
		while($row=mysql_fetch_assoc($Consulta1->Resultado))
		{
			//donde se agregan los datos que se mostraran en cada columna
			$clase="filaTablaSinFondo";
                        if($agregar)
					$clase="filaTablaConFondo";
                 	print'<tr class="'.$clase.'">';
			echo "\n";
			//$i:desde que columna se empieza a graficar
			$i = 1;
			while ($i < mysql_num_fields($Consulta1->Resultado) && $i!=0) {
				$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				//para agregar color a una fila
				$clase="filaTablaSinFondo";
				if($agregar)
					$clase="filaTablaConFondo";
				echo '<td>';
			//Columnas que son de tipo booleano.						
				if($metadatos->name=="Habilitado")
				{
				   $checkeado="";
				   if($row[$metadatos->name]!=0)
					$checkeado= "checked=\"checked\"";
				   echo '<input name="checkboxAsistencia2" type="checkbox" id="checkboxAsistencia2" '.$checkeado.' onclick="javascript: return false;" />';
				}
				//Columnas que se quiere modificar el valor ej: 1=Masculino
				else if($metadatos->name=="Género")
				{
				   if($row[$metadatos->name]!=0)
						echo "Masculino";
					else
						echo "Femenino";
				}
				//Columnas vacías
				else if($metadatos->name=="Carné")
				{
					if($row["Carné"]!=0)
						echo $row[$metadatos->name];
				}
 else if($metadatos->name=="Foto")
                        {
                            $foto=$row["Foto"];
                            if(empty($foto))
                            {
                                $foto="default";
                            }
                            echo '<img  height="100" src="../../fotos/'.$foto.'.jpg" />';
                        }
				else
					echo $row[$metadatos->name];
				echo "</td>\n";						
				++$i;
			}
					echo '<td>';
						//Eliminar
						echo	'<span style="cursor:pointer"; onclick="Eliminardoblerepanel('.$idEvento.','.$row["Personal_idPersonal"].',4);"><i class="icon icon-bin"></i>Eliminar</samp>';
						echo "</td>\n";		
			echo "\n";
			print '</tr>';
if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
				}
                print '</table>';
            }   
?>
    </div>
<?php 
$consulta1->Evento_ver_Lugar($idEvento);
if(mysql_num_rows($consulta1->Resultado)==0)
{
?>
<h3 align="center" style="color:#093">*No existe lugar asignados por favor asigne un lugar y presione actualizar.</h3>
<input type="button" name="actualizar" id="actualizar" value="Actualizar" onclick="AsignarPersonal(0,document.getElementById('idEvento').value,0,document.getElementById('grupo').value);" />
<?php
}
else
{
?>
 <form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
<div align="right">
<input type="button" name="actualizar" id="actualizar" value="Actualizar" onclick="AsignarPersonal(0,document.getElementById('idEvento').value,0,document.getElementById('grupo').value);" />
</div>
<br>
      <input type="hidden" name="idEvento" id="idEvento" value="<?php echo $idEvento?>"/>
      <input type="hidden" name="grupo" id="grupo" value="<?php echo $grupoeve?>"/>
      <label for="lista_personal">Personal: </label>

      <select name="lista_personal" id="lista_personal">
<option disabled selected=selected value="-">Seleccione una opcion</option>
 <?php
				$Consulta1->Personal_ver_idgrupo($grupoeve);
				while ($row = mysql_fetch_assoc($Consulta1->Resultado)) {
                    $Consulta2->Personal_ver_simple($idEvento, $row[idPersonal]);
                    $comprobacion = $Consulta2->Resultado;
                        if(mysql_num_rows($comprobacion)==0)
                        {
                            echo "<option selected=selected value=".$row['idPersonal'].">".$row['Nombre']."</option>";
                        }
				}
		 ?>
      </select>
<td><label for="ListaLugar">Lugar de asignación</label></td>
     <td><select name="ListaLugar" id="ListaLugar">
  <?php
    			$consulta1->Evento_ver_Lugar($idEvento);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['Lugar_idLugar'].">".$row['Nombre del lugar']."</option>";
				}
		 ?>
  </select></td>
      <input type="button" name="boton_lugar" id="boton_lugar" value="Asignar" onclick="AsignarPersonal(document.getElementById('lista_personal').value,document.getElementById('idEvento').value,document.getElementById('ListaLugar').value,document.getElementById('grupo').value);" />
<?
}
?>
    </form>

</body>
</html>
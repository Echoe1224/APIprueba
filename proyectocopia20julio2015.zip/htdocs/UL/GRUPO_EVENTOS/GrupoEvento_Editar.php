<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Editar evento</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/Templates/menu.php";*/
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<link rel="icon" type="image/ico" href="../../favicon.ico" />
<!-- InstanceBeginEditable name="head" -->
				<?php
		$carpeta = "../../UL/DIPLOMA/DiplomaImagen/";
		$TipoEventoCantidad =new Consulta;
		
        $consulta=new Servidor;
        $consulta->conectar();
    	$filtro=$_POST['idRegistro'];
        $id=$_POST["cod"];
        $temp=1; 
        if($filtro=='')
        {
            $filtro=$id;
        }
        $consulta=mysql_fetch_assoc(mysql_query("SELECT * FROM GrupoEvento WHERE idGrupoEvento='$filtro'"));
		
       
		
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
    	{
            $contador=0;
            $diploma="";
             //INICIA codigo para guardar imagen en la carpeta
            $target_dir = "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/UL/DIPLOMA/DiplomaImagen/"; 
            $diploma=basename($_FILES["fileToUpload"]["name"]);
            if($diploma=="")
            {
                if (!empty($_POST["listaImagenes"]))
                {
               
                    if($_POST["listaImagenes"]!='Cambiar imagen')
                    {
                         $diploma=$_POST["listaImagenes"];
                        ++$contador;                    
                    }
                    else
                    {
                        
                        $diploma=$consulta['Diploma'];
                        ++$contador; 
                    }

                }
            
            }
            else
            if($diploma!="")
            {
        
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        // verificar si la lo que se cargó es una imagen
        if(isset($_POST["fileToUpload"])) 
        {
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if($check !== false) 
            {
                echo "El archivo es una imagen - " . $check["mime"] . ". ";
                $uploadOk = 1;
            } else 
            {
                echo "El archivo no es una imagen.";
                $uploadOk = 0;
            }
            
        }
        // verificar si la imagen ya existe o no
        if (file_exists($target_file)) 
        {
            echo "El archivo ya existe.";
            $uploadOk = 0;
        }
        // verificar el tamaño del archivo
        if ($_FILES["fileToUpload"]["size"] > 1000000) 
        {
            echo "El archivo es muy pesado, escoge uno menos pesado";
            $uploadOk = 0;
        }
        // formato de archivos permitidos
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) 
        {
            echo "Disculpe, solo se permiten archivos con extención JPG, JPEG, PNG y GIF ";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) 
        {
            echo "Disculpe, no se pudo cargar su archivo.";
        // if everything is ok, try to upload file
        } else 
        {
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
            {
                echo "    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
               ++$contador;
               
            } else 
            {
                echo "Disculpe, se ha producido un herror al intentar subir su archivo";
            }
        }
      
        }
    	
        
        
            
            if (!empty($_POST["Nombre"]))
    		{
                $Nombre=$_POST["Nombre"];
                ++$contador;
    		}
            
            if (!empty($_POST["CostoInscripcion"]))
            {
                $costo=$_POST["CostoInscripcion"];
                ++$contador;
            }
            if (!empty($_POST["descripcion"]))
            {
                $descripcion=$_POST["descripcion"];
               
            }
            if (!empty($_POST["text_estado"]))
            {
                $estado=$_POST["text_estado"];
                if($estado=="Activar")
                {
                    $estado=1;
                }
                else if($estado=="Desactivar") {$estado=0;}
                ++$contador;
            }
           
            
            

            if($contador==4)
            {
                $consulta1->GrupoEvento_verificar_nombre2($filtro,$Nombre);
				$TipoEventoCantidad->TipoEventoCantidad_ver($filtro);
				$dato=$TipoEventoCantidad->Resultado;
                
                $res=$consulta1->Resultado;

            	while($row = mysql_fetch_assoc($res))
                {
    					$temp=$row["Cantidad"];                        
    			}
               
    			mysql_free_result($res);
				$cantidad=0;
                if($temp==0)
        		{
                    $consulta1->GrupoEvento_actualizar($Nombre,$costo,$descripcion,$diploma,$estado,$id);
					while($row = mysql_fetch_assoc($dato))
					{
						$idTipoEvento=$row['TipoEvento_idTipoEvento'];
						$cantidad=$_POST[$idTipoEvento];
						$TipoEventoCantidad->TipoEventoCantidad_editar($filtro,$idTipoEvento,$cantidad);						                        
					}
                                        
                    header("Location: http:/UL/GRUPO_EVENTOS/GrupoEvento_ver.php");
        		}
                else
                {
                    echo'<script> alert("Ya existe un registro con el mismo nombre, por favor cámbielo ");</script>';                    
                }
                /*
                echo 'nombre: '.$Nombre.'<br>';
                 echo 'fecha1: '.$Fecha1.'<br>';
                  echo 'fecha2: '.$Fecha2.'<br>';
                   echo 'costo: '.$costo.'<br>';
                    echo 'descripcion: '.$descripcion.'<br>';
                     echo 'diploma: '.$diploma.'<br>';
                      echo 'estado: '.$estado.'<br>';*/
                
           
            }
    	}
           
?>
<script src="../../UL/GRUPO_EVENTOS/datetimepicker_css.js"></script>
<script>
    function onFileSelected(event) 
	{
	  var selectedFile = event.target.files[0];
	  var reader = new FileReader();
	
	  var imgtag = document.getElementById("myimage");
	  imgtag.title = selectedFile.name;
	
	  reader.onload = function(event) {
		imgtag.src = event.target.result;
	  };
	
	  reader.readAsDataURL(selectedFile);
	}
</script>
<style>
.myButton {
	background-color: #060;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
	border-radius:6px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#FFF;
	font-family:Arial;
	font-size:13px;
	padding:2px 60px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.myButton:hover {
	background-color:#5cbf2a;
}
.myButton:active {
	position:relative;
	top:1px;
}
.caja {
    
    border-radius: 20px;
    border: 2px solid #8AC007;
    padding: 20px; 
     
}

</style>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <?php
        if(isset($_POST['idRegistro']))
        {
    		$idGrupo=$_POST['idRegistro'];
        }
		else
        {
			$idGrupo=0;
        }
        
        if ($idGrupo>0)
        {
		
        ?>
        <div class="modal-container">
            <div id="modal"></div>
        </div>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
                  <input name="formulario" id="formulario" value="GrupoEvento_actualizar" type="hidden">
                  <input name="cod" id="cod" value="<?php echo $filtro ?>" type="hidden">
                 <h2 style="text-align:center"> Editar evento </h2>
                 <div align="center">
                    <HR width="80%"> 
                 </div>
                  <br/>
                  <br/>
                  <br/>
                  <div align="center">
                	<table  cellspacing="5">
  <tr>
    <td>
    <table width="525" >
                  <tr>
                    <td width="185">Nombre del evento:</td>
                    <td width="328"><input type="text" name="Nombre" class="caja2" value="<? print $consulta['Nombre'];?>" id="Nombre" pattern="[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ,. ]{1,100}" title="Solo se aceptan letras y numeros." required="required" autofocus="autofocus"></td>
                  </tr>
                  <tr>
                    <td>Costo de inscripción: Q.</td>
                    <td><input type="text" name="CostoInscripcion" class="caja2" value="<? print $consulta['CostoInscripcion'];?>" id="CostroInscripcion" pattern="\d+(\.\d{1,4})?" title="Ingrese solamente números" required="required"></td>
                  </tr>
                  <tr>
                    <td>Estado:</td>
                    <td>
                    <input type="radio" name="text_estado" <?php if (isset($consulta['EstadoGrupoEvento']) && $consulta['EstadoGrupoEvento']==1) echo "checked";?> value="Activar" id="text_estado">Activar
        <input type="radio" name="text_estado" <?php if (isset($consulta['EstadoGrupoEvento']) && $consulta['EstadoGrupoEvento']==0) echo "checked";?> value="Desactivar" id="text_estado">Desactivar
                    </td>
                  </tr>
                  <tr>
                    <td>Descripción:</td>
                    <td>   
                    	<textarea 
                            name="descripcion" id="descripcion" cols="45" rows="5" value="">  <?php echo $consulta['DescripcionGrupoEvento'];?>
                        </textarea>                 
                    </td>
                  </tr>
                  
                  <tr>
                    <td>Seleccione la imagen del diploma (Únicamente de extensión .jpg y de tamaño 1000x750)</td>
                    <td> 
                    <label for="listaImagenes">Lista de imagenes</label>
  						<select name="listaImagenes" id="listaImagenes">
                          <option selected=selected value="Cambiar imagen">--Cambiar imagen--</option>
 							<?php
							$consulta1->GrupoEvento_ver();
							while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
							echo "<option  value=".$row['Diploma'].">".$row['Diploma']."</option>";
				}
		 					?>
					  </select>  
                    	<input type="file"  name="fileToUpload" id="fileToUpload" onchange="onFileSelected(event)">
                      <img  height="100" id="myimage" src="
                      <?php 
                      $todo=$carpeta.$consulta['Diploma']; 
                        echo $todo;      
                      ?>" >						            		
                    </td>
                  </tr>
        </table>
      </td>
    <td>
    
    <div id="tipos" class="caja">
    </div>
     <div align="center">
     	<a href="javascript:abrirMPost('','../Modal/TipoEvento_modal2.php')" class="myButton">Agregar otro tipo de actividad</a>
     </div>
    </td>
  </tr>
</table>
        </br>
        </br>
                <input type="submit" name="button" id="button" value="Guardar" />
                <input type="button" name="button" id="button" value="Cancelar" onclick="window.open('GrupoEvento_ver.php','_self')" />
                                
            </form>   
     <script>
		desplegarTipos();
		function desplegarTipos()
		{
			ProcesarPaginaGetConParametros("GrupoEvento_tipoEventos_editar.php","filtro='<?php echo $filtro ?>'","tipos");
		}
	</script>
                <?php
    }
    else
    {
        ?>
        <h2 align="center">Necesita seleccionar un Evento</h2>
        <br />
        <h4 align="center"><a href="GrupoEvento_ver.php"> Seleccionar</a></h4>
        <?php
    }
    ?>
                </div>		
            
                </div>
				
				<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
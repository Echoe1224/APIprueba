<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<?php
    //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php"; 
	$Consulta1=new Consulta;
	$filtro=$_POST['cod'];
	$Consulta1->GrupoEvento_verDetalle($filtro);
	if(mysql_num_rows($Consulta1->Resultado)==0)
    {
		print 'No se encontró datos';
	}
	else
	{
    	$row = mysql_fetch_assoc($Consulta1->Resultado,0);
		//`idParticipante`,`Nombre`,`Carnet`,`Semestre_idSemestre`,`Foto`
		$Nombre=$row["Nombre"];
		$Fecha1=$row["FechaInicio"];
		$Fecha2=$row["FechaFinal"];
        $costo=$row["Costo"];
	}
?>
<table width="299">
  <tr>
    <td width="175">Nombre:</td>
    <td width="112"><?php echo $nombre;?></td>
  </tr>
  <tr>
    <td>Fecha de inicio:</td>
    <td><?php echo $Fecha1;?></td>
  </tr>
  <tr>
    <td>Fecha final:</td>
    <td><?php echo $Fecha2;?></td>
  </tr>
  <tr>
    <td>Costo de inscripción:</td>
    <td><?php echo $costo;?></td>
  </tr>
</table>
</body>
</html>
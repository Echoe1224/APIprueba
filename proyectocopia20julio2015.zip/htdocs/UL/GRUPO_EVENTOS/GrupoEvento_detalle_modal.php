<?php

    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	
	$Consulta1=new Consulta;
	$dato=0;
    $filtro=$_POST['idRegistro'];
    session_start();
    $_SESSION['codGE']=$filtro;
    $_SESSION['CE']=$filtro;
    $Consulta1->GrupoEvento_ver2($filtro);
    if(mysql_num_rows($Consulta1->Resultado)==0)
    {
        print 'No se encontró datos';
    }
	else
	{
    	$row = mysql_fetch_assoc($Consulta1->Resultado,0);
		$Nombre=$row["Nombre"];
		$Fecha1=$row["FechaInicio"];
		$Fecha2=$row["FechaFinal"];
        $costo=$row["CostoInscripcion"];
	}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<link rel="stylesheet" href="../../UL/CITEIN/modal.css" />
<div align="right"><span style="cursor:pointer;" onclick="cerrarVentana();" title="Cerrar">X</span></div>
</head>

<body>
<div align="center">        
   <table align="center"width="426" >
  <tr>
    <td width="511">
        <table align="center" width="350">
          <tr>
            <td colspan="2" style="text-align:center" ><h2>Detalle del evento <?php echo $Nombre;?></h2></th></td>
          </tr>
          <tr>
            <td width="203">Fecha de inicio:</td>
            <td width="135"><?php echo $Fecha1;?></td>
          </tr>
          <tr>
            <td>Fecha final:</td>
            <td><?php echo $Fecha2;?></td>
          </tr>
          <tr>
            <td>Costo de inscripción: Q.</td>
            <td><?php echo $costo;?></td>
          </tr>
        </table>
        
      <!-- -----------tabla para mostrar tipo de evento y cantidad--------- -->
      </br>
      <table align="center"  width="370" borde="1" >
          <tr>
            <td width="174"  ><b>Tipo de evento</b></td>
            <td width="184" style="text-align:center" ><b>Cantidad permitida por participante</b></td>
            
          </tr>
             <tr >
            
            <?php        		
			 $Consulta1->GrupoEvento_verDetalle($filtro);
				while ($row = mysql_fetch_assoc($Consulta1->Resultado)) 
                {
					echo'<td>
                            <label>'.$row['Nombre'].'</label>
						</td>';
					echo'<td style="text-align:center">
                            <label>'.$row['Cantidad'].'</label>
                        </td> 
                        </tr>
                        ';    	
				}
			?>
    
            </table>
            
            </body>
      
</html>
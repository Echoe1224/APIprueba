<?php
		include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
			$consulta1=new Consulta;
			$diploma='';
            $x=$y=0;
			$codigo=$_GET['cod'];
	
			$consulta1->GrupoEvento_ver_diploma($codigo);
			$row = mysql_fetch_assoc($consulta1->Resultado);
			$diploma=$row['Diploma'];
			$UrlDiploma='../../UL/DIPLOMA/DiplomaImagen/'.$diploma;
			
			$x=$_POST['EjeX']-0;
			$y=$_POST['EjeY'];
			echo'<p><b>Nota:</b>Por favor doble click para capturar la posición donde se imprimirá la actividad del participante y un último click para mostrar el  mimo</p>';
			if($x!=""&& $y!="")
			{
				$consulta1->Posiciones_actualizar_tipoEvento($x,$y,$codigo);
				//echo $consulta1;
			}
			
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Coordenadas de actividades</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script>
var x,y=0;
function showCoords(event) 
{
     x = event.clientX;
     y = event.clientY;
    var coords = "Aquí aparecerá su texto, dos veces click por favor"
    document.getElementById("Posicion_mouse").innerHTML = coords;
	
}
 function onEnviar()
 {
       document.getElementById("EjeX").value=x;
	   document.getElementById("EjeY").value=y;
    }
	function DarClick()
	{
		document.getElementById('Recargar').click();
	}
	
</script>
<style>
	#Posicion_mouse
{
    z-index:100;
    position:absolute;    
    color:#093;
    font-size:24px;
    font-weight:bold;
    left:<?php echo $x;?>;
    top:<?php echo $y;?>;
    
}

</style>
<title>Documento sin título</title>
</head>

<body>

        <form  method="POST" name="myForm" onSubmit="onEnviar()">
<input type="hidden" name="EjeX" id="EjeX" value="<?php echo $ejex ?>">
<input type="hidden" name="EjeY" id="EjeY" value="<?php echo $ejey ?>">
			<div id="Posicion_mouse"></div>
            <div class="right_content">
     			<img src="<?php echo $UrlDiploma ?>" alt="Esperando imagen" title="image" id="xd" onclick="showCoords(event)" ondblclick="DarClick()" />
        
			</div>
            <p style="text-align:center">
                <input type="submit" value="Recargar" name="Recargar" id="Recargar" />
            </p>

</form>
			
</body>
</html>
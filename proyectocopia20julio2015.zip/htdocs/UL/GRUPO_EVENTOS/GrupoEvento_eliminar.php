<?php
	    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php"; 
		
		$consulta=new Consulta;
		if ($_SERVER["REQUEST_METHOD"] == "POST") 
		{
			if (!empty($_POST["idRegistro"]))
			{
				$id=$_POST['idRegistro'];
				$consulta->GrupoEvento_eliminar($id); 
			}
		}
?>

   <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
      <div style="text-align:center">
      <label>¿Está seguro de eliminar el reguistro?</label><br />
      <input type="submit" value="Elimar" />
      </div>
   </form>
   <form action="GrupoEvento_ver.php">
      <div style="text-align:center">
      <input type="submit" value="Cancelar" />
      </div>
   </form>

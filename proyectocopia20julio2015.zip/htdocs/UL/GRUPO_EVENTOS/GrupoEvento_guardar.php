<?php
        include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		$consulta=new Consulta;
/*
		$id=$_GET["idGrupoEvento"];
		$Nombre=$_GET["nom"];
		$FechaInicio=$_GET["date1"];
		$FechaFinal=$_GET["date2"];
		$Costo=$_GET["Cost"];
*/

        $id="81";
		$Nombre="MESO";
		$FechaInicio="2015-05-05";
		$FechaFinal="2015-05-06";
		$Costo="200";
        
        echo $id.'<br>';
        echo $Nombre.'<br>';
        echo $FechaInicio.'<br>';
        echo $FechaFinal.'<br>';
        echo $Costo.'<br>';

        
		$consulta->Actualizar_GrupoEvento($Nombre,$FechaInicio,$FechaFinal,$Costo,$id);
        echo $consulta->Resultado;
	
					

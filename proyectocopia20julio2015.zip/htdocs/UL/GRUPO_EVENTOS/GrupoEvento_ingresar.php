<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Ingresar Evento</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>

<link type="text/css" rel="stylesheet" href="DatePicker.css"/>
<script type="text/javascript" src="DatePicker.js"></script>
<script type="text/javascript">
function init() {
calendar.set("text_fech1");
calendar.set("text_fech2")
}
</script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/Templates/menu.php";*/
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
    include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
    $consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<link rel="icon" type="image/ico" href="../../favicon.ico" />
<!-- InstanceBeginEditable name="head" -->
    		<?php
$nombreErr=$fecha1Err=$fecha2Err=$costoErr=$canidadErr= $imagenErr=$imagenErr2="";
		$nombre=$fech1=$fech2=$costo=$cantidad=$idTipoEvento=$descripcion=$idGrupoEvento="";
        $diploma="";
		$contador=0;	
		$nombreTipo;
        $temp=1; 
		$fechaActual=date("Y/m/d");
        
		if ($_SERVER["REQUEST_METHOD"] == "POST") 
		{
            
            //INICIA codigo para guardar imagen en la carpeta
        
            $target_dir = "../../UL/DIPLOMA/DiplomaImagen/";
            
            $diploma=basename($_FILES["fileToUpload"]["name"]);
            $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
            $uploadOk = 1;
            $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
            // verificar si la lo que se cargó es una imagen
        
            if(isset($_POST["fileToUpload"])) 
            {
            
                    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
                    if($check !== false) 
                    {
                        echo "El archivo es una imagen - " . $check["mime"] . ". ";
                        $uploadOk = 1;
                    } else 
                    {
                        echo "El archivo no es una imagen.";
                        $uploadOk = 0;
                    }
            }                
                // verificar si la imagen ya existe o no
                if (file_exists($target_file)) 
                {
                    $imagenErr2= "El archivo ya existe.";
                    $uploadOk = 0;
                }
                // verificar el tamaño del archivo
                if ($_FILES["fileToUpload"]["size"] > 1000000) 
                {
                    echo "El archivo es muy pesado, escoge uno menos pesado";
                    $uploadOk = 0;
                }
                // formato de archivos permitidos
                if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                && $imageFileType != "gif" ) 
                {
                    echo  "Disculpe, solo se permiten archivos con extención JPG, JPEG";
                    $uploadOk = 0;
                }
                // Check if $uploadOk is set to 0 by an error
                if ($uploadOk == 0) 
                {
                    echo "Disculpe, no se pudo cargar su archivo.";
                // if everything is ok, try to upload file
                } else 
                {
                    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
                	{
                        echo "    El archivo ". basename( $_FILES["fileToUpload"]["name"]). " fue cargado correctamente.";
                        ++$contador;
                    } else 
                	{
                        echo  "Disculpe, se ha producido un herror al intentar subir su archivo";
                        
                    }
                    
                }
				
				if(empty($_POST["fileToUpload"]))
				{
					$imagenErr='La imagen del diploma es necesario';
				}
   
        
//FINAL del codigo de guardar imgen en respectiva carpeta 

			if (!empty($_POST["text_nombre"]))
			{
				$nombre = test_input($_POST["text_nombre"]);
					++$contador;	
			}
			if (!empty($_POST["text_fech1"]))
			{
				$fech1 = $_POST["text_fech1"];
				if(strtotime($fech1)<strtotime($fechaActual))
				{
					$fecha1Err="La fecha de inicio no puede ser menor a la fecha actual ";
				}
				else
				{
					++$contador;
				}
			} 
            else
            {
                $fecha1Err="Debe ingresar la fecha de inicio";   
            }
			if (!empty($_POST["text_fech2"]))
			{
				$fech2=$_POST["text_fech2"];
				if(strtotime($fech2)<strtotime($fech1))
				{
					$fecha2Err="La fecha de finalización no puede ser menor a la fecha de inicio";
				}
				else
				{
					++$contador;
				}
				
			}
            else
            {
                $fecha2Err="Debe ingresar la fecha de finalización";   
            }
			
			if (!empty($_POST["text_inscripcion"]))
			{
				$costo = test_input($_POST["text_inscripcion"]);
					++$contador;
			}
            if (!empty($_POST["descripcion"]))
    		{
				$descripcion = test_input($_POST["descripcion"]);
				
			}
             
			
			
			/*codigo nuev
				guardar los datos de los textbox*/
                session_start();
                
			$nuevoID=0;
			if($contador==5)
			{
                $consulta1->GrupoEvento_verificar_nombre($nombre);
                $res=$consulta1->Resultado;
            	while($row = mysql_fetch_assoc($res))
                {
    					$temp=$row["Cantidad"];
                        
    			}

    			mysql_free_result($res);
                if($temp==0)
        		{
                
    				$consulta1->Insertar_GrupoEvento($nombre,$fech1,$fech2,$costo,$descripcion,$diploma);
    				while($row1=mysql_fetch_assoc($consulta1->Resultado))
    			    {
    				    $nuevoID=$row1["id"];
    			    }
    			
        			$consulta1->TipoEvento_ver2();
        			$idTipoEvento=0;
        			$dato=$consulta1->Resultado;
        			
    			
        			while($row=mysql_fetch_assoc($dato))
        			{
        				//columnas de la consulta: `idTipoEvento`,`Nombre`,`Estado`
        				$idTipoEvento=$row["idTipoEvento"];
        				$cantidadTipoEvento=$_POST[$idTipoEvento];
        				$consulta1->Insertar_TipoEventoCantidad($idTipoEvento,$nuevoID,$cantidadTipoEvento);
        			}
                    $nombre=$fech1=$fech2=$costo="";
                    header("Location:http:/UL/GRUPO_EVENTOS/GrupoEvento_ver.php");
    			}
                else
                {
                    $nombreErr="Ya existe una actividad con el mismo nombre. \n Por favor intente con otro nombre";
                }
   
		}
       
}
		

function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<style> 
.error {color: #FF0000;}
.myButton {
    background-color: #060;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
	border-radius:6px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#FFF;
	font-family:Arial;
	font-size:13px;
	padding:2px 60px;

	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.myButton:hover {
	background-color:#5cbf2a;
}
.myButton:active {
	position:relative;
	top:1px;
}
.caja {
    
    border-radius: 20px;
    border: 2px solid #8AC007;
    padding: 20px; 
     
}
</style>
<script type="text/javascript">

    $(document).ready(function () {
        yourFunction();
    });
function yourFunction()
    {
         $("#text_inscripcion").on("keyup", function()
         {
            var valid = /^\d{0,4}(\.\d{0,2})?$/.test(this.value),
                val = this.value;
            
            if(!valid)
            {
                this.value = val.substring(0, val.length - 1);
            }
        });
    }
</script>
<script src="datetimepicker_css.js"></script>
    <style>
		.borde
		{
			border: 1px dashed  #FF0000;
		}
	</style>
    <script>
	function onFileSelected(event) 
	{
	  var selectedFile = event.target.files[0];
	  var reader = new FileReader();
	
	  var imgtag = document.getElementById("myimage");
	  imgtag.title = selectedFile.name;
	
	  reader.onload = function(event) {
		imgtag.src = event.target.result;
	  };
	
	  reader.readAsDataURL(selectedFile);
	}
</script>

<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1" onload="init()">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
        if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <div class="modal-container">
            <div id="modal"></div>
        </div>
        <h2 style="text-align:center"> Crear evento </h2>
        <div align="center"><hr width="80%"></div>
<p><span class="error"> * Campos requeridos</span></p>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">

  <table width="925" height="309" border="0" cellspacing="5">
    <tr>
      <td width="576"><table width="576" height="247" border="0" cellspacing="5">
        <tr>
          <td width="171"><label for="text_nombre">Nombre:</label></td>
          <td width="318"><input type="text" name="text_nombre" id="text_nombre" placeholder="Ingrese el nombre del evento." maxlength="25" size="25" value="<?php echo $nombre;?>" pattern="[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ ]{1,100}" title="Hay caracteres no permitidos, intente otra vez" required="required" autofocus="autofocus"/><span class="error">* <?php echo $nombreErr;?></span></td>
        </tr>
        <tr>
          <td><label for="text_fech1">Fecha de inicio:</label></td>
          <td>
              <input type="text" name="text_fech1" id="text_fech1" placeholder="Ingrese fecha de inicio." readonly="readonly" value="<?php echo $fech1;?>"/>
              <span class="error">* <?php echo $fecha1Err;?></span>
          </td>
        </tr>
        <tr>
          <td><label for="text_fech2">Fecha de finalización:</label></td>
          <td>
              <input type="text" name="text_fech2" id="text_fech2" placeholder="Ingrese fecha final." readonly="readonly" value="<?php echo $fech2;?>" />
              <span class="error">* <?php echo $fecha2Err;?></span>
          </td>
        </tr>
        <tr>
          <td>Costo de la inscripción: Q.</td>
          <td><input type="text" name="text_inscripcion" id="text_inscripcion"  placeholder="Ingrese costo de inscripción." size="20" value="<?php echo $costo;?>" pattern="[0-9.]{1,6}" title="Ingrese solamente números" required="required"/></td>
        </tr>
        <tr>
          <td>
            <label for="descripcion">Descripción:</label>
        </td>
          <td>
            <textarea  name="descripcion" id="descripcion" cols="45" rows="5" value=""><?php echo $descripcion?></textarea>
          </td>
        </tr>
        <tr>
          <td>
            <span style="text-align:left">Seleccione la imagen del diploma (Únicamente de extensión .jpg y de tamaño 1000x750):</span>
          </td>
          <td>
          
            <span style="text-align:left">
                <input type="file" name="fileToUpload" id="fileToUpload" class="fileToUpload" onchange="onFileSelected(event)"/>
            </span>
            <span style="text-align:left"><img  height="100" id="myimage" /></span>
            <span class="error">* <?php echo $imagenErr; ?></span>

          </td>
        </tr>
      </table>
      </td>
      <td align="center" width="350">
          <div id="tipos" class="caja">
          </div> 
          <a href="javascript:abrirMPost('','../Modal/TipoEvento_modal2.php')" class="myButton">Agregar otro tipo de actividad</a>
        </td>
        
        </tr>
  </table>
  <div align="right">
  
  </div>
  </br>
  </br>
  <p style="text-align:center">
    <input name="submit" type="submit"  id="submit" value="Guardar"/>
    <input name="cancelar" type="button"  id="cancelar" value="Cancelar" onclick="window.location.href='GrupoEvento_ver.php'"/>
  </p>

    </form>
    <script>
	desplegarTipos();
	function desplegarTipos()
	{
		ProcesarPaginaGetConParametros("GrupoEvento_tipoEventos.php","","tipos");
	}
	</script>
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>

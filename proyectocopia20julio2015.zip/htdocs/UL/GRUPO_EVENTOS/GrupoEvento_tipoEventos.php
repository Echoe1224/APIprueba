<?php
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;

$consulta1->TipoEvento_ver2();
$con=1;
$var1;
echo '<table min-width="300">';
echo '<tr>
        <td width="127" style="text-align:center"><b>Tipo de actividad</b></td>
        <td width="157" style="text-align:center"><b>cantidad de actividades permitidas</b>
        </td>';
					
while($row=mysql_fetch_assoc($consulta1->Resultado))
{
	//columnas de la consulta: `idTipoEvento`,`Nombre`,`Estado`
     
	echo '<tr>';
		echo '<td width="100">';
		echo	'<label> '.$row["Nombre"].'</label>
			  </td>'; 
		echo '<td >
				<input type = "text" name = "'.$row["idTipoEvento"].'" id = "'.$row["idTipoEvento"].'" value="0"  size="5" style = "text-align:center"  pattern="[0-9.]{1,3}" title="Ingrese solamente números" required="required" />';
		echo '</td>
		</tr>';
	++$con;
	
}
			echo '</table>';
?>
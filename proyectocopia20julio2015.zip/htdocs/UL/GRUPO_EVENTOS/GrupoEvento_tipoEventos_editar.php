<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
	$filtro=$_GET['filtro'];
	
?>

<table width="337" height="85" cellspacing="5" >
      <tr>
        <td width="127" style="text-align:center"><b>Tipo de actividad</b></td>
        <td width="157" style="text-align:center"><b>cantidad de actividades permitidas</b></td>
      </tr>
      <tr>
      <?php    			
                        $consulta1->TipoEventoCantidad_ver($filtro);
                        while ($row = mysql_fetch_assoc($consulta1->Resultado)) 
                        {
                            echo'<td>
                            		<label>'.$row['Nombre'].':</label>
								</td>';
							echo' <td>
									<input type="text" name="'.$row["TipoEvento_idTipoEvento"].'" id="'.$row["TipoEvento_idTipoEvento"].'" value="'.$row['Cantidad'].'" size="5" pattern= "[0-9]" required="required" title= "Ingresar solamente números"/>
								</td>
                        		</tr>
                        ';    
                        }
						
        ?>
        
        
      </tr>
</table>
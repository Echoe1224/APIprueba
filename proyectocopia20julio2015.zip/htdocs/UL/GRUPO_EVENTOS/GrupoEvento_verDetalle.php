<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Detalle del evento</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="ajax.js" language="JavaScript"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/Templates/menu.php";*/
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<link rel="icon" type="image/ico" href="../../favicon.ico" />
<!-- InstanceBeginEditable name="head" -->
		<?php
	
?>
  <script>
     function abrir(miVar)
    {
        var parametro=document.createElement("INPUT");
		parametro.setAttribute("type","hidden")
		parametro.name="idRegistro";
		parametro.value=miVar;
		var formulario=document.createElement("FORM");
		formulario.name="otro";
		formulario.method="post";
		formulario.target="_blanck";
		formulario.action="../../UL/DIPLOMA/Diploma.php";
		formulario.appendChild(parametro);
		formulario.submit();
	}
     function abrir2(pagina,parametros)
{
    //ejemplo parametros='\'nombreParametro=valor&Parametro2=valor2\'';
	formulario=document.createElement("FORM");
	formulario.name="form1";
	formulario.method="post";
    formulario.target="_blanck";
	formulario.action=pagina;
	parametros=parametros.toString();
    while(parametros!=""){
    	texto=document.getElementById('texto');
	    pos=parametros.indexOf('&');
		subTexto=parametros.substring(0,pos);
		if(subTexto==""){
        	subTexto=parametros;
            parametros="";
        }     
        else
        	parametros=parametros.substring(pos+1);
		pos=subTexto.indexOf('=');
		if(pos>0)
    	{
        	NombreParametro=subTexto.substring(0,pos);
           	ValorParametro=subTexto.substring(pos+1);
	        if(NombreParametro!=""&&ValorParametro!=""){
				parametro=document.createElement("INPUT");
				parametro.setAttribute("type","hidden")
				parametro.name=NombreParametro;
				parametro.value=ValorParametro;
				formulario.appendChild(parametro);
			}
   		}
	}	
	formulario.submit();
}

    function ChangeName(codigo)
    {
        document.getElementById('cod'+codigo).innerHTML="Volver a imprimir";        
    }
</script>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
       
        <div class="ventana">
            <div id="modal"></div>
        </div>
         <?php
        if(isset($_POST['idRegistro']))
        {
           $Consulta1=new Consulta;
    $dato=0;
    $filtro=$_POST['idRegistro'];
    session_start();
    $_SESSION['codGE']=$filtro;
    $_SESSION['CE']=$filtro;
    $Consulta1->GrupoEvento_ver2($filtro);
    if(mysql_num_rows($Consulta1->Resultado)==0)
    {
        print 'No se encontró datos';
    }
	else
	{
    	$row = mysql_fetch_assoc($Consulta1->Resultado,0);
		$Nombre=$row["Nombre"];
		$Fecha1=$row["FechaInicio"];
		$Fecha2=$row["FechaFinal"];
        $costo=$row["CostoInscripcion"];
	}
        }
		else
        {
			$filtro=0;
        }
        
        if ($filtro>0)
        {
		
        ?>
        <form id="form1" name="form1" method="post" action="">
            <input type="hidden" name="formulario" id="formulario" value="detalle" />
            <input type="hidden" name="paginaFiltro" id="paginaFiltro" value="GrupoEvento_verDetalle_filtrar.php" />
            <input type="hidden" name="paginaEliminar" id="paginaEliminar" value="..\..\BLL\eliminar.php" />
            
            <div style="text-align:right">
                <a style="padding-left:50px; color:#333; text-decoration:none" href="GrupoEvento_diploma.php" target="_blanck"><i class="icon icon-cogs"></i>Configurar coordenadas</a>
            </div>
            <div align="center">
                </br>
                <h2>Diplomas del evento <?php echo $Nombre;?></h2>
                <hr width="80%">
            </div> 
            </br>
            </br>
   <div align="center">        
   
    <p><b>Seleccione el semestre a imprimir diploma</b></p>

        <div id="listaSemestre">
                <select name="lista_semestre" id="lista_semestre" onchange="openVentana('lista_semestre','../Modal/semestre_modal.php','idDiv=listaSemestre'),Filtrar3('idSemestre='+document.getElementById('lista_semestre').value);">
                    <option disabled selected> -- Actividad -- </option>
                    <?php
                    
                    $consulta1->Idgrupoevento_ver_su_tipoEvento($_POST['idRegistro'],$filtro);
                    while ($row = mysql_fetch_assoc($consulta1->Resultado)) 
                    { 
                        echo '<option  value="A'.$row['idEvento'].'" >'.$row['Nombre'].'</option>';
                    }    
                    ?>
                    <option disabled> -- Semestre -- </option>
                    <?php
                        	$Consulta1->semestre_ver();
            				while ($row = mysql_fetch_assoc($Consulta1->Resultado)) 
                            { 
            					echo '<option  value="S'.$row['id'].'">'.$row['Semestre'].'</option>';
            				}    
                            
                            echo '<option value= "100">Todos... </option>';
            		 ?>
                </select>
                
        </div>
        <br/>     
  </tr>
</table>
</div>
        <br/>
        <br/>
        
        <script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    Filtrar3('idSemestre='+document.getElementById('lista_semestre').value);
                });
         </script>
           <div id="cuadro">
                <h2>Listado de participantes del semestre seleccionado</h2>
            <div>
            	<label for="texto_filtro">Filtrar: </label>
            	<input type="text" name="texto_filtro" id="texto_filtro" onKeyUp="Filtrar3('idSemestre='+document.getElementById('lista_semestre').value);" />
            </div>
            <br/>
            
            <div class="dataGridViewDiv" id="resultados"></div>
            </div>


</form>
<?php
    }
    else
    {
        ?>
        <h2 align="center">Necesita seleccionar un Evento</h2>
        <br />
        <h4 align="center"><a href="GrupoEvento_ver.php"> Seleccionar</a></h4>
        <?php
    }
    ?>

<script>
/* Modal***************************************************************************** */
    /*Función que se llama desde la página del formulario (ej: pagina.php)*/
    function procesar(pagina,parametros){
        /*var parametros = "id="+ $('#idDato').val()+"&nombre="+$('#nombreDato').val();*/
        ProcesarPaginaPostConParametros(pagina,parametros,"modal");
    }
    function openVentana(idLista,pagina,parametros){
    	if(document.getElementById(idLista)!=null && document.getElementById(idLista).value=="+")
    	{
    		$(".ventana").slideDown("slow");
    		//ProcesarPaginaGetConParametros('\'pagina.php\'','');
    		//parametros: url,idLista,idDiv
    		var param="url="+pagina+"&idLista="+idLista+"&"+parametros;
    		ProcesarPaginaPostConParametros(pagina,param,"modal");
    	}
    }
    function closeVentana(ingresado,pagina,consulta,idLista,divLista){
    	$(".ventana").slideUp("fast");
    /*			var consulta="SELECT `id`, `Nombre` FROM `Prueba`";
    	deben ser id y Nombre colocar as id y as Nombre si las columnas se llaman diferente
    	var idLista="lista";*/
    	if(ingresado==1)
    	{
    		var funcion="openVentana(\'"+idLista+"\','"+pagina+"','idDiv="+divLista+"');";
    		var parametros="consulta="+consulta+"&idLista="+idLista+"&funcion="+funcion;
    		//Verificar la direccion de la pagina /BLL/lista.php    ../ => retroceder una carpeta
    		ProcesarPaginaPostConParametros("../../BLL/lista.php",parametros,divLista);
    	}
    }
    function ingresarDatos(pagina,parametros)
    {
    	var param="url="+pagina+"&"+parametros;
    	ProcesarPaginaPostConParametros(pagina,param,"modal");
    }
</script>
        
<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
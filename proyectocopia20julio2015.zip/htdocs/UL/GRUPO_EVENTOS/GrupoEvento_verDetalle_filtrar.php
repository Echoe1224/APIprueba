<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Filtrando...</title>
<script src="../../BLL/ajax.js" language="javascript"></script>

</head>

<body>
    <?php
    //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$Consulta1=new Consulta;
	session_start();
    
	$filtro=$_GET['filtro'];
    $idgrupo=$_POST['idRegistro'];
    //echo $filtro;
    $idSemestre=$_GET['idSemestre'];
	$idGrupoEvento=$_SESSION['codGE'];
//Consulta que se quiere ver en el dataGridView
    $numero=0;
    if($idSemestre=="100")
    {
        $Consulta1->Participante_diploma_todos($idGrupoEvento,$filtro);
                
    }
    else if(substr($idSemestre,0,1)=='S')
    {
        //$id=substr($idSemestre,1,2)
        $id = substr($idSemestre, 1);
        $Consulta1->Participante_diploma_semestre($id,$idGrupoEvento,$filtro);
        
    }
    else if(substr($idSemestre,0,1)=='A')
    {
        //echo 'hola '.$idgrupo;
        //$id=substr($idSemestre,1,2)
        $id = substr($idSemestre, 1);
        $Consulta1->Evento_ver_su_actividad($id,$idGrupoEvento,$filtro);
    }
  
   if(mysql_num_rows($Consulta1->Resultado)==0)
	{
	  print 'No se encontraron datos';  
	}
	else
	{
		//Se agrega el codigo del ancabezado de la tabla
		print'<table class = "tabla">';
		echo "\n";
		echo '<thead class="dgv-titulo">';
		//$i:desde que columna se empieza a graficar
		$i = 1;
//Encabezado del dataGridView
		while ($i < mysql_num_fields($Consulta1->Resultado)) {
				$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				echo '<td>'.$metadatos->name.'</td>';
				$i++;
			}
			echo '<td>Acciones</td>';
		print '</thead>';
		echo "\n";
//Datos del dataGridView
		$agregar=false;
		while($row=mysql_fetch_assoc($Consulta1->Resultado))
		{
            $clase="filaTablaSinFondo";
    		if($agregar)
				$clase="filaTablaConFondo";
			//donde se agregan los datos que se mostraran en cada columna
		print'<tr  class="'.$clase.'">';
			echo "\n";
			//$i:desde que columna se empieza a graficar
			$i = 1;
			while ($i < mysql_num_fields($Consulta1->Resultado) && $i!=0) {
				$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				//para agregar color a una fila
				
				echo '<td>';
			//Columnas que son de tipo booleano.						
				if($metadatos->name=="Habilitado")
				{
				   $checkeado="";
				   if($row[$metadatos->name]!=0)
					$checkeado= "checked=\"checked\"";
				   echo '<input name="checkboxAsistencia2" type="checkbox" id="checkboxAsistencia2" '.$checkeado.' onclick="javascript: return false;" />';
				}
				else
					echo $row[$metadatos->name];
				echo "</td>\n";						
				++$i;
                
                
                
			}

//Opciones que tendra cada registro del dataGridView
					echo '<td>';
        	//Responder Encuesta
			            //imprimir
                    
						        if(substr($idSemestre,0,1)=='S' || $idSemestre=="100")
                                {
                                echo	'<i class="icon icon-printer"><span id="cod'.$numero.'" style="cursor:pointer"; onclick="abrir('.$row['idParticipante'].'),ChangeName('.$numero.');">Imprimir</span"></i>';
                               
                                ++$numero;
                                //onclick="abrir2(\'../../UL/DIPLOMA/DIPLOMA1.php\',\'idParticipante='.$row['idParticipante'].'&actividad='.$row['Actividad'].'\')
                                }
                                if(substr($idSemestre,0,1)=='A')
                                {
                                echo    '<i class="icon icon-printer"><span id="cod'.$numero.'" style="cursor:pointer"; onclick="abrir2(\'../../UL/DIPLOMA/DIPLOMA1.php\',\'idParticipante='.$row['Participante_idParticipante'].'&actividad='.$row['Actividad'].'&Duración='.$row['Duración'].'\'),ChangeName('.$numero.');">Imprimir</span"></i>';
                               
                                ++$numero;
                                }
                                
                            
			echo "</td>\n";	
            
			echo "\n";
			print '</tr>';
			if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
		}
		print '</table>';
	}		
    

?>
</body>
</html>
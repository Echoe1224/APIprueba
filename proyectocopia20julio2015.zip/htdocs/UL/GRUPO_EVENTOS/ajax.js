//Esta es la funcion del Ajax, le puse Buscador por gusto
function Buscador()
{
        var xmlhttp=false;
        try 
        {
               xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
        } 
        catch (e) 
        {
               try
               {
                  xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
               } 
			   catch (E) 
			   {
                  xmlhttp = false;
               }
        }
 
        if (!xmlhttp && typeof XMLHttpRequest!='undefined') 
		{
               xmlhttp = new XMLHttpRequest();
			   xmlhttp.overrideMimeType('text/xml');
        }

        return xmlhttp;
}
function MostrarPagina(pagina)
{
    var tabla=document.getElementById('modal');
	//var pag=document.getElementById('pagina').value;
//	var parametros=document.getElementById('parametros');
	var ajax=Buscador();
	ajax.open('GET',pagina+"?url="+pagina);
//	ajax.open('POST',pag);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			tabla.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}
function Semestre()
{
	var filtro=document.getElementById('texto_filtro').value;
    var semestre=document.getElementById('lista_semestre');
    var idSemestre=semestre.options[semestre.selectedIndex].value;
	var tabla=document.getElementById('resultados');
	var pag=document.getElementById('paginaFiltro').value;
	var ajax=Buscador();
	ajax.open('GET',pag+'?filtro='+filtro+'&idSemestre='+idSemestre);
//	ajax.open('POST',pag);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			tabla.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}

function EventoFiltro()
{
	var filtro=document.getElementById('texto_filtro').value;
        var grupoevento=document.getElementById('grupoevento').value;
	var tabla=document.getElementById('resultados');
	var pag=document.getElementById('paginaFiltro').value;
	var ajax=Buscador();
	ajax.open('GET',pag+'?filtro='+filtro+'&grupoevento='+grupoevento);
//	ajax.open('POST',pag);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			tabla.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}
/*function Filtrar2()
{
    //Función para filtrar datos y desplegar en un DIV diferente al de 'resultados'
	ajax=Buscador();
	panel=document.getElementById('detalle');
	filtro=document.getElementById('texto_filtro').value;
    pag=document.getElementById('paginaFiltro2').value;
	ajax.open('GET',pagina+'?filtro='+filtro);
//	ajax.open('POST',pag);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			panel.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}*/
function Filtrar2()
{
	//Función para filtrar datos y desplegar en un DIV diferente al de 'resultados'
	var filtro=document.getElementById('texto_filtro').value;
//	pag=document.getElementById('paginaFiltro').value;
	var panel = document.getElementById('detalle');
	var pagina=document.getElementById('paginaFiltro2').value;
	var ajax=Buscador();
	ajax.open('GET',pagina+'?filtro='+filtro);
//	ajax.open('POST',pag);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			panel.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}
function Filtrar3(parametros)
{
	var filtro=document.getElementById('texto_filtro').value;
	var tabla=document.getElementById('resultados');
	var pag=document.getElementById('paginaFiltro').value;
	var ajax=Buscador();
	ajax.open('GET',pag+'?filtro='+filtro+'&'+parametros);
//	ajax.open('POST',pag);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			tabla.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}
function Editar(idRegistro)
{
	//resultados tiene que ser un DIV (un "panel") para desplegar los resultados de la página a abrir
	var panel=document.getElementById('resultados');
	var pagina=document.getElementById('paginaEditar');
	var ajax=Buscador();
	ajax.open('GET',pagina+"?idRegistro="+idRegistro);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			panel.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}
/*
	Esta función simplemente abrira una pagina que tiene que estar escrito
	en un campo oculto <hidden value="guardar.php" (cualquier página)
	El método es post asi que en "guardar.php"
	tendran que recibir esos parametros que necesiten procesar.

*/
function AbrirPagina(idRegistro,pagina)
{
	var parametro=document.createElement("INPUT");
	parametro.setAttribute("type","hidden")
	parametro.name="idRegistro";
	parametro.value=idRegistro;
	var formulario=document.createElement("FORM");
	formulario.name="form1";
	formulario.method="post";
	formulario.action=pagina;
	formulario.appendChild(parametro);
	formulario.submit();
/*	<form id="form1" name="form1" method="post" action="">*/
	/*location.href=carpeta de la página que esta llamando a la función*/
/*	setTimeout("location.href = \""+pagina+"\"",3000);*/
}
function AbrirPagina2(idRegistro,idRegistro2,pagina)
{
    var parametro=document.createElement("INPUT");
	parametro.setAttribute("type","hidden")
	parametro.name="idRegistro";
	parametro.value=idRegistro;
    var parametro2=document.createElement("INPUT");
    parametro2.setAttribute("type","hidden")
	parametro2.name="idRegistro2";
	parametro2.value=idRegistro2;
	var formulario=document.createElement("FORM");
	formulario.name="form1";
	formulario.method="post";
	formulario.action=pagina;
	formulario.appendChild(parametro,parametro2);
	formulario.submit();
/*	<form id="form1" name="form1" method="post" action="">*/
	/*location.href=carpeta de la página que esta llamando a la función*/
/*	setTimeout("location.href = \""+pagina+"\"",3000);*/
}
function AbrirPaginaPostConParametros(pagina,parametros)
{
	//ejemplo parametros='\'nombreParametro=valor&Parametro2=valor2\'';
	var formulario=document.createElement("FORM");
	formulario.name="form1";
	formulario.method="post";
	formulario.action=pagina;
	var parametros=parametros.toString();
    while(parametros!=""){
    	var texto=document.getElementById('texto');
	    pos=parametros.indexOf('&');
		subTexto=parametros.substring(0,pos);
		if(subTexto==""){
        	subTexto=parametros;
            parametros="";
        }     
        else
        	parametros=parametros.substring(pos+1);
		pos=subTexto.indexOf('=');
		if(pos>0)
    	{
        	NombreParametro=subTexto.substring(0,pos);
           	ValorParametro=subTexto.substring(pos+1);
	        if(NombreParametro!=""&&ValorParametro!=""){
				parametro=document.createElement("INPUT");
				parametro.setAttribute("type","hidden")
				parametro.name=NombreParametro;
				parametro.value=ValorParametro;
				formulario.appendChild(parametro);
			}
   		}
	}	
	formulario.submit();
}

function ProcesarPaginaPostConParametros(pagina,parametros,panel)
{
	/*ejemplo
	parametros="nombreParametro=valor&Parametro2=valor2";
	pagina="pagina.php";
	panel="nombreDIV";
	*/
	var resultado=document.getElementById(panel);
	var ajax=Buscador();
	ajax.open('POST',pagina);
	ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			resultado.innerHTML = ajax.responseText;
		}
	}
	ajax.send(parametros);
}
function ProcesarPaginaGetConParametros(pagina,parametros)
{
	//ejemplo parametros='\'nombreParametro=valor&Parametro2=valor2\'';
	var panel=document.getElementById('resultados');
	var ajax=Buscador();
	ajax.open('GET',pagina+"?"+parametros);
	ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			panel.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}
function Procesar(idRegistro,pagina)
{
	//resultados tiene que ser un DIV (un "panel") para desplegar los resultados de la página a abrir
	var panel=document.getElementById('resultados');
	var parametro="idRegistro="+idRegistro;
	var ajax=Buscador();
	ajax.open('POST',pagina);
	ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			panel.innerHTML = ajax.responseText;
		}
	}
	ajax.send(parametro);
}


function Eliminar(idRegistro)
{
	if(confirm("Esta seguro de eliminar el registro"))
	{
			var panel=document.getElementById('resultados');
			var pagina=document.getElementById('paginaEliminar').value;
			var params = "idRegistro="+idRegistro+"&formulario="+document.getElementById('formulario').value;
            ajax=Buscador();
            ajax.open('POST',pagina);
			ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			/*ajax.setRequestHeader("Content-length", params.length);
			ajax.setRequestHeader("Connection", "close");*/
            ajax.onreadystatechange=function()
            {
                  if(ajax.readyState == 4)
                  {
					  if (ajax.status == 200) {
                        panel.innerHTML = ajax.responseText;
						setTimeout("Filtrar();",interval = 3000);
					  }
                  }
            }
            ajax.send(params);
	}
	else
		return false;
}

function Eliminardoblere(idRegistro,idRegistro2,ver)
{
	if(confirm("Esta seguro de eliminar el registro"))
	{
			var panel=document.getElementById('resultados');
			var pagina=document.getElementById('paginaEliminar').value;
			var params = "idRegistro="+idRegistro+"&idRegistro2="+idRegistro2+"&verificacion="+ver+"&formulario="+document.getElementById('formulario').value;
alert(idRegistro);
            ajax=Buscador();
            ajax.open('POST',pagina);
			ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			/*ajax.setRequestHeader("Content-length", params.length);
			ajax.setRequestHeader("Connection", "close");*/
            ajax.onreadystatechange=function()
            {
                  if(ajax.readyState == 4)
                  {
					  if (ajax.status == 200) {
                        panel.innerHTML = ajax.responseText;
						setTimeout("Filtrar();",interval = 3000);
					  }
                  }
            }
            ajax.send(params);
	}
	else
		return false;
}
<html>
<head>
<link type="text/css" rel="stylesheet" href="DatePicker.css"/>
<script type="text/javascript" src="DatePicker.js"></script>
<script type="text/javascript">
function init() {
calendar.set("date");
}
</script>
</head> <body onload="init()">
<form action="" method="post">
<input type="text" name="date" id="date">
</form>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Editar gasto</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="../../BLL/modal.js" language="JavaScript"></script>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
    <div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar evento</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <?php
        if(isset($_POST['idRegistro']))
        {
        	$idgasto=$_POST['idRegistro'];
        }
		else
        {
			$idgasto=0;
        }
        $consulta1->Gasto_seleccionar("$idgasto");
        $res=$consulta1->Resultado;
        while($row=mysql_fetch_assoc($res))
        {
            $nodocumento=$row["NoDocumento"];
            $descripcion=$row["Descripcion"];
            $idtipogasto=$row["IdTipoGasto"];
            $tipogasto=$row["NombreTipo_Gasto"];
            $monto=$row["Monto"];
            $idpatrocinador=$row["idPatrocinador"];
            $patrocinador=$row["Patrocinador"];
        }
        if ($idgasto>0)
        {
        ?>
        <div class="ventana">
            <div id="modal"></div>
        </div>
    <form id="form1" method="post" action="<?php echo htmlspecialchars("/DAL/guardar.php");?>">
      	<p>
      	  <input name="formulario" id="formulario"
         value="editar_gastos" type="hidden">
   	  </p>
      	  <H2 align="center" >Editar gastos</H2><br>
      	  
      	  
   	  </p>
    <div align="center">
   	  <table style="align: center" width="550" cellspacing="5" align="center" border="0">
   	    <tr>
              <td style="text-align: right;">No. documento:</td>
              <td><input name="nodocumento"
         id="nodocumento" required="required" type="text" maxlength="45" size="38" pattern="[0-9]{1,45}" required="" title="Se necesita un nombre de documento (solamente números)" value="<?php echo $nodocumento; ?>"/></td>
        </tr>
            <tr>
              <td style="text-align: right;"><label>Descripción: </label></td>
              <td><textarea name="descripcion" id="descripcion" required="required" cols="45" rows="5" maxlength="45" required="" title="Se necesita una descripción" pattern="[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ,. ]{1,45}"><?php echo $descripcion; ?></textarea></td>
            </tr>
            <tr>
              <td style="text-align: right;"><label>Tipo de gasto: </label></td>
              <td>
              <div id="listaTipogasto">
                <select  name="TipoGasto" id="TipoGasto"
            onchange="openVentana('TipoGasto','../Modal/tipogasto_modal.php','idDiv=listaTipogasto');">
                <option selected=selected value="<?php echo $idtipogasto; ?>"><?php echo $tipogasto; ?></option>
                <?php				
                $consulta1->TipoGasto_Listar();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option value=".$row['id'].">".$row['nombre']."</option>";
				}
				echo '<option value="+">Agregar otro</option>';
				?>
			</select>
            </div>
              </td>
            </tr>
            <tr>
              <td style="text-align: right;"><label>Monto: </label></td>
              <td><input name="monto" id="monto" required="required" type="text" size="38" value="<?php echo $monto; ?>" maxlength="10" size="20"  pattern="\d+(\.\d{1,10})?" required="" title="Ingrese solamente números" /></td>
            </tr>
            <tr>
              <td style="text-align: right;"><label>Patrocinador: </label></td>
              <td><div id="listaPatrocinador">
                <select  name="Patrocinador" id="Patrocinador"
            onchange="openVentana('Patrocinador','../Modal/patrocinador_modal.php','idDiv=listaPatrocinador');">
                <option selected=selected value="<?php echo $idpatrocinador; ?>"><?php echo $patrocinador; ?></option>
                <?php    			
                $consulta1->Listar_Patrocinadores();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option value=".$row['id'].">".$row['nombre']."</option>";
				}
				echo '<option value="+">Agregar otro</option>';
				?>
			</select>
            </div>
              <input style="display:none" type"text" name="idgasto" value="<?php echo $idgasto; ?>">
              </td>
            </tr>
              <tr> 
              <td style="text-align: right;"><label></label></td>
              <td><input name="EventoGrupo" id="EventoGrupo" required="required"
         type="text" style="display:none" value="<?php echo $_SESSION['idGrupoEvento']?>"/></td>
            </tr>
        </table>
        </br>
  <input id="submit" value="Guardar" type="submit">
  <input style="display:inline" type="button" name="boton" id="boton" value="Cancelar" onClick="window.location.href='/UL/Gastos/Gastos_ver.php'"/>
  </div>
    </form> 
    <?php
    }
    else
    {
        ?>
        <h2 align="center">Necesita seleccionar gasto</h2>
        <br />
        <h4 align="center"><a href="Gastos_ver.php"> Seleccionar</a></h4>
        <?php
    }
    ?>
		<!-- InstanceEndEditable -->
<?php
    }
    }
    ?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Ingresar gasto</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="../../BLL/modal.js" language="JavaScript"></script>

<?php
    $MiConsulta=new Consulta;
    
$docErr=$desErr=$montoErr="";
$doc=$des=$monto="";
$contador=0;

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
	if (empty($_POST["nodocumento"]))
	{
		$docErr="El numero de documento es requerido";
	}
	else
	{
		$doc = test_input($_POST["nodocumento"]);
		if (!preg_match("/^[0-9]*$/",$doc)) 
		{
  			$nombreErr="Ingrese solamente numeros"; 
		}
		else
		{
			++$contador;
		}
	}
	if (empty($_POST["descripcion"]))
	{
		$desErr ="La descripción es requerido";
	}
	else
	{
		$des = test_input($_POST["descripcion"]);
		if (!preg_match("/^[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ,. ]*$/",$des)) 
		{
    	 	$desErr ='El formato de la descripción es inválido.';
		}
		else
		{
			++$contador;
		}
	}
	if (empty($_POST["monto"]))
	{
		$montoErr="El monto es requerido";
	}
	else
	{
        $monto=$_POST["monto"];
			++$contador;
	}
	
	if($contador==3)
	{   
        $tipogasto=$_POST["TipoGasto"];
        $patrocinador=$_POST["Patrocinador"];
        $eventogrupo=$_POST["EventoGrupo"];        
        $consulta1->Insertar_gasto($doc,$tipogasto,$des,$monto,$patrocinador,$eventogrupo);
        $doc=$tipogasto=$des=$monto=$patrocinador=$eventogrupo="";
        header("Location: http:/UL/Gastos/Gastos_ver.php");
	}


}
function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<style> 
.error {color: #FF0000;} 
</style>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
    <div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar evento</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <div class="ventana">
            <div id="modal"></div>
        </div>
<form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
      	<p>
      	  <input name="formulario" id="formulario"
         value="Registro_gastos" type="hidden">
   	  </p>
      	  <H2 align="center" >Registrar Gasto</H2><br>
      	  
      	  
   	  </p>
         <div align="center">
         <span class="error">* Campos requeridos.</span>
   	  <table style="align: center" width="750" cellspacing="5" align="center" border="0">
   	    <tr>
              <td style="text-align: right;">No. documento:</td>
              <td>
              <input name="nodocumento" id="nodocumento"  type="text" value="<?php echo $doc;?>" size="38" placeholder="Ingrese el número de documento." maxlength="45" pattern="[0-9]{1,45}" required="" title="Se necesita un numero de documento (solamente números)"/>
              <span class="error">* <?php echo $docErr;?></span>
              </td>
        </tr>
            <tr>
              <td style="text-align: right;"><label>Descripción: </label></td>
              <td><textarea name="descripcion" id="descripcion" placeholder="Ingrese la descripción del gasto." cols="45" rows="5" maxlength="45" pattern="[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ,. ]{1,45}" required="" title="Se necesita una descripción"> <?php echo $des;?></textarea>
              <span class="error">* <?php echo $desErr;?></span>
              </td>
            </tr>
            <tr>
              <td style="text-align: right;"><label>Tipo de gasto: </label></td>
              <td>
              <div id="listaTipogasto">
                <select  name="TipoGasto" id="TipoGasto"
            onchange="openVentana('TipoGasto','../Modal/tipogasto_modal.php','idDiv=listaTipogasto');">
            	<?php				
                $consulta1->TipoGasto_Listar();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['id'].">".$row['nombre']."</option>";
				}
				echo '<option value="+">Agregar otro</option>';
				?>
			</select>
            </div>
            </td>
            </tr>
            <tr>
              <td style="text-align: right;"><label>Monto: </label></td>
              <td><input name="monto" id="monto" type="text" size="38" value="<?php echo $monto;?>" maxlength="10" size="20"  placeholder="Ingrese el monto del gasto." pattern="\d+(\.\d{1,10})?" required="" title="Ingrese solamente números y un punto" />
              <span class="error">* <?php echo $montoErr;?></span>
              </td>
            </tr>
            <tr>
              <td style="text-align: right;"><label>Patrocinador: </label></td>
              <td>
             <div id="listaPatrocinador">
                <select  name="Patrocinador" id="Patrocinador"
            onchange="openVentana('Patrocinador','../Modal/patrocinador_modal.php','idDiv=listaPatrocinador');">
                <?php				
                $consulta1->Listar_Patrocinadores();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['id'].">".$row['nombre']."</option>";
				}
				echo '<option value="+">Agregar otro</option>';
				?>
			</select>
            </div>
             </td>
            </tr>
              <tr> 
              <td style="text-align: right;"><label></label></td>
              <td><input name="EventoGrupo" id="EventoGrupo" required="required"
         type="text" style='display: none;' value="<?php echo $_SESSION['idGrupoEvento']?>"/></td>
            </tr>
        </table>
<br/>
  <input id="submit" value="Guardar" type="submit">
  <input style="display:inline" type="button" name="boton" id="boton" value="Cancelar" onclick="window.location.href='Gastos_ver.php'">
  </div>
    </form> 
		<!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
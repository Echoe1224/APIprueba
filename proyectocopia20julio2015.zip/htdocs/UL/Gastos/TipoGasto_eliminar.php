<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Eliminar tipo de gasto</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>
<?php
    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->

<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
    <div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {?>
    <nav class="menu">
        <ul>
            <li><a href="../Inicio/inicio.php"><span class="primero"><i class="icon icon-home"></i></span>CITEIN</a></li>
<!-- Menú Evento -->
            <li><a href="../Evento/Evento_ver.php"><span class="segundo"><i class="icon icon-table2"></i></span>EVENTO</a>
                <ul>
                    <li><a href="../Evento/Evento_ver.php">Ver eventos</a></li>
                    <li> <a href="../Evento/Evento_ingresar.php" >Crear evento</a></li>
                    <li> <a href="../Evento/Educador_ver.php" >Ver educadores</a></li>
                    <li> <a href="../Evento/Educador_ingresar.php" >Nuevo educador</a></li>
                    <li> <a href="../Encuesta/Encuesta_ver.php" >Ver encuestas</a></li>
                    <li> <a href="../Encuesta/Encuesta_ingresar.php" >Nueva encuesta</a></li>
                </ul>
            </li>
<!-- Menú Participante -->
            <li><a href="../Participante/Participante_ver_informacion.php"><span class="tercero"><i class="icon icon-accessibility"></i></span>PARTICIPANTE</a>
                <ul>
                    <li><a href="../Participante/Participante_ver.php">Ver participantes</a></li>
                    <li><a href="../Participante/Participante_ingresar.php">Nuevo participante</a></li>
                </ul>
            </li>
<!-- Menú Administrador -->
            <?php if($_SESSION['tipo']==1){ ?>
            <li><a href="../Usuarios/Usuario_ver.php"><span class="cuarto"><i class="icon icon-user-tie"></i></span>ADMINISTRADOR</a>
                <ul>
                    <li><a href="../Usuarios/Usuario_ver.php">Ver usuario</a></li>
                    <li><a href="../Usuarios/Usuario_ingresar.php">Nuevo usuario</a></li>
                    <li><a href="../GRUPO_EVENTOS/GrupoEvento_ingresar.php">Nuevo grupo de eventos</a></li>
                    <li><a href="../GRUPO_EVENTOS/GrupoEvento_ver.php">Ver grupos de eventos</a></li>
                </ul>
            </li>
            <?php } ?>
<!-- Menú Personal -->
            <li><a href="../Evento/Personal_ver.php"><span class="quinto"><i class="icon icon-user"></i></span>PERSONAL</a>
                <ul>
                    <li><a href="../Evento/Personal_ver.php">Ver personal</a></li>
                    <li><a href="../Evento/Personal_ingresar.php">Nuevo personal</a></li>
                    <li><a href="Gastos_ver.php">Ver gastos</a></li>
                    <li><a href="Gasto_ingresar.php">Nuevo gasto</a></li>
                    <li><a href="../PATROCINADOR/Patrocinador_ver.php">Ver patrocinadores</a></li>
                    <li><a href="../PATROCINADOR/Patrocinador_ingresar.php">Nuevo patrocinador</a></li>
                </ul>
            </li>
<!-- Menú Reportes -->
            <li><a href="../Reporte/GrupoEvento_reporte.php"><span class="sexto"><i class="icon icon-file-text2"></i></span>REPORTES</a>
                <ul>
                    <li><a href="../Reporte/GrupoEvento_reporte.php">De grupo de eventos</a></li>
                    <li><a href="../Reporte/Evento_reporte.php">De eventos</a></li>
                    <li><a href="../Reporte/Participante_reporte.php">De participantes</a></li>
                    <li><a href="../Reporte/Personal_reporte.php">De personal</a></li>
                    <li><a href="../Reporte/Patrocinador_reporte.php">De patrocinadores</a></li>
                    <li><a href="../Reporte/Gastos_reporte.php">De gastos</a></li>
                </ul>
            </li>
<!-- Menú Mantenimiento -->
            <li><a href="#"><span class="septimo"><i class="icon icon-equalizer2"></i></span>Mantenimiento</a>
                <ul>
                    <li><a href="../Evento/Semestre_ver.php">Ver semestres</a></li>
                    <li><a href="../Jornada/Jornada_ver.php">Ver jornadas</a></li>
                    <li><a href="../Seccion/Seccion_ver.php">Ver sección</a></li>
                    <li><a href="../Evento/TipoEvento_ver.php">Ver tipos de evento</a></li>
                    <li><a href="../Evento/Lugar_ver.php" >Ver lugares</a></li>
                    <?php if($_SESSION['tipo']==1){ ?>
                    <li><a href="TipoGasto_ver.php">Ver tipos de gasto</a></li>
                    <?php } ?>
                    
                </ul>
            </li>
        </ul>
    </nav>
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <?php
        if(isset($_POST["idRegistro"]))
        {
    		$idtipogasto=$_POST['idRegistro'];
        }
		else
        {
			$idtipogasto=0;
        }
        $consulta1->TipoGasto_seleccionar("$idtipogasto");
        $res=$consulta1->Resultado;
        while($row=mysql_fetch_assoc($res))
        {
            $desc=$row["TipoGasto"];
        }
        ?>
    <form id="form1" method="post" action="<?php echo htmlspecialchars("/DAL/guardar.php");?>">
      	<p>
      	  <input name="formulario" id="formulario"
         value="eliminar_TipoGasto" type="hidden">
   	  </p>
      	  <H3 align="center" >Esta seguro que quiere eliminar el tipo gasto:</H3><br>
          <h3 align="center"><?php echo $desc; ?></h3>
      	  
   	  </p>
         <input style="display:none" name="idtipogasto" id="idtipogasto" required="required" value="<?php echo $idtipogasto; ?>" type="text" /></td>
         <input id="submit" value="Eliminar" type="submit">
    </form>
    <form action="TipoGasto_ver.php">
        <br/>
        <input type="submit" value="Cancelar">
    </form>
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
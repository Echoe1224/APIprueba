<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Filtrando...</title>
<script src="../../BLL/ajax.js" language="javascript"></script>
<script src="../../UL/Jornada/ajax1.js" language="javascript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>

<body>
    <?php
    //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";  
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";   
    $Consulta1=new Consulta;
    $q=$_GET['filtro'];
//Consulta que se quiere ver en el dataGridView
   $Consulta1->listar_TipoGasto($q);
   if(mysql_num_rows($Consulta1->Resultado)==0)
    {
	  print 'No se encontró datos';  
	}
	else
    {
		//Se agrega el codigo del ancabezado de la tabla
		print'<table class = "tabla">';
		echo "\n";
		echo '<tr class="dgv-titulo">';
		//$i:desde que columna se empieza a graficar
		$i = 1;
//Encabezado del dataGridView
		    while ($i < mysql_num_fields($Consulta1->Resultado)) {
				$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				echo '<td>'.$metadatos->name.'</td>';
				echo "\n";
				$i++;
			}
			echo '<td>Opciones</td>';
			echo "\n";
		print '</tr>';
		echo "\n";
//Datos del dataGridView
		$agregar=false;
		while($row=mysql_fetch_assoc($Consulta1->Resultado))
		{
			$clase="filaTablaSinFondo";
			if($agregar)
				$clase="filaTablaConFondo";
			//donde se agregan los datos que se mostraran en cada columna
			print'<tr  class="'.$clase.'">';
			echo "\n";
			//$i:desde que columna se empieza a graficar
			$i = 1;
			while ($i < mysql_num_fields($Consulta1->Resultado) && $i!=0)
            {
				    $metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				//para agregar color a una fila
				echo '<td>';
			//Columnas que son de tipo booleano.						
				if($metadatos->name=="Habilitado")
				{
				   $checkeado="";
				   if($row[$metadatos->name]!=0)
					$checkeado= "checked=\"checked\"";
				   echo '<input name="checkboxAsistencia2" type="checkbox" id="checkboxAsistencia2" '.$checkeado.' onclick="javascript: return false;" />';
				}
				else
					echo $row[$metadatos->name];
				echo "</td>\n";						
				++$i;
			}
    				
//Opciones que tendra cada registro del dataGridView
			echo '<td>';
			//Responder Encuesta
			//Resultado
            $pagEditar='\'TipoGasto_editar.php\'';
            $pagEliminar='\'TipoGasto_eliminar.php\'';
		   
            //Editar
						echo	'<span style="cursor:pointer"; onclick="AbrirPagina('.$row["idTipoGasto"].','.$pagEditar.'); "><i class="icon icon-pencil"></i> Editar</span>
        						<br>'."\n";
                        //echo "<a style='text-decoration:none; color:#000' href='Jornada_editar.php?q=$row[0]>Editar</a><br>"."\n"; 
						//Eliminar
						echo	'<span style="cursor:pointer"; onclick="Confirmar('.$row["idTipoGasto"].');"><i class="icon icon-bin"></i> Eliminar</samp>';
			echo "</td>\n";    				
			echo "\n";
			print '</tr>';
			if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
		}
		print '</table>';
	}		
?>
</body>
</html>
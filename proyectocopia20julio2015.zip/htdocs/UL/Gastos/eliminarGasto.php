<?php
        include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		
		$consulta1=new Consulta;
		//$q=$_GET['q'];     
        $id=$_GET["q"];
            $consulta1->Gasto_eliminar($id);
            ?>
            <h4 align="center">Eliminando registro</h4>
            <meta http-equiv="Refresh" content="3;url=/UL/Gastos/Gastos_ver.php">
            <?php
?>


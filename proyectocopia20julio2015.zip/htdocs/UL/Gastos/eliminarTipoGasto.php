<?php
	   include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		
		$consulta1=new Consulta;
		//$q=$_GET['q'];     
        $idTipoGasto=$_GET["q"];
           $consulta1->TipoGasto_listarporid($idTipoGasto);
           $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
            {
                $consulta1->TipoGasto_eliminar($idTipoGasto);
                ?>
                <H4 align="center">Eliminando tipo de gasto</H4>
                <meta http-equiv="Refresh" content="3;url=/UL/Gastos/TipoGasto_ver.php">
                <?   
            }
            else if(mysql_num_rows($res)>0)
            {
                 ?>
                <H4 align="center">El tipo de gasto no se puede eliminar por estar</H4>
                <h4 align="center">asignado en los gastos</h4>
                <meta http-equiv="Refresh" content="3;url=/UL/Gastos/TipoGasto_ver.php">
                <?php
            }
?>
		
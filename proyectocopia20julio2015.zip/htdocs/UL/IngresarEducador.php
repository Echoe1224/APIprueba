<?php
include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
$consulta1=new Consulta;
// define variables and set to empty values
$errorNombre = "";
$errortelefono="";
$errorcorreo="";
$errorempres="";
$errorpais="";
$nombre = "";
$telefono="";
$correo="";
$idtipoevento="";
$empresa="";
$pais="";
$idpersonal="";
$sinErrores="f";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$sinErrores="v";
	if (empty($_POST["texto_nombre"])) {
     $errorNombre = "El Nombre del Evento requerido.";
     $sinErrores="f";
	}
    else {
     $nombre = test_input($_POST["texto_nombre"]);
     if (!preg_match("/^[0-9a-zA-Z ]*$/",$nombre)) {
     		$errorNombre = "Ingrese solo letras, números y espacios.";
			$sinErrores="f";
		 }
	}
	if (empty($_POST["telefono"])) {
     $errortelefono = "El Telefono es requerido.";
     $sinErrores="f";
	}
    else {
     $telefono = test_input($_POST["telefono"]);
     if (!preg_match("/^[0-9]*$/",$telefono)) {
     		$errortelefono = "Ingrese solo números.";
			$sinErrores="f";
		 }
	}
     $empresa = test_input($_POST["empresa"]);
     if (!preg_match("/^[0-9a-zA-Z ]*$/",$telefono)) {
     		$errorempresa = "Ingrese solo números, letras y espacios.";
			$sinErrores="f";
		 }
    $correo = test_input($_POST["correo"]);
     if (!preg_match("/^[a-zA-Z-0-9 ]*$/",$correo)) {
         	$errorcorreo = "Caracter no aceptado";
			$sinErrores="f";
		 }
	if (empty($_POST["paisdeorigen"])) {
     $errorpais = "El Pais es requerido.";
     $sinErrores="f";
	}
    else {
     $pais = test_input($_POST["paisdeorigen"]);
     if (!preg_match("/^[a-zA-Z]*$/",$pais)) {
     		$errorpais = "Ingrese solo letras.";
			$sinErrores="f";
		 }
	}
	if($sinErrores=="v")
	{
		$idtipoevento=$_POST["Nombre_tipoevento"];
		$idpersonal=$_POST["Personal"];
        $consulta1->Educador_insertar($nombre,$telefono,$correo,$idtipoevento,$empresa,$pais,$idpersonal);
		$errorpais=$nombre =$telefono=$correo=$idtipoevento=$empresa=$pais=$idpersonal="";
	   // funciones
	}
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<style type="text/css">
	.error {color: #FF0000;}
		#results {
			margin: 20px;
			padding: 20px;
			padding-top:0px;
			border: 1px solid;
			background: #ccc;
		}
    </style>
</head>

<body bgcolor="#006633" text="#FFFFFF">
  	<h1 style="text-align:left"><img src="../../Logo-Meso-Color.png" width="150" height="141" alt="TextAlt">CITEIN</h1>
	<h1 style="text-align:center">Ingreso Educador</h1>
		<form name="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">            
       	  <table width="800" height="183" border="0" align="center" style="background:#333333">
        		<td width="358" valign="top" nowrap="nowrap">
                <p><span class="error">* Campos requeridos.</span>        		</p>
                <p>
		        <label for="texto_nombre">Nombre del Educador: </label>
        		<input name="texto_nombre" type="text" id="texto_nombre" value="<?php echo $nombre;?>" size="50" maxlength="50">
                  <span class="error">* <?php echo $errorNombre;?></span></p>
        		<p>
        		  <label for="telefono">Telefono</label>
        		  <input type="text" name="telefono" id="telefono" value="<?php echo $telefono;?>" size="50" maxlength="8">
                  <span class="error">* <?php echo $errortelefono;?></span></p>
        		<p>
        		  <label for="correo">Correo</label>
        		  <input type="text" name="correo" id="correo" value="<?php echo $correo;?>" size="50" maxlength="50">
        		  <span class="error"><?php echo $errorcorreo;?></span>
        		</p>
        		<p>
                <label for="Nombre_tipoevento">Nombre del Evento:</label>
                  <select name="Nombre_tipoevento" id="Nombre_tipoevento" selectedvalue=>
                    <?php
				$consulta1->TipoEvento_ver();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['idTipoEvento'].">".$row['Nombre']."</option>";
				}
				?>
                  </select>
                </p>
        		<p>
        		  <label for="empresa">Empresa</label>
        		  <input type="text" name="empresa" id="empresa" value="<?php echo $empresa?>" size="50" maxlength="50"><span class="error"><?php echo $errorempresa;?></span>
        		</p>
        		<p>
        		  <label for="paisdeorigen">Pais de Origen</label>
        		  <input type="text" name="paisdeorigen" id="paisdeorigen" value="<?php echo $pais?>"><span class="error">* <?php echo $errorpais;?></span>
        		</p>
        		<p>
        		  <label for="Personal">Personal a Cargo</label>
        		  <select name="Personal" id="Personal">
                  <?php
    			$consulta1->Personal_ver();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['idPersonal'].">".$row['Nombre']."</option>";
				}
				?>
      		    </select>
                </p>
        		<p>
        		  <input type="submit" name="boton_guardar" id="boton_guardar" value="Guardar">
        		  <input type="submit" name="boton_cancelar" id="boton_cancelar" value="Cancelar">
      		  </p></td>
                <td width="190" align="center" valign="top">
				</script>
      			</td>
      </table>
</form>
</body>
</html>
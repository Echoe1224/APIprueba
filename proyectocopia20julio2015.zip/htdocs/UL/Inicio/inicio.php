<?php
session_start();
if($_POST["texto_idGrupoEvento"]>0)
$_SESSION['idGrupoEvento']=$_POST["texto_idGrupoEvento"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<!-- InstanceBeginEditable name="doctitle" -->
<title>Inicio</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<!--**********************************Librerias  u otras cosas de encabeza AQUÍ*************************************-->

<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
    <div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h2 align="center">Seleccione un evento para administrar</h2>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de Eventos Inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                    $_SESSION['FechaInicio']=$row["FechaInicio"];
                    $_SESSION['FechaFinal']=$row["FechaFinal"];  
                }
            }
            echo '<h3>Se está administrando el evento:</h3>';
            echo '<h1 align="center">'.$NombreG.'</h1>';
        }
    ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        
<form id="form1" name="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

  <input type="text" name="texto_idGrupoEvento" id="texto_idGrupoEvento" style="display:none" />
  <div style="display:none" ><input type="submit" name="boton_enviar2" id="boton_enviar2" value="Enviar" /></div>
  <script>
  function funcionidevento(idevento)
  {
  document.getElementById('texto_idGrupoEvento').value=idevento;
  document.getElementById('boton_enviar2').click();
  }
  </script>
</form>

        <?php 
$consulta1->GrupoEvento_ver_detalle_habilitados();
$grupoEventos=$consulta1->Resultado;
echo'<br/>';

while($grupo=mysql_fetch_assoc($grupoEventos))
{   
    if($grupo["diainicio"]=="Sunday")
        $diainicio="domingo";
    if($grupo["diainicio"]=="Monday")
        $diainicio="lunes";
    if($grupo["diainicio"]=="Tuesday")
        $diainicio="martes";
    if($grupo["diainicio"]=="Wednesday")
        $diainicio="miércoles";
    if($grupo["diainicio"]=="Thursday")
        $diainicio="jueves";
    if($grupo["diainicio"]=="Friday")
        $diainicio="viernes";
    if($grupo["diainicio"]=="Saturday")
        $diainicio="sábado";
        
    if($grupo["mesinicio"]=="January")
        $mesinicio="enero";
    if($grupo["mesinicio"]=="February")
        $mesinicio="febrero";
    if($grupo["mesinicio"]=="March")
        $mesinicio="marzo";
    if($grupo["mesinicio"]=="April")
        $mesinicio="abril";
    if($grupo["mesinicio"]=="May")
        $mesinicio="mayo";
    if($grupo["mesinicio"]=="June")
        $mesinicio="junio";
    if($grupo["mesinicio"]=="July")
        $mesinicio="julio";
    if($grupo["mesinicio"]=="August")
        $mesinicio="agosto";
    if($grupo["mesinicio"]=="September")
        $mesinicio="septiembre";
    if($grupo["mesinicio"]=="October")
        $mesinicio="octubre";
    if($grupo["mesinicio"]=="November")
        $mesinicio="noviembre";
    if($grupo["mesinicio"]=="December")
        $mesinicio="diciembre";
        
    if($grupo["diafinal"]=="Sunday")
        $diafinal="domingo";
    if($grupo["diafinal"]=="Monday")
        $diafinal="lunes";
    if($grupo["diafinal"]=="Tuesday")
        $diafinal="martes";
    if($grupo["diafinal"]=="Wednesday")
        $diafinal="miércoles";
    if($grupo["diafinal"]=="Thursday")
        $diafinal="jueves";
    if($grupo["diafinal"]=="Friday")
        $diafinal="viernes";
    if($grupo["diafinal"]=="Saturday")
        $diafinal="sábado";
        
    if($grupo["mesfinal"]=="January")
        $mesfinal="enero";
    if($grupo["mesfinal"]=="February")
        $mesfinal="febrero";
    if($grupo["mesfinal"]=="March")
        $mesfinal="marzo";
    if($grupo["mesfinal"]=="April")
        $mesfinal="abril";
    if($grupo["mesfinal"]=="May")
        $mesfinal="mayo";
    if($grupo["mesfinal"]=="June")
        $mesfinal="junio";
    if($grupo["mesfinal"]=="July")
        $mesfinal="julio";
    if($grupo["mesfinal"]=="August")
        $mesfinal="agosto";
    if($grupo["mesfinal"]=="September")
        $mesfinal="septiembre";
    if($grupo["mesfinal"]=="October")
        $mesfinal="octubre";
    if($grupo["mesfinal"]=="November")
        $mesfinal="noviembre";
    if($grupo["mesfinal"]=="December")
        $mesfinal="diciembre";
    echo '</br>';
//`idGrupoEvento`,`Nombre`, `FechaInicio`,`FechaFinal`, `CostoInscripcion`,`DescripcionGrupoEvento`
echo '<section id="container">
	<div class="padding-contenido">
    	<div class="contenedor_2">
	        <div class="wrapper p5" style="border-top: 1px solid #89AF25;
                                           border-right: 1px solid #89AF25;
                                           border-bottom: 1px solid #89AF25;
                                           border-left: 1px solid #89AF25;
                                           padding: 5px 5px 5px 15px;">
    	     <article class="grid">';
             echo '</br>';
                echo ' 		   <h3>'.$grupo["Nombre"].'</h3>';
                echo '         <p>'.$grupo["DescripcionGrupoEvento"].'</p>';

?>               
                <table width="800" height="110" border="0">
                  <tr>
                    <td width="160">Fecha de inicio: </td>
                    <td width="160"><?php echo $diainicio.' '.$grupo["numinicio"].'-'. $mesinicio.'-'.$grupo["anoinicio"] ?></td>
                    <td width="180">Participantes registrados:</td>
                    <td width="40"><?php echo $grupo["totalParticipante"] ?></td>
                    <td width="120"></td>
                  </tr>
                  <tr>
                    <td>Fecha de finalización: </td>
                    <td><?php echo $diafinal.' '.$grupo["numfinal"].'-'. $mesfinal.'-'.$grupo["anofinal"]?></td>
                    <td>Actividades registradas:</td>
                    <td><?php echo $grupo["TotalActividades"] ?></td>
                    <td style="text-align:right;"><?php echo '<input type="button" name="hola" value="Administrar" onclick="funcionidevento('.$grupo["idGrupoEvento"].')"/>'; ?></td>
                  </tr>
                  <tr>
                    <td>Costo de inscripción: </td>
                    <td>Q. <?php echo $grupo["CostoInscripcion"] ?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                </table>
<?php
                echo '</br>';

echo '       </article>
        	</div>';
echo '</div>
</div>
</section>';
}

?>
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Editar jornada</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/Templates/menu.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->

<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <?php
        if(isset($_POST['idRegistro']))
        {
    		$idJornada=$_POST['idRegistro'];
        }
		else
        {
			$idJornada=0;
        }
        $consulta1->Jornada_seleccionar("$idJornada");
        $res=$consulta1->Resultado;
        while($row=mysql_fetch_assoc($res))
        {
            $NombreJornada=$row["Jornada"];
            $estado=$row["EstadoJornada"];
        }
        if ($idJornada>0)
        {
        ?>
    <form id="form1" method="post" action="<?php echo htmlspecialchars("/DAL/guardar.php");?>">
      	<p>
      	  <input name="formulario" id="formulario"
         value="editar_Jornada" type="hidden">
   	  </p>
      	  <H2 align="center" >Editar jornada</H2><br>
      	  
   	  </p>
         <div align="center">
   	  <table width="370" cellspacing="5" align="center" border="0">
   	    <tr>
              <td style="text-align:center">Jornada:</td>
              <td><input name="Jornada"
         id="Jornada" required="required" autocomplete="off" value="<?php echo $NombreJornada; ?>" type="text" maxlength="45" title="Se necesita un nombre de jorndada (solamente letras)" pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}"/></td>
         <td><input style="display:none" name="idJornada" id="idJornada" required="required" value="<?php echo $idJornada ?>" type="text" /></td>
        </tr>
        <tr>
        <td style="text-align: right;"><label>Estado: </label></td>
              <td>
                <?php
                if($estado==0)
                {
                    ?>
                    <input type="radio" name="estado" value="1"> Activo
                    <input type="radio" name="estado" value="0" checked> Inactivo<br>
                    <?php
                }
                else if ($estado==1)
                {
                    ?>
                    <input type="radio" name="estado" value="1" checked> Activo
                    <input type="radio" name="estado" value="0"> Inactivo<br>
                    <?php  
                }
                ?>
                
              </td>
        </tr>
        </table>
        </br>
  <input id="submit" value="Guardar" type="submit">
  <input style="display:inline" type="button" name="boton" id="boton" value="Cancelar" onClick="window.location.href='Jornada_ver.php'"/>
  </div>
    </form>
   <?php
    }
    else
    {
        ?>
        <h2 align="center">Necesita seleccionar una jornada</h2>
        <br />
        <h4 align="center"><a href="Jornada_ver.php"> Seleccionar</a></h4>
        <?php
    }
    ?>
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
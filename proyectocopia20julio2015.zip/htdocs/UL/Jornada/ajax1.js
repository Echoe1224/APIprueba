//Esta es la funcion del Ajax, le puse Buscador por gusto
function Buscador()
{
        var xmlhttp=false;
        try 
    	{
               xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
        } 
		catch (e) 
		{
               try 
			   {
                  xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
               } 
			   catch (E) 
			   {
                  xmlhttp = false;
               }
        }
 
        if (!xmlhttp && typeof XMLHttpRequest!='undefined') 
		{
               xmlhttp = new XMLHttpRequest();
			   xmlhttp.overrideMimeType('text/xml');
        }

        return xmlhttp;
}
/*la siguiente funcion es donde se hace un llamado a la funcion Buscador()=Ajax()
y es en esta funcion donde llamo mi pagina que es procrocesar, que es donde se dibuna la tabla.
Cuando ustedes van a agregar su funcion ponganle como Buscar_Participante() un decir, y solo copiar pegar y cambiar los respectivos parametros y así con las otras funciones que crearann 


En cada funcion que cree es necesario crear la respectiva pagina del mismo, debido a que ajax lo necesita, por eso mismo no recargamos la pagina automaticamente, sino lo hace ajax

las paginas que cree son:
Buscar= donde se dibuja el contenedor y textbox de la busqueda

editar= donde se llaman los datos para mostrarlos en los textboxs y poder modificarlos

Eliminar=que es donde hago el llamado de la funcion eliminar

guardar=que es donde hago el llamado de la funcion que es para actualizar el valor de las tablas y obtener los respectivos parametros para modificar

procesar=donde se van a dibujar todas las tablas que requira la busqueda

preguntaran por que tantas paginas?, ajax recarga las paginas en tiempo real, es como el compilador que tiene visualStudio C#, por lo mismo que hay necesidad de crear las respectivas paginas
*/  
function Buscar()
{
	q=document.getElementById('valor').value;
	c=document.getElementById('resultados');
	ajax=Buscador();
	ajax.open('GET','Jornada_filtrar.php?q='+q);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			c.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}

function mensaje()
{
    alert("esta funcionando");

}

function Eliminar(q)
{
	c=document.getElementById('resultados');
	ajax=Buscador();
	ajax.open('GET','eliminar.php?q='+q);
	ajax.onreadystatechange=function()
	{
		if(ajax.readyState == 4)
		{
			c.innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
}

function Confirmar(q)
{
	con=confirm("Esta seguro de eliminar el registro")
	if(con)
	{
		Eliminar(q);
	}
	else
	{
		return false;
	}
}
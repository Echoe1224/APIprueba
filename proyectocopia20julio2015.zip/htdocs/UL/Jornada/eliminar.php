<?php
	  include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		
		$consulta1=new Consulta;
		//$q=$_GET['q'];     
        $idjornada=$_GET['q']; 
           $consulta1->Jornada_listarporid($idjornada);
           $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
            {
                $consulta1->Jornada_eliminar($idjornada);
                ?>
                <h4 align="center">Eliminando registro</h4>
                <meta http-equiv="Refresh" content="1;url=/UL/Jornada/Jornada_ver.php">
                <?   
            } 
            else if(mysql_num_rows($res)>0)
            {
                 ?>
                <H4 align="center">La jornada no se puede eliminar por estar</H4>
                <h4 align="center">asignada en un registro</h4>
                <meta http-equiv="Refresh" content="2;url=/UL/Jornada/Jornada_ver.php">
                <?php
            }
?>


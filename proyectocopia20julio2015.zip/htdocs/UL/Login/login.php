<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_inicio.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<?php
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
    $consulta1=new Consulta;
?>
<!-- InstanceBeginEditable name="doctitle" -->
<title>Iniciar sesión</title>
<style type="text/css">
.alert-box {
    color:#555;
    border-radius:10px;
    font-family:Tahoma,Geneva,Arial,sans-serif;font-size:11px;
    padding:10px 10px 10px 36px;
    margin:10px;
}
.alert-box span {
    font-weight:bold;
    text-transform:uppercase;
}
.error {
    background:#ffecec url('../../UL/CITEIN/iconoError.png') no-repeat 10px 50%;
    border:1px solid #f5aca6;
}
    
    .myButton {
    background-color:#1e8038;
    -moz-border-radius:7px;
	-webkit-border-radius:7px;
	border-radius:7px;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:21px;
	padding:16px 300px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.myButton:hover {
	background-color:#5cbf2a;
}
.myButton:active {
	position:relative;
	top:1px;
}

      

.text1
{
border: 2px solid rgb(173, 204, 204);
height: 31px;
width: 150px;
box-shadow: 0px 0px 27px rgb(204, 204, 204) inset;
transition:500ms all ease;
padding:3px 3px 3px 3px;
}

.text1:hover, .text1:focus
{
width:175px;
transition:500ms all ease;
background:url(../../UL/CITEIN/user.png) no-repeat right;
background-size:25px 25px;
background-position:96% 62%;
padding:3px 32px 3px 3px;
}
.text2
{
border: 2px solid rgb(173, 204, 204);
height: 31px;
width: 150px;
box-shadow: 0px 0px 27px rgb(204, 204, 204) inset;
transition:500ms all ease;
padding:3px 3px 3px 3px;
}

.text2:hover, .text2:focus
{
width:175px;
transition:500ms all ease;
background:url(../../UL/CITEIN/lock.png) no-repeat right;
background-size:25px 25px;
background-position:96% 62%;
padding:3px 32px 3px 3px;
}

    </style>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->

<!-- **********************************Libreias  u otras cosas de encabeza AQUÍ************************************* -->

<!-- InstanceEndEditable -->
</head>

<body>
<!-- InstanceBeginEditable name="Contenido" -->
<?php session_start();;
function verificar_login($user,$password,&$result) 
{
    $sql = "SELECT * FROM Usuario WHERE Usuario = '$user' and Contrasena = '$password' and Estado='1'";
    $rec = mysql_query($sql) or die('Mi error es: '.mysql_error());
    $count = 0;
    while($row = @mysql_fetch_object($rec))
    {
        $count++;
        $result = $row;
    }
    if($count == 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
if(!isset($_SESSION['userid']))
{
    if(isset($_POST['usuario']))
    {
        if(verificar_login($_POST['usuario'],$_POST['pass'],$result) == 1)
        {
            $_SESSION['userid'] = $result->idUsuario;
            $_SESSION['usuario']=$result->Usuario;
            $_SESSION['tipo']=$result->Administrador;
            $_SESSION['nombre']=$result->Nombre;
            ?>
            <meta http-equiv="refresh" content="0; url=/UL/Inicio/inicio.php">
            <?php
            //echo"window.location='UL/Inicio/inicio.php'";
            //echo"location.href = "UL/Inicio/inicio.php"";
            //echo"<script>window.location="UL/Inicio/inicio.php"</script>";
            //header("location:http://citein.hostingla.in/UL/Inicio/inicio.php");
        }
        else
        {
            echo '<div class="alert-box error"><span>error: </span>Datos incorrectos, intente nuevamente.</div>';
        }
    }
    ?>
    <style type="text/css">
    .error
    {
        color: red;
        font-weight: bold;
        margin: 10px;
        text-align: center;
    }
    </style>

<div align="right"><span style="cursor:pointer;" onclick="cerrarM();" title="Cerrar">X</span></div>
<h2  align="left">Iniciar sesión</h2>
<hr>
<div align="center">
<form  id="form1" name="form1" method="post" action="">
<?php
if(!isset($_POST["bandera"]))
{
$archivo_actual = $_SERVER["REQUEST_URI"];
//echo $archivo_actual;
if($archivo_actual=="/UL/Login/login.php")
{
 header('location: ../../index.php');   
}
}
?>
    <table width="252" height="147" border="0" cellspacing="5">
<tr>
<td rowspan="3"><img name="Universidad Mesoamericana" src="../../UL/CITEIN/Universidad.png" width="129" height="126" alt=""></td>
</tr>
      <tr>
	    <td width="103">Usuario:</td>
	    <td width="130">
        
	      <label for="texto_usuario"></label>
	      <input class="text1" name="texto_usuario" type="text" id="texto_usuario" accesskey="u" size="35" maxlength="10" />
        
    </tr>
	  <tr>
	    <td>Contraseña:</td>
	    <td>
	      <label for="texto_pass"></label>
	      <input class="text2" name="texto_pass" type="password" id="texto_pass" accesskey="c" size="35" maxlength="10" />
        </td>
    </tr>
	  <tr>
    </tr>
  </table>
  <hr>
  <div align="center">
      <input class="myButton" type="button" name="boton_login" id="boton_login" value="Iniciar sesión"  onclick="abrir2('usuario='+document.getElementById('texto_usuario').value+'&pass='+document.getElementById('texto_pass').value)"/>
    </div>
   </form>
  </div>
<?php
}
else 
{ 
        if(!isset($_SESSION['usuario']))header("Location: logout.php");  
        $tiempo = (isset($_SESSION['time'])) ? $_SESSION['time'] : strtotime(date("Y-m-d H:i:s")); 
        $actual =  strtotime(date("Y-m-d H:i:s")); 
        (($actual-$tiempo) >= 900) ? header("Location: logout.php") : $_SESSION['time'] =$actual;
        ?>

<div align="center">
<div align="right"><span style="cursor:pointer;" onclick="cerrarM();" title="Cerrar">X</span></div>
<H3>Ha iniciado sesión como "<?php echo $_SESSION['usuario'];?>"</H3>
<br/>
<br/>
<a style="color:#333; text-decoration:none;" href="/UL/Inicio/inicio.php"><H3><i class="icon icon-home"></i> Ir al sistema<H3></a>
<br/>
<br/>
<a style="color:#333; text-decoration:none;" href="../UL/Login/logout.php"><H3><i class="icon icon-exit"></i> Cerrar sesión<H3></a>
<?php
}
?>
</div>
</body>
<!-- InstanceEnd --></html>



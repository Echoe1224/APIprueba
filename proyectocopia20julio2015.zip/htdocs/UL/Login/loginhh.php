<?php
session_start();
            $_SESSION['userid'] = 1;
            $_SESSION['usuario']='usuario';
            $_SESSION['tipo']=1;
            $_SESSION['nombre']='NombreU';
            header("location:/UL/Inicio/inicio.php");
?>
<?php
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	$consulta1=new Consulta;
// define variables and set to empty values
$erroridlugar = $errornombre = $errorcapacidad = "";
$idlugar = $nombre = $capacidad = "";
$cont=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["texto_idlugar"])) {
	   	$erroridlugar = "El Identificador del lugar es requerido.";
               $idlugar="";
		//++$cont;
	}
	else {
	       $idlugar= test_input($_POST["texto_idlugar"]);
	    // check if name only contains letters and whitespace
		if (!preg_match("/^[0-9]*$/",$idlugar)) {
    		$erroridlugar = "Ingrese solamente letras y/o números sin espacios.";
			}
		else{
			++$cont;
		}
	}
	if(empty($_POST["texto_nombre"])){
   		$nombre="";
		++$cont;
	}
	else{
	   $nombre = test_input($_POST["texto_nombre"]);
	   if (!preg_match("/^[0-9-a-zA-Z]*$/",$nombre)) {
    	 	$errornombre='Ingrese número o letras.';
		 }
		else{
			++$cont;
		}
	}
	if(empty($_POST["texto_capacidad"])){
   		$capacidad="";
		//++$cont;
	}
	else{
	   $capacidad = test_input($_POST["texto_capacidad"]);
	   if (!preg_match("/^[0-9]*$/",$capacidad)) {
    	 	$errorcapacidad='Ingrese solo números.';
		 }
    else{
		$cont++;
	}
	}
	if($cont==3)
	{
		$consulta1->RegistroLugares_insertar($idlugar, $nombre, $capacidad, '1');
        $idlugar=$nombre=$capacidad=" ";
        $url="http://citein.hostingla.in/UL/opciones.php"; 
        echo "<SCRIPT>window.location='$url';</SCRIPT>"; 
	}
}

function test_input($data) {
   $data = trim($data); 	
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<style type="text/css">
	.error {color: #FF0000;}
		#results {
			margin: 20px;
			padding: 20px;
			padding-top:0px;
			border: 1px solid;
			background: #ccc;
		}
    </style>
    
</head>

<body bgcolor="#006633" text="#FFFFFF">
  	<h1 style="text-align:left"><img src="../Logo-Meso-Color.png" width="150" height="141" alt="TextAlt">CITEIN</h1>
	<h1 style="text-align:center">Registro de Lugares</h1>
		<form name="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">            
       	  <table width="800" height="183" border="0" align="center" style="background:#333333">
        		<td width="358" valign="top" nowrap="nowrap">
<!--  *********************************************************Formulario**************************************************** -->                
                <p><span class="error">* Campos requeridos.</span></p>
                <p>
                  <label for="texto_idlugar">Id Lugar: </label>
                  <input name="texto_idlugar" type="text" id="texto_idlugar" value="<?php echo $id;?>" size="50" maxlength="45">
                   <span class="error">* <?php echo $erroridlugar;?></span> <br/>
                </p>
        		<p>
		        <label for="texto_nombre">Nombre: </label>
        		         <input name="texto_nombre" type="text" id="texto_nombre" value="<?php echo $nombre;?>" size="50" maxlength="9">
                  <span class="error">* <?php echo $errornombre;?></span> </p>
        		<p>
        		  <label for="texto_capacidad">Capacidad;   </label> 
                  <input name="texto_capacidad" type="text" id="texto_capacidad" value="<?php echo $capacidad;?>" size="50" maxlength="9">
                  <span class="error">* <?php echo $errorcapacidad;?></span><br/>
        		</p>
        		<p>&nbsp;</p>
        		<div id="boton_guardar">
                <input type="submit" name="boton_guardar" id="boton_guardar" value="Guardar"> 
                <input type="button" name="boton_cancelar" id="boton_cancelar" value="Cancelar" onClick="almacenar_captura()">
                </div>
                </td>
                <td width="190" align="center" valign="top">
      		</td>
      </table>
</form>
</body>
</html>	
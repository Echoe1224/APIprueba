<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Modificando un Select</title>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script type="text/javascript" src="../../BLL/ajax.js"></script>
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<!-- <link rel="stylesheet" type="text/css" href="css/estilos.css">*/-->
<link rel="stylesheet" type="text/css" href="../CITEIN/estilos.css">
<?php
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	$consulta1=new Consulta;
?>
</head>

<body>
<div align="center">
<!-- Nombre de la pagina y los parametros del formulario para un nuevo dato -->
  <input type="hidden" name="pagina" id="pagina" value="pagina.php" />
  <input type="hidden" name="parametros" id="parametros" value="" />
<h1>Agregando nuevos datos en una lista </h1>
  <form id="form1" name="form1" method="post" action="">
  <div class="ventana">
  	<div class="cerrar"><a href="javascript:closeVentana();"><i class="icon icon-cross"></i> Cerrar</a></div>
    <div id="resultados"></div>
  </div>
  <div id="numeros">
  	<label for="lista">Lista</label>
    <select name="lista" id="lista" onchange="openVentana();">
      <?php
	  $consulta1->prueba_ver();
	  while($row= mysql_fetch_assoc($consulta1->Resultado)){
      	echo '<option value="'.$row["id"].'">'.$row["Nombre"].'</option>'."\n";
	  }
	  ?>
      <option value="+">Agregar otro.</option>
    </select>
    </div>
  </form>
</div>
<script type="text/javascript">
	/*Función que se llama desde la página del formulario (ej: pagina.php)*/
	function procesar(){
		var parametros = "id="+ $('#idDato').val()+"&nombre="+$('#nombreDato').val();
		ProcesarPaginaPostConParametros($('#pagina').val(),parametros,"resultados");
	}
	function openVentana(bandera){
		if(document.getElementById('lista').value=="+")
		{
			$(".ventana").slideDown("slow");
			//ProcesarPaginaGetConParametros('\'pagina.php\'','');
			MostrarPagina();
		}
	}
	function closeVentana(){
		$(".ventana").slideUp("fast");
		$('#lista').empty();
		var consulta="SELECT `id`, `Nombre` FROM `Prueba`";
		var etiqueta="Lista de números";
		var funcion="openVentana()";
		var idLista="lista";
		parametros="consulta="+consulta+"&etiqueta="+etiqueta+"&idlista="+idLista+"&funcion="+funcion;
		ProcesarPaginaPostConParametros("../../BLL/lista.php",parametros,"numeros");
	}
</script>
</body>
</html>
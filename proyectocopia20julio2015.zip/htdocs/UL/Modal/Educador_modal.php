﻿<?php
include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
$Consulta2=new Consulta;
// define variables and set to empty values
$errorNombre = "";
$nombre= $parametros = "";
$error = FALSE;
$ingresado = 0;
$cont=0;
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	if(isset($_POST["url"]))
	{
		$url=$_POST["url"];
	}
	$idLista=$_POST["idLista"];
	$idDiv=$_POST["idDiv"];
	$parametros="idLista=".$_POST["idLista"]."&idDiv=".$_POST["idDiv"];
$hojadevida="";

            if(isset($_POST["Nombre"]))
            {
                $nombre=$_POST["Nombre"];
                $cont++;
            }

            if(isset($_POST["Telefono"]))
                $tel=$_POST["Telefono"];

            if(isset($_POST["Correo"]))
                $correo=$_POST["Correo"];

	    if(isset($_POST["listaeventos"]))
                $listaeve=$_POST["listaeventos"];
           
	    if(isset($_POST["Empresa"]))
                $empresa=$_POST["Empresa"];

	    if(isset($_POST["Pais"]))
                $pais=$_POST["Pais"];

	    if(isset($_POST["NombreEncargado"]))
                $listaenc=$_POST["NombreEncargado"];

    if($cont>0)
	{
       $Consulta2->Educador_verificar_nombre($nombre);
        $row = $Consulta2->Resultado;
        if(mysql_num_rows($row)==0)
        {          
$consulta1->Educador_insertar($nombre,$tel,$correo,$listaeve,$empresa,$pais,$listaenc,$hojadevida);  
$nombre=$tel=$correo=$listaeve=$empresa=$pais=$listaenc=$hojadevida="";
			$ingresado=TRUE;

$hecho="Educador Ingresado";
        }
        else
        {
                $ernom="Ya existe un Educador con el mismo nombre";
        }
    }
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<div class="btnCerrar">
<div class="btnCerrar">
<!-- EDITAR ---------------------------------------------------------- -->
    <a
    href="javascript:closeVentana(<?php echo $ingresado; ?>,'<?php echo $url; ?>','SELECT  `idEducador` AS  `id` ,  `Nombre` AS  `nombre` 
FROM  `Educador` 
WHERE  `EstadoEducador`=1 
ORDER BY  `idEducador` Desc','<?php echo $idLista; ?>','<?php echo $idDiv; ?>');"
    ><i class="icon icon-cross"></i> Cerrar</a>
</div>



<?php
if($ingresado==FALSE)
{
    if($error==TRUE)
    {
        echo '<div align="center"><h3>No se pudo insertar el dato.\n<br />Puede que ya existe el dato.</h3></div>';
    }
    ?>
<div class="formularioVentana">
    <h2 align="center">Nuevo educador</h2>
<!--    <hr> -->
<!--     <span class="error">* Campos requeridos</span> -->
    <table width="200" border="0" cellspacing="1" align="center">
  <tr>
    <td ><label for="Nombre">Nombre</label></td>
    <td ><input type="text" name="Nombre" id="Nombre" value="<? print $nombre;?>" size="15" maxlength="45" placeholder="Ingrese el nombre del conferencista." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" required title="Se necesita un nombre del Conferencista(ingrese solamente letras)"/></td>
    <td><span class="error">*<? print $ernom;?></td>
  </tr>
  <tr>
    <td ><label for="Teléfono">
      Teléfono</label></td>
   <td><input type="text" name="Telefono" id="Telefono" value="<? print $tel;?>" size="15" maxlength="8" placeholder="Ingrese un número telefonico" pattern="[0-9]{1,45}" required title="Se necesita un número de teléfono(ingrese solamente números)"/></td>
   <td><span class="error">*</span></td>
  </tr>
  <tr>
   <td> <label for="Correo">
      E-mail:</label></td>
    <td ><input type="text" name="Correo" id="Correo" value="<? print $correo;?>" size="15" maxlength="150" placeholder="Ingrese un correo." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ.@0-9 ]{1,45}" title="Se necesita un correo electronico(ingrese solamente letras)" /></td>
  </tr>
  <tr>
<td ><label for="listaeventos">Tipo de Actividad</label></td>
  <td ><div id="lista_eventos">
<select name="listaeventos" id="listaeventos"  onchange="openVentana('listaeventos','../Modal/TipoEvento_modal.php','idDiv=lista_eventos');">
 <?php
				$consulta1->TipoEvento_ver_lista($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option value=".$row['id']; if($listaeve==$row['id']) echo 'selected="selected"'; echo">".$row['nombre']."</option>";
				}
		 ?>
  </select>
</div></td>
     <td width="200"><span class="error">*</span></td>
  </tr>
  <tr>
    <td><label for="HoraFinal3">Empresa</label></td>
   <td><input type="text" name="Empresa" id="Empresa" value="<? print $empresa;?>" size="15" maxlength="45" placeholder="Ingrese la empresa donde labora." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ. ]{1,45}" required title="Se necesita un nombre de empresa(ingrese solamente letras)"/></td>
   <td><span class="error">*</span></td>
  </tr>
  <tr>
  <td ><label for="Pais"><br />
      País de Origen: </label></td>
   <td><input type="text" name="Pais" id="Pais" value="<? print $pais;?>" size="15" maxlength="45" placeholder="Ingrese el País de donde proviene." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" required title="Se necesita un País(ingrese solamente letras)"/>
    <br /></td>
    <td><span class="error">*</span></td>
  </tr>
  <tr>
  <td>Personal Encargado</td>
    <td><select name="NombreEncargado" id="NombreEncargado" onchange="cargar(this.value,'Personal_ingresar.php')" onFocus='cargarlista()'>
  <?php
    			$consulta1->Personal_ver_idgrupo($_SESSION['idGrupoEvento']);
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['idPersonal'].">".$row['Nombre']."</option>";
				}
		 ?>
  </select></td>
  </tr>
        <tr>
            <td></td>
<!-- EDITAR --------------------------------------------------------------- -->
<!-- onclick=ingresarDatos(url,parametro1=valor1&parametro2=valor2...) -->
            <td><input name="Botón" type="button" value="Ingresar" 
            onclick="ingresarDatos('<?php echo $url; ?>','<?php echo $parametros; ?>'+'&Nombre='+document.getElementById('Nombre').value+'&Telefono='+document.getElementById('Telefono').value+'&Correo='+document.getElementById('Correo').value+'&listaeventos='+document.getElementById('listaeventos').value+'&Empresa='+document.getElementById('Empresa').value+'&Pais='+document.getElementById('Pais').value+'&NombreEncargado='+document.getElementById('NombreEncargado').value)"></td>
            <!-- ingresarDatos(url,parametros & id=textboxId & nombre=textBoxNombre&...nombreParametro=valor) -->
        </tr>
  </table>
</div>
<?php
}else{
    echo '<div align="center"><h2><i class="icon icon-check"></i>Educador creado.</h2></div>';
}
?>
<script language="javascript">
function cargar(numero,pagina)
{
if(numero=='+')
{
var win = window.open(pagina, '_blank'); 
win.focus();
}
}
</script>
</body>
</html>	
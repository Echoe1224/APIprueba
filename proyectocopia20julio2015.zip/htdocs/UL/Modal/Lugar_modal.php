﻿<?php
include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
// define variables and set to empty values
$errorNombre = "";
$nombre= $parametros = "";
$error = FALSE;
$ingresado = 0;
$cont=0;
$Consulta1=new Consulta;
        $Consulta2=new Consulta;  

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	if(isset($_POST["url"]))
	{
		$url=$_POST["url"];
	}
	$idLista=$_POST["idLista"];
	$idDiv=$_POST["idDiv"];
	$parametros="idLista=".$_POST["idLista"]."&idDiv=".$_POST["idDiv"];
	if(isset($_POST["nombre"]))
 {
                $nombre=$_POST["nombre"];
$cont++;
 }
            else
            {
                echo '<br> No Existe nombre';
            }
 if(isset($_POST["capacidad"]))
 {
                $capacidad=$_POST["capacidad"];
 }
            else
            {
                $capacidad=0;
            }

	if($cont>0)
	{
$consulta1->Lugar_verificar($nombre);
        $veri = $consulta1->Resultado;
        if(mysql_num_rows($veri)==0)
        {          
 $consulta1->RegistroLugares_insertar($nombre, $capacidad, '1');  
$nombre="";
$capacidad="";

		if (!$consulta1->Resultado)
			$error=TRUE;
		else
			$ingresado=TRUE;
$hecho="Lugar Ingresado con Éxito.";
      }
else
{
$errorNombre="* Ya existe un lugar con el mismo nombre";
}

	}
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<div class="btnCerrar">
<div class="btnCerrar">
<!-- EDITAR ---------------------------------------------------------- -->
    <a
    href="javascript:closeVentana(<?php echo $ingresado; ?>,'<?php echo $url; ?>','SELECT  `idLugar` AS  `id` ,  `Nombre` AS  `nombre` 
FROM  `Lugar` 
WHERE  `Disponible`=1 
ORDER BY  `idLugar` desc','<?php echo $idLista; ?>','<?php echo $idDiv; ?>');"
    ><i class="icon icon-cross"></i> Cerrar</a>
</div>



<?php
if($ingresado==FALSE)
{
    if($error==TRUE)
    {
        echo '<div align="center"><h3>No se pudo insertar el dato.\n<br />Puede que ya existe el dato.</h3></div>';
    }
    ?>
<div class="formularioVentana">
    <h2>Nuevo lugar</h2>
<!--    <hr> -->
<!--     <span class="error">* Campos requeridos</span> -->
    <table>
        <tr>
            <td>Nombre:</td>
            <td><input name="texto_nombre" type="text" id="texto_nombre" value="<?php echo $nombre;?>" size="15" maxlength="45" placeholder="Ingrese el nombre del Lugar." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ0-9 -]{1,45}" required title="Se necesita un nombre del Lugar(Letras y números)">
            <span class "error"> <?php echo $errorNombre ?></span>
            </td>
        </tr>
 <tr>
            <td>Capacidad:</td>
            <td><input name="texto_capacidad" type="text" id="texto_capacidad" value="<?php echo $capacidad;?>"size="15" maxlength="5" placeholder="Ingrese el capacidad del lugar." pattern="[0-9]{1,45}" required title="Se necesita una cantidad(solamente números)">
            <span class "error"> <?php echo $errorNombre ?></span>
            </td>
        </tr>
        <tr>
            <td></td>
<!-- EDITAR --------------------------------------------------------------- -->
<!-- onclick=ingresarDatos(url,parametro1=valor1&parametro2=valor2...) -->
            <td><input name="Botón" type="button" value="Ingresar" 
            onclick="ingresarDatos('<?php echo $url; ?>','<?php echo $parametros; ?>'+'&nombre='+document.getElementById('texto_nombre').value+'&capacidad='+document.getElementById('texto_capacidad').value)"></td>
            <!-- ingresarDatos(url,parametros & id=textboxId & nombre=textBoxNombre&...nombreParametro=valor) -->
        </tr>
  </table>
</div>
<?php
}else{
    echo '<div align="center"><h2><i class="icon icon-check"></i>Lugar Creado.</h2></div>';
}
?>
</body>
</html>
﻿<?php
include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
$consulta2=new Consulta;
// define variables and set to empty values
$errorNombre = "";
$nombre= $parametros = "";
$error = FALSE;
$ingresado = 0;
$cont=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	if(isset($_POST["url"]))
	{
		$url=$_POST["url"];
	}
	$idLista=$_POST["idLista"];
	$idDiv=$_POST["idDiv"];
	$parametros="idLista=".$_POST["idLista"]."&idDiv=".$_POST["idDiv"];

			$ingresado=TRUE;
 session_start();
$grupo=$_SESSION['idGrupoEvento'];
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<div class="btnCerrar">
<div class="btnCerrar">
<!-- EDITAR ---------------------------------------------------------- -->

    <a  id="boton_pag"
    href="javascript:closeVentanaper(<?php echo $ingresado; ?>,'<?php echo $url; ?>','SELECT idPersonal AS  `id` ,  `Nombre` AS  `nombre` 
FROM Personal WHERE GrupoEvento_idGrupoEvento =<?php echo $grupo; ?> AND EstadoPersonal =1 ORDER BY  `idPersonal` desc','<?php echo $idLista; ?>','<?php echo $idDiv; ?>');"
    ><i class="icon icon-cross"></i> Cerrar</a>
<script>
javascript:closeVentanaper(<?php echo $ingresado; ?>,'<?php echo $url; ?>','SELECT idPersonal AS  `id` ,  `Nombre` AS  `nombre` 
FROM Personal WHERE GrupoEvento_idGrupoEvento =<?php echo $grupo; ?> AND EstadoPersonal =1 ORDER BY  `idPersonal` desc','<?php echo $idLista; ?>','<?php echo $idDiv; ?>');
</script>
</div>
<?php
if($ingresado==FALSE)
{
header("Location: Semestre_ver.php");
    if($error==TRUE)
    {
        echo '<div align="center"><h3>No se pudo insertar el dato.\n<br />Puede que ya existe el dato.</h3></div>';
    }
    ?>
<div class="formularioVentana">
    <h2>Cargando Personal</h2>
<br></br>
<!--    <hr> -->
<!--     <span class="error">Ingresando personal, cuando termine presione cerrar</span> -->
    <table>
        <tr>
            
        </tr>
        <tr>
            <td>input type="hidden"  name="nombretipoevento" placeholder="Nombre del tipo de actividad." value="<?php echo $grupo; ?>"></td>
<!-- EDITAR --------------------------------------------------------------- -->
<!-- onclick=ingresarDatos(url,parametro1=valor1&parametro2=valor2...) -->
            <td><br></br><input name="Botón" type="button" value="Ingresar" 
            onclick="ingresarDatos('<?php echo $url; ?>','<?php echo $parametros; ?>'+'&nombre='+document.getElementById('nombretipoevento').value)"></td>
            <!-- ingresarDatos(url,parametros & id=textboxId & nombre=textBoxNombre&...nombreParametro=valor) -->
<td></td>
        </tr>
  </table>
</div>
<?php
}else{
    echo '<div align="center"><h2><i class="icon icon-check"></i>Cargando personal.</h2></div>';
}
?>
</body>
</html>
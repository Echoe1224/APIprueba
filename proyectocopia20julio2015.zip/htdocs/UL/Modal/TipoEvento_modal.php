<?php
include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
$consulta2=new Consulta;
// define variables and set to empty values
$errorNombre = "";
$nombre= $parametros = "";
$error = FALSE;
$ingresado = 0;
$cont=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	if(isset($_POST["url"]))
	{
		$url=$_POST["url"];
	}
	$idLista=$_POST["idLista"];
	$idDiv=$_POST["idDiv"];
	$parametros="idLista=".$_POST["idLista"]."&idDiv=".$_POST["idDiv"];
	if(isset($_POST["nombre"]))
	{
		if (empty($_POST["nombre"])) {
			$errorNombre = "El nombre de la actividad es requerido.";
		}
		else {
			$nombre= test_input($_POST["nombre"]);
			// check if name only contains letters and whitespace
			if (!preg_match("/^[a-zA-ZÁÉÍÓÚáéíóú]*$/",$nombre)) {
				$errorNombre = "Ingrese solamente letras.";
				}
			else{
				++$cont;
			}
		}
	}
	if($cont>0)
	{
 $consulta1->TipoEvento_verificar($nombre);
        $row = $consulta1->Resultado;
if(mysql_num_rows($row)==0)
{
		$consulta1->TipoEvento_insertar($nombre,1);

		if (!$consulta1->Resultado)
			$error=TRUE;
		else
			$ingresado=TRUE;
$consulta1->TipoEvento_verificar($nombre);
        $row =mysql_fetch_assoc($consulta1->Resultado);
$consulta1->GrupoEvento_ver();
while($veric=mysql_fetch_assoc($consulta1->Resultado))
{
$consulta2->Insertar_TipoEventoCantidad($row['idTipoEvento'],$veric['idGrupoEvento'],0);
}
}
else
{
$errorNombre = "Ya existe un tipo de actividad con el mismo nombre.";
}
	}
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<div class="btnCerrar">
<!-- EDITAR ---------------------------------------------------------- -->
    <a
    href="javascript:closeVentana(<?php echo $ingresado; ?>,'<?php echo $url; ?>','SELECT  `idTipoEvento` AS  `id` ,  `Nombre` AS  `nombre` 
FROM  `TipoEvento` 
WHERE  `Estado`=1 
ORDER BY  `idTipoEvento` desc','<?php echo $idLista; ?>','<?php echo $idDiv; ?>');"
    ><i class="icon icon-cross"></i> Cerrar</a>
</div>



<?php
if($ingresado==FALSE)
{
    if($error==TRUE)
    {
        echo '<div align="center"><h3>No se pudo insertar el dato.\n<br />Puede que ya existe el dato.</h3></div>';
    }
    ?>
<div class="formularioVentana">
    <h2>Nuevo tipo de actividad</h2>
<br></br>
<!--    <hr> -->
<!--     <span class="error">* Campos requeridos</span> -->
    <table>
        <tr>
            <td>Nombre:</td>
            <td><input type="text" id="nombretipoevento" name="nombretipoevento" placeholder="Nombre del tipo de actividad." value="<?php echo $nombre?>">
            <span class "error">* <?php echo $errorNombre ?></span>
            </td>
        </tr>
        <tr>
            <td></td>
<!-- EDITAR --------------------------------------------------------------- -->
<!-- onclick=ingresarDatos(url,parametro1=valor1&parametro2=valor2...) -->
            <td><br></br><input name="Botón" type="button" value="Ingresar" 
            onclick="ingresarDatos('<?php echo $url; ?>','<?php echo $parametros; ?>'+'&nombre='+document.getElementById('nombretipoevento').value)"></td>
            <!-- ingresarDatos(url,parametros & id=textboxId & nombre=textBoxNombre&...nombreParametro=valor) -->
<td></td>
        </tr>
  </table>
</div>
<?php
}else{
    echo '<div align="center"><h2><i class="icon icon-check"></i>Tipo de actividad creada.</h2></div>';
}
?>
</body>
</html>
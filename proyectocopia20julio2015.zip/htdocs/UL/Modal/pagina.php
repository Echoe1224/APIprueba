<?php
include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	$consulta1=new Consulta;
// define variables and set to empty values
$errorNombre = $errorId = "";
$nombre = $id = $url = $idLista = $etiquetaLista = $idDiv = "";
$ingresado = $error = FALSE;
$cont=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	if(isset($_POST["url"]))
	{
		$url=$_POST["url"];
	}
	if(isset($_POST["id"]))
	{
		if (empty($_POST["id"])) {
			$errorId = "El número es requerido.";
		}
		else {
			$id = test_input($_POST["id"]);
			// check if name only contains letters and whitespace
			if (!preg_match("/^[0-9]*$/",$id)) {
				$errorId = "Ingrese solamente números.";
				}
			else{
				++$cont;
			}
		}
	}
	if(isset($_POST["nombre"]))
	{
		if (empty($_POST["nombre"])) {
			$errorNombre = "El nombre es requerido.";
		}
		else {
			$nombre = test_input($_POST["nombre"]);
			// check if name only contains letters and whitespace
			if (!preg_match("/^[a-zA-ZÁÉÍÓÚÑáéíóúñ]*$/",$nombre)) {
				$errorNombre = "Ingrese solamente letras.";
				}
			else{
				++$cont;
			}
		}
	}
	if($cont==2)
	{
		$consulta1->prueba_nuevo($id,$nombre);
		if (!$consulta1->Resultado)
			$error=TRUE;
		else
			$ingresado=TRUE;
	}
	
	}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Página modal</title>
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
</head>

<body>
<!-- EDITAR --------------------------------------------------------------- -->
<!-- closeVentana(pagina,consulta,idLista,etiquetaLista,divLista) -->
<div class="btnCerrar"><a 
href="javascript:closeVentana('<?php echo $url; ?>','SELECT `id`, `Nombre` FROM `Prueba`','<?php echo $idLista; ?>','<?php echo $etiquetaLista; ?>','<?php echo $idDiv; ?>');"
><i class="icon icon-cross"></i> Cerrar</a></div>
<?php
	if($ingresado==FALSE)
	{
		if($error==TRUE)
		{
			echo '<div align="center"><h3>No se pudo insertar el dato.\n<br />Puede que ya existe el dato.</h3></div>';
		}
		?>
    <div class="formularioVentana">
        <h2>Formulario Nuevo Dato</h2>
        <hr>
        <table>
        <span class="error">* Campos requeridos</span>
              <tr>
                    <td>id:</td>
                    <td><input type="text" id="texto_id" name="texto_id" placeholder="Ingrese un número." value="<?php echo $id?>" >
                    <span class "error">* <?php echo $errorId ?></span>
                    </td>
              </tr>
                <tr>
                    <td>Nombre:</td>
                    <td><input type="text" id="texto_nombre" name="texto_nombre" placeholder="Nombre del número." value="<?php echo $nombre?>">
                    <span class "error">* <?php echo $errorNombre ?></span>
                    </td>
                </tr>
                <tr>
                    <td></td>
<!-- EDITAR --------------------------------------------------------------- -->
<!-- onclick=ingresarDatos(url,parametro1=valor1&parametro2=valor2...) -->
                    <td><input name="Botón" type="button" value="Ingresar" 
                    onclick="ingresarDatos('<?php echo $url; ?>','id='+document.getElementById('texto_id').value+ '&nombre='+document.getElementById('texto_nombre').value)"></td>
                    <!-- ingresarDatos(url, id=textboxId&nombre=textBoxNombre&...nombreParametro=valor) -->
                </tr>
	      </table>
    <?php
	}else{
        echo '<div align="center"><h2><i class="icon icon-check"></i>Dato ingresado.</h2></div>';
	}
	?>
	</div>
</body>
</html>
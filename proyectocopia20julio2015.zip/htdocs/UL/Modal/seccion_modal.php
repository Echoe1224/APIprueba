<?php
include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
// define variables and set to empty values
$errorSeccion = "";
$seccion = $parametros = "";
$error = FALSE;
$ingresado = 0;
$cont=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	if(isset($_POST["url"]))
	{
		$url=$_POST["url"];
	}
	$idLista=$_POST["idLista"];
	$idDiv=$_POST["idDiv"];
	$parametros="idLista=".$_POST["idLista"]."&idDiv=".$_POST["idDiv"];
	if(isset($_POST["seccion"]))
	{
		if (empty($_POST["seccion"])) {
			$errorSeccion = "El nombre de la sección es requerido.";
		}
		else {
			$seccion = test_input($_POST["seccion"]);
			// check if name only contains letters and whitespace
			if (!preg_match("/^[a-zA-ZÁÉÍÓÚÑáéíóúñ]*$/",$seccion)) {
				$errorSeccion = "Ingrese solamente letras.";
				}
			else{
				++$cont;
			}
		}
	}
	if($cont==1)
	{
		$consulta1->Seccion_verificar2($seccion);
		$row=mysql_fetch_assoc($consulta1->Resultado);
		if($row["cantidad"]!=0)
		{
			$errorSeccion="Ya existe la sección, verifique su estado.";
		}
		else
		{
			$consulta1->Seccion_nueva($seccion);
			if (!$consulta1->Resultado)
				$error=TRUE;
			else
				$ingresado=1;
		}
	}
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<div class="btnCerrar">
<!-- EDITAR ---------------------------------------------------------- -->
    <a
    href="javascript:closeVentana(<?php echo $ingresado; ?>,'<?php echo $url; ?>','SELECT `idSeccion` AS `id`, `Seccion` AS `nombre` FROM `Seccion` WHERE `EstadoSeccion`=1 ORDER BY `idSeccion` desc','<?php echo $idLista; ?>','<?php echo $idDiv; ?>');"
    ><i class="icon icon-cross"></i> Cerrar</a>
</div>


<?php
if($ingresado==FALSE)
{
    if($error==TRUE)
    {
        echo '<div align="center"><h3>No se pudo insertar el dato.\n<br />Puede que ya existe el dato.</h3></div>';
    }
    ?>
<div class="formularioVentana">
    <h2>Nueva sección</h2>
<!--    <hr> -->
<!--     <span class="error">* Campos requeridos</span> -->
    <table>
        <tr>
            <td>Sección:</td>
            <td><input type="text" id="texto_seccion" name="texto_seccion" placeholder="Nombre de la sección." value="<?php echo $seccion?>">
            <span class "error">* <?php echo $errorSeccion ?></span>
            </td>
        </tr>
        <tr>
            <td></td>
<!-- EDITAR --------------------------------------------------------------- -->
<!-- onclick=ingresarDatos(url,parametro1=valor1&parametro2=valor2...) -->
            <td><input name="Botón" type="button" value="Ingresar" 
            onclick="ingresarDatos('<?php echo $url; ?>','<?php echo $parametros; ?>'+'&seccion='+document.getElementById('texto_seccion').value)"></td>
            <!-- ingresarDatos(url,parametros & id=textboxId & nombre=textBoxNombre&...nombreParametro=valor) -->
        </tr>
  </table>
</div>
<?php
}else{
    echo '<div align="center"><h2><i class="icon icon-check"></i>Sección creada.</h2></div>';
}
?>
</body>
</html>
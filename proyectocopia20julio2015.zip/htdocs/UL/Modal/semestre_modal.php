<?php
include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
// define variables and set to empty values
$errorSemestre = "";
$semestre = $parametros = "";
$error = FALSE;
$ingresado = 0;
$cont=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	if(isset($_POST["url"]))
	{
		$url=$_POST["url"];
	}
	$idLista=$_POST["idLista"];
	$idDiv=$_POST["idDiv"];
	$parametros="idLista=".$_POST["idLista"]."&idDiv=".$_POST["idDiv"];
	if(isset($_POST["semestre"]))
	{
		if (empty($_POST["semestre"])) {
			$errorSemestre = "El nombre del semestre es requerido.";
		}
		else {
			$semestre = test_input($_POST["semestre"]);
			// check if name only contains letters and whitespace
			if (!preg_match("/^[a-zA-ZÁÉÍÓÚÑáéíóúñ]*$/",$semestre)) {
				$errorSemestre = "Ingrese solamente letras.";
				}
			else{
				++$cont;
			}
		}
	}
	if($cont==1)
	{
		$consulta1->Semestre_nuevo($semestre);
		if (!$consulta1->Resultado)
			$error=TRUE;
		else
			$ingresado=TRUE;
	}
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<div class="btnCerrar">
<!-- EDITAR ---------------------------------------------------------- -->
    <a
    href="javascript:closeVentana(<?php echo $ingresado; ?>,'<?php echo $url; ?>','SELECT  `idSemestre` AS  `id` ,  `Semestre` AS  `nombre` 
FROM  `Semestre` 
WHERE  `EstadoSemestre`=1 
ORDER BY  `idSemestre` desc','<?php echo $idLista; ?>','<?php echo $idDiv; ?>');"
    ><i class="icon icon-cross"></i> Cerrar</a>
</div>


<?php
if($ingresado==FALSE)
{
    if($error==TRUE)
    {
        echo '<div align="center"><h3>No se pudo insertar el dato.\n<br />Puede que ya existe el dato.</h3></div>';
    }
    ?>
<div class="formularioVentana">
    <h2>Nuevo Semestre</h2>
<!--    <hr> -->
<!--     <span class="error">* Campos requeridos</span> -->
    <table>
        <tr>
            <td>Semestre:</td>
            <td><input type="text" id="texto_semestre" name="texto_semestre" placeholder="Nombre del semestre." value="<?php echo $semestre?>">
            <span class "error">* <?php echo $errorSemestre ?></span>
            </td>
        </tr>
        <tr>
            <td></td>
<!-- EDITAR --------------------------------------------------------------- -->
<!-- onclick=ingresarDatos(url,parametro1=valor1&parametro2=valor2...) -->
            <td><input name="Botón" type="button" value="Ingresar" 
            onclick="ingresarDatos('<?php echo $url; ?>','<?php echo $parametros; ?>'+'&semestre='+document.getElementById('texto_semestre').value)"></td>
            <!-- ingresarDatos(url,parametros & id=textboxId & nombre=textBoxNombre&...nombreParametro=valor) -->
        </tr>
  </table>
</div>
<?php
}else{
    echo '<div align="center"><h2><i class="icon icon-check"></i>Semestre creado.</h2></div>';
}
?>
</body>
</html>
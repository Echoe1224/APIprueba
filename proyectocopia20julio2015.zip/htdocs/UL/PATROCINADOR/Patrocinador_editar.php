<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Editar patrocinador</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/Templates/menu.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<link rel="icon" type="image/ico" href="../../favicon.ico" />
<!-- InstanceBeginEditable name="head" -->
		
<?php
         
    	$consulta=new Consulta;
		$filtro=$_POST['idRegistro'];
        $nuevoId=$_POST['id'];
        $contador=0;
        //----vars para mostrar error------
        $nombreErr=$telefonoErr=$empresaErr=$cenasErr=$descErr="";
        
        if($filtro=='')
        {
            $filtro=$nuevoId;
        }
        
        $consulta=mysql_fetch_assoc(mysql_query("SELECT * FROM Patrocinador WHERE idPatrocinador='$filtro'"));   
        
                
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
           if (!empty($_POST["text_nombre"]))
            {
           
        		$nombre = test_input($_POST["text_nombre"]);
        		if (!preg_match("/^[a-zA-Z ñáéíóú ]*$/",$nombre)) 
        		{
          			$nombreErr="Ingrese solamente letras y espacios"; 
        		}
        		else
        		{
        			++$contador;
        		}
        	}
			
            if (!empty($_POST["text_telefono"]))
            {
        	
        		$telefono = test_input($_POST["text_telefono"]);
        		if (!preg_match("/^[0-9]*$/",$telefono)||(!preg_match("/^*$/",$telefono)&&strlen($telefono
        		)<8)) 
        		{
            	 	$telefonoErr ='El formato del número de teléfono es inválido.';
        		}
        		else
        		{
        			++$contador;
        		}
        	}
            
            if (!empty($_POST["text_empresa"]))
            {
        	
        		$empresa = test_input($_POST["text_empresa"]);		
        			++$contador;
        		
        	}
            
            if (!empty($_POST["text_cenas"]))
            {
        	
        		$cenas = test_input($_POST["text_cenas"]);
        		if (!preg_match("/^[0-9]*$/",$cenas)||(!preg_match("/^*$/",$cenas)&&strlen($cenas)<1)) 
        		{
            	 	$cenasErr ='El formato del número de cenas es inválido.';
        		}
        		else
        		{
        			++$contador;
        		}
        	}
            
            if (!empty($_POST["text_estado"]))
            {
                $estado=$_POST["text_estado"];
                if($estado=="Activar")
                {
                    $estado=1;
                }
                else if($estado=="Desactivar") {$estado=0;}
                ++$contador;
            }
				
			if (empty($_POST["descripcion"]))
            {
        		$descErr = "";
        	}
        	else
        	{
        		$descripcion = test_input($_POST["descripcion"]);
        	}    
	/*
            
				echo 'nombre:'.$nombre.'<br>';
				echo 'telefono:'.$telefon.'<br>';
				echo 'empresa:'.$empresa.'<br>';
				echo 'cenas:'.$cenas.'<br>';
				echo 'descrip:'.$descripcion.'<br>';
				echo 'Estado:'.$estado.'<br>';
				echo 'iddd:'.$nuevoId.'<br>';*/
                if($contador==5)
                {
                    $consulta1->Patrocinador_verificar_nombre2($nuevoId,$nombre);
                    $res=$consulta1->Resultado;
    
                    while($row = mysql_fetch_assoc($res))
                    {
        					$temp=$row["Cantidad"];                        
        			}
               
        			mysql_free_result($res);
                    if($temp==0)
            		{
        				$x=$consulta1->Actualizar_patrocinador($nombre,$telefono,$empresa,$cenas,$descripcion,$estado,$nuevoId);
        				header("Location: http:/UL/PATROCINADOR/Patrocinador_ver.php");
            		}
                    else
                    {
                            $nombreErr="Ya existe un patrocinador con el mismo nombre "; 
                    }
                }

					
		}
        
        function test_input($data) 
        {
          $data = trim($data);
          $data = stripslashes($data);
          $data = htmlspecialchars($data);
          return $data;
        }
?>
<style> 
.error {color: #FF0000;} 
</style>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
   <?php
    }
    else
    {
        if($_SESSION['idGrupoEvento']>0)
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <?php
        if(isset($_POST['idRegistro']))
        {
        	$idGrupo=$_POST['idRegistro'];
        }
		else
        {
			$idGrupo=0;
        }
        
        if ($idGrupo>0)
        {
		
        ?>
        	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >
<input name="formulario" id="formulario" value="Patrocinador_editar" type="hidden">
<input type="hidden" name="id" value="<?php echo $filtro ?>" />

  <div align="center"  >
  <h2 align="center">Editar patrocinador</h2>
                    <br />
            		<div align="center"><hr width="80%"></div>
                    <br />
                    <br />
                    <br />
<table width="522" align="center"  cellspacing="5">
  <tr>
    <td width="189">Nombre:</td>
    <td width="95"><input type="text" name="text_nombre" value="<? print $consulta['Nombre'];?>" placeholder="Ingrese el nombre del patrocinador." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" required title="Se necesita un nombre del patrocinador (solamente letras y espacios)" /><span class="error">* <?php echo $nombreErr;?></span> </td></td>
  </tr>
  <tr>
    <td>Teléfono:</td>
    <td><input type="text" name="text_telefono" maxlength="8" value="<? print $consulta['Telefono'];?>"  placeholder="Ingrese número de teléfono" pattern="[0-9]{8}" required title="Se necesita el número de teléfono del patrocinador (solamente números)"/><span class="error">* <?php echo $telefonoErr;?></span></td></td>
  </tr>
  <tr>
    <td>Empresa:</td>
    <td><input type="text" name="text_empresa" value="<? print $consulta['Empresa'];?>" placeholder="Ingrese el nombre de la empresa"  required title="Se necesita el nombre de la empresa"/><span class="error">* <?php echo $empresaErr;?></span></td></td>
  </tr>
  <tr>
    <td>Comidas (Desayuno, almuerzo, cena):</td>
    <td><input type="text" name="text_cenas" maxlength="2" value="<? print $consulta['Cenas'];?>" placeholder="Ingrese la cantidad de cenas" pattern="[0-9]" required title="Si no hay cenas, favor de ingresar 0"/><span class="error">* <?php echo $cenasErr ?></span></td></td>
  </tr>
  <tr>
    <td>Descripción del patrocinio:</td>
    <td>
        <textarea 
            name="descripcion" id="descripcion" cols="45" rows="5">  <?php echo $consulta['DescripcionPatrocinio'];?>
        </textarea>
    </td>
  </tr>
  <tr>
    <td>Estado:</td>
    <td> 
    <input type="radio" name="text_estado" <?php if (isset($consulta['EstadoPatrocinador']) && $consulta['EstadoPatrocinador']==1) echo "checked";?> value="Activar" id="text_estado">Activar
        <input type="radio" name="text_estado" <?php if (isset($consulta['EstadoPatrocinador']) && $consulta['EstadoPatrocinador']==0) echo "checked";?> value="Desactivar" id="text_estado">Desactivar
      </td>
  </tr>
</table>
 
<input type="submit" value="Guardar"/>
<input type="button" value="Cancelar" onClick="window.open('Patrocinador_ver.php','_self')"/>
 </div>
</form>
<?php
    }
    else
    {
        ?>
        <h2 align="center">Necesita seleccionar un patrocinador</h2>
        <br />
        <h4 align="center"><a href="Patrocinador_ver.php"> Seleccionar</a></h4>
        <?php
    }
    ?>
   
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
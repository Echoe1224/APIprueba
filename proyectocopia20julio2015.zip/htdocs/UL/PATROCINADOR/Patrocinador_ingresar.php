<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Ingresar patrocinador</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*    include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/Templates/menu.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<link rel="icon" type="image/ico" href="../../favicon.ico" />
<!-- InstanceBeginEditable name="head" -->
		
<?php
	$MiConsulta=new Consulta;
	
$nombreErr=$telefonoErr=$empresaErr=$cenasErr=$descErr="";
$nombre=$telefono=$empresa=$cenas=$desc="";
$contador=0;

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
	if (empty($_POST["text_nombre"]))
	{
		$nombreErr="El nombre es requerido";
	}
	else
	{
		$nombre = test_input($_POST["text_nombre"]);
		if (!preg_match("/^[a-zA-Z ñáéíóú ]*$/",$nombre)) 
		{
  			$nombreErr="Ingrese solamente letras y espacios"; 
		}
		else
		{
			++$contador;
		}
	}
	if (empty($_POST["text_telefono"]))
	{
		$telefonoErr ="El telefono es requerido";
	}
	else
	{
		$telefono = test_input($_POST["text_telefono"]);
		if (!preg_match("/^[0-9]*$/",$telefono)||(!preg_match("/^*$/",$telefono)&&strlen($telefono
		)<8)) 
		{
    	 	$telefonoErr ='El formato del número de teléfono es inválido.';
		}
		else
		{
			++$contador;
		}
	}
	if (empty($_POST["text_empresa"]))
	{
		$empresaErr="El nombre de la empresa es requerido";
	}
	else
	{
		$empresa = test_input($_POST["text_empresa"]);		
			++$contador;
		
	}
	
	if (empty($_POST["text_cenas"]))
	{
		$cenasErr="este campo es requerido";
	}
	else
	{
		$cenas = test_input($_POST["text_cenas"]);
		if (!preg_match("/^[0-9]*$/",$cenas)||(!preg_match("/^*$/",$cenas)&&strlen($cenas)<1)) 
		{
    	 	$cenasErr ='El formato del número de cenas es inválido.';
		}
		else
		{
			++$contador;
		}
	}
	if (empty($_POST["text_desc"]))
	{
		$descErr = "";
	}
	else
	{
		$desc = test_input($_POST["text_desc"]);
	}
	
	
	if($contador==4)
	{           
                $temp=1;
                $MiConsulta->Patrocinador_verificar_nombre($nombre);
                $res=$MiConsulta->Resultado;
            	while($row = mysql_fetch_assoc($res))
                {
    					$temp=$row["Cantidad"];
                        
    			}

    			mysql_free_result($res);
                if($temp==0)
        		{
            		$MiConsulta->Insertar_patrocinador($nombre,$telefono,$empresa,$cenas,$desc);
            	
            		$nombre=$telefono=$empresa=$cenas=$desc="";
            		$nombreErr=$telefonoErr=$cenasErr=$descErr="";
                    header("Location:http:/UL/PATROCINADOR/Patrocinador_ver.php");
        		}
                else
                {
                    $nombreErr="Ya existe un Patrocinador con éste nombre. \n Por favor intente con otro nombre";
                }
	}


}


function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<style> 
.error {color: #FF0000;} 
</style> 
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
        if($_SESSION['idGrupoEvento']>0)
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            <div align="center">
            <h2 align="center">Agregar nuevo patrocinador</h2>
                    <br />
            		<div align="center"><hr width="80%"></div>
                    <br />
                    <br />
                    <br />

              <table width="608" border="0" cellspacing="5">
                <tr>
                  <td width="158"><label for="text_nombre">Nombre: </label></td>
                  <td width="300"><input name="text_nombre" type="text" id="text_nombre" size="50" maxlength="45" value="<?php echo $nombre; ?>"  placeholder="Ingrese el nombre del patrocinador." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" required title="Se necesita un nombre del patrocinador (solamente letras y espacios)" />
                    <span class="error">* <?php echo $nombreErr;?></span></td>
                </tr>
                <tr>
                  <td>Teféfono:</td>
                  <td><input name ="text_telefono" type="text" id="text_telefono" size ="20" maxlength="8" value="<?php echo $telefono; ?>"  placeholder="Ingrese número de teléfono" pattern="[0-9]{8}" required title="Se necesita el número de teléfono del patrocinador (solamente números)"/>
                    <span class="error">* <?php echo $telefonoErr;?></span></td>
                </tr>
                <tr>
                  <td>Empresa:</td>
                  <td><input name="text_empresa" type="text" id="text_empresa" size="50" maxlength="45" value="<?php echo $empresa; ?>" placeholder="Ingrese el nombre de la empresa"  required title="Se necesita el nombre de la empresa"/>
                    <span class="error">* <?php echo $empresaErr;?></span></td>
                </tr>
                <tr>
                  <td>Comidas (Desayuno, almuerzo, cena):</td>
                  <td><input name="text_cenas" type="text" id="text_cenas" size="20" maxlength="2" value="<?php echo $cenas; ?>" placeholder="Ingrese la cantidad de comidas" pattern="[0-9]" required title="si no hay comidas, favor de ingresar 0"/>
                    <span class="error">* <?php echo $cenasErr ?></span></td>
                </tr>
                <tr>
                  <td>Descripción del patrocinio:</td>
                  <td><textarea name="text_desc" id="text_desc" cols="45" rows="5"><?php echo $desc;?></textarea></td>
                </tr>
              </table>
              <p>
                <input type="submit" name="boton_guardar"  id="boton_guardar" value="Guardar" />
                <input type="button" name="boton_cancelar" id="boton_cancelar" value="Cancelar" onclick="window.open('Patrocinador_ver.php','_self')" />
              </p>
            </div>
        	</form>   
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
<?php session_start();
//include_once "http://citein.hostingla.in/UL/conexion.php";
function verificar_login($user,$password,&$result) 
{
    $sql = "SELECT * FROM Usuario WHERE Usuario = '$user' and Contrasena = '$password' and Estado='1'";
    $rec = mysql_query($sql) or die('Mi error es: '.mysql_error());
    $count = 0;
    while($row = @mysql_fetch_object($rec))
    {
        $count++;
        $result = $row;
    }
    if($count == 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
if(!isset($_SESSION['userid']))
{
    if(isset($_POST['boton_login']))
    {
        if(verificar_login($_POST['texto_usuario'],$_POST['texto_pass'],$result) == 1)
        {
            $_SESSION['userid'] = $result->idUsuario;
            $_SESSION['usuario']=$result->Usuario;
            $_SESSION['tipo']=$result->Administrador;
            $_SESSION['nombre']=$result->Nombre;
            header("location:/UL/Inicio/inicio.php");
        }
        else
        {
            echo '<script>abrirVentana2();</script>';
        }
    }
    ?>
    <style type="text/css">
	
	.login-popup {
    display: none;
    background: #333;
    padding: 10px;
    border: 2px solid #ddd;
    float: left;
    font-size: 1.2em;
    position: fixed;
    top: 50%;
    left: 50%;
    z-index: 99999;
    box-shadow: 0px 0px 20px #999;
    /* CSS3 */
        -moz-box-shadow: 0px 0px 20px #999;
    /* Firefox */
        -webkit-box-shadow: 0px 0px 20px #999;
    /* Safari, Chrome */
	border-radius: 3px 3px 3px 3px;
    -moz-border-radius: 3px;
    /* Firefox */
        -webkit-border-radius: 3px;
    /* Safari, Chrome */;
}
    
	.myButton {
	background-color:#1e8038;
	-moz-border-radius:7px;
	-webkit-border-radius:7px;
	border-radius:7px;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:21px;
	padding:16px 31px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.myButton:hover {
	background-color:#5cbf2a;
}
.myButton:active {
	position:relative;
	top:1px;
}

      

.text1
{
border: 2px solid rgb(173, 204, 204);
height: 31px;
width: 100px;
box-shadow: 0px 0px 27px rgb(204, 204, 204) inset;
transition:500ms all ease;
padding:3px 3px 3px 3px;
}

.text1:hover, .text1:focus
{
width:150px;
transition:500ms all ease;
background:url(http://simpleicon.com/wp-content/uploads/users-2.png) no-repeat right;
background-size:25px 25px;
background-position:96% 62%;
padding:3px 32px 3px 3px;
}
.text2
{
border: 2px solid rgb(173, 204, 204);
height: 31px;
width: 100px;
box-shadow: 0px 0px 27px rgb(204, 204, 204) inset;
transition:500ms all ease;
padding:3px 3px 3px 3px;
}

.text2:hover, .text2:focus
{
width:150px;
transition:500ms all ease;
background:url(http://simpleicon.com/wp-content/uploads/lock-1.png) no-repeat right;
background-size:25px 25px;
background-position:96% 62%;
padding:3px 32px 3px 3px;
}

    </style>
<form  id="form1" name="form1" method="post" autocomplete="off" action="">
<div  id="cerrar" class="cerrar" align="right"><span style="cursor:pointer;" onclick="cerrarVentana();" title="Cerrar">X</span></div>
<h2 style="color:#FFF" align="left">Iniciar sesión</h2>
<div align="center">
<hr>

    <table style="color:#FFF" width="252" height="147" border="0" cellspacing="5">
      <tr>
	    <td sty width="103">Usuario:</td>
        <td>

	      <label for="texto_usuario"></label>
	      <input  class="text1" name="texto_usuario" type="text" id="texto_usuario" accesskey="u" size="20" maxlength="10" />
    	</td>
    </tr>
	  <tr>
	    <td>Contraseña:</td>
	    <td>
	      <label for="texto_pass">
	        <input class="text2" name="texto_pass" type="password" id="texto_pass" accesskey="c" size="20" maxlength="10" />
	      </label></td>
    </tr>
  </table>
  
  </div>
  <hr>
  <div align="right">
      <table>
        <tr>
            <td align="center" >
              <input class="myButton" type="submit" name="boton_login" id="boton_login" value="Ingresar" />
            </td>
            
        </tr>
      </table>
  </div>
  

  </form>
  
<?php
}
else 
{ 
        if(!isset($_SESSION['usuario']))header("Location: logout.php");  
        $tiempo = (isset($_SESSION['time'])) ? $_SESSION['time'] : strtotime(date("Y-m-d H:i:s")); 
        $actual =  strtotime(date("Y-m-d H:i:s")); 
        (($actual-$tiempo) >= 900) ? header("Location: ../../UL/Login/logout.php") : $_SESSION['time'] =$actual;
        ?>


<div align="center">
<H3>Ha iniciado sesión como "<?php echo $_SESSION['usuario'];?>"</H3>
<br/>
<a href="http://citein.hostingla.in/UL/Inicio/inicio.php"><H3>Ir a la pagina de inicio</H3></a>
<br/>
<a href="../../UL/Login/logout.php"><H3>Cerrar Sesion</H3></a>
<?php
}
?>
</div>


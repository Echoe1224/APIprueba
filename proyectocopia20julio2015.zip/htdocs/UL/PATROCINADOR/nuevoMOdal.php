<style type="text/css">
    .alert-box {
		color:#555;
		border-radius:10px;
		font-family:Tahoma,Geneva,Arial,sans-serif;font-size:11px;
		padding:10px 36px;
		margin:10px;
	}
	.alert-box span {
		font-weight:bold;
		text-transform:uppercase;
	}
	.error 
        {
		background:#ffecec url('http://icdn.pro/images/es/b/o/boton-de-error-icono-5371-128.png') no-repeat 10px 50%;
		border:1px solid #f5aca6;
	}
	</style>
<div id="cerrar" class="cerrar" align="right"><span style="cursor:pointer;" onclick="cerrarVentana(),cerrarVentana();" title="Cerrar">X</span></div>
<br /><br /><br /><br /><br /><br /><br /><br />
<div align="center" class="alert-box error"><span>error: </span>Datos incorrectos, intente nuevamente</div>
<br /><br /><br /><br /><br /><br /><br /><br />
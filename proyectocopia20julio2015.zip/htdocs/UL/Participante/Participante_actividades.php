<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Actividades y playeras del participante</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<!-- <script src="../UL/CITEIN/jquery-1.11.3.js"></script>-->
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if(isset($_POST["idE"]) && isset($_POST["idL"]))
	{
		$consulta1->EventoParticipante_nuevo($_POST["idRegistro"],$_POST["idE"],$_POST["idL"],$_POST["et"]);
	}
	else if(isset($_POST["el"]))
	{
		$consulta1->EventoParticipante_eliminar2($_POST["idRegistro"],$_POST["idEvento"]);
	}
	else if(isset($_POST["idP"]))
	{
		$consulta1->ParticipantePlayera_nueva($_POST["idRegistro"],$_POST["idP"],$_POST["CE"]);
	}
	else if(isset($_POST["idPE"]))
	{
		$consulta1->ParticipantePlayera_eliminar($_POST["idRegistro"],$_POST["idPE"]);
	}
}
?>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar.</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h2 align="center">'.$NombreG.'</h2>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
<?php
        if(!isset($_POST['idRegistro']))
	    {
    		echo '<h5 align="center">Seleccione un participante</h5>';
            echo '<div align="center"><a href="Participante_ver.php">Seleccionar un participante.</a></div>';
        }
		else
		{
?>
        <a style="padding-left:50px; color:#333; text-decoration:none" href="Participante_ver.php"><i class="icon icon-undo2"></i> Atrás</a>
        <br  />
        <br  />
  <form id="form1" name="form1" method="post" action="">
  <h2>Actividades del participante</h2>
  <br  />
<!-- desplegar todos las actividades, ordenados por tipo de actividad, desplegar:nombre,fecha,horaI y Final, tipoActividad -->
    <div class="dataGridViewDiv">
    <table class = "tabla">
    	<tr class="dgv-titulo">
    	<?php
		$consulta1->Participante_eventos($_POST["idRegistro"]);
		/*idParticipante`,
        `idEvento`,`Tipo de actividad`,Actividad,`Descripción`,Fecha,`Hora de inicio`,`Hora final`,`Costo extra`*/
		$res=$consulta1->Resultado;
		$i = 2;
//Encabezado del dataGridView
		while ($i < mysql_num_fields($res))
		{
			$metadatos = mysql_fetch_field($res, $i);
			?>
            <td><?php echo $metadatos->name;?></td>
            <?php
			$i++;
		}
		?>
			<td>Opciones</td>
		</tr>
        <?php
		//Datos del dataGridView
		$agregar=false;
		while($row=mysql_fetch_assoc($res))
		{
			//donde se agregan los datos que se mostraran en cada columna
			//para agregar color a una fila
				$clase="filaTablaSinFondo";
				if($agregar)
					$clase="filaTablaConFondo";
			?>
            <tr class="<?php echo $clase;?>">
            <?php
			//$i:desde que columna se empieza a graficar
			$i = 2;
			while ($i < mysql_num_fields($res) && $i!=0) {
				$metadatos = mysql_fetch_field($res, $i);
				
                ?>
				<td>
                <?php
				//Columnas vacías
				if($metadatos->name=="Costo extra")
				{
					echo 'Q. '.$row["Costo extra"];
				}
				else
					echo $row[$metadatos->name];
				?>
				</td>
				<?php
                ++$i;
			}
			$pagDetalles='\'Participante_ver_detalle.php\'';
//Opciones que tendra cada registro del dataGridView
			?>
            <td>
            <?php
			//Eliminar
			?>
				<span style="cursor:pointer;" onclick="eliminarActividad(<?php echo $row["idEvento"];?>);"><i class="icon icon-bin"></i> Eliminar</span><br />
			</td>
            </tr>
            <?php
			if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
		}
		?>
    </table>
    </div>
	<br  />
	<table width="595" border="0" cellspacing="5" style="border-bottom:1px solid #333; border-top:1px solid #333;">
	  <tr width="124" style="font-weight:bold;">
	    <td width="133" style="border-bottom:1px solid #333;">Tipo de actividad</td>
	    <td width="164" style="border-bottom:1px solid #333;">Derechos a participar</td>
	    <td width="88" style="border-bottom:1px solid #333;">Asignadas</td>
	    <td width="153" style="border-bottom:1px solid #333;">Total de costo extra</td>
	    <td width="17">&nbsp;</td>
      </tr>
      <?php
	  	$consulta1->TipoEventoCantidad_asignadas($_POST["idRegistro"],$_SESSION['idGrupoEvento']);
		$res=$consulta1->Resultado;
		/*`TipoEventoCantidad`.TipoEvento_idTipoEvento, `TipoEventoCantidad`.GrupoEvento_idGrupoEvento,TipoEvento.Nombre as `Tipo de actividad`, `TipoEventoCantidad`.`Cantidad` as `Permitidas`,`Asignadas` ,Total*/
		$total=0;
		while($row=mysql_fetch_assoc($res))
		{
	  ?>
      <tr>
	    <td><?php echo $row["Tipo de actividad"];?></td>
	    <td><?php echo $row["Permitidas"];?></td>
	    <td><?php echo $row["Asignadas"];?></td>
	    <td><?php echo $row["Total"];?></td>
	    <td><input type="hidden" id="r<?php echo $row["TipoEvento_idTipoEvento"];?>" value="<?php echo $row["Permitidas"]-$row["Asignadas"];?>" /></td>
      </tr>
      <?php
		  $total=$total+$row["Total"];
		}
	  ?>
	  <tr>
	    <td>&nbsp;</td>
	    <td>&nbsp;</td>
	    <td>&nbsp;</td>
	    <td><?php echo 'Total: Q. '.$total;?></td>
	    <td>&nbsp;</td>
      </tr>
	  </table>
      <br />
      <h2>Playeras del participante</h2>
	  <br  />
      <div class="dataGridViewDiv">
    <table class = "tabla">
    	<tr class="dgv-titulo">
    	<?php
		$consulta1->Participante_playeras($_POST["idRegistro"]);
		/*`Participante_idParticipante`, `Playera_idPlayera`,`Playera`, p.`Costo`*/
		$res=$consulta1->Resultado;
		$cantPlayeras=0;
		$cantPlayeras=mysql_num_rows($res);
		$i = 2;
//Encabezado del dataGridView
		while ($i < mysql_num_fields($res))
		{
			$metadatos = mysql_fetch_field($res, $i);
			?>
            <td><?php echo $metadatos->name;?></td>
            <?php
			$i++;
		}
		?>
			<td>Opciones</td>
		</tr>
        <?php
		//Datos del dataGridView
		$agregar=false;
		while($row=mysql_fetch_assoc($res))
		{
			//donde se agregan los datos que se mostraran en cada columna
			//para agregar color a una fila
				$clase="filaTablaSinFondo";
				if($agregar)
					$clase="filaTablaConFondo";
			?>
            <tr class="<?php echo $clase;?>">
            <?php
			//$i:desde que columna se empieza a graficar
			$i = 2;
			while ($i < mysql_num_fields($res) && $i!=0) {
				$metadatos = mysql_fetch_field($res, $i);
				
                ?>
				<td>
                <?php
				//Columnas vacías
				if($metadatos->name=="Costo")
				{
					echo 'Q. '.$row["Costo"];
				}
				else
					echo $row[$metadatos->name];
				?>
				</td>
				<?php
                ++$i;
			}
//Opciones que tendra cada registro del dataGridView
			?>
            <td>
            <?php
			//Eliminar
			?>
				<span style="cursor:pointer;" onclick="eliminarPlayera(<?php echo $row["Playera_idPlayera"];?>);"><i class="icon icon-bin"></i> Eliminar</span><br />
			</td>
            </tr>
            <?php
			if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
		}
		?>
    </table>
    </div>
  </form>
  <form id="form3" name="form3" method="post" action="">
    <input type="hidden" name="idRegistro" id=="idRegistro" value="<?php echo $_POST["idRegistro"]; ?>" />
    <input type="hidden" name="idPE" id="idPE" />
    <input style="display:none;" type="submit" name="boton_eliminar_playera" id="boton_eliminar_playera" value="Enviar" />
  </form>
<div align="right">
    	<a class="boton-link" href="javascript:imprimir('form1');"><i class="icon icon-printer"></i> Imprimir</a>
    </div>
    <br />
    <hr>
  	<div>
   	  <h2 align="center">Asignar actividades al participante</h2>
   	  <br  />
      <h4>Seleccione un tipo de actividad.</h4>
      <label for="lista_tipos">Tipo de actividad: </label>
      <select name="lista_tipos" id="lista_tipos" onchange="verActividades();">
      	<?php
	  	$consulta1->TipoEvento_ver_lista($_SESSION['idGrupoEvento']);
		$res=$consulta1->Resultado;
		//`id`, `nombre`
		while($row=mysql_fetch_assoc($res))
		{
	  	?>
        <option value="<?php echo $row["id"];?>"><?php echo $row["nombre"];?></option>
        <?php
		}
		?>
      </select>
      <p style="color:#F00; font-weight:bold; display:none;" id="advertencia">Advertencia: La actividad tendrá un costo extra.</p>
      <div id="actividades">
      </div>
      <div id="lugares">
      </div>
      <br  />
      <input type="button" name="boton_asignar" id="boton_asignar" value="Asignar actividad" onclick="Asignar();" />
    </div>
    <div>
    <br />
    <hr />
   	  <h2 align="center">Agregar playeras al participante</h2>
      <?php
	  if($cantPlayeras>0)
	  {
	  ?>
      <p style="color:#F00; font-weight:bold;" id="advertencia">Advertencia: La playera tendrá un costo extra.</p>
      <?php
	  }
	  ?>
      <div class="dataGridViewDiv">
    <table class = "tabla">
    	<tr class="dgv-titulo">
    	<?php
		$consulta1->Playera_disponibles_participante($_POST["idRegistro"],$_SESSION['idGrupoEvento']);
		/*`idPlayera`, `Playera`,`Costo`*/
		$res=$consulta1->Resultado;
		$i = 1;
//Encabezado del dataGridView
		while ($i < mysql_num_fields($res))
		{
			$metadatos = mysql_fetch_field($res, $i);
			?>
            <td><?php echo $metadatos->name;?></td>
            <?php
			$i++;
		}
		?>
			<td>Opciones</td>
		</tr>
        <?php
		//Datos del dataGridView
		$agregar=false;
		while($row=mysql_fetch_assoc($res))
		{
			//donde se agregan los datos que se mostraran en cada columna
			//para agregar color a una fila
				$clase="filaTablaSinFondo";
				if($agregar)
					$clase="filaTablaConFondo";
			?>
            <tr class="<?php echo $clase;?>">
            <?php
			//$i:desde que columna se empieza a graficar
			$i = 1;
			while ($i < mysql_num_fields($res) && $i!=0) {
				$metadatos = mysql_fetch_field($res, $i);
				
                ?>
				<td>
                <?php
				//Columnas vacías
				if($metadatos->name=="Costo")
				{
					if($cantPlayeras==0)
						echo 'Q. 0.00';
					else
						echo 'Q. '.$row["Costo"];
				}
				else
					echo $row[$metadatos->name];
				?>
				</td>
				<?php
                ++$i;
			}
//Opciones que tendra cada registro del dataGridView
			?>
            <td>
            <?php
			//Eliminar
			?>
				<span style="cursor:pointer;" onclick="agregarPlayera(<?php echo $row["idPlayera"];?>);"><i class="icon icon-plus"></i> Agregar</span><br />
			</td>
            </tr>
            <?php
			if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
		}
		?>
    </table>
    <form id="form2" name="form2" method="post" action="">
      <input type="hidden" name="idRegistro" id="idRegistro" value="<?php echo $_POST["idRegistro"]; ?>" />
      <input type="hidden" name="idP" id="idP" />
      <input type="hidden" name="CE" id="CE" value="<?php if($cantPlayeras>0) echo 1; else echo 0; ?>" />
      <input style="display:none;" type="submit" name="boton_agregar_playera" id="boton_agregar_playera" value="Enviar" />
    </form>
      </div>
    </div>
    <script>
	verActividades();
	function Asignar()
	{
		if(document.getElementById('lista_actividades')!=null && document.getElementById('lista_lugar')!=null)
		{
			if(parseInt(document.getElementById('disponible').innerHTML)>0)
			{
			var extra=0;
			if(document.getElementById("r"+document.getElementById('lista_tipos').value).value<=0)
				extra=1;
			AbrirPaginaPostConParametros('Participante_actividades.php',"idRegistro="+<?php echo $_POST["idRegistro"];?>+"&idE="+document.getElementById('lista_actividades').value+"&idL="+document.getElementById('lista_lugar').value+"&et="+extra);
			}
			else
			alert('Ya no hay espacio en el lugar seleccionado.');
		}
		else
		{
			alert('Se debe seleccionar una actividad y un lugar.');
		}
	}
	function verActividades()
	{
		var val=parseInt(document.getElementById("r"+document.getElementById('lista_tipos').value).value);
		var parametros="";
		if(val<=0)
		{
			document.getElementById('advertencia').style.display='';
			parametros="d=1";
		}
		else
		{
			document.getElementById('advertencia').style.display='none';
			parametros="d=0";
		}
		document.getElementById('actividades').innerHTML="Cargando...";
		document.getElementById('lugares').innerHTML="";
		parametros=parametros+"&idParticipante="+<?php echo $_POST["idRegistro"];?>;
		parametros=parametros+"&idGrupo="+<?php echo $_SESSION['idGrupoEvento'];?>;
		parametros=parametros+"&idTipoEvento="+document.getElementById('lista_tipos').value;
		ProcesarPaginaGetConParametros("Participante_actividades_disponibles.php",parametros,"actividades");
/*		var checkExist = setInterval(function() {
			if (document.getElementById("lista_actividades")!=null) {
				var x = document.getElementById("lista_actividades");
				x.remove(x.length-1);
				clearInterval(checkExist);
				}}, 500); // check every 100ms*/
		var element = document.getElementById("actividades");
		var alignWithTop = true;
		element.scrollIntoView(alignWithTop);
		verLugares();
	}
	function verLugares()
	{
		var cont=0;
		document.getElementById('lugares').innerHTML="Cargando...";
		var checkExist = setInterval(function() 
		{
			if(cont<6)
				cont++;
			else
				document.getElementById('lugares').innerHTML="";
			var x=document.getElementById("lista_actividades");
			if (x!=null) 
			{
				clearInterval(checkExist);
				if(x.length>0)
				{
					var parametros="idEvento="+x.value;
					ProcesarPaginaGetConParametros("Participante_lugares_actividad_disponibles.php",parametros,"lugares");
				}
			}
		}, 500);
		verDetalle();
	}
	function verDetalle()
	{
		var checkList = setInterval(function() 
		{
			var l = document.getElementById("lista_lugar");
			if (l!=null && l.length>0)
			{
				clearInterval(checkList);
				document.getElementById('capacidad').innerHTML=document.getElementById("c"+l.value).value;
				document.getElementById('disponible').innerHTML=document.getElementById("d"+l.value).value;
			}
		}, 500);
		/*
		document.getElementById('detallesLugar').innerHTML("Capacidad: "+lugarDetalle[document.getElementById("lista_lugar").selectedIndex,0]+"  Disponible: "+lugarDetalle[document.getElementById("lista_lugar").selectedIndex,1]);*/
	}
	function eliminarActividad(id)
	{
		if(confirm("Se eliminará la actividad del participante."))
		{
			var parametros="idRegistro="+<?php echo $_POST["idRegistro"];?>;
			parametros=parametros+"&el=1&idEvento="+id;
			AbrirPaginaPostConParametros("Participante_actividades.php",parametros);
		}
	}
	function agregarPlayera(id)
	{
		document.getElementById('idP').value=id;
		document.getElementById('boton_agregar_playera').click();
	}
	function eliminarPlayera(id)
	{
		document.getElementById('idPE').value=id;
		document.getElementById('boton_eliminar_playera').click();
	}
	</script>
    <?php
		}
	?>
        <!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
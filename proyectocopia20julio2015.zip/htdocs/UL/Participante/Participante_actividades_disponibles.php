<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Actividades disponibles</title>
<script src="../../BLL/ajax.js" language="javascript"></script>
</head>

<body>
<p>
  <?php
	//Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";  
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";  
	$Consulta1=new Consulta;
	$idParticipante=$_GET['idParticipante'];
	$idGrupo=$_GET['idGrupo'];
	$idTipoEvento=$_GET['idTipoEvento'];
	$desplegar=$_GET['d'];
//Consulta que se quiere ver en el dataGridView
   $Consulta1->Evento_disponibles_participante($idParticipante,$idGrupo,$idTipoEvento);
   /*E1.`idEvento`,E1.`Nombre` as `Actividad`,E1.`DescripcionEvento` as `Descripción`,E1.`Fecha`,E1.`HoraInicio` as `Hora de inicio`,E1.`HoraFinal` as `Hora final`*/
   if(mysql_num_rows($Consulta1->Resultado)==0)
	{
	  print 'No hay actividades disponibles para el participante';  
	}
	else
	{
		?>
		<h3>Listado de actividades</h3>
        <?php
		//Se agrega el codigo del ancabezado de la tabla
		print'<table class = "tabla">';
		echo "\n";
		echo '<tr class="dgv-titulo">';
		//$i:desde que columna se empieza a graficar
		$i = 1;
//Encabezado del dataGridView
		while ($i < mysql_num_fields($Consulta1->Resultado)) {
				$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				echo '<td>'.$metadatos->name.'</td>';
				echo "\n";
				$i++;
			}
		print '</tr>';
		echo "\n";
//Datos del dataGridView
		$agregar=false;
		while($row=mysql_fetch_assoc($Consulta1->Resultado))
		{
			$clase="filaTablaSinFondo";
			if($agregar)
				$clase="filaTablaConFondo";
			//donde se agregan los datos que se mostraran en cada columna
			print'<tr >';
			echo "\n";
			//$i:desde que columna se empieza a graficar
			$i = 1;
			while ($i < mysql_num_fields($Consulta1->Resultado) && $i!=0) 
			{
				$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				//para agregar color a una fila
				echo '<td>';
			//Columnas que son de tipo booleano.						
				if($metadatos->name=="Descripción")
				{
				   echo substr($row[$metadatos->name],0,40);
				}
				else if($metadatos->name=="Costo extra")
				{
					if($desplegar==1)
						echo $row[$metadatos->name];
					else
						echo "0.00";
				}
				else
					echo $row[$metadatos->name];
				echo "</td>\n";						
				++$i;
			}					
			echo "\n";
			print '</tr>';
			if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
		}
		print '</table>';
		?>
        <br  />
<div>
  <p>
  <h4>Seleccione una actividad.</h4>
    <label for="lista_actividades">Actividad: </label>
    <select name="lista_actividades" id="lista_actividades" onchange="verLugares()">
      <?php
	  mysql_data_seek($Consulta1->Resultado, 0);
		while($row=mysql_fetch_assoc($Consulta1->Resultado))
		{
		?>
      	<option value="<?PHP echo $row["idEvento"];?>"><?PHP echo $row["Actividad"];?></option>
      	<?php
		}
		?>      
    </select>
  </p>
</div>
<p>
  <?php
	}
?>
</p>
</body>
</html>
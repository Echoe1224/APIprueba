<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Editando participante</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<!-- <script src="../UL/CITEIN/jquery-1.11.3.js"></script>-->
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="../../BLL/modal.js" language="JavaScript"></script>
<?php
// define variables and set to empty values
$errorNombre = $errorCarne = $errorUsuario = $errorJornada = $errorSeccion = $errorGenero = $errorSemestre = "";
$nombre = $carne = $semestre = $talla = $foto = $usuario = $seccion = $jornada = $genero = $playera = $idParticipante = $estado = "";
$cont=0;
$actualizado=FALSE;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	/* Si presionaron en cancelar la actualización */
if($_POST["boton"]=="Cancelar")
	header('Location: Participante_ver.php');
else if($_POST["boton"]=="Guardar")
{
	if(!empty($_POST["idRegistro"]))
	{
		$idParticipante=$_POST["idRegistro"];
		++$cont;
	}
	if (empty($_POST["texto_nombre"])) {
	   	$errorNombre = "El nombre es requerido.";
	}
	else {
		$nombre = test_input($_POST["texto_nombre"]);
	    // check if name only contains letters and whitespace
		if (!preg_match("/^[a-zA-ZÁÉÍÓÚÑáéíóúñ ]*$/",$nombre)) {
    		$errorNombre = "Ingrese solamente letras y espacios.";
			}
		else{
			++$cont;
		}
	}
	if(empty($_POST["texto_carne"])){
   		$carne=0;
		++$cont;
	}
	else{
	   $carne = test_input($_POST["texto_carne"]);
	   /*if (!preg_match("/^[0-9]*$/",$carne)||(!preg_match("/^*$/",$carne)&&strlen($carne)<9))*/
	   if (strlen($carne)<9) {
    	 	$errorCarne='El formato del carnet es inválido.';
		 }
		else{
			++$cont;
		}
	}
	if(empty($_POST["texto_usuario"]))
		$errorUsuario="Es necesario un usuario de 5 caracteres (Alias).";
	else{
		$usuario=test_input($_POST["texto_usuario"]);
		if (!preg_match("/^[a-zA-ZÁÉÍÓÚÑáéíóúñ0-9]*$/",$usuario)||strlen($usuario)<5) {
    		$errorUsuario = "Es necesario un usuario de 5 caracteres.";
			}
		else{
			++$cont;
		}
	}
	if(empty($_POST["lista_jornada"]))
		$errorJornada="Seleccione una jornada.";
	else{
		$jornada = (int) preg_replace('/[^0-9]/', '', $_POST["lista_jornada"]);
		if($jornada>0 && !empty($jornada)){
			++$cont;
		}
		else
			$errorJornada="Seleccione una jornada.";
	}
	if(empty($_POST["lista_seccion"]))
		$errorSeccion="Seleccione una sección.";
	else{
		$seccion = (int) preg_replace('/[^0-9]/', '', $_POST["lista_seccion"]);
		if($seccion>0 && !empty($seccion)){
			++$cont;
		}
		else
			$errorSeccion="Seleccione una sección.";
	}
	if(empty($_POST["lista_semestre"]))
		$errorSemestre="Seleccione un semestre.";
	else{
		$semestre = (int) preg_replace('/[^0-9]/', '', $_POST["lista_semestre"]);
		if($semestre>0 && !empty($semestre)){
			++$cont;
		}
		else
			$errorSemestre="Seleccione un semestre.";
	}
	if(!isset($_POST["lista_genero"]))
		$errorGenero="Seleccione un género.";
	else{
		$genero=$_POST["lista_genero"];
		++$cont;
	}
	$playera=1;
	if(!isset($_POST["check_playera"]))
		$playera = 0;
	$certificado=1;
	if(!isset($_POST["check_certificado"]))
		$certificado = 0;
	$estado=1;
	if(!isset($_POST["check_habilitado"]))
		$estado=0;
	$talla=$_POST["lista_talla"];
	if($cont==8)
	{
		$consulta1->Participante_validacion2($nombre,$carne,$_SESSION['idGrupoEvento'],$_POST["idRegistro"],$usuario);
		while($row = mysql_fetch_assoc($consulta1->Resultado))
		{
			//Cantidad de participantes con el mismo nombre
			if($row["dato"]=="nombre")
				$cantN=$row["cantidad"];
			//Cantidad de participantes con el mismo carné
			else if($row["dato"]=="carne")
				$cantC=$row["cantidad"];
			else
				$cantU=$row["cantidad"];
		}
		if($cantU>0)
			$errorUsuario="Ya existe un participante con el mismo usuario.";
		else if($carnet==0&&$cantN>0)
			$errorNombre="Ya existe un participante con el mismo nombre.";
		else if($cantC>0 && $carnet!=0)
			$errorCarne="Ya hay un participante con el mismo carné.";
		else
		{
		$consulta1->Participante_actualizar($idParticipante,$nombre,$carne,$semestre,$talla,$genero,$playera,$certificado,$estado,$jornada,$seccion,$usuario);
		$actualizado=TRUE;
		$errorNombre = $errorCarne = $errorFoto = $errorUsuario = $errorJornada = $errorSeccion = $errorGenero = $errorSemestre = "";
		$nombre = $carne = $semestre = $talla = $foto = $usuario = $seccion = $jornada = $genero = $playera = "";
		}
    }
}
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar.</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h2 align="center">'.$NombreG.'</h2>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
	 <?php
	 if($actualizado)
	 {
		?>
        <div align="center">
        <h2><i class="icon icon-check"></i>Participante actualizado.</h2>
        <div style="display:none">
        <form id="forma" name="forma" method="post" action="Participante_ver.php">
          <input type="submit" name="boton_pag" id="boton_pag" value="" />
        </form>
        </div>
        </div>
        <script>
			setTimeout("document.getElementById('boton_pag').click();",1000);
		</script>
        <?php
	 }
	else if(isset($_POST["idRegistro"]))
	{
        $consulta1->Participante_detalle($_POST["idRegistro"],$_SESSION['idGrupoEvento']);
        //`Nombre`, `Carne`, `Semestre_idSemestre`,`Semestre`.Semestre, `Foto`, `Talla`, `Genero`, `PlayeraEntregada`, `CertificadoEntregado`, `EstadoParticipante`, `Jornada_idJornada`, `Seccion_idSeccion`, `UsuarioParticipante`
        $res=$consulta1->Resultado;
        $row=mysql_fetch_assoc($res);
    ?>
    <h2 align="center">Editar participante</h2>
    <a style="padding-left:50px; color:#333; text-decoration:none" href="Participante_ver.php"><i class="icon icon-undo2"></i> Atrás</a>
    <div align="center">
	<form id="form1" name="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
		<input type="hidden" name="idRegistro" id="idRegistro" value="<?php echo $_POST["idRegistro"]; ?>" />
        <br />
      <table width="654" border="0" cellspacing="5" align="center">
      	<tr>
          <td width="157"></td>
          <td width="282"><span class="error">* Campos requeridos.</span></td>
          <td width="189">&nbsp;</td>
        </tr>
        <tr>
          <td width="157">Nombre:</td>
          <td width="282"><label for="texto_nombre"></label>
   	     	<input name="texto_nombre" type="text" id="texto_nombre" placeholder="Ingrese el nombre del participante." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" required title="Se necesita un nombre del participante (solamente letras)" value = "<?php if($nombre!="") echo $nombre; else echo $row["Nombre"]; ?>" size="47" maxlength="45"/>
          </td>
          <td width="189"><span class="error">* <?php echo $errorNombre; ?></span></td>
        </tr>
        <tr>
          <td>Carné:</td>
          <td><label for="texto_carne"></label>
           	<input name="texto_carne" type="text" id="texto_carne" value = "<?php if($carne!="") echo $carne; else echo $row["Carne"]; ?>" size="47" maxlength="9" placeholder="Ingrese el carné del participante." pattern="[0-9]{0,9}" title="Solo se aceptan números" />
          </td>
          <td><span class="error">* <?php echo $errorCarne; ?></span></td>
        </tr>
        <tr>
          <td>Semestre</td>
          <td><div id="listaSemestre">
            	<select name="lista_semestre" id="lista_semestre"
            onchange="openVentana('lista_semestre','../Modal/semestre_modal.php','idDiv=listaSemestre');">
            	<?php				
				$consulta1->semestre_ver();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option value=".$row['id']; if($semestre==$row['id']) echo 'selected="selected"'; echo">".$row['Semestre']."</option>";
				}
				echo '<option value="+">Agregar otro</option>';
				?>
			</select>
            </div>
          </td>
          <td><span class="error">* <?php echo $errorSemestre; ?></span></td>
        </tr>
        <tr>
          <td>Talla de la playera::</td>
          <td><label for="lista_talla"></label>
           	<select name="lista_talla" id="lista_talla">
                <option value="S" <?php if($talla=="S" || ($talla==""&&$row["Talla"]=="S"))echo 'selected="selected"'; ?>>S</option>
                <option value="M" <?php if($talla=="M" || ($talla==""&&$row["Talla"]=="M"))echo 'selected="selected"'; ?>>M</option>
                <option value="L" <?php if($talla=="L" || ($talla==""&&$row["Talla"]=="L"))echo 'selected="selected"'; ?>>L</option>
                <option value="XL" <?php if($talla=="XL" || ($talla==""&&$row["Talla"]=="XL"))echo 'selected="selected"'; ?>>XL</option>
                <option value="XXL" <?php if($talla=="XXL" || ($talla==""&&$row["Talla"]=="XXL"))echo 'selected="selected"'; ?>>XXL</option>
            </select>
          </td>
          <td></td>
        </tr>
        <tr>
          <td><label for="lista_genero">Género:</label></td>
          <td>
           	<select name="lista_genero" id="lista_genero">
              <option value="1" <?php if($genero=="1" || $row["Genero"]=="1")echo 'selected="selected"'; ?>>Masculino</option>
   	          <option value="0" <?php if($genero=="0" || $row["Genero"]=="0")echo 'selected="selected"'; ?>>Femenino</option>
   	        </select>
          </td>
          <td><span class="error">* <?php echo $errorGenero; ?></span></td>
        </tr>
        <tr>
          <td><label for="lista_jornada">Jornada:</label></td>
          <td><div id="listaJornada"><select name="lista_jornada" id="lista_jornada"
            onchange="openVentana('lista_jornada','../Modal/jornada_modal.php','idDiv=listaJornada');">
            	<?php				
				$consulta1->Jornada_ver2();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
                        echo "<option value=".$row['id']; if($jornada==$row['id']) echo 'selected="selected"'; echo">".$row['Jornada']."</option>";
                    }
                    echo '<option value="+">Agregar otro</option>';
				?>
			</select></div></td>
          <td><span class="error">* <?php echo $errorJornada; ?></span></td>
   	    </tr>
        <tr>
          <td><label for="lista_seccion">Sección:</label></td>
          <td><div id="listaSeccion">
            	<select name="lista_seccion" id="lista_seccion"
                onchange="openVentana('lista_seccion','../Modal/seccion_modal.php','idDiv=listaSeccion');">
				<?php				
                    $consulta1->seccion_ver2();
                    //`id` ,  `Seccion`
                    while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
                        echo "<option value=".$row['id'].'"'; if($seccion==$row['id']) echo 'selected="selected"'; echo '>'.$row['Seccion']."</option>";
                    }
                    echo '<option value="+">Agregar otro</option>';
                ?>
                </select>
            </div></td>
          <td><span class="error">* <?php echo $errorSeccion; ?></span></td>
        </tr>
        <tr>
          <td>Playera:</td>
       	  <td><input type="checkbox" name="check_playera" id="check_playera"
            	<?php
	            if(($row["PlayeraEntregada"]!=0&&$playera=="") || ($playera!="" && $playera!=0))
    	            echo 'checked="checked"';
        	    ?>/>
            <label for="check_playera"> Entregada</label></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Certificado:</td>
          <td><input type="checkbox" name="check_certificado" id="check_certificado"
	            <?php
    	        if(($row["CertificadoEntregado"]!=0&&$certificado=="") || ($certificado!="" && $certificado!=0))
        	        echo 'checked="checked"';
				else
					echo 'onclick="javascript: return false;"';
				?>/>
            <label for="check_certificado"> Entregado</label></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Usuario:</td>
          <td><label for="texto_usuario"></label>
   	        <input name="texto_usuario" type="text" id="texto_usuario" pattern="[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ]{5}" required="required" title="Se necesita un usuario (5 caracteres)" placeholder="Usuario del participante (5 caracteres)" value = "<?php if($usuario!="") echo $usuario; else echo $row["UsuarioParticipante"]; ?>" size="47" maxlength="5" />
          </td>
          <td><span class="error">* <?php echo $errorUsuario; ?></span></td>
        </tr>
        <tr>
          <td>Habilitado:</td>
          <td><input name="check_habilitado" type="checkbox" id="check_habilitado"
            	<?php
        	    if(($row["EstadoParticipante"]!=0&&$estado=="") || ($estado!=""&&$estado!=0))
    	            echo 'checked="checked" ';
				?>/>
          </td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td></td>
          <td>
          	<input style="display:inline" type="submit" name="boton" id="boton" value="Guardar" />
       		<input style="display:inline" type="submit" name="boton" id="boton" value="Cancelar" />
          </td>
          <td>&nbsp;</td>
        </tr>
      </table>
      </form>
	<?php
        }
        else
        {
            echo '<br /><h2 align="center">Debe seleccionar un participante</h2>';
        }
    ?>
    </div>
      <!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
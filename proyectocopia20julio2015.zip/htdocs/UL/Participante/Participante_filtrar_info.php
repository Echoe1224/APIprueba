<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Filtrando...</title>
<script src="../../BLL/ajax.js" language="javascript"></script>
<link rel="stylesheet" href="../CITEIN/estilo2.css" >
</head>

<body>
	<?php
    //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$Consulta1=new Consulta;
	$filtro=$_GET['filtro'];
//Consulta que se quiere ver en el dataGridView
   $Consulta1->Participante_ver_eventos($filtro);
   if(mysql_num_rows($Consulta1->Resultado)==0)
	{
	  print 'No se encontró datos';  
	}
	else
	{
		//Se agrega el codigo del ancabezado de la tabla
		print'<table class = "tabla">';
		echo "\n";
		echo '<tr>';
		//$i:desde que columna se empieza a graficar
		$i = 3;
//Encabezado del dataGridView
		while ($i < mysql_num_fields($Consulta1->Resultado)) {
			$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
			echo '<td class="filaTablaConFondo" style="color: #FFF; font-weight: bold;">'.$metadatos->name.'</td>';
			$i++;
		}
		echo '<td class="filaTablaConFondo" style="color: #FFF; font-weight: bold;">Acciones</td>';
		print '</tr>';
		echo "\n";
//Datos del dataGridView
		$agregar=false;
		while($row=mysql_fetch_assoc($Consulta1->Resultado))
		{
			//donde se agregan los datos que se mostraran en cada columna
			print'<tr>';
			echo "\n";
			//$i:desde que columna se empieza a graficar
			$i = 3;
			while ($i < mysql_num_fields($Consulta1->Resultado)) {
				$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				//para agregar color a una fila
				$clase="filaTablaSinFondo";
				if($agregar)
					$clase="filaTablaConFondo";
				echo '<td class="'.$clase.'">';
			//Columnas que son de tipo booleano.						
				if($metadatos->name=="EstadoParticipante" || $metadatos->name=="Encuestado")
				{
				   $checkeado="";
				   if($row[$metadatos->name]!=0)
					$checkeado= "checked=\"checked\"";
				   echo '<input name="checkboxAsistencia2" type="checkbox" id="checkboxAsistencia2" '.$checkeado.' onclick="javascript: return false;" />';
				}
				else
					echo $row[$metadatos->name];
				echo "</td>\n";						
				++$i;
			}
			if(!empty($row["idEncuesta"]) && $row["Encuestado"]==0)
			{
			$pagResultado='\'../Encuesta/Encuesta_responder.php\'';
			$parametros='\'idEncuesta='.$row["idEncuesta"].'&idParticipante='.$row["idParticipante"].'&idEvento='.$row["idEvento"].'\'';
//Opciones que tendra cada registro del dataGridView
			echo '<td class='.$clase.'>';
			//Responder Encuesta
			echo	'<span style="cursor:pointer"; onclick="AbrirPaginaPostConParametros('.$pagResultado.','.$parametros.');">Encuesta</span><br>';
			echo "</td>\n";					
			echo "\n";
			}
			print '</tr>';
			if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
		}
		print '</table>';
	}
?>
</body>
</html>
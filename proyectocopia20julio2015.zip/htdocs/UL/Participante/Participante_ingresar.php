<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Registrar participante</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<!-- <script src="../UL/CITEIN/jquery-1.11.3.js"></script>-->
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="../../BLL/modal.js" language="JavaScript"></script>
<?php
// define variables and set to empty values
$errorNombre = $errorCarnet = $errorFoto = $errorUsuario = $errorJornada = $errorSeccion = $errorGenero = $errorSemestre = "";
$nombre = $carnet = $semestre = $talla = $foto = $usuario = $idFoto = $seccion = $jornada = $genero = $playera = "";
$cont=$idp=0;
$ingresado=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
if($_POST["boton"]=="Cancelar")
		header('Location: Participante_ver.php');
else if(isset($_POST["boton"])=="Guardar")
{
	if (empty($_POST["texto_nombre"])) {
	   	$errorNombre = "El nombre es requerido.";
	}
	else {
		$nombre = test_input($_POST["texto_nombre"]);
	    // check if name only contains letters and whitespace
		if (!preg_match("/^[a-zA-ZÁÉÍÓÚÑáéíóúñ ]*$/",$nombre)) {
    		$errorNombre = "Ingrese solamente letras y espacios.";
			}
		else{
			++$cont;
		}
	}
	if(empty($_POST["texto_carnet"])){
   		$carnet=0;
		++$cont;
	}
	else{
	   $carnet = test_input($_POST["texto_carnet"]);
	   /*if (!preg_match("/^[0-9]*$/",$carnet)||(!preg_match("/^*$/",$carnet)&&strlen($carnet)<9))*/
	   if (strlen($carnet)<9) {
    	 	$errorCarnet='El formato del carnet es inválido.';
		 }
		else{
			++$cont;
		}
	}
	if(empty($_POST["data_uri"])){
		$foto="";
		$errorFoto="La fotografía es requerida.";
	}
	else{
		$foto=$_POST["data_uri"];
		++$cont;
	}
	if(empty($_POST["texto_usuario"]))
		$errorUsuario="Es necesario un usuario de 5 caracteres (Alias).";
	else{
		$usuario=test_input($_POST["texto_usuario"]);
		if (!preg_match("/^[a-zA-Z1-9ÁÉÍÓÚÑáéíóúñ]*$/",$usuario)||strlen($usuario)<5) {
    		$errorUsuario = "Es necesario un usuario de 5 caracteres (Solo números y letras).";
			}
		else{
			++$cont;
		}
	}
	if(empty($_POST["lista_jornada"]))
		$errorJornada="Seleccione una jornada.";
	else{
		$jornada = (int) preg_replace('/[^0-9]/', '', $_POST["lista_jornada"]);
		if($jornada>0 && !empty($jornada))
			++$cont;
		else
			$errorJornada="Seleccione una jornada.";
	}
	if(empty($_POST["lista_seccion"]))
		$errorSeccion="Seleccione una sección1.";
	else{
		$seccion = (int) preg_replace('/[^0-9]/', '', $_POST["lista_seccion"]);
		if($seccion>0 && !empty($seccion))
			++$cont;
		else
			$errorSeccion="Seleccione una sección.";
	}
	if(empty($_POST["lista_semestre"]))
		$errorSemestre="Seleccione un semestre.";
	else{
		$semestre = (int) preg_replace('/[^0-9]/', '', $_POST["lista_semestre"]);
		if($semestre>0 && !empty($semestre))
			++$cont;
		else
			$errorSemestre="Seleccione un semestre.";
	}
	if(!isset($_POST["genero"]))
		$errorGenero="Seleccione un sexo.";
	else{
		$genero=$_POST["genero"];
		++$cont;
	}
	if($cont==8)
	{
		$consulta1->Participante_validacion($nombre,$carnet,$_SESSION['idGrupoEvento']);
		while($row = mysql_fetch_assoc($consulta1->Resultado))
		{
			//Cantidad de participantes con el mismo nombre
			if($row["dato"]=="nombre")
				$cantN=$row["cantidad"];
			//Cantidad de participantes con el mismo carné
			else
				$cantC=$row["cantidad"];
		}
		if($carnet==0&&$cantN>0)
			$errorNombre="Ya existe un participante con el mismo nombre.";
		else if($cantC>0 && $carnet!=0)
			$errorCarnet="Ya hay un participante con el mismo carné.";
		else
		{
		$talla=$_POST["lista_talla"];
		$grupo=$_POST["grupo"];
		$idFoto=date('YmdHis');//Extraemos la fecha del servidor
		/*echo $nombre.','.$carnet.','.$semestre.','.$idFoto.','.$talla.','.$usuario.','.$genero.','.$playera.','.$inscripcion.','.$grupo.','.$jornada.','.$seccion;*/
		$consulta1->participante_nuevo($nombre,$carnet,$semestre,$idFoto,$talla,$usuario,$genero,0,$grupo,$jornada,$seccion);
		$res=mysql_fetch_assoc($consulta1->Resultado);
		$idp=$res["id"];
		$filename = "../../fotos/".$idFoto.'.jpg';//Dirección de la foto.
		file_put_contents($filename, file_get_contents($foto));//se guarda la foto en el servidor.
		$errorNombre = $errorCarnet = $errorFoto = $errorUsuario = $errorJornada = $errorSeccion = $errorGenero = $errorSemestre = "";
		$nombre = $carnet = $semestre = $talla = $foto = $usuario = $idFoto = $seccion = $jornada = $genero = $inscripcion = $playera = "";
		$ingresado=1;
		}
    }
}
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<style type="text/css">
#results {
	margin: 5px;
	padding: 5px;
	padding-top:0px;
	border: 1px solid;
	background: #7CA921;
}
</style>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un evento a gestionar.</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar evento.</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h2 align="center">'.$NombreG.'</h2>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <div class="ventana">
            <div id="modal"></div>
        </div>
<form name="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
	  <input type="hidden" name="grupo" id="grupo" value="<?php echo $_SESSION['idGrupoEvento']; ?>" />
      <?php if($ingresado==1)
	  {?>
		  <h3 align="center" style="color:#093">Participante ingresado.</h3>
          <br />
          <?php
          if($idp>0)
		  { ?>
          <div align="center">
		  	<a href="javascript:AbrirPaginaPostConParametros('Participante_actividades.php','idRegistro=<?php echo $idp;?>');" style="color:#093">Asignar actividades.</a>
            </div>
            <?php
		  } ?>
          <?php
	  }?>
	  <h2>Ingresar un nuevo participante</h2>
	<p>&nbsp;</p>
	<table width="96%" height="100%" border="0" align="center">
        <td width="641" valign="top" nowrap="nowrap">
<!--  *********************************************************Formulario**************************************************** -->                
        <p><span class="error">* Campos requeridos.</span></p>
        
        <table width="642" height="344" border="0" cellspacing="5">
          <tr>
            <td width="105"><label for="texto_nombre">Nombre: </label></td>
            <td width="282"><input name="texto_nombre" type="text" id="texto_nombre" value="<?php echo $nombre; ?>" size="47" maxlength="45" placeholder="Ingrese el nombre del participante." pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" required title="Se necesita un nombre del participante (solamente letras)"></td>
            <td width="229"><span class="error">* <?php echo $errorNombre; ?> </span></td>
          </tr>
          <tr>
            <td><label for="texto_carnet">Carné: </label></td>
            <td><input name="texto_carnet" type="text" id="texto_carnet" value="<?php if($carnet!=0) echo $carnet; ?>" size="47" maxlength="9" placeholder="Ingrese el carné del participante." pattern="[0-9]{0,9}" title="Solo se aceptan números"></td>
            <td><span class="error">* <?php echo $errorCarnet; ?></span></td>
          </tr>
          <tr>
            <td><label for="lista_semestre">Semestre:</label></td>
            <td>
            <div id="listaSemestre">
            	<select name="lista_semestre" id="lista_semestre"
            onchange="openVentana('lista_semestre','../Modal/semestre_modal.php','idDiv=listaSemestre');">
            	<?php				
				$consulta1->semestre_ver();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option value=".$row['id']; if($semestre==$row['id']) echo 'selected="selected"'; echo">".$row['Semestre']."</option>";
				}
				echo '<option value="+">Agregar otro</option>';
				?>
			</select>
            </div>
            </td>
            <td><span class="error"><?php echo "* ".$errorSemestre; ?></span></td>
          </tr>
          <tr>
            <td><label for="lista_talla">Talla de la playera: </label></td>
            <td><select name="lista_talla" id="lista_talla">
                <option value="S">XS</option>
                <option value="S">S</option>
                <option value="M">M</option>
                <option value="L">L</option>
                <option value="XL">XL</option>
                <option value="XXL">XXL</option>
              </select></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><label>
              Sexo:</label></td>
            <td><label>
              <input type="radio" name="genero" value="1" id="genero" required="required" <?php if($genero==1) echo 'checked="checked"'; ?> />
              Masculino</label>
              <label>
              <input type="radio" name="genero" value="0" id="genero" />
              Femenino</label></td>
            <td><span class="error">* </span></td>
          </tr>
          <tr>
            <td><label for="lista_jornada">Jornada:</label></td>
            <td>
            <div id="listaJornada">
            <select name="lista_jornada" id="lista_jornada"
            onchange="openVentana('lista_jornada','../Modal/jornada_modal.php','idDiv=listaJornada');">
            	<?php				
				$consulta1->Jornada_ver2();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
                        echo "<option value=".$row['id']; if($jornada==$row['id']) echo 'selected="selected"'; echo">".$row['Jornada']."</option>";
                    }
                    echo '<option value="+">Agregar otro</option>';
				?>
			</select>
            </div>
            </td>
            <td><span class="error"><?php echo "* ".$errorJornada; ?></span></td>
          </tr>
          <tr>
            <td><label for="lista_seccion">Seccion:</label></td>
            <td>
            <div id="listaSeccion">
            	<select name="lista_seccion" id="lista_seccion"
                onchange="openVentana('lista_seccion','../Modal/seccion_modal.php','idDiv=listaSeccion');">
				<?php				
                    $consulta1->seccion_ver2();
                    //`id` ,  `Seccion`
                    while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
                        echo "<option value=".$row['id'].'"'; if($seccion==$row['id']) echo 'selected="selected"'; echo '>'.$row['Seccion']."</option>";
                    }
                    echo '<option value="+">Agregar otro</option>';
                ?>
                </select>
            </div>
            </td>
            <td><span class="error"><?php echo "* ".$errorSeccion; ?></span></td>
          </tr>
          <tr>
            <td><label for="texto_usuario">Usuario: </label></td>
            <td><input name="texto_usuario" type="text" required id="texto_usuario" pattern="[A-Za-z0-9ÑñáéíóúÁÉÍÓÚ]{5}" title="Se necesita un usuario de 5 caracteres" value="<?php echo $usuario; ?>" size="20" maxlength="5" placeholder="Usuario del participante (5 caracteres)" /></td>
            <td><span class="error">* <?php echo $errorUsuario; ?></span></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="boton" id="boton" value="Guardar" />
              <input type="button" name="boton" id="boton" value="Cancelar" onclick="redirigir();" /></td>
            <td>&nbsp;</td>
          </tr>
        </table>
        </td>
        <td width="309" align="center" valign="top">
<!-- ********************************Lugar donde se desplegara la imagen tomada******************************** -->
        <div id="results" align="center" style="width:300px;">
            <h2>Foto del participante</h2>
            <br/>
            <img id="foto" width="100%" src="<?php if(empty($foto)) echo '../../fotos/default.jpg'; else echo $foto; ?>"/>
            <br/>
            <input type="hidden" name="data_uri" id="data_uri" value="<?php echo $foto; ?>">
        </div>
        <div id="boton_activar_camara">
        <input type="button" onClick="adjuntarCamara()" value="Activar cámara">
        </div>
        <p>
          <span class="error">* <?php echo $errorFoto; ?> </span> <br/>
        </p>
<!-- ********************************Configurar la toma de fotografía********************************************* -->
        <div style="text-align: center;" id="my_camera"></div>
        <!-- Primero, se incluirá la librería de javascrip "webcam.js" --> 
        <script type="text/javascript" src="../CITEIN/webcam.js"></script> 
        <!-- configurar la camara (tamaño, formato, calidad) --> 
        <script language="JavaScript">
        Webcam.set({
            width: 320,
            height: 240,
            image_format: 'jpeg',
            jpeg_quality: 90
        });
        </script>
        <!-- botones ************************************************************** -->
        <div id="boton_capturar" style="display:none">
        <input type="button" onClick="capturar()" value="Capturar">
        </div>
<!--        
        <div id="boton_capturar" style="display:none">
        <input type="button" onClick="capturar()" value="Capturar">
        </div>                
        <div id="boton_capturado" style="display:none">
        <input value="Tomar otra" onclick="otra_captura()" type="button">
        <input value="Guardar foto" onclick="guardar_captura()" type="button">
        </div> -->
    </td>
  </table>
</form>
	<!-- Codigo para manejar la captura y desplegar localmente -->
        <script language="JavaScript">
        function adjuntarCamara(){
            Webcam.attach('#my_camera');
            //document.getElementById('results').style.display = 'none';
            document.getElementById('boton_activar_camara').style.display = 'none';
            document.getElementById('boton_capturar').style.display = '';
            document.getElementById('results').style.display = 'none';				
        }
        function capturar() {
            // congelar la camara para que el usuario pueda ver la captura.
            //Webcam.freeze();
			Webcam.snap( function(data_uri) {
                // desplegar los resultados en la pagina.
                //document.getElementById('results').innerHTML = '<h2>Fotografía:</h2>' + '<img src="'+data_uri+'"/>';
                // Ocultar botones para que ya no se pueda tomar ninguna fotografía desde de haber guardado.
                
                document.getElementById('boton_capturar').style.display = 'none';
                document.getElementById('results').style.display = '';
                //document.getElementById('results').style.display = '';
                /*document.getElementById('results').innerHTML = 
                        '<h2>Foto del participante</h2>' + 
                        '<img src="'+data_uri+'"/>';*/
                document.getElementById('foto').src=data_uri;
                document.getElementById('data_uri').value=data_uri;
                Webcam.reset();
                } );
			document.getElementById('boton_activar_camara').style.display = '';
        }
        function otra_captura() {
            // cancelar la captura y activar la camara en vivo.
            Webcam.unfreeze();
            // swap buttons back
            document.getElementById('boton_capturar').style.display = '';
            document.getElementById('boton_capturado').style.display = 'none';
        }
        function guardar_captura() {
            // actualmente se ha hecho una captura y se ha desplegado.
            Webcam.snap( function(data_uri) {
                // desplegar los resultados en la pagina.
                //document.getElementById('results').innerHTML = '<h2>Fotografía:</h2>' + '<img src="'+data_uri+'"/>';
                // Ocultar botones para que ya no se pueda tomar ninguna fotografía desde de haber guardado.
                document.getElementById('boton_capturar').style.display = 'none';
                document.getElementById('boton_capturado').style.display = 'none';
                document.getElementById('boton_recapturar').style.display = '';
                document.getElementById('results').style.display = '';
                document.getElementById('results').style.background="#CCCCCC";
                //document.getElementById('results').style.display = '';
                /*document.getElementById('results').innerHTML = 
                        '<h2>Foto del participante</h2>' + 
                        '<img src="'+data_uri+'"/>';*/
                document.getElementById('foto').src=data_uri;
                document.getElementById('data_uri').value=data_uri;
                Webcam.reset();
                } );
        }
		function redirigir()
		{
			window.location.href = "Participante_ver.php"
		}
        /*function almacenar_captura(){
            Webcam.upload(var_temp, 'http://citein.hostingla.in/DAL/guardar_foto.php', function(code, text) {
                    // Upload complete!
                    // 'code' will be the HTTP response code from the server, e.g. 200
                    // 'text' will be the raw response content
                    
                } );	
        }*/
		</script>


		<!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
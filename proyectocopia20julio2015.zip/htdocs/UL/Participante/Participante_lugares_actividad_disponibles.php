<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";  
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";  
	$Consulta1=new Consulta;
	$idEvento=$_GET['idEvento'];
	$Consulta1->Evento_lugar_disponible($idEvento);
    //idLugar,`Lugar`,Capacidad,`Disponible`
	if(mysql_num_rows($Consulta1->Resultado)==0)
	{
	  print 'No hay lugares disponibles.';  
	}
	else
	{
		?>
        <h4>Seleccione un lugar de la actividad.</h4>
	<label for="lista_lugar"> Lugar: </label>
<select name="lista_lugar" id="lista_lugar" onchange="verDetalle();">
			<?php
            while($row=mysql_fetch_assoc($Consulta1->Resultado))
            {
			?>
  <option value="<?php echo $row["idLugar"];?>"><?php echo $row["Lugar"];?></option>
			<?php
			}
			?>
</select>
		<br  />
        <br  />
		<table width="223" border="0" cellspacing="5">
		  <tr>
			<td width="136" style="border-bottom:1px solid #333;">Capacidad del lugar</td>
			<td width="68" style="border-bottom:1px solid #333;">Disponible</td>
		  </tr>
		  <tr>
			<td><p id="capacidad"></p></td>
			<td><p id="disponible"></p></td>
		  </tr>
		</table>
		<?php
		mysql_data_seek($Consulta1->Resultado, 0);
		while($row=mysql_fetch_assoc($Consulta1->Resultado))
		{
			?>
			<input type="hidden" id="<?php echo 'c'.$row["idLugar"];?>" value="<?php echo $row["Capacidad"];?>" />
			<input type="hidden" id="<?php echo 'd'.$row["idLugar"];?>" value="<?php echo $row["Disponible"];?>" />
			<?php
		}
	}
	?>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Detalles del participante</title>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
?>
</head>

<body>
<div align="right"><span style="cursor:pointer;" onclick="cerrarM();" title="Cerrar">X</span></div>
<h2 align="center">Detalles del participante</h2>
   <div align="center">     
<?php
if(isset($_POST["idRegistro"]))
{
	$consulta1->Participante_detalle($_POST["idRegistro"],$_POST['idGrupo']);
	/*`idParticipante`, `Nombre`, `Carne`, `Semestre_idSemestre`,`Semestre`.Semestre, `Foto`, `Talla`, `Genero`, `PlayeraEntregada`, `CertificadoEntregado`, `GrupoEvento_idGrupoEvento`, `EstadoParticipante`, `Jornada_idJornada`, `Seccion_idSeccion`, `UsuarioParticipante`*/
	$res=$consulta1->Resultado;
	$row=mysql_fetch_assoc($res);
	?>
    <img src="../../fotos/<?php echo $row["Foto"].'.jpg';?>" width="383" height="245" alt="Foto del participante" />
    
    <table width="393" border="0" cellspacing="5">
      <tr>
        <td width="131">Nombre:</td>
        <td width="243"><?php echo $row["Nombre"];?></td>
      </tr>
      <tr>
        <td>Carné:</td>
        <td><?php echo $row["Carne"];?></td>
      </tr>
      <tr>
        <td>Semestre:</td>
        <td><?php echo $row["Semestre"]; ?></td>
      </tr>
      <tr>
        <td>Jornada:</td>
        <td><?php echo $row["Jornada"]; ?></td>
      </tr>
      <tr>
        <td>Sección</td>
        <td><?php echo $row["Seccion"]; ?></td>
      </tr>
      <tr>
        <td>Talla de playera:</td>
        <td><?php echo $row["Talla"]; ?></td>
      </tr>
      <tr>
        <td>Género:</td>
        <td>
		<?php
		if($row["Genero"]!=0)
			echo 'Masculino';
		else
			echo 'Femenino';
		?>
        </td>
      </tr>
      <tr>
        <td>Playera:</td>
        <td>
        <?php
		if($row["PlayeraEntregada"]==0){
			?>
			<form id="form1" name="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["Participante_ver.php"]);?>">
			  No entregada <input type="submit" name="boton_playera" id="boton_playera" value="Entregar" />
			  <input type="hidden" name="playera" id="playera" value="<?php echo $row["idParticipante"]; ?>" />
			</form>
            <?php
		}
		else
			echo 'Entregada';
		?>
        </td>
      </tr>
      <tr>
        <td>Certificado:</td>
        <td>
        <?php
		if($row["CertificadoEntregado"]==0){
			echo 'No entregado';
		}
		else
			echo 'Entregado';
		?>
        </td>
      </tr>
	  <tr>
        <td>Usuario:</td>
        <td><?php echo $row["UsuarioParticipante"]; ?></td>
      </tr>
      <tr>
        <td>Habilitado:</td>
        <td><input name="check_estado" type="checkbox" onclick="javascript: return false;" id="check_estado"
        <?php 
		if($row["EstadoParticipante"]==1)
			echo 'checked="checked" ';
		?>/>
        </td>
      </tr>
	  <tr>
	    <td>&nbsp;</td>
		<td>&nbsp;</td>
	  </tr>
      <tr>
        <td></td>
        <td></td>
      </tr>
    </table>
    <?php
}
else
	echo '<br /><br /><tr><h3>Ningún participante seleccionado</h3>';
?>
	</div>
</body>
</html>
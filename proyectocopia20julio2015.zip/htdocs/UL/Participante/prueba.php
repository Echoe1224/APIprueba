<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Filtrando...</title>
<script src="../../BLL/ajax.js" language="javascript"></script>
</head>

<body>
	<?php
	//Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";  
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";  
	$Consulta1=new Consulta;
	$filtro=$_GET['filtro'];
	$idGrupo=$_GET['grupo'];
//Consulta que se quiere ver en el dataGridView
   $Consulta1->Participante_por_semestre(1,1);
   /*`idParticipante`, `Nombre`,`Carné`, Semestre.Semestre,`Talla de Playera`,`Género`,`Habilitado`*/
   if(mysql_num_rows($Consulta1->Resultado)==0)
	{
	  print 'No se encontraron datos';  
	}
	else
	{
		//Se agrega el codigo del ancabezado de la tabla
		print'<table class = "tabla">';
		echo "\n";
		echo '<thead class="dgv-titulo">';
		//$i:desde que columna se empieza a graficar
		$i = 1;
//Encabezado del dataGridView
		while ($i < mysql_num_fields($Consulta1->Resultado)) {
				$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				echo '<td>'.$metadatos->name.'</td>';
				echo "\n";
				$i++;
			}
			echo '<td>Opciones</td>';
			echo "\n";
		print '</thead>';
		echo "\n";
//Datos del dataGridView
		$agregar=false;
		while($row=mysql_fetch_assoc($Consulta1->Resultado))
		{
			$clase="filaTablaSinFondo";
			if($agregar)
				$clase="filaTablaConFondo";
			//donde se agregan los datos que se mostraran en cada columna
			print'<tr  class="'.$clase.'">';
			echo "\n";
			//$i:desde que columna se empieza a graficar
			$i = 1;
			while ($i < mysql_num_fields($Consulta1->Resultado) && $i!=0) 
			{
				$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				//para agregar color a una fila
				echo '<td>';
				if($metadatos->name=="Nombre")
				{
					?>
                    <span style="cursor:pointer;" onclick="abrirMPost('idRegistro='+<?php echo '\''.$row["idParticipante"].'\'';?>+'&idGrupo='+<?php echo $idGrupo;?>,'Participante_ver_detalle.php');"><?php echo $row[$metadatos->name]; ?></span>
                    <?php
				}
			//Columnas que son de tipo booleano.
				else if($metadatos->name=="Habilitado")
				{
				   $checkeado="";
				   if($row[$metadatos->name]!=0)
					$checkeado= "checked=\"checked\"";
				   echo '<input name="checkboxAsistencia2" type="checkbox" id="checkboxAsistencia2" '.$checkeado.' onclick="javascript: return false;" />';
				}
				//Columnas que se quiere modificar el valor ej: 1=Masculino
				else if($metadatos->name=="Género")
				{
				   if($row[$metadatos->name]!=0)
						echo "Masculino";
					else
						echo "Femenino";
				}
				//Columnas vacías
				else if($metadatos->name=="Carné")
				{
					if($row["Carné"]!=0)
						echo $row[$metadatos->name];
				}
				else
					echo $row[$metadatos->name];
				echo "</td>\n";						
				++$i;
			}
			$pagActividades='\'Participante_actividades.php\'';
			$pagEditar='\'Participante_editar.php\'';
//Opciones que tendra cada registro del dataGridView
			echo '<td>';
			//Actividades
			echo	'<span style="cursor:pointer;" onclick="AbrirPagina('.$row["idParticipante"].','.$pagActividades.')"><i class="icon icon-event"></i> Actividades y Playeras</span><br />';
			//Editar
			echo	'<span style="cursor:pointer;" onclick="AbrirPagina('.$row["idParticipante"].','.$pagEditar.')"><i class="icon icon-pencil"></i> Editar</span><br />';
			//Eliminar
			echo	'<span style="cursor:pointer;" onclick="eliminarP('.$row["idParticipante"].');"><i class="icon icon-bin"></i> Eliminar</span><br />';
			echo "</td>";					
			echo "\n";
			print '</tr>';
			if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
		}
		print '</table>';
	}	
?>
</body>
</html>
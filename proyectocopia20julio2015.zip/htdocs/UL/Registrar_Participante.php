<?php
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	$consulta1=new Consulta;
// define variables and set to empty values
$errorNombre = $errorCarnet = $errorFoto = $errorUsuario = "";
$nombre = $carnet = $semestre = $talla = $foto = $usuario = $idFoto= "";
$cont=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["texto_nombre"])) {
	   	$errorNombre = "El nombre es requerido.";
	}
	else {
		$nombre = test_input($_POST["texto_nombre"]);
	    // check if name only contains letters and whitespace
		if (!preg_match("/^[a-zA-Z ]*$/",$nombre)) {
    		$errorNombre = "Ingrese solamente letras y espacios.";
			}
		else{
			++$cont;
		}
	}
	if(empty($_POST["texto_carnet"])){
   		$carnet="";
		++$cont;
	}
	else{
	   $carnet = test_input($_POST["texto_carnet"]);
	   if (!preg_match("/^[0-9]*$/",$carnet)||(!preg_match("/^*$/",$carnet)&&strlen($carnet)<9)) {
    	 	$errorCarnet='El formato del carnet es inválido.';
		 }
		else{
			++$cont;
		}
	}
	if(empty($_POST["data_uri"])){
		$foto="";
		$errorFoto="La fotografía es requerida.";
	}
	else{
		$foto=$_POST["data_uri"];
		++$cont;
	}
	if(empty($_POST["texto_usuario"]))
	{
		$usuario="";
		$errorUsuario="Es necesario un usuario (Alias).";
	}
	else{
		$usuario=$_POST["texto_usuario"];
		if (!preg_match("/^[a-zA-Z1-9]*$/",$usuario)||strlen($usuario)<5) {
    		$errorNombre = "Ingrese 5 números o letras.";
			}
		else{
			++$cont;
		}
	}
	if($cont==4)
	{
		$idFoto=date('YmdHis');//Extraemos la fecha del servidor
		$filename = "../fotos/".$idFoto.'.jpg';//Dirección de la foto.
		file_put_contents($filename, file_get_contents($foto));//se guarda la foto en el servidor.
		$semestre=$_POST["lista_semestre"];
		$talla=$_POST["lista_talla"];
		$consulta1->participante_nuevo($nombre,$carnet,$semestre,$idFoto,$talla);
		$errorNombre = $errorCarnet = $errorFoto = "";
		$nombre = $carnet = $semestre = $talla = $foto = $idFoto= "";
    }
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Registrar Participante</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="CITEIN/estilos.css"  />
<link rel="stylesheet" href="CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="CITEIN/main.js"></script>
<!-- InstanceBeginEditable name="head" -->
<style type="text/css">
	.error {color: #FF0000;}
		#results {
			margin: 5px;
			padding: 5px;
			padding-top:0px;
			border: 1px solid;
			background: #7CA921;
		}
    </style>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../portada_secundaria.png" alt="" />
	</div>
        <header>
		<nav class="menu">
			<ul>
				<li><a href="#"><span class="primero"><i class="icon icon-home"></i></span>CITEIN</a></li>
				<li><a href="#"><span class="segundo"><i class="icon icon-table2"></i></span>EVENTOS</a>
					<ul>
						<li><a href="#">Ver eventos</a></li>
						<li><a href="#">Crear evento</a></li>
					</ul>
				</li>
				<li><a href="#"><span class="tercero"><i class="icon icon-accessibility"></i></span>PARTICIPANTES</a>
					<ul>
						<li><a href="#">Ver participantes</a></li>
						<li><a href="#">Nuevo participante</a></li>
					</ul>
                </li>
				<li><a href="#"><span class="cuarto"><i class="icon icon-user"></i></span>PERSONAL</a>
					<ul>
						<li><a href="#">Ver personal</a></li>
						<li><a href="#">Nuevo personal</a></li>
					</ul>
                </li>
				<li><a href="#"><span class="quinto"><i class="icon icon-exit"></i></span>Cerrar Sesión</a></li>
			</ul>
		</nav>
        </header>
        </div>

<div class="contenedor">
	<div class="contenido">
    <!-- InstanceBeginEditable name="Contenido" -->
	<form name="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">            
       	  <table width="100%" height="100%" border="0" align="center">
        		<td width="358" valign="top" nowrap="nowrap">
<!--  *********************************************************Formulario**************************************************** -->                
                <p><span class="error">* Campos requeridos.</span></p>
                <p>
                  <label for="texto_nombre">Nombre: </label>
                  <input name="texto_nombre" type="text" id="texto_nombre" value="<?php echo $nombre;?>" size="50" maxlength="45">
                   <span class="error">* <?php echo $errorNombre;?></span> <br/>
                </p>
        		<p>
		        <label for="texto_carnet">Carnet: </label>
        		<input name="texto_carnet" type="text" id="texto_carnet" value="<?php echo $carnet;?>" size="50" maxlength="9">
                   <span class="error">* <?php echo $errorCarnet;?></span> <br/>                
                  </p>
        		<p>
		        <label for="lista_semestre">Semestre:</label>
				<select name="lista_semestre" id="lista_semestre">
				<?php				
				$consulta1->semestre_ver();
				while ($row = mysql_fetch_assoc($consulta1->Resultado)) {
					echo "<option selected=selected value=".$row['id'].">".$row['Semestre']."</option>";
				}
				?>
				</select>
				</p>
        		<p>
        		  <label for="lista_talla">Tamaño de la playera: </label>
                  <select name="lista_talla" id="lista_talla">
                    <option value="S">S</option>
                    <option value="M">M</option>
                    <option value="L">L</option>
                    <option value="XL">XL</option>
                    <option value="XXL">XXL</option>
                  </select>
                </p>
        		<p>
        		  <label for="texto_usuario">Usuario: </label>
        		  <input type="text" name="texto_usuario" id="texto_usuario" value="<?php echo $usuario; ?>" />
                  <span class="error">* <?php echo $errorUsuario;?></span> <br/>
        		</p>

				<div id="boton_guardar">
                <input type="submit" name="boton_guardar" id="boton_guardar" value="Guardar"> 
                <input type="button" name="boton_cancelar" id="boton_cancelar" value="Cancelar" onClick="almacenar_captura()">
                </div>
                </td>
                <td width="190" align="center" valign="top">
<!-- ********************************Lugar donde se desplegara la imagen tomada******************************** -->
		        <div id="results">
                    <h2>Foto del participante</h2>
                    <br/>
                	<img id="foto" src="<?php echo $foto;?>"/>
                    <br/>
                    <input type="hidden" name="data_uri" id="data_uri" value="<?php echo $foto;?>">
                </div>
                <div id="boton_recapturar" style="display:none">
				<input value="Tomar Otra" onclick="adjuntarCamara()" type="button">
				</div>
                <p>
               	  <span class="error">* <?php echo $errorFoto;?></span> <br/>
                </p>
<!-- ********************************Configurar la toma de fotografía********************************************* -->
                <div style="text-align: center;" id="my_camera"></div>
				<!-- Primero, se incluirá la librería de javascrip "webcam.js" --> 
				<script type="text/javascript" src="webcam.js"></script> 
				<!-- configurar la camara (tamaño, formato, calidad) --> 
				<script language="JavaScript">
				Webcam.set({
					width: 320,
					height: 240,
					image_format: 'jpeg',
					jpeg_quality: 90
				});
				</script>
                <!-- botones -->
				<div id="boton_activar_camara">
				<input type="button" onClick="adjuntarCamara()" value="Activar Cámara">
		        </div>
        		<div id="boton_capturar" style="display:none">
				<input type="button" onClick="capturar()" value="Capturar">
                </div>                
        		<div id="boton_capturado" style="display:none">
				<input value="Tomar Otra" onclick="otra_captura()" type="button">
				<input value="Guardar Foto" onclick="guardar_captura()" type="button">
				</div>
                
        		<!-- Codigo para manejar la captura y desplegar localmente -->
		        <script language="JavaScript">
				function adjuntarCamara(){
					Webcam.attach('#my_camera');
					//document.getElementById('results').style.display = 'none';
					document.getElementById('boton_activar_camara').style.display = 'none';
					document.getElementById('boton_recapturar').style.display = 'none';
					document.getElementById('boton_capturar').style.display = '';
					document.getElementById('results').style.display = 'none';				
				}
				function capturar() {
					// congelar la camara para que el usuario pueda ver la captura.
					Webcam.freeze();
					// swap button sets
					document.getElementById('boton_capturar').style.display = 'none';
					document.getElementById('boton_capturado').style.display = '';
				}
				function otra_captura() {
					// cancelar la captura y activar la camara en vivo.
					Webcam.unfreeze();
					// swap buttons back
					document.getElementById('boton_capturar').style.display = '';
					document.getElementById('boton_capturado').style.display = 'none';
				}
				function guardar_captura() {
					// actualmente se ha hecho una captura y se ha desplegado.
					Webcam.snap( function(data_uri) {
						// desplegar los resultados en la pagina.
						//document.getElementById('results').innerHTML = '<h2>Fotografía:</h2>' + '<img src="'+data_uri+'"/>';
						// Ocultar botones para que ya no se pueda tomar ninguna fotografía desde de haber guardado.
						document.getElementById('boton_capturar').style.display = 'none';
						document.getElementById('boton_capturado').style.display = 'none';
						document.getElementById('boton_recapturar').style.display = '';
						document.getElementById('results').style.display = '';
						document.getElementById('results').style.background="#CCCCCC";
						//document.getElementById('results').style.display = '';
						/*document.getElementById('results').innerHTML = 
    			        		'<h2>Foto del participante</h2>' + 
								'<img src="'+data_uri+'"/>';*/
						document.getElementById('foto').src=data_uri;
						document.getElementById('data_uri').value=data_uri;
						Webcam.reset();
						} );
				}
				function almacenar_captura(){
					Webcam.upload(var_temp, 'http://citein.hostingla.in/DAL/guardar_foto.php', function(code, text) {
    	    	            // Upload complete!
		        	        // 'code' will be the HTTP response code from the server, e.g. 200
        		    	    // 'text' will be the raw response content
							
			        	} );	
				}
				</script>
      		</td>
	      </table>
		</form>
	<!-- InstanceEndEditable -->
    
    </div>
    
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="../../../BLL/ajax.js" language="javascript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>
<?php
	   include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		$Consulta1=new Consulta;
$consulta1=new Consulta;
       $Consulta2=new Consulta;
       $Consulta3=new Consulta;
session_start();
        $idgrupoevento=$_SESSION['idGrupoEvento'];
$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Evento seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
?>
<body>
<a style="padding-left:50px; color:#333; text-decoration:none" href="Evento_reporte.php"><i class="icon icon-undo2"></i> Atrás</a>
<form id="form1" name="form1" method="post" action="">
<h3 align="center">Reporte del evento:<? print $NombreG;?></h3>
<br></br>
<div class="tablas" align="center">
 <table align="center" width="863" style="border:1px solid black; text-align:center ; border-collapse:collapse" >
<tr>
<td style="border:1px dotted black;"><H4 style="text-align: center">Nombre</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Carné</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Jornada</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Semestre</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Seccion</H4></td>
</tr>
	<?php

			$idTipo=$idgrupoevento;

        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        

//Consulta que se quiere ver en el dataGridView

           $Consulta1->participante_ver_grupo_asistencia($idgrupoevento);
           $Consulta2->participante_ver_grupo_asistencia($idgrupoevento);
           $row=mysql_fetch_assoc($Consulta1->Resultado);
           $cantidad=$Consulta1->Resultado;
$tipoeve=mysql_fetch_assoc($cantidad);
            echo '<H3 align="center">Total de actividades:'.mysql_num_rows($cantidad).'</H3>';

           if(mysql_num_rows($cantidad)==0)
            {
              print '<tr>No hay personal asignado</tr>';  
            }
            else
            {
                while($Tipos=mysql_fetch_assoc($Consulta2->Resultado))
                {
                    echo '<tr ><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Nombre'].'</h4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Carne'].'</H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Jornada'].'</H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Semestre'].'</H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Seccion'].'</H4></td></tr>';
                }
            }
?>
</table>
</div>
</form>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="../../BLL/ajax.js" language="javascript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>
<?php
	   include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		$Consulta1=new Consulta;
$consulta1=new Consulta;
       $Consulta2=new Consulta;
       $Consulta3=new Consulta;
session_start();
        $idgrupoevento=$_SESSION['idGrupoEvento'];
$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
?>
<body>
<form id="form1" name="form1" method="post" action="">
<h3 align="center">Reporte del evento:<? print $NombreG;?></h3>
<br></br>
<div align="center">
<table style="border:1px solid black; text-align:center ; border-collapse:collapse"  width:"500" align="center" >
<tr>
<td style="border:1px dotted black;"><H4 style="text-align: center">Tipo de actividad</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Cantidad de actividades</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Cantidad de participantes</H4></td>
</tr>
	<?php
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
       
 if(isset($_GET['filtro']))
                $filtro=$_GET['filtro'];
            else
                 $filtro=0;

//Consulta que se quiere ver en el dataGridView
           $Consulta1->participante_ver_grupo($_SESSION['idGrupoEvento']);
           $totalparticipante=mysql_num_rows($Consulta1->Resultado);
           $Consulta1->Evento_ver_descripcion_evento2($idgrupoevento);
           $Consulta2->TipoEvento_ver_lista($_SESSION['idGrupoEvento']);
           $row=mysql_fetch_assoc($Consulta1->Resultado);
           $cantidad=mysql_num_rows($Consulta1->Resultado);
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print 'No existen actividades asignadas';  
            }
            else
            {
                while($Tipos=mysql_fetch_assoc($Consulta2->Resultado))
                {
                    $Consulta3->Evento_ver_descripcion_tipoevento($Tipos['id'],$idgrupoevento);
                    $cantidadtipoeve=mysql_num_rows($Consulta3->Resultado);
$Consulta3->TipoEvento_ver_participantes($Tipos['id'],$idgrupoevento);
                    $cantidadpar=mysql_num_rows($Consulta3->Resultado);
                    echo '<tr><td style="border:1px dotted black;"><H4 style="text-align: center"><span style="cursor:pointer"; onclick="especifico('.$Tipos['id'].');">'.$Tipos['nombre'].'</span></H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$cantidadtipoeve.'</H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$cantidadpar.'</H4></td></tr>';
                }
            }
echo '<tr>
<td style="border:1px dotted black;"><H3 align="center">Totales:</H3></td>
<td style="border:1px dotted black;"><H3 align="center"><span style="cursor:pointer"; onclick="completo();">'.$cantidad.'</span></H3></td>
<td style="border:1px dotted black;"><H3 align="center"><span style="cursor:pointer"; onclick="completopar();">'.$totalparticipante.'</span></H3></td>
</tr>';
?>
</table>
<br></br>

</div>
<div align="center">
<table>
<tr>
<td>
<table style="border:1px solid black; text-align:center ; border-collapse:collapse"  width:"500" align="center" >
<tr>
<td style="border:1px dotted black;"><H4 align="center">Jornada</H4></td>
<td style="border:1px dotted black;"><H4 align="center"><span style="cursor:pointer"; onclick="completo();">Cantidad de participantes</span></H4></td>
</tr>
	<?php
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
       
 if(isset($_GET['filtro']))
                $filtro=$_GET['filtro'];
            else
                 $filtro=0;

//Consulta que se quiere ver en el dataGridView
           $Consulta1->Jornada_ver2();
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print 'No existen jornadas';  
            }
            else
            {
                while($Tipos=mysql_fetch_assoc($Consulta1->Resultado))
                {
   $Consulta3->participante_ver_grupo_jornada($idgrupoevento,$Tipos['id']);
                    $cantidadjor=mysql_num_rows($Consulta3->Resultado);
                    echo '<tr><td style="border:1px dotted black;"><H4 style="text-align: center"><span style="cursor:pointer"; onclick="especificojss('.$Tipos['id'].',1);">'.$Tipos['Jornada'].'</span></H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$cantidadjor.'</H4></td></tr>';
                }
            }
?>
</table>
</td>
<td>
<table style="border:1px solid black; text-align:center ; border-collapse:collapse"  width:"500" align="center" >
<tr>
<td style="border:1px dotted black;"><H4 align="center">Semestre</H4></td>
<td style="border:1px dotted black;"><H4 align="center"><span style="cursor:pointer"; onclick="completo();">Cantidad de participantes</span></H4></td>
</tr>
	<?php
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
       
 if(isset($_GET['filtro']))
                $filtro=$_GET['filtro'];
            else
                 $filtro=0;

//Consulta que se quiere ver en el dataGridView
           $Consulta1->semestre_ver();
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print 'No existen semestres';  
            }
            else
            {
                while($Tipos=mysql_fetch_assoc($Consulta1->Resultado))
                {
   $Consulta3->participante_ver_grupo_semestre($idgrupoevento,$Tipos['id']);
                    $cantidadjor=mysql_num_rows($Consulta3->Resultado);
                    echo '<tr><td style="border:1px dotted black;"><H4 style="text-align: center"><span style="cursor:pointer"; onclick="especificojss('.$Tipos['id'].',2);">'.$Tipos['Semestre'].'</span></H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$cantidadjor.'</H4></td></tr>';
                }
            }
?>
</table>
</td>
<td>
<table style="border:1px solid black; text-align:center ; border-collapse:collapse"  width:"500" align="center" >
<tr>
<td style="border:1px dotted black;"><H4 align="center">Seccion</H4></td>
<td style="border:1px dotted black;"><H4 align="center"><span style="cursor:pointer"; onclick="completo();">Cantidad de participantes</span></H4></td>
</tr>
	<?php
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
       
 if(isset($_GET['filtro']))
                $filtro=$_GET['filtro'];
            else
                 $filtro=0;

//Consulta que se quiere ver en el dataGridView
           $Consulta1->seccion_ver2();
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print 'No existen secciones';  
            }
            else
            {
                while($Tipos=mysql_fetch_assoc($Consulta1->Resultado))
                {
   $Consulta3->participante_ver_grupo_seccion($idgrupoevento,$Tipos['id']);
                    $cantidadjor=mysql_num_rows($Consulta3->Resultado);
                    echo '<tr><td style="border:1px dotted black;"><H4 style="text-align: center"><span style="cursor:pointer"; onclick="especificojss('.$Tipos['id'].',3);">'.$Tipos['Seccion'].'</span></H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$cantidadjor.'</H4></td></tr>';
                }
            }
?>
</table>
</td>
</tr>
</table>
<br></br>

</div>
</div>
</form>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="../../../BLL/ajax.js" language="javascript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>
<?php
	   include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		$Consulta1=new Consulta;
$consulta1=new Consulta;
       $Consulta2=new Consulta;
       $Consulta3=new Consulta;
session_start();
        $idgrupoevento=$_SESSION['idGrupoEvento'];
 if(isset($_POST['idRegistro']))
        {
			$idTipo=$_POST['idRegistro'];
        }
		else
        {
			$idTipo=0;
        }
		$ver=$_POST['veri'];

$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Evento seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
if($ver==1)
		{
$consulta1->Jornada_seleccionar($idTipo);
            $nombre=mysql_fetch_assoc($consulta1->Resultado);
}
else if($ver==2)
		{
$consulta1->Semestre_ver_datos($idTipo);
            $nombre=mysql_fetch_assoc($consulta1->Resultado);
}
else if($ver==3)
    	{
$consulta1->Seccion_seleccionar($idTipo);
            $nombre=mysql_fetch_assoc($consulta1->Resultado);
}
?>
<body>
<a style="padding-left:50px; color:#333; text-decoration:none" href="Evento_reporte.php"><i class="icon icon-undo2"></i> Atrás</a>
<form id="form1" name="form1" method="post" action="">
<h3 align="center">Reporte del evento:<? print $NombreG;?></h3>
<?php if($ver==1)
		{?>
<h3 align="center">Jornada: <? print $nombre['Jornada'];?></h3>
<?php }
else if($ver==2)
		{?>
<h3 align="center">Semestre: <? print $nombre['Semestre'];?></h3>
<?php }
else if($ver==3)
    	{?>
<h3 align="center">Seccion: <? print $nombre['Seccion'];?></h3>
<?php }?>
<br></br>
<div class="tablas" align="center">

<?php 
$Consulta3->Evento_ver_grupo_solo($idgrupoevento);
if(mysql_num_rows($Consulta3->Resultado)==0)
            {
              print '<tr>No hay actividades asignadas</tr>';  
            }
            else
            {
                while($Actividades=mysql_fetch_assoc($Consulta3->Resultado))
                {
?>
<H3 align="left"><? print $Actividades['Nombre Actividad'];?></h3>
 <table align="center" width="863" style="border:1px solid black; text-align:center ; border-collapse:collapse" >
<tr>
<td style="border:1px dotted black;"><H4 style="text-align: center">Nombre</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Carné</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Jornada</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Semestre</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Seccion</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Asistencia</H4></td>
</tr>
	<?php
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        

//Consulta que se quiere ver en el dataGridView
		if($ver==1)
		{
           $Consulta1->participante_ver_grupo_jornada2($idgrupoevento,$idTipo,$Actividades['idEvento']);
		}
else if($ver==2)
		{
   $Consulta1->participante_ver_grupo_semestre2($idgrupoevento,$idTipo,$Actividades['idEvento']);
}
else if($ver==3)
    	{
   $Consulta1->participante_ver_grupo_seccion2($idgrupoevento,$idTipo,$Actividades['idEvento']);
}
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print '<tr>No hay participantes asignados</tr>';  
            }
            else
            {
                while($Tipos=mysql_fetch_assoc($Consulta1->Resultado))
                {
if($Tipos['Asistencia']==1)
{
$asis="Asistido";
}
else
{
$asis="No asistido";
}
                    echo '<tr ><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Nombre'].'</h4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Carne'].'</H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Jornada'].'</H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Semestre'].'</H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Seccion'].'</H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$asis.'</H4></td></tr>';
                }
            }
?>
</table>
<?php }
}?>
</div>
</form>
</body>
</html>
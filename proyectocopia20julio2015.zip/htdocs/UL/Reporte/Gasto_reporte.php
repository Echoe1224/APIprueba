<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script src="../../BLL/ajax.js" language="javascript"></script>
<script src="../../UL/PATROCINADOR/ajax1.js" language="javascript"></script>

<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>

<body>
    <?php
    /**/
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
	    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	    include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	    include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php"; 
		$Consulta1=new Consulta;
        session_start();
        $filtro=$_SESSION['idGrupoEvento'];
        
        $Consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
        $res=$Consulta1->Resultado;
        if(mysql_num_rows($res)==0)
        $NombreG="Evento seleccionado inexistente";
        else
        {
            while($row=mysql_fetch_assoc($res))
            {
                $NombreG=$row["Nombre"];
            }
        }
        
//Consulta que se quiere ver en el dataGridView
           $Consulta1->Gasto_Reporte_General($filtro);
           if(mysql_num_rows($Consulta1->Resultado)==0)
            {
              print 'No se encontró datos';  
            }
            else
            {
                ?>
				<H2 align="center" >Reporte de gastos de <?php echo $NombreG; ?></H2>
<br/>
                <table style="border:1px solid black; text-align:center ; border-collapse:collapse" width:"500"="" align="center">
                <tbody>
                <tr>
                    <td style="padding:3px 7px 2px 7px;border:1px solid  #666" width="201"><big style="font-weight: bold;">Descripción</big></td>
                    <td style="padding:3px 7px 2px 7px;border:1px solid  #666" width="201"><span style="font-weight: bold;">Total</span></td>
                </tr>
                <?php 
                $total=0;
                while ($fila=mysql_fetch_array($Consulta1->Resultado))
                {
                    ?>
                    <tr>
                        <td style="border:1px dotted black;">
                        <?php 
                            echo "<a style='text-decoration:none; color:#000' href='reporte_gastos_especifico_ver.php?reporte=$fila[0]&nombre=$fila[1]'> $fila[1] </a>"; 
                        ?>
                        </td> 
                        <td style="border:1px dotted black;" style="text-align: center;"><?php echo $fila[2]; ?></td>
                    </tr>
                    <?php 
                    $total=$total+$fila[2];
                }
                ?>
            </tbody>
            </table>
            <br/>
            <H3 align="center">Total Q. <?php echo $total; ?></H3>
            <br/>
            <?php 
            }   
            	
				
				
				/*if (!$metadatos) {
					        echo "No hay información disponible<br />\n";
					    }
					    echo "<pre>
						blob:         $metadatos->blob
						max_length:   $metadatos->max_length
						multiple_key: $metadatos->multiple_key
						name:         $metadatos->name
						not_null:     $metadatos->not_null
						numeric:      $metadatos->numeric
						primary_key:  $metadatos->primary_key
						table:        $metadatos->table
						type:         $metadatos->type
						unique_key:   $metadatos->unique_key
						unsigned:     $metadatos->unsigned
						zerofill:     $metadatos->zerofill
						</pre>";*/	
?>
</body>
</html>
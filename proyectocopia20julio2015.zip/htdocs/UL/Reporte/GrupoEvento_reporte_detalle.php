<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_grupo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Reporte detallado de evento</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="../CITEIN/main.js"></script>
<?php
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script type="text/javascript">
function imprSelec(muestra)
{
    var ficha=document.getElementById(muestra);
    var ventimp=window.open(' ','popimpr');
    ventimp.document.write(ficha.innerHTML);
    ventimp.document.close();
    ventimp.print();
    ventimp.close();
}
</script>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']<=0)
	    {
    		echo '<h5 align="center">Seleccione un grupo de eventos a gestionar</h5>';
            echo '<div class="hiper" align="center"><a href="../Inicio/inicio.php">Seleccionar grupo de eventos</a></div>';
        }
        else
        {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
                $NombreG="Grupo de eventos seleccionado inexistente";
            else
            {
                while($row=mysql_fetch_assoc($res))
                {
                    $NombreG=$row["Nombre"];
                }
            }
            echo '<h1 align="center">'.$NombreG.'</h1>';
         ?>
    	<!-- InstanceBeginEditable name="Contenido" -->
        <?php
		$cod=$_GET['g']; 
			$nombre=$_GET['nom'];
		?>
          <a style="padding-left:50px; color:#333; text-decoration:none" href="GrupoEvento_reporte.php"><i class="icon icon-undo2"></i> Atrás</a>
        	<form id="form1" name="form1" method="post" action="">
        <h2 style="text-align:center"> Reporte de <? print $nombre; ?></h2>
        <p style="text-align:center">
        <div align="center">
        <table width="900" align="center" style="border:1px solid black; text-align:center ; border-collapse:collapse" >
                      <tr> 
                          <th > </th>
                          <th colspan="3"> </th>
                          <th colspan="3" style="border:1px groove"> Ingresos</th>
                      </tr>
                      <tr>
                        <th>Participantes</th>
                        <th>Actividades</th>
                        <th>Personal</th>
                        <th>Gastos</th>
                        <th>Por inscripción</th>
                        <th>Por costo extra</th>
                        <th>Total</th>
                      </tr>
                                                                   
                                <?php    			
                                    $consulta1->GrupoEvento_reporte_detalle($cod);
                                    $row = mysql_fetch_assoc($consulta1->Resultado);
                                    $ingreso1=$row['Ingresos'];
                                    $ingreso2=$row['Ingreso2'];
                                    $total=$ingreso1+$ingreso2;
                                    
                                        echo'
            							<tr>
    										<td>'.$row['totalParticipante'].'</td>
    										<td>'.$row['TotalActividades'].'</td>
    										<td>'.$row['totalpersonal'].'</td>
    										<td>Q.'.$row['totalgastos'].'</td>
    										<td>Q.'.$row['Ingresos'].'</td>
                                            <td>Q.'.$row['Ingreso2'].'</td>
                                            <td>Q.'.$total.'</td>	
										</tr>
                                        ';
                                ?>
                    </table>
                    </div>        
        </p>
        <div align="center">
                <table align="center" width="863" style="border:1px solid black; text-align:center ; border-collapse:collapse" >
              <tr>
                <th style="padding:3px 7px 2px 7px;border:1px solid  #666"  width="161">Actividades</th>
                <th style="padding:3px 7px 2px 7px;border:1px solid  #666" width="138">Tipo de actividad</th>
                <th style="padding:3px 7px 2px 7px;border:1px solid  #666" width="128">Fecha</th>
                <th style="padding:3px 7px 2px 7px;border:1px solid  #666" width="128">Hora</th>
                <th style="padding:3px 7px 2px 7px;border:1px solid  #666" width="126">Duración(Hrs)</th>
                <th style="padding:3px 7px 2px 7px;border:1px solid  #666" width="90">Educador asignado</th>
                <th style="padding:3px 7px 2px 7px;border:1px solid  #666" width="79">Personal</th>
                <th style="padding:3px 7px 2px 7px;border:1px solid  #666" width="95">Costo</th>
              </tr>
             
              <?php    		
            		  		
                            $consulta1->GrupoEvento_reporte_detalle($cod);
                            while ($row = mysql_fetch_assoc($consulta1->Resultado)) 
                            {
                                echo' <tr>
                                <td style="border:1px dotted black;">'.$row['Nombre del evento'].'</td>
                                <td style="border:1px dotted black;">'.$row['Tipo de evento'].'</td>
                                <td style="border:1px dotted black;">'.$row['Fecha'].'</td>
								<td style="border:1px dotted black;">'.$row['inicio'].'</td>
                                <td style="border:1px dotted black;">'.$row['Duración'].'</td>
                                <td style="border:1px dotted black;">'.$row['Educador'].'</td>
                                <td style="border:1px dotted black;">'.$row['Personal'].'</td>
                                <td style="border:1px dotted black;">Q.'.$row['Costo'].'</td>
                                </tr>
                                ';
                                    
                            }
                        ?>
                         
                        
                </table>
        </div>
</form>
	</br>
      </br>
      </br>
	<div align="center">
        <a class="boton-link" href="javascript:imprSelec('form1')"><i class="icon icon-printer"></i> Imprimir reporte</a>
      </div>
		<!-- InstanceEndEditable -->
	<?php
    }
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
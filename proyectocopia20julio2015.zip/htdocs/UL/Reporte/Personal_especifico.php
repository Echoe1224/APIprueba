<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="../../../BLL/ajax.js" language="javascript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>

<body>
<a style="padding-left:50px; color:#333; text-decoration:none" href="Personal_reporte.php"><i class="icon icon-undo2"></i> Atrás</a>
<form id="form1" name="form1" method="post" action="">
<div align="center">
<table align="center" width="863" style="border:1px solid black; text-align:center ; border-collapse:collapse" >
	<?php
 if(isset($_POST['idRegistro']))
        {
			$idTipo=$_POST['idRegistro'];
        }
		else
        {
			$idTipo=0;
        }
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
	    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
		$Consulta1=new Consulta;
       $Consulta2=new Consulta;
       $Consulta3=new Consulta;
session_start();
//echo $idTipo;
        $idgrupoevento=$_SESSION['idGrupoEvento'];
//Consulta que se quiere ver en el dataGridView

           $Consulta1->Personal_ver_descripcion2($idTipo,$idgrupoevento);
           $Consulta2->Personal_ver_descripcion2($idTipo,$idgrupoevento);
           $row=mysql_fetch_assoc($Consulta1->Resultado);
           $cantidad=$Consulta1->Resultado;
$tipoeve=mysql_fetch_assoc($cantidad);
            echo '<H3 align="center">Detalles del personal:'.$tipoeve['Nombre'].'</H3>';

           if(mysql_num_rows($cantidad)==0)
            {
              print 'No existe ese miembro del Personal';  
            }
            else
            {
                while($Tipos=mysql_fetch_assoc($Consulta2->Resultado))
                {
                    echo '<tr><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Nombre'].'</h4></td><td style="border:1px dotted black;"><H4 style="text-align: center">Carné: '.$Tipos['Carnet'].'</h4></td><td style="border:1px dotted black;"><H4 style="text-align: center">Teléfono: '.$Tipos['Telefono'].'</H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">Sección: '.$Tipos['Seccion'].' </h4></td><td style="border:1px dotted black;"><H4 style="text-align: center"> Jornada: '.$Tipos['Jornada'].'</H4></td></tr>';
                }
            }
?>
</table>
<br></br>
<table align="center" width="863" style="border:1px solid black; text-align:center ; border-collapse:collapse" >
<tr>
<td style="border:1px dotted black;"><H4 style="text-align: center">Actividad</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Fecha</H4></td>
</tr>
	<?php

//Consulta que se quiere ver en el dataGridView

           $Consulta1->Personal_ver_actividades($idTipo);
           $Consulta2->Personal_ver_actividades($idTipo);
           $row=mysql_fetch_assoc($Consulta1->Resultado);
           $cantidad=$Consulta1->Resultado;
$tipoeve=mysql_fetch_assoc($cantidad);
            echo '<H3 align="center">Actividades asignadas</H3>';

           if(mysql_num_rows($cantidad)==0)
            {
              print 'No existe ese actividades para este miembro del personal';  
            }
            else
            {
                while($Tipos=mysql_fetch_assoc($Consulta2->Resultado))
                {
                    echo '<tr><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Nombre de la actividad'].'</h4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$Tipos['Fecha'].'</h4></td></tr>';
                }
            }
?>
</table>
</div>
</form>
</body>
</html>
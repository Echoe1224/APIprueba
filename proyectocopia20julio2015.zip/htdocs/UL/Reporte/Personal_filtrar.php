<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="../../../BLL/ajax.js" language="javascript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>

<body>
<form id="form1" name="form1" method="post" action="">
<div align="center">
<table style="border:1px solid black; text-align:center ; border-collapse:collapse"  width:"500" align="center" >
<tr>
<td style="border:1px dotted black;"><H4 style="text-align: center">Personal</H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Cantidad actividades asignadas</H4></td>
</tr>
	<?php
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
   include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
session_start();
		$Consulta1=new Consulta;
       $Consulta2=new Consulta;
       $Consulta3=new Consulta;
       $Consulta4=new Consulta;
       $Consulta5=new Consulta;
       $Consulta6=new Consulta;
       
 if(isset($_GET['filtro']))
                $filtro=$_GET['filtro'];
            else
                 $filtro=0;
        $idgrupoevento=$_SESSION['idGrupoEvento'];
//Consulta que se quiere ver en el dataGridView
//$pagesp='\'Personal_especifico.php\'';

            $Consulta5->Personal_contar_activo($idgrupoevento);
$Consulta6->Personal_contar_activo($idgrupoevento);
           $row=mysql_fetch_assoc($Consulta5->Resultado);
         $cantidad=mysql_num_rows($Consulta5->Resultado);      
                if(mysql_num_rows($Consulta5->Resultado)==0)
            {
              print 'No existe Personal Disponible para el evento';  
            }
            else
            {
while($row=mysql_fetch_assoc($Consulta6->Resultado))
                {
$Consulta2->Personal_ver_actividades($row['idPersonal']);
           $conteo=mysql_num_rows($Consulta2->Resultado);
                      //echo '<tr><td><H4 style="text-align: justify center"> <span style="cursor:pointer"; onclick="especifico('.$row['idPersonal'].');">Miembro del Personal: '.$row["Personal Activo"].'</span></H4></tr></td>';
                      echo '<tr><td style="border:1px dotted black;"><H4 style="text-align: center"><span style="cursor:pointer"; onclick="especifico('.$row['idPersonal'].');"> '.$row["Personal Activo"].'</span></H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$conteo.'</h4></td></tr>';
        		echo $cantidad["Conteo"];
                }
                
            }
?>

<input type="hidden" name="idEvento" id="idEvento" value="<?php echo $idgrupoevento?>"/>
</table>
</div>
</form>
</body>
</html>	
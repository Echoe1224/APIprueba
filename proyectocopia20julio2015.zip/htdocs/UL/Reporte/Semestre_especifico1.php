<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="../../../BLL/ajax.js" language="javascript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
</head>

<body>
<form id="form1" name="form1" method="post" action="">
<div align="center">
<table style="border:1px solid black; text-align:center ; border-collapse:collapse"  width:"500" align="center" >
<tr>
<td style="border:1px dotted black;"><H4 style="text-align: center">Semestre </H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Cantidad de playeras </H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Cantidad de playeras de hombre </H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Cantidad de playeras de mujer </H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Cantidad de tipos de playeras </H4></td>
<td style="border:1px dotted black;"><H4 style="text-align: center">Tallas</H4></td>
</tr>

	<?php
        //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
	       include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
session_start();
		$Consulta1=new Consulta;
       $Consulta2=new Consulta;
       $Consulta3=new Consulta;
       $Consulta4=new Consulta;
       $Consulta5=new Consulta;
       $Consulta6=new Consulta;
       
 if(isset($_GET['idRegistro']))
                $idtipo=$_GET['idRegistro'];
            else
                 $idtipo=0;
        $idgrupoevento=$_SESSION['idGrupoEvento'];
//Consulta que se quiere ver en el dataGridView
//$pagesp='\'Personal_especifico.php\'';


            $Consulta5->semestre_ver();     
                if(mysql_num_rows($Consulta5->Resultado)==0)
            {
              print 'No existe playeras entregadas para el semestre seleccionado';  
            }
            else
            {
while($conteo=mysql_fetch_assoc($Consulta5->Resultado))
                {
                   
                    for ($galletas = 0; $galletas < 6; $galletas++){
                    if($galletas==0){
                        $aux="XS";
                    }
                    else if($galletas==1){
                        $aux="S";
                    }
                    else if($galletas==2){
                        $aux="M";
                    }
                    else if($galletas==3){
                        $aux="L";
                    }
                    else if($galletas==4){
                        $aux="XL";
                    }
                    else if($galletas==5){
                        $aux="XXL";
                    }
$Consulta2->playera_semestre($conteo['id'],$idgrupoevento,$aux);
           $row=mysql_fetch_assoc($Consulta2->Resultado);
                      //echo '<tr><td><H4 style="text-align: justify center"> <span style="cursor:pointer"; onclick="especifico('.$row['idPersonal'].');">Miembro del Personal: '.$row["Personal Activo"].'</span></H4></tr></td>';
                      echo '<tr><td style="border:1px dotted black;"><H4 style="text-align: center">'.$row["Semestre"].'</H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$row["totalParticipante"].'</h4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$row["TotalHombres"].'</h4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$row["TotalMujeres"].'</h4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$row["Cantidadtipoplayera"].'</H4></td><td style="border:1px dotted black;"><H4 style="text-align: center">'.$aux.'</H4></td></tr>';
                    }
                }
                
            }
?>  
</table>
<table style="border:1px solid black; text-align:center ; border-collapse:collapse"  width:"500" align="center" >
<td> Sección:</td>
  <td>
  <select name="Seccion" id="Seccion" onchange="especifico(id,2);">
                  	<?php
    			$Consulta2->Seccion_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option selected=selected value=".$row['idSeccion'].">".$row['Seccion']."</option>";
				}
                //echo '<option value="+">Agregar otro</option>';
		 ?>
  </select>
  </td>
  
  <td> Jornada:</td>
  <td>               
  <select name="Jornada" id="Jornada" onchange="especifico(id,3);">
          			<?php
    			$Consulta2->Jornada_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option selected=selected value=".$row['idJornada'].">".$row['Jornada']."</option>";
				}
                //echo '<option value="+">Agregar otro</option>';
		 ?>
  </select>
  </td>
  
  <td> Semestre:</td>
  <td>               
  <select name="Semestre" id="Semestre" onchange="especifico(id,1);">
          			<?php
    			$Consulta2->Semestre_ver();
				while ($row = mysql_fetch_assoc($Consulta2->Resultado)) {
					echo "<option selected=selected value=".$row['idSemestre'].">".$row['Semestre']."</option>";
				}
                //echo '<option value="+">Agregar otro</option>';
		 ?>
  </select>
  </td>

<input type="hidden" name="idEvento" id="idEvento" value="<?php echo $idgrupoevento?>"/>
</table>
</div>
</form>
</body>
</html>	
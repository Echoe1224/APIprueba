<?php
        include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php"; 
		
		$consulta1=new Consulta;    
        $idseccion=$_GET["q"];
           $consulta1->Seccion_listarporid($idseccion);
           $res=$consulta1->Resultado;
            if(mysql_num_rows($res)==0)
            {
                $consulta1->Seccion_eliminar($idseccion);
                ?>
                <h4 align="center">Eliminando sección</h4>
                <meta http-equiv="Refresh" content="1;url=/UL/Seccion/Seccion_ver.php">
                <?   
            } 
            else if(mysql_num_rows($res)>0)
            {
                 ?>
                <H4 align="center">La sección no se puede eliminar por estar</H4>
                <h4 align="center">asignada en un registro</h4>
                <meta http-equiv="Refresh" content="3;url=/UL/Seccion/Seccion_ver.php">
                <?php
            }
?>

	
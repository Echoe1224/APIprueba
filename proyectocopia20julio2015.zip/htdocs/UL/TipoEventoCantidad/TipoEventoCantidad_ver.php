<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Filtrar TipoEventoCantidad</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>
<?php
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	$consulta1=new Consulta;
    $consulta1->Usuario_ver();
    $Admin=$consulta1->Resultado;
?>
<!-- InstanceBeginEditable name="head" -->
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<link rel="stylesheet" href="http://citein.hostingla.in/UL/CITEIN/estilo2.css" >
<style type="text/css">

.dataGridViewDiv {
	min-width: 50%;
	min-height: 100px;
	border: 1px solid #066;
}
</style>
<!-- InstanceEndEditable -->
</head>
    
<body bgcolor="#F1F1F1">
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
        <header>
		<nav class="menu">
			<ul>
				<li><a href="../inicio.php"><span class="primero"><i class="icon icon-home"></i></span>CITEIN</a></li>
				<li><a href="#"><span class="segundo"><i class="icon icon-table2"></i></span>EVENTOS</a>
					<ul>
						<li><a href="#">Ver eventos</a></li>
						<li><a href="#">Crear evento</a></li>
					</ul>
				</li>
				<li><a href="#"><span class="tercero"><i class="icon icon-accessibility"></i></span>PARTICIPANTES</a>
					<ul>
						<li><a href="#">Ver participantes</a></li>
						<li><a href="../Registrar_Participante.php">Nuevo participante</a></li>
					</ul>
                </li>
                <?php if($Admin==TRUE){ ?>
				<!-- Opciones para administrador -->
                <li><a href="#"><span class="cuarto"><i class="icon icon-user"></i></span>OTROS</a>
					<ul>
						<li><a href="#">Tipo evento</a></li>
                        <ul>
							<li><a href="#">Tipo evento</a></li>
                        </ul>
						<li><a href="#">Nuevo tipo evento</a></li>
                        <li><a href="#">Nuevo tipo evento</a></li>
					</ul>
                </li>
                <?php } ?>
				<li><a href="#"><span class="cuarto"><i class="icon icon-user"></i></span>PERSONAL</a>
					<ul>
						<li><a href="#">Ver personal</a></li>
						<li><a href="#">Nuevo personal</a></li>
					</ul>
                </li>
				<li><a href="#"><span class="quinto"><i class="icon icon-exit"></i></span>Cerrar Sesión</a></li>
			</ul>
		</nav>
        </header>
        </div>

<div class="contenedor">
	<div class="contenido">
    <!-- InstanceBeginEditable name="Contenido" -->
    	<script language="javascript">
                $(document).ready(function() {
                    // any code goes here
                    Filtrar();
                });
         </script>
         <form id="form1" name="form1" method="post" action="">
            <input type="hidden" name="paginaFiltro" id="paginaFiltro" value="TipoEventoCantidad_filtrar.php" />
            <input type="hidden" name="paginaEditar" id="paginaEditar" value="Encuesta_filtrar.php" />
            <input type="hidden" name="paginaEliminar" id="paginaEliminar" value="..\..\BLL\eliminar.php" />
        	<div>
            	<label for="texto_filtro">Filtrar: </label>
            	<input type="text" name="texto_filtro" id="texto_filtro" onKeyUp="Filtrar();" />
            </div>
            <br/>
            <div class="dataGridViewDiv" id="resultados"></div>
          </form>
	<!-- InstanceEndEditable -->
    
    </div>
    
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
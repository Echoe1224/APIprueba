<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Ingresar usuario</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="../CITEIN/estilos.css"  />
<link rel="stylesheet" href="../CITEIN/fonts.css" />
<script src="../../BLL/ajax.js" language="JavaScript"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../CITEIN/main.js"></script>
<?php
/*	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/Templates/menu.php";*/
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	include $_SERVER['DOCUMENT_ROOT']."/Templates/menu.php";
	$consulta1=new Consulta;
    session_start();
//    $_SESSION['idGrupoEvento']=91;
?>
<!-- InstanceBeginEditable name="head" -->
<script>
function limpia(elemento)
{
if(elemento.value==" ")
elemento.value = "";
}
</script>
<?php
    $MiConsulta=new Consulta;

$nombreErr=$usuarioErr=$contraErr="";
$usuario=" ";
$nombre=$contra=$tipo="";
$contador=0;

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
	if (empty($_POST["nombre"]))
	{
		$nombreErr="El nombre es requerido";
        $usuarioErr ="El usuario es requerido";
	}
	else
	{
		$nombre = test_input($_POST["nombre"]);
		if (!preg_match("/^[a-zA-Z ñáéíóú ]*$/",$nombre)) 
		{
  			$nombreErr="Ingrese solamente letras y espacios"; 
		}
		else
		{
			++$contador;
		}
	}
	if (empty($_POST["user"]))
	{
		$usuarioErr ="El usuario es requerido";
	}
	else
	{
		$usuario = test_input($_POST["user"]);
		if (!preg_match("/^[a-zA-Z0-9]*$/",$usuario)) 
		{
    	 	$usuarioErr ='El formato del usuario es inválido.';
		}
		else
		{
			++$contador;
		}
	}
	if (empty($_POST["password"]))
	{
        $contra="";
		$contraErr="La contraseña es requerida";
	}
	else
	{
		$contra = test_input($_POST["password"]);
    	if (!preg_match("/^[a-zA-Z0-9]*$/",$contra)) 
		{
    	 	$contraErr ='El formato de contraseña es inválido.';
		}
		else
		{
			++$contador;
		}
		
	}
	
	if($contador==3)
	{           
        if($consulta1->Usuario_VerificarUsuario($usuario)==0)
        {
            $tipo=$_POST["TipoUsuario"];
            //echo $tipo;
            $consulta1->Usuario_IngresarUsuario($nombre,$usuario,$contra,$tipo);
            $nombre="";
            $usuario=NULL;
            $contra="";
            $tipo="";
            $error="";
            header("Location: http:/UL/Usuarios/Usuario_ver.php");
        }
        else
        {
            $error="El usuario ya existe por favor seleccione otro";
        }
	}


}
function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<style> 
.error {color: #FF0000;} 
</style>
<!-- InstanceEndEditable -->
</head>
    
<body  bgcolor="#F1F1F1" >
	<div class="contenedor">
    <div class="logo" align="center">
	    	<img src="../../portada_secundaria.png" alt="" />
	</div>
    <header>
    <?php
    if($_SESSION['userid']>0)
    {
		menu();
	?>
    
    </header>
    </div>
	<div class="contenedor" style="text-align:right;">
    	Bienvenido <?php echo $_SESSION['nombre'];?><br />
    	<a style="color:#333; text-decoration:none;" href="../Login/logout.php"><i class="icon icon-exit"></i> Cerrar sesión</a>
    <?php
    }?>
    </div>
<div class="contenedor">
	<div class="contenido">
    
    <?php
    if($_SESSION['userid']==0)
    {
    ?>
        <h1 align="center">Necesita iniciar sesión para poder usar el sistema</h1>
        <br />
	    <h4 align="center"><a href="../Login/login.php"><i class="icon icon-enter"></i> Iniciar sesión</a></h4>
    <?php
    }
    else
    {
    	if($_SESSION['idGrupoEvento']>0)
	    {
        	$consulta1->GrupoEvento_ver2($_SESSION['idGrupoEvento']);
            $res=$consulta1->Resultado;
            $row=mysql_fetch_assoc($res);
            $NombreG=$row["Nombre"];
            echo '<h1 align="center">'.$NombreG.'</h1>';
         
        }
        ?>
    	<!-- InstanceBeginEditable name="Contenido" -->


<h3 align="center"><?php echo $error;?></h3>
        <form id="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
      	<p>
      	  <input name="formulario" id="formulario"
         value="Registrar_usuario" type="hidden">
   	  </p>
      	  <H2 align="center" >Registrar nuevo usuario</H2><br>
   	  </p>
      <div align="center">
      <span class="error">* Campos requeridos.</span>
   	  <table width="550" cellspacing="5" align="center" border="0">
   	    <tr>
              <td style="text-align: right;">Nombre:</td>
              <td><input name="nombre"
         id="nombre" type="text" value="<?php echo $nombre;?>" onfocus="javascript: limpia(user);" placeholder="Ingrese el nombre." required="" title="Se necesita un nombre (solamente letras)" pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ ]{1,45}" autocomplete="off" maxlength="45"/>
         <span class="error">* <?php echo $nombreErr;?></span>
         </td>
        </tr>
            <tr>
              <td style="text-align: right;"><label>Usuario: </label></td>
              <td><input name="user" id="user" value='<?php echo $usuario;?>' onmousemove="javascript: limpia(this);" onfocus="javascript: limpia(this);" required="" title="Se necesita un nombre de usuario (solamente letras y numeros)" pattern="[A-Za-z0-9Ññ]{1,45}" placeholder="Ingrese nombre de usuario." autocomplete="off" type="text" maxlength="45">
              <span class="error">* <?php echo $usuarioErr;?></span>
              </td>
            </tr>
            <tr>
              <td style="text-align: right;"><label>Contraseña: </label></td>
              <td><input name="password" id="password" value="<?php echo $contra;?>"  required="" title="Se necesita una contraseña" pattern="[A-Za-z0-9Ññ ]{1,45}" placeholder="Ingrese la contraseña." type="password" autocomplete="off" maxlength="10">
              <span class="error">* <?php echo $contraErr;?></span>
              </td>
            </tr>
            <tr>
              <td style="text-align: right;"><label>Tipo de usuario: </label></td>
              <td><select name="TipoUsuario" >
                <option value="1">Administrador</option>
                <option value="2">Organizador</option>
                <option value="3">Catedratico</option>
                <option value="4">Encargado de inscripciones</option>
                <option value="5">Encargado de asistencia</option>
                <option value="6">Encargado de impresiones</option>
              </select></td>
            </tr>
            <tr>
        </table>
<br/>
  <input id="submit" value="Guardar" type="submit">
  <input style="display:inline" type="button" name="boton" id="boton" value="Cancelar" onclick="window.location.href='/UL/Usuarios/Usuario_ver.php'">
  </div>
    </form>    
		<!-- InstanceEndEditable -->
	<?php
    }
	?>  
    </div>
  <footer>
  	<a id="to-the-top" href="#">
    <span><i class="icon icon-shift"></i></span></a>
    <label>© Copyright 2015</label>
    <br/>
    <label>CITEIN</label>
  </footer>
</div>
</body>
<!-- InstanceEnd --></html>
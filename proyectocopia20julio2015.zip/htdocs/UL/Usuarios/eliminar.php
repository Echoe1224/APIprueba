<?php
	     include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";  
    	
		$consulta1=new Consulta;
        $id=$_GET["q"];
            $consulta1->Usuario_eliminar($id);
            ?>
            <h4 align="center">Eliminando usuario</h4>
            <meta http-equiv="Refresh" content="3;url=/UL/Usuarios/Usuario_ver.php">
            <?php;
?>


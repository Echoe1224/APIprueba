<?php
// datos para la conexion a mysql
define('DB_SERVER','sql304.hostingla.in');
define('DB_NAME','hos7_15945417_citein');
define('DB_USER','hos7_15945417');
define('DB_PASS','citein1234');
$con = mysql_connect(DB_SERVER,DB_USER,DB_PASS);
mysql_select_db(DB_NAME,$con);
?>
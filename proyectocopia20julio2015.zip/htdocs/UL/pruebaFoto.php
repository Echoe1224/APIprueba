<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<style>
#container
{
    height:400px;
    width:400px;
    position:relative;
}

#image
{
    position: absolute;
	left: 36px;
	top: -13px;
}
#text
{
	z-index: 100;
	position: absolute;
	color: #093;
	font-size: 24px;
	font-weight: bold;
	left: 217px;
	top: 142px;
	width: 257px;
	height: 60px;
}
</style>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript">
     $(document).ready(function(){
          $('#pdf').click(function(){
               printDiv();
               function printDiv() {
                    var printContents = $(".right_content").html();
                    var originalContents = document.body.innerHTML;
                    document.body.innerHTML = printContents;
                    window.print();
                    document.body.innerHTML = originalContents;
               }
          });
      });
</script>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div class="right_content">
    <img src="../fondo.jpg" width="889" height="782" id="image"/>
    <p id="text">
        Hello World!
    </p>
</div>
<input type="button" value="pdf" />

</form>

	
</body>
</html>
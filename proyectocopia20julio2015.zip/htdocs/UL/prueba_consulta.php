<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<?php
include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Servidor.php";
	include "/home/vol15_8/hostingla.in/hos7_15945417/htdocs/DAL/Consulta.php";
	$consulta1=new Consulta;
	$mensaje="";
	
		$idRegistro=22;
		//variable que pueden usar para no saturar el explorador
		$temp=1;
			echo '<br>dentro<br>';
			//Verificar si hay registros dependientes de este registro
			$consulta1->Encuesta_cantidad_asignado($idRegistro);
			$res=$consulta1->Resultado;
			//`Cantidad`
			echo $consulta1->Consulta;
			while($row=mysql_fetch_assoc($res))
                {
					echo 'algo';
					echo '<br>'.$row["Cantidad"]."<br>\n";
				}
			$número_filas=-1;
			$número_filas = mysql_num_rows($res);
			echo "<br>$número_filas Filas\n";
?>
</body>
</html>
<!<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_inicio.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="main.js"></script>
<link rel="stylesheet" href="CITEIN/estilos3.css"  />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Documento sin título</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
</head>

<body>
<!-- Encabezado             ------------------------------------------>
    <header class="primary-header container group">
      
      <h1 class="logo">
        <a href="index.html"><img src="../Logo-Meso-Color.png" width="140px" /><br />Eventos CITEIN</a>
      </h1>
      <h3 class="tagline"></h3>
      <h3 class="tagline"></h3>
      
      <nav class="nav primary-nav">
        <a href="participante.php">Participante</a>   /   
        <a href="login.php">Iniciar Sesión</a>
      </nav>

    </header>
<?php session_start();
include_once "conexion.php";
function verificar_login($user,$password,&$result) 
{
    $sql = "SELECT * FROM Usuario WHERE Usuario = '$user' and Contrasena = '$password'";
    $rec = mysql_query($sql);
    $count = 0;
    while($row = mysql_fetch_object($rec))
    {
        $count++;
        $result = $row;
    }
    if($count == 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
if(!isset($_SESSION['userid']))
{
    if(isset($_POST['boton_login']))
    {
        if(verificar_login($_POST['texto_usuario'],$_POST['texto_pass'],$result) == 1)
        {
            $_SESSION['userid'] = $result->idUsuario;
            $_SESSION['usuario']=$result->Usuario;
            $_SESSION['tipo']=$result->Administrador;
            header("location:http://citein.hostingla.in/UL/Inicio/inicio.php");
        }
        else
        {
            echo '<div class="error">Su usuario es incorrecto, intente nuevamente.</div>';
        }
    }
    ?>
    <style type="text/css">
    .error
    {
        color: red;
        font-weight: bold;
        margin: 10px;
        text-align: center;
    }
    </style>

<!-- Contenido            ------------------------------------------------->
    <section class="row-alt">
<!-- InstanceBeginEditable name="Contenido" -->
<div align="center">
	<table width="252" height="147" border="0" cellspacing="5">
	  <tr>
	    <td width="103">Usuario:</td>
	    <td width="130"><form id="form1" name="form1" method="post" action="">
	      <label for="texto_usuario"></label>
	      <input name="texto_usuario" type="text" id="texto_usuario" accesskey="u" size="20" maxlength="10" />
        </td>
    </tr>
	  <tr>
	    <td>Contraseña:</td>
	    <td>
	      <label for="texto_pass"></label>
	      <input name="texto_pass" type="password" id="texto_pass" accesskey="c" size="20" maxlength="10" />
        </td>
    </tr>
	  <tr>
	    <td>&nbsp;</td>
	    <td>
	      <input type="submit" name="boton_login" id="boton_login" value="Iniciar Sesión" />
	    </form></td>
    </tr>
  </table>
  </div>
<!-- InstanceEndEditable -->
	</section>
    <footer>
      <a id="to-the-top" href="#">
      <span><i class="icon icon-shift"></i></span></a>
      <label>© Copyright 2015</label>
      <br/>
      <label>CITEIN</label>
    </footer>
<?php
}
else 
{

    echo '<a href="logout.php">Cerrar Sesion</a>';
    ?>
        <?php 
        if(!isset($_SESSION['usuario']))header("Location: logout.php");  
        $tiempo = (isset($_SESSION['time'])) ? $_SESSION['time'] : strtotime(date("Y-m-d H:i:s")); 
        $actual =  strtotime(date("Y-m-d H:i:s")); 
        (($actual-$tiempo) >= 900) ? header("Location: logout.php") : $_SESSION['time'] =$actual;
        
}
?>
</body>
<!-- InstanceEnd --></html>	
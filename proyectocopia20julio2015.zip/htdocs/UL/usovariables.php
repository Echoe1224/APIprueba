<?php 
session_start();
if($_SESSION['userid']==0)
{
    echo 'Usted no esta logeado';
}
else
{
        if($_SESSION['tipo']==1)
        {
            echo 'Usted es un administrador';
            echo ' su usuario es: ';
            echo $_SESSION['usuario'];
        }
        else if($_SESSION['tipo']==0)
        {
            echo 'Usted es un operador';
            echo ' su usuario es: ';
            echo $_SESSION['usuario'];
        }
}
?>		
<!DOCTYPE html> 
<html> 
<head> 
<title>Probando bootstrap</title> 
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
</head> 
<body class="container">


<?php
    $directory="Portada/";
    $dirint = dir($directory);
    $count=1;
    $dire = "Portada/";
    $ds  = opendir($dire);
    while (false !== ($nombre_archivo = readdir($ds))) 
    {
        $archivos[] = $nombre_archivo;
    }
    $total_archivos = count($archivos);
    $total = $total_archivos-1;
    //echo $total;
    ?>
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
    <ol class=" carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        
   <?php
   for ($i = 1; $i < $total; $i++) 
   {
        echo '<li data-target="#myCarousel" data-slide-to="'.$i.'"></li>';
   }
   ?>
    </ol>
      <div align="center" class="carousel-inner" role="listbox">
      <div class="item active">
          <img src="/Portada/MESO.JPG"  alt="">
          <div class="container">
            <div class="carousel-caption">
            </div>
          </div>
        </div>
    <?php
    
    
    while (($archivo = $dirint->read()) !== false)
    {
        if (eregi("gif", $archivo) || eregi("jpg", $archivo) || eregi("png", $archivo))
        {
            $url=$directory.$archivo;  
            echo '<div class="item">
                <img src="'.$url.'"  alt="">
                <div class="container">
                    <div class="carousel-caption">
                    </div>
                </div>
            </div>';
        }
    }
    $dirint->close();
?>
 </div>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</body> 
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_inicio.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="UL/CITEIN/estilos_inicio.css"  />
<link rel="stylesheet" href="UL/CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="UL/CITEIN/main.js"></script>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
?>
<!-- InstanceBeginEditable name="doctitle" -->
<title>Eventos CITEIN</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="UL/CITEIN/galeria.css"  />
<script src="BLL/ajax.js" language="JavaScript"></script>
<link rel="stylesheet" href="UL/CITEIN/modal.css" />
<link rel="stylesheet" href="UL/CITEIN/fonts.css"  />
<!-- InstanceEndEditable -->
</head>

<body>
<div id="wrapper">
    <div id="header"><!-- Encabezado             ------------------------------------------>
        <header class="primary-header group">
          <nav class="nav primary-nav">
            <a href="index.php"><i class="icon icon-home"></i> Inicio</a>   /
            <a href="pagina/participante.php"><i class="icon icon-accessibility"></i> Participante</a>   /   
            <a href="javascript:login();"><i class="icon icon-enter"></i> Iniciar Sesión</a>
          </nav>
        </header>
    </div>
    <div id="content">
    <!-- Contenido            ------------------------------------------------->
        <div class="modal-container">
			<div id="modal" class="modal"></div>
		</div>
    <!-- InstanceBeginEditable name="Contenido" -->
<div align="center">
<?php
$directory="Portada/";
$dirint = dir($directory);
$count=1;
$ds  = opendir($directory);
    while (false !== ($nombre_archivo = readdir($ds))) 
    {
        $archivos[] = $nombre_archivo;
    }
    $total_archivos = count($archivos);
    $total = $total_archivos-2;
?>
<div style="height:355px;" id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
    <ol class=" carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
   <?php
   for ($i = 1; $i < $total; $i++) 
   {
        echo '<li data-target="#myCarousel" data-slide-to="'.$i.'"></li>';
   }
   ?>
    </ol>
  <div align="center" class="carousel-inner" style="background:none;" role="listbox">
  	<div class="item active">
	  <img height="355px" src="/Portada/portada.jpg"  alt="">
	  <div class="container">
		<div class="carousel-caption">
		</div>
	  </div>
	</div>
	<?php
    
    $count=1;
    while (($archivo = $dirint->read()) !== false)
    {
		if($archivo!="portada.jpg")
		{
        if (eregi("gif", $archivo) || eregi("jpg", $archivo) || eregi("png", $archivo))
        {
            $url=$directory.$archivo;  
            echo '<div class="item">
                <img height="355px" src="'.$url.'"  alt="">
                <div class="container">
                    <div class="carousel-caption">
                    </div>
                </div>
            </div>';
            $count++;
        }
		}
    }
    $dirint->close();
    ?>
</div>
<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
	<span class="icon icon-prev" aria-hidden="true"></span>
	<span class="sr-only">Anterior</span>
</a>
<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
	<span class="icon icon-next" aria-hidden="true"></span>
	<span class="sr-only">Siguiente</span>
</a>
</div>
<section class="row-alt">
<?php
$consulta1->GrupoEvento_ver_detalle_habilitados();
$grupoEventos=$consulta1->Resultado;
//`idGrupoEvento`,`Nombre`,`DescripcionGrupoEvento`
while($grupo=mysql_fetch_assoc($grupoEventos))
{
	?>
    <div align="center">
    <h2 ><?php echo $grupo["Nombre"]; ?></h2>
    </div>
    <div align="center">
	<h3 align="center"><?php echo $grupo["DescripcionGrupoEvento"]; ?></h3>
    </div>
	<div class="grid">
	<?php
	$consulta1->GrupoEvento_ver_eventos_habilitados($grupo["idGrupoEvento"]);
	$eventos=$consulta1->Resultado;
	//`idEvento`,`Nombre`,`DescripcionEvento`,`TipoEvento_idTipoEvento`,`Fecha`,`HoraInicio`,`HoraFinal`,`Imagen
	while($evento=mysql_fetch_assoc($eventos))
	{
		?>
        <article class="teaser col-1-3">
			<a href="javascript:abrirVentana('evento=<?php echo $evento["idEvento"];?>');">
            <?php
			if(empty($evento["Imagen"]))
	 		{
				?>
	 			<figure><img width="100%" src="imagenes/conferencia2.jpg" /></figure>
               <?php
			}
			else
			{
				echo '<figure><img width="100%" src="imagenes/'.$evento["Imagen"].' " /></figure>';
			}
			?>
				<span>
				<h3><?php echo $evento["Nombre"];?></h3>
	            <?php
            	if(strlen($evento["DescripcionEvento"])<120)
				{
					echo '<p>'.$evento["DescripcionEvento"].'</p>';
				}
				else
				{
					echo '<p>'.substr($evento["DescripcionEvento"],137)."...".'</p>';
				}
				?>
				</span>
			</a>
		</article>
    <?php
	}
	?>
	</div>
<?php
}
?>
</section>
</div>
<script type="text/javascript" src="http://s3.amazonaws.com/codecademy-content/courses/hour-of-code/js/alphabet.js"></script>
<canvas id="myCanvas"></canvas>
<script type="text/javascript" src="http://s3.amazonaws.com/codecademy-content/courses/hour-of-code/js/bubbles.js"></script>
<script>
var red = [0, 100, 63];
var orange = [40, 100, 60];
var green = [75, 100, 40];
var blue = [196, 77, 55];
var purple = [280, 50, 60];

var myName = "Daniel Xep";
var letterColors=[blue,green,red,purple,orange];
if(10>3){
    bubbleShape="circle";
}
else{
    bubbleShape="square";
}


drawName(myName, letterColors);
bounceBubbles();
</script>
<script>
function abrirVentana(parametro)
	{
		abrirMGet(parametro,"/pagina/ver_evento.php");
	}
	function abrir2(param)
	{
		abrirMPost(param,"/UL/Login/login.php");
	}
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<!-- InstanceEndEditable -->
    </div>
    <div id="footer">
          <label style="color:#999;">CITEIN 2015</label>
          <br/>
          <label style="color:#999; text-align:right;">UNIVERSIDAD MESOAMERICANA</label>
    </div>
</div>
<script>
	function login()
	{
		abrirMPost("","../UL/Login/login.php");
	}
</script>
</body>
<!-- InstanceEnd --></html>

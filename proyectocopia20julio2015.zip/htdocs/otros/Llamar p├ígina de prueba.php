<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<meta content="text/html; utf-8" http-equiv="content-type"><title>Llamar página de prueba</title>

</head><body>
<form method="post" action="/DAL/guardar_archivo.php" name="llamar">prueba llamar pag.&nbsp;<button value="Llamar" name="boton_llamar"></button></form>
</body></html>
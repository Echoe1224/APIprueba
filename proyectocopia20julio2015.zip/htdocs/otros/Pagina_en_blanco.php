<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<meta content="text/html; charset=utf-8" http-equiv="content-type"><title>Página en blanco</title>    
</head><body>
    <p>Página en blanco</p>
    <p>
  <?php 
        $url= 'http://'.$_SERVER['HTTP_HOST'].dirname('../fotos/123456.jpeg');//.dirname($_SERVER['REQUEST_URI']);//.'/'.$filename;//generamos la respuesta como la ruta completa
        echo '<br><br>'.$url;
    ?>
    </p>
</body></html>
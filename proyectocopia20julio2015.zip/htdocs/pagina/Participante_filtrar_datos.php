<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Datos del participante</title>
</head>

<body>
<?php
    //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php"; 
	$Consulta1=new Consulta;
	$filtro=$_GET['filtro'];
	$Consulta1->Participante_ver_datos_usuario($filtro);
	/*`idParticipante`, `Participante`, `Carne`, `Semestre_idSemestre`,Semestre.Semestre, `Foto`, `Talla`, `Genero`, `PlayeraEntregada`, `CertificadoEntregado`, `GrupoEvento_idGrupoEvento`,GrupoEvento.Nombre, `EstadoParticipante`, `Jornada_idJornada`,Jornada.Jornada, `Seccion_idSeccion`,Seccion.Seccion, `UsuarioParticipante`*/
	if(mysql_num_rows($Consulta1->Resultado)==0)
    {
		print 'No se encontró datos';
	}
	else
	{
    	$row = mysql_fetch_assoc($Consulta1->Resultado,0);
		//`idParticipante`,`Nombre`,`Carnet`,`Semestre_idSemestre`,`Foto`
		$idParticipante=$row["idParticipante"];
		$nombre=$row["Participante"];
		$carnet=$row["Carne"];
		$foto=$row["Foto"];
		if(empty($foto))
		$foto="default";
		?>
	<table style="vertical-align:top; alignment-baseline:central;" width="200">
	  <tr>
		<td width="70"><b>Nombre:</b></td>
		<td width="118"><?php echo $nombre;?></td>
	  </tr>
	  <tr>
		<td><b>Carné:</b></td>
		<td><?php echo $carnet?></td>
	  </tr>
	  <tr>
	    <td><b>Semestre:</b></td>
	    <td><?php echo $row["Semestre"];?></td>
      </tr>
	  <tr>
	    <td><b>Jornada</b></td>
	    <td><?php echo $row["Jornada"];?></td>
      </tr>
	  <tr>
	    <td><b>Sección:</b></td>
	    <td><?php echo $row["Seccion"];?></td>
      </tr>
	  <tr>
	    <td><b>Playera:</b></td>
	    <td><?php echo $row["Talla"];?></td>
      </tr>
	  <tr>
	    <td><b>Género:</b></td>
	    <td><?php if($row["Genero"]==1) echo 'Masculino'; else echo 'Femenino';?></td>
      </tr>
	  <tr>
	    <td>&nbsp;</td>
	    <td>&nbsp;</td>
      </tr>
	</table>
	<img width="150px;" src="../../fotos/<?php echo $foto;?>.jpg" />
	<?php
	}
?>
<!--<table style="vertical-align:top; alignment-baseline:central;" width="200">
  <tr>
    <td width="70">Nombre:</td>
    <td width="118"><?php echo $nombre;?></td>
  </tr>
  <tr>
    <td>Carnet:</td>
    <td><?php echo $carnet;?></td>
  </tr>
</table>
<p>&nbsp;</p>
<img src="../../fotos/<?php echo $foto;?>.jpg" />-->
</body>
</html>
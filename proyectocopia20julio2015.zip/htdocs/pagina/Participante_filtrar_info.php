<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Filtrando...</title>
<script src="../BLL/ajax.js" language="javascript"></script>
<style>
#customers
{
font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
width:100%;
border-collapse:collapse;
}
#customers td, #customers th 
{
font-size:0.8em;
border:1px solid #98bf21;
padding:3px 7px 2px 7px;
}
#customers th 
{
font-size:1em;
text-align:left;
padding-top:5px;
padding-bottom:4px;
background-color:#A7C942;
color:#fff;

}
#customers tr.alt td 
{
color:#000;
background-color:#EAF2D3;
}
</style>
</head>

<body>
<?php
    //Esta pagina se utiliza para generar la tabla de la busqueda a realizar        
    include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$Consulta1=new Consulta;
	$filtro=$_GET['filtro'];
//Consulta que se quiere ver en el dataGridView
   $Consulta1->Participante_ver_eventos($filtro);
   /*Participante.idParticipante,
    Encuesta.idEncuesta,
    Evento.Nombre AS `Actividad`,
    TipoEvento.Nombre AS `Tipo de actividad`,
    GrupoEvento.Nombre AS `Evento`,
    DATE_FORMAT(Evento.Fecha, \"%d-%m-%Y\") as Fecha,
    Evento.HoraInicio as `Hora inicial`,
    Evento.HoraFinal as `Hora final`,
    EventoParticipante.Asistencia AS `Asistido`,
    EventoParticipante.Encuestado*/
   if(mysql_num_rows($Consulta1->Resultado)==0)
	{
	  print 'No se encontraron datos';  
	}
	else
	{
		//Se agrega el codigo del ancabezado de la tabla
		print'<table id="customers">';
		echo "\n";
		echo '<tr>';
		//$i:desde que columna se empieza a graficar
		$i = 3;
//Encabezado del dataGridView
		while ($i < mysql_num_fields($Consulta1->Resultado)) {
			$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
			echo '<th>'.$metadatos->name.'</th>';
			$i++;
		}
		echo '<th>Opción</th>';
		print '</tr>';
		echo "\n";
//Datos del dataGridView
		$agregar=false;
		while($row=mysql_fetch_assoc($Consulta1->Resultado))
		{
			//donde se agregan los datos que se mostraran en cada columna
			print'<tr>';
			echo "\n";
			//$i:desde que columna se empieza a graficar
			$i = 3;
			while ($i < mysql_num_fields($Consulta1->Resultado)) {
				$metadatos = mysql_fetch_field($Consulta1->Resultado, $i);
				//para agregar color a una fila
				$clase="filaTablaSinFondo";
				if($agregar)
					$clase="filaTablaConFondo";
				echo '<td>';
			//Columnas que son de tipo booleano.						
				if($metadatos->name=="EstadoParticipante" || $metadatos->name=="Encuestado" || $metadatos->name=="Asistido")
				{
				   $checkeado="";
				   if($row[$metadatos->name]!=0)
					$checkeado= "checked=\"checked\"";
				   echo '<input name="checkboxAsistencia2" type="checkbox" id="checkboxAsistencia2" '.$checkeado.' onclick="javascript: return false;" />';
				}
				else
					echo $row[$metadatos->name];
				echo "</td>\n";						
				++$i;
			}
			if(!empty($row["idEncuesta"]) && $row["Encuestado"]==0 && $row["Asistido"]==1)
			{
			$pagResultado='\'../UL/Encuesta/Encuesta_responder.php\'';
			$parametros='\'idEncuesta='.$row["idEncuesta"].'\'+String.fromCharCode(38)+\'idParticipante='.$row["idParticipante"].'\'+String.fromCharCode(38)+\'idEvento='.$row["idEvento"].'\'+String.fromCharCode(38)+\'usuario=\'+document.getElementById(\'texto_filtro\').value';
//Opciones que tendra cada registro del dataGridView
			echo '<td>';
			//Responder Encuesta
			echo '<span style="cursor:pointer;" onclick="javascript:abrirVentana('.$parametros.');">Encuesta</span>';
			echo "</td>\n";					
			echo "\n";
			}
			print '</tr>';
			if($agregar)
				$agregar=false;
			else
				$agregar=true;
			echo "\n";
		}
		print '</table>';
	}
?>
</body>
</html>
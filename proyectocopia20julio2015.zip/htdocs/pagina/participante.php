<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/CITEIN_plantilla_inicio.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../UL/CITEIN/estilos_inicio.css"  />
<link rel="stylesheet" href="../UL/CITEIN/fonts.css" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="../UL/CITEIN/main.js"></script>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
?>
<!-- InstanceBeginEditable name="doctitle" -->
<title>Participante</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<script src="../BLL/ajax.js" language="JavaScript"></script>
<link rel="stylesheet" href="../UL/CITEIN/modal.css" />
<style type="text/css">
.dataGridViewDiv {
	color:#FFF;
	min-width: 960px;
	min-height: 100px;
	border: 1px solid #333;
	margin:10px;
}
.caja {
    
    border-radius: 20px;
    border: 2px solid #3f7f00;
    min-width: 965px;
    min-height: 105px;
     margin:10px;
}
</style>
<?php
$usuario="";
if(isset($_GET["usuario"]))
{
	$usuario=$_GET["usuario"];
}
?>
<!-- InstanceEndEditable -->
</head>

<body>
<div id="wrapper">
    <div id="header"><!-- Encabezado             ------------------------------------------>
      <header class="primary-header group" style="color:#FFF;">
          <div style="float:left; vertical-align:bottom;">
        	<img height="30px;" src="../UL/CITEIN/Universidad.png" alt="UMESQ" style="float:left;" />
            <p style="float:right; margin-top:15px; margin-bottom:0px; font-weight:bold;">CITEIN</p>
          </div>
        <nav class="nav primary-nav" style="margin-top:10px;">
            <a href="../index.php"><i class="icon icon-home"></i> Inicio</a>   /
            <a href="participante.php"><i class="icon icon-accessibility"></i> Participante</a>   /   
            <a href="javascript:login();"><i class="icon icon-enter"></i> Iniciar Sesión</a>
          </nav>
        </header>
    </div>
    <div id="content">
    <!-- Contenido            ------------------------------------------------->
        <div class="modal-container">
			<div id="modal" class="modal"></div>
		</div>
    <!-- InstanceBeginEditable name="Contenido" -->
	<form id="form1" name="form1" method="post" action="">
        <input type="hidden" name="formulario" id="formulario" value="ver info" />
        <input type="hidden" name="paginaFiltro" id="paginaFiltro" value="../UL/Participante/Participante_filtrar_info.php" />
        <input type="hidden" name="paginaFiltro" id="paginaFiltro2" value="../UL/Participante/Participante_filtrar_datos.php" />
        <br  />
        <div align="center">
           <label for="texto_filtro" style="color:#2B4228; font-weight:bold;"><strong>Usuario</strong>: </label>
           <input name="texto_filtro" type="text" id="texto_filtro" maxlength="5" value="<?php echo $usuario;?>"/> 
           <a class="boton-link" href="javascript:BuscarParticipante();"><i class="icon icon-search"></i> Buscar</a>
        </div>
        <br/>
        <div id="detalle" align="center"></div>
        <br  />
        <div align="center">
        <h2 align="center">Listado de actividades del participante</h2>
        </div>
        <div class="caja">
         </br>
            <div id="resultados">
            </div>
        </br>
        </div>
     </form>
     <script>
	 var body = $('body'),
    modal_container = $('.modal-container');
	inicio();
	function inicio()
	{
		var texto=document.getElementById('texto_filtro').value;
		if(texto.length>=5)
			BuscarParticipante();
	}
	function BuscarParticipante()
	{
		/*Filtrar2(panel,pagina,parametros)*/
		var filtro=document.getElementById('texto_filtro').value;
		if(filtro.length>=5)
		{
			Filtrar2("detalle","Participante_filtrar_datos.php","filtro="+filtro);
			Filtrar2("resultados","Participante_filtrar_info.php","filtro="+filtro);
		}
		else{
			alert("Ingrese un usuario válido");
		}
	}
	function abrirVentana(param)
	{
		$(".modal-container").slideDown("slow");
		ProcesarPaginaPostConParametros("../UL/Encuesta/Encuesta_responder.php",param,"modal");
		toggleModal();
	}
    function cerrarVentana()
    {
		$(".modal-container").slideUp("slow");
		toggleModal();
	}
	function toggleModal() {
        body.toggleClass('body-locked');
        modal_container.toggleClass('dp-block');
    }
	function abrir2(param)
	{
		abrirMPost(param+'&bandera=1',"../UL/Login/login.php");
	}
	 </script>
<!-- InstanceEndEditable -->
    </div>
    <div id="footer">
          <label style="color:#999;">CITEIN 2015</label>
          <br/>
          <label style="color:#999; text-align:right;">UNIVERSIDAD MESOAMERICANA</label>
    </div>
</div>
<script>
	function login()
	{
		abrirMPost("bandera=1","../UL/Login/login.php");
	}
</script>
</body>
<!-- InstanceEnd --></html>

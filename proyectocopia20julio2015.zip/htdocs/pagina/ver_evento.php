<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Detalles del evento</title>
<?php
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Servidor.php";
	include $_SERVER['DOCUMENT_ROOT']."/DAL/Consulta.php";
	$consulta1=new Consulta;
?>
</head>

<body id="body2" bgcolor="#F1F1F1">
<div align="right"><span style="cursor:pointer;" onclick="cerrarM();" title="Cerrar">X</span></div>
<?php
if(isset($_GET["evento"]))
{
	$id=$_GET["evento"];
	$consulta1->Evento_ver_detalle($id);
	/* `idEvento`, `Evento`.Nombre AS `Evento`, `DescripcionEvento`, `TipoEvento`.Nombre AS `TipoEvento`, `Fecha`, `HoraInicio`, `HoraFinal`, `GrupoEvento`.Nombre AS `GrupoEvento`, `Personal_idPersonal_Encargado`, `Encuesta_idEncuesta`, `Costo`, `Imagen`, `EstadoEvento*/
	$res=$consulta1->Resultado;
	if(mysql_num_rows($res)<=0)
		echo '<h1 align="center">No se puede mostrar los detalles del evento</h1>';
	while($row=mysql_fetch_assoc($res))
	{
		?>
		<form id="form1" name="form1" method="GET" action="">
		<h1 align="center"><?php echo $row["GrupoEvento"];?></h1>
		<div align="center">
			<figure>
            <?php
			if(empty($row["Imagen"]))
			{
			  echo '<img width="350px" height="350px" src="../imagenes/conferencia2.jpg" />';
			}
			else
			{
			  echo '<img width="350px" height="350px" src="../fotos/'.$row["Imagen"].'" />';
			}
			?>
			</figure>
			<br /><br />
			<h3><?php echo $row["Evento"];?></h3>
			<p align="center"><?php echo $row["DescripcionEvento"]?></p>
			<table width="35%" border="0" cellspacing="5">
			<tr>
			  <td width="50%">Tipo de actividad:</td>
			  <td width="50%"><?php echo $row["TipoEvento"];?></td>
			</tr>
			<tr>
			  <td>Fecha de la actividad:</td>
			  <td><?php echo $row["Fecha"];?></td>
			</tr>
			<tr>
			  <td>Hora de inicio:</td>
			  <td><?php echo $row["HoraInicio"];?></td>
			</tr>
			<tr>
			  <td>Hora final:</td>
			  <td><?php echo $row["HoraFinal"];?></td>
			</tr>
			<tr>
			  <td>Lugar(es):</td>
              <?php
			  $consulta1->Evento_ver_Lugar($id);
			  //`EventoLugar`.Evento_idEvento,  `Lugar`.Nombre as 'Nombre del Lugar',  `Lugar`.Capacidad
			  $res2=$consulta1->Resultado;
			  while($row2=mysql_fetch_assoc($res2))
			  {
				  ?>
                  <td><?php echo $row2["Nombre del Lugar"];?></td>
                  <?php
			  }
			  ?>
			</tr>
			</table>
		</div>
		
		</form>
        <?php
	}
}
else
{
	echo '<h1 align="center">Seleccione un evento para ver los detalles</h1>';
}
?>
</body>
</html>